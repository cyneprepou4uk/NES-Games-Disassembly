0x000010 ---- xx:C000:  .byte $43   ; 
0x000011 ---- xx:C001:  .byte $4F   ; 
0x000012 ---- xx:C002:  .byte $50   ; 
0x000013 ---- xx:C003:  .byte $59   ; 
0x000014 ---- xx:C004:  .byte $52   ; 
0x000015 ---- xx:C005:  .byte $49   ; 
0x000016 ---- xx:C006:  .byte $47   ; 
0x000017 ---- xx:C007:  .byte $48   ; 
0x000018 ---- xx:C008:  .byte $54   ; 
0x000019 ---- xx:C009:  .byte $20   ; 
0x00001A ---- xx:C00A:  .byte $31   ; 
0x00001B ---- xx:C00B:  .byte $39   ; 
0x00001C ---- xx:C00C:  .byte $38   ; 
0x00001D ---- xx:C00D:  .byte $31   ; 
0x00001E ---- xx:C00E:  .byte $20   ; 
0x00001F ---- xx:C00F:  .byte $31   ; 
0x000020 ---- xx:C010:  .byte $39   ; 
0x000021 ---- xx:C011:  .byte $38   ; 
0x000022 ---- xx:C012:  .byte $35   ; 
0x000023 ---- xx:C013:  .byte $20   ; 
0x000024 ---- xx:C014:  .byte $4E   ; 
0x000025 ---- xx:C015:  .byte $41   ; 
0x000026 ---- xx:C016:  .byte $4D   ; 
0x000027 ---- xx:C017:  .byte $43   ; 
0x000028 ---- xx:C018:  .byte $4F   ; 
0x000029 ---- xx:C019:  .byte $20   ; 
0x00002A ---- xx:C01A:  .byte $4C   ; 
0x00002B ---- xx:C01B:  .byte $54   ; 
0x00002C ---- xx:C01C:  .byte $44   ; 
0x00002D ---- xx:C01D:  .byte $2E   ; 
0x00002E ---- xx:C01E:  .byte $0D   ; 
0x00002F ---- xx:C01F:  .byte $0A   ; 
0x000030 ---- xx:C020:  .byte $41   ; 
0x000031 ---- xx:C021:  .byte $4C   ; 
0x000032 ---- xx:C022:  .byte $4C   ; 
0x000033 ---- xx:C023:  .byte $20   ; 
0x000034 ---- xx:C024:  .byte $52   ; 
0x000035 ---- xx:C025:  .byte $49   ; 
0x000036 ---- xx:C026:  .byte $47   ; 
0x000037 ---- xx:C027:  .byte $48   ; 
0x000038 ---- xx:C028:  .byte $54   ; 
0x000039 ---- xx:C029:  .byte $53   ; 
0x00003A ---- xx:C02A:  .byte $20   ; 
0x00003B ---- xx:C02B:  .byte $52   ; 
0x00003C ---- xx:C02C:  .byte $45   ; 
0x00003D ---- xx:C02D:  .byte $53   ; 
0x00003E ---- xx:C02E:  .byte $45   ; 
0x00003F ---- xx:C02F:  .byte $52   ; 
0x000040 ---- xx:C030:  .byte $56   ; 
0x000041 ---- xx:C031:  .byte $45   ; 
0x000042 ---- xx:C032:  .byte $44   ; 
0x000043 ---- xx:C033:  .byte $20   ; 
0x000044 ---- xx:C034:  .byte $20   ; 
0x000045 ---- xx:C035:  .byte $20   ; 
0x000046 ---- xx:C036:  .byte $20   ; 
0x000047 ---- xx:C037:  .byte $20   ; 
0x000048 ---- xx:C038:  .byte $20   ; 
0x000049 ---- xx:C039:  .byte $20   ; 
0x00004A ---- xx:C03A:  .byte $20   ; 
0x00004B ---- xx:C03B:  .byte $20   ; 
0x00004C ---- xx:C03C:  .byte $20   ; 
0x00004D ---- xx:C03D:  .byte $20   ; 
0x00004E ---- xx:C03E:  .byte $0D   ; 
0x00004F ---- xx:C03F:  .byte $0A   ; 
0x000050 ---- 00:C040:  .byte $52   ; 0014F5 001504
0x000051 ---- 00:C041:  .byte $59   ; 0014F5 001504
0x000052 ---- 00:C042:  .byte $4F   ; 0014F5 001504
0x000053 ---- 00:C043:  .byte $55   ; 0014F5 001504
0x000054 ---- 00:C044:  .byte $49   ; 0014F5 001504
0x000055 ---- 00:C045:  .byte $54   ; 0014F5 001504
0x000056 ---- 00:C046:  .byte $49   ; 0014F5 001504
0x000057 ---- 00:C047:  .byte $20   ; 0014F5 001504
0x000058 ---- 00:C048:  .byte $4F   ; 0014F5 001504
0x000059 ---- 00:C049:  .byte $4F   ; 0014F5 001504
0x00005A ---- 00:C04A:  .byte $4B   ; 0014F5 001504
0x00005B ---- 00:C04B:  .byte $55   ; 0014F5 001504
0x00005C ---- 00:C04C:  .byte $42   ; 0014F5 001504
0x00005D ---- 00:C04D:  .byte $4F   ; 0014F5 001504
0x00005E ---- 00:C04E:  .byte $20   ; 0014F5 001504
0x00005F ---- 00:C04F:  .byte $20   ; 0014F5 001504
0x000060 ---- xx:C050:  .byte $54   ; 
0x000061 ---- xx:C051:  .byte $41   ; 
0x000062 ---- xx:C052:  .byte $4B   ; 
0x000063 ---- xx:C053:  .byte $45   ; 
0x000064 ---- xx:C054:  .byte $46   ; 
0x000065 ---- xx:C055:  .byte $55   ; 
0x000066 ---- xx:C056:  .byte $4D   ; 
0x000067 ---- xx:C057:  .byte $49   ; 
0x000068 ---- xx:C058:  .byte $20   ; 
0x000069 ---- xx:C059:  .byte $48   ; 
0x00006A ---- xx:C05A:  .byte $59   ; 
0x00006B ---- xx:C05B:  .byte $4F   ; 
0x00006C ---- xx:C05C:  .byte $55   ; 
0x00006D ---- xx:C05D:  .byte $44   ; 
0x00006E ---- xx:C05E:  .byte $4F   ; 
0x00006F ---- xx:C05F:  .byte $55   ; 
0x000070 ---- xx:C060:  .byte $4A   ; 
0x000071 ---- xx:C061:  .byte $55   ; 
0x000072 ---- xx:C062:  .byte $4E   ; 
0x000073 ---- xx:C063:  .byte $4B   ; 
0x000074 ---- xx:C064:  .byte $4F   ; 
0x000075 ---- xx:C065:  .byte $20   ; 
0x000076 ---- xx:C066:  .byte $4F   ; 
0x000077 ---- xx:C067:  .byte $5A   ; 
0x000078 ---- xx:C068:  .byte $41   ; 
0x000079 ---- xx:C069:  .byte $57   ; 
0x00007A ---- xx:C06A:  .byte $41   ; 
0x00007B ---- xx:C06B:  .byte $20   ; 
0x00007C ---- xx:C06C:  .byte $20   ; 
0x00007D ---- xx:C06D:  .byte $20   ; 
0x00007E ---- xx:C06E:  .byte $20   ; 
0x00007F ---- xx:C06F:  .byte $20   ; 
0x000080 ---- 00:C070:  SEI  ; 
0x000081 ---- 00:C071:  LDA #$10  ; 
0x000083 nz-- 00:C073:  STA $2000  ; $2000
0x000086 nz-- 00:C076:  CLD  ; 
0x000087 nz-- 00:C077:  LDX #$02  ; 
; 2 refs via 00008C 000094
0x000089 ---- 00:C079:  LDA $2002  ; $2002
0x00008C ---- 00:C07C:  BPL $C079  ; 000089
0x00008E N--- 00:C07E:  LDA #$06  ; 
0x000090 nz-- 00:C080:  STA $2001  ; $2001
0x000093 nz-- 00:C083:  DEX  ; 
0x000094 ---- 00:C084:  BNE $C079  ; 000089
0x000096 -Z-- 00:C086:  LDX #$7F  ; 
0x000098 nz-- 00:C088:  TXS  ; 
0x000099 nz-- 00:C089:  JSR $D491  ; 0014A1
; 1 refs via 0014F2
0x00009C -Z-- 00:C08C:  LDA #$00  ; 
0x00009E nZ-- 00:C08E:  STA ram_004F  ; $004F
0x0000A0 nZ-- 00:C090:  STA ram_0050  ; $0050
0x0000A2 nZ-- 00:C092:  JSR $D467  ; 001477
; 2 refs via 0002A2 00147F
0x0000A5 ---- 00:C095:  JSR $D17F  ; 00118F
; 1 refs via 001285
0x0000A8 -Z-- 00:C098:  LDA #$00  ; 
0x0000AA nZ-- 00:C09A:  STA ram_004B  ; $004B
; 1 refs via 0000BB
0x0000AC nZ-- 00:C09C:  JSR $D16A  ; 00117A
; 1 refs via 00118E
0x0000AF Nz-- 00:C09F:  JSR $C7AB  ; 0007BB
; 3 refs via 000166 0007D2 0007D5
0x0000B2 ---- 00:C0A2:  JSR $C9C0  ; 0009D0
; 1 refs via 000A4C
0x0000B5 -Z-- 00:C0A5:  JSR $C3B5  ; 0003C5
; 1 refs via 00042C
0x0000B8 nz-- 00:C0A8:  JSR $C41D  ; 00042D
; 1 refs via 00044E
0x0000BB nZ-- 00:C0AB:  JMP $C09C  ; 0000AC
; 1 refs via 000A92
0x0000BE nz-- 00:C0AE:  LDA ram_004B  ; $004B
0x0000C0 ---- 00:C0B0:  BNE $C0BE  ; 0000CE
0x0000C2 -Z-- 00:C0B2:  JSR $D470  ; 001480
; 1 refs via 00148D
0x0000C5 nz-- 00:C0B5:  JSR $C9B0  ; 0009C0
; 1 refs via 0009CF
0x0000C8 -Z-- 00:C0B8:  JSR $D7B4  ; 0017C4
; 1 refs via 0017DB
0x0000CB -Z-- 00:C0BB:  JSR $D467  ; 001477
; 2 refs via 0000C0 00147F
0x0000CE -z-- 00:C0BE:  JSR $E413  ; 002423
; 1 refs via 00242F
0x0000D1 N--- 00:C0C1:  LDA #$10  ; 
0x0000D3 nz-- 00:C0C3:  STA ram_0090  ; $0090
0x0000D5 nz-- 00:C0C5:  LDA #$18  ; 
0x0000D7 nz-- 00:C0C7:  STA ram_0098  ; $0098
0x0000D9 nz-- 00:C0C9:  LDA #$84  ; 
0x0000DB Nz-- 00:C0CB:  STA ram_00A0  ; $00A0
0x0000DD Nz-- 00:C0CD:  LDA #$00  ; 
0x0000DF nZ-- 00:C0CF:  STA ram_00A8  ; $00A8
0x0000E1 nZ-- 00:C0D1:  STA ram_006E  ; $006E
0x0000E3 nZ-- 00:C0D3:  STA ram_00B0  ; $00B0
0x0000E5 nZ-- 00:C0D5:  STA ram_0081  ; $0081
0x0000E7 nZ-- 00:C0D7:  STA ram_007B  ; $007B
0x0000E9 nZ-- 00:C0D9:  STA ram_005C  ; $005C
0x0000EB nZ-- 00:C0DB:  STA ram_004F  ; $004F
0x0000ED nZ-- 00:C0DD:  STA ram_0050  ; $0050
0x0000EF nZ-- 00:C0DF:  STA ram_006F  ; $006F
0x0000F1 nZ-- 00:C0E1:  STA ram_0070  ; $0070
0x0000F3 nZ-- 00:C0E3:  LDA ram_004B  ; $004B
0x0000F5 ---- 00:C0E5:  BNE $C0EA  ; 0000FA
0x0000F7 -Z-- 00:C0E7:  JSR $CAF5  ; 000B05
; 3 refs via 0000F5 00015D 000B6C
0x0000FA ---- 00:C0EA:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x0000FD -z-- 00:C0ED:  JSR $C6D2  ; 0006E2
; 1 refs via 00072D
0x000100 ---- 00:C0F0:  JSR $C8D0  ; 0008E0
; 1 refs via 000908
0x000103 --C- 00:C0F3:  LDA ram_000B  ; $000B
0x000105 --C- 00:C0F5:  AND #$10  ; 
0x000107 --C- 00:C0F7:  BEQ $C0FC  ; 00010C
0x000109 -zC- 00:C0F9:  JSR $DEA6  ; 001EB6
; 2 refs via 000107 001EC7
0x00010C -Z-- 00:C0FC:  LDA ram_0006  ; $0006
0x00010E ---- 00:C0FE:  AND #$F0  ; 
0x000110 ---- 00:C100:  BNE $C13E  ; 00014E
0x000112 -Z-- 00:C102:  LDA ram_0008  ; $0008
0x000114 ---- 00:C104:  AND #$01  ; 
0x000116 ---- 00:C106:  BEQ $C120  ; 000130
0x000118 -z-- 00:C108:  LDA ram_0081  ; $0081
0x00011A ---- 00:C10A:  BNE $C111  ; 000121
0x00011C -Z-- 00:C10C:  INC ram_0081  ; $0081
0x00011E ---- 00:C10E:  JMP $C144  ; 000154
; 1 refs via 00011A
0x000121 -z-- 00:C111:  INC ram_005C  ; $005C
0x000123 ---- 00:C113:  LDA ram_005C  ; $005C
0x000125 ---- 00:C115:  CMP #$0E  ; 
0x000127 ---- 00:C117:  BNE $C144  ; 000154
0x000129 -Z-- 00:C119:  LDA #$00  ; 
0x00012B nZ-- 00:C11B:  STA ram_005C  ; $005C
0x00012D nZ-- 00:C11D:  JMP $C144  ; 000154
; 1 refs via 000116
0x000130 -Z-- 00:C120:  LDA ram_0008  ; $0008
0x000132 ---- 00:C122:  AND #$02  ; 
0x000134 ---- 00:C124:  BEQ $C13E  ; 00014E
0x000136 -z-- 00:C126:  LDA ram_0081  ; $0081
0x000138 ---- 00:C128:  BNE $C12F  ; 00013F
0x00013A -Z-- 00:C12A:  INC ram_0081  ; $0081
0x00013C ---- 00:C12C:  JMP $C144  ; 000154
; 1 refs via 000138
0x00013F -z-- 00:C12F:  DEC ram_005C  ; $005C
0x000141 ---- 00:C131:  LDA ram_005C  ; $005C
0x000143 ---- 00:C133:  CMP #$FF  ; 
0x000145 ---- 00:C135:  BNE $C144  ; 000154
0x000147 ---- xx:C137:  .byte $A9   ; 
0x000148 ---- xx:C138:  .byte $0D   ; 
0x000149 ---- xx:C139:  .byte $85   ; 
0x00014A ---- xx:C13A:  .byte $5C   ; 
0x00014B ---- xx:C13B:  .byte $4C   ; 
0x00014C ---- xx:C13C:  .byte $44   ; 
0x00014D ---- xx:C13D:  .byte $C1   ; 
; 2 refs via 000110 000134
0x00014E ---- 00:C13E:  LDA ram_0006  ; $0006
0x000150 ---- 00:C140:  AND #$03  ; 
0x000152 ---- 00:C142:  BEQ $C147  ; 000157
; 5 refs via 00011E 000127 00012D 00013C 000145
0x000154 ---- 00:C144:  JSR $C6C6  ; 0006D6
; 2 refs via 000152 0006E1
0x000157 ---- 00:C147:  LDA ram_0008  ; $0008
0x000159 ---- 00:C149:  AND #$08  ; 
0x00015B ---- 00:C14B:  BNE $C150  ; 000160
0x00015D -Z-- 00:C14D:  JMP $C0EA  ; 0000FA
; 1 refs via 00015B
0x000160 -z-- 00:C150:  LDA #$20  ; 
0x000162 nz-- 00:C152:  STA ram_006E  ; $006E
0x000164 nz-- 00:C154:  INC ram_004B  ; $004B
0x000166 ---- 00:C156:  JMP $C0A2  ; 0000B2
; 2 refs via 000290 000A8B
0x000169 -Z-- 00:C159:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x00016C -z-- 00:C15C:  JSR $EA51  ; 002A61
; 1 refs via 002A8D
0x00016F -Z-- 00:C15F:  LDA #$1C  ; 
0x000171 nz-- 00:C161:  STA ram_0005  ; $0005
0x000173 nz-- 00:C163:  LDA #$00  ; 
0x000175 nZ-- 00:C165:  STA ram_004F  ; $004F
0x000177 nZ-- 00:C167:  STA ram_0050  ; $0050
0x000179 nZ-- 00:C169:  STA ram_006D  ; $006D
0x00017B nZ-- 00:C16B:  LDA #$04  ; 
0x00017D nz-- 00:C16D:  STA ram_004D  ; $004D
0x00017F nz-- 00:C16F:  JSR $CC90  ; 000CA0
; 7 refs via 0001AB 0001B1 0001BE 0001C4 0001CC 0001D2 000CC1
0x000182 ---- 00:C172:  JSR $CA91  ; 000AA1
; 1 refs via 000B04
0x000185 nZ-- 00:C175:  LDA ram_004C  ; $004C
0x000187 ---- 00:C177:  BNE $C1C5  ; 0001D5
0x000189 -Z-- 00:C179:  LDA ram_0008  ; $0008
0x00018B ---- 00:C17B:  AND #$08  ; 
0x00018D ---- 00:C17D:  BNE $C1C5  ; 0001D5
0x00018F -Z-- 00:C17F:  LDA ram_0008  ; $0008
0x000191 ---- 00:C181:  AND #$01  ; 
0x000193 ---- 00:C183:  BNE $C191  ; 0001A1
0x000195 -Z-- 00:C185:  LDA ram_0006  ; $0006
0x000197 ---- 00:C187:  AND #$01  ; 
0x000199 ---- 00:C189:  BEQ $C1A4  ; 0001B4
0x00019B -z-- 00:C18B:  LDA ram_000B  ; $000B
0x00019D ---- 00:C18D:  AND #$07  ; 
0x00019F ---- 00:C18F:  BNE $C1A4  ; 0001B4
; 1 refs via 000193
0x0001A1 ---- 00:C191:  LDA #$00  ; 
0x0001A3 nZ-- 00:C193:  STA ram_000B  ; $000B
0x0001A5 nZ-- 00:C195:  INC ram_0085  ; $0085
0x0001A7 ---- 00:C197:  LDA ram_0085  ; $0085
0x0001A9 ---- 00:C199:  CMP #$24  ; 
0x0001AB ---- 00:C19B:  BNE $C172  ; 000182
0x0001AD -Z-- 00:C19D:  LDA #$23  ; 
0x0001AF nz-- 00:C19F:  STA ram_0085  ; $0085
0x0001B1 nz-- 00:C1A1:  JMP $C172  ; 000182
; 2 refs via 000199 00019F
0x0001B4 ---- 00:C1A4:  LDA ram_0008  ; $0008
0x0001B6 ---- 00:C1A6:  AND #$02  ; 
0x0001B8 ---- 00:C1A8:  BNE $C1B6  ; 0001C6
0x0001BA -Z-- 00:C1AA:  LDA ram_0006  ; $0006
0x0001BC ---- 00:C1AC:  AND #$02  ; 
0x0001BE ---- 00:C1AE:  BEQ $C172  ; 000182
0x0001C0 -z-- 00:C1B0:  LDA ram_000B  ; $000B
0x0001C2 ---- 00:C1B2:  AND #$07  ; 
0x0001C4 ---- 00:C1B4:  BNE $C172  ; 000182
; 1 refs via 0001B8
0x0001C6 -z-- 00:C1B6:  LDA #$00  ; 
0x0001C8 nZ-- 00:C1B8:  STA ram_000B  ; $000B
0x0001CA nZ-- 00:C1BA:  DEC ram_0085  ; $0085
0x0001CC ---- 00:C1BC:  BNE $C172  ; 000182
0x0001CE -Z-- 00:C1BE:  LDA #$01  ; 
0x0001D0 nz-- 00:C1C0:  STA ram_0085  ; $0085
0x0001D2 nz-- 00:C1C2:  JMP $C172  ; 000182
; 2 refs via 000187 00018D
0x0001D5 -z-- 00:C1C5:  LDA #$01  ; 
0x0001D7 nz-- 00:C1C7:  STA ram_0301  ; $0301
0x0001DA nz-- 00:C1CA:  STA ram_0302  ; $0302
0x0001DD nz-- 00:C1CD:  STA ram_0303  ; $0303
0x0001E0 nz-- 00:C1D0:  LDA ram_004B  ; $004B
0x0001E2 ---- 00:C1D2:  BNE $C1E2  ; 0001F2
0x0001E4 -Z-- 00:C1D4:  JSR $C9B0  ; 0009C0
; 1 refs via 0009CF
0x0001E7 -Z-- 00:C1D7:  LDA ram_0085  ; $0085
0x0001E9 ---- 00:C1D9:  JSR $F000  ; 003010
; 1 refs via 003089
0x0001EC -Z-- 00:C1DC:  JSR $CAF5  ; 000B05
; 1 refs via 000B6C
0x0001EF ---- 00:C1DF:  JMP $C1E5  ; 0001F5
; 1 refs via 0001E2
0x0001F2 -z-- 00:C1E2:  JSR $CB5D  ; 000B6D
; 2 refs via 0001EF 000BAD
0x0001F5 ---- 00:C1E5:  LDA #$00  ; 
0x0001F7 nZ-- 00:C1E7:  STA ram_000C  ; $000C
0x0001F9 nZ-- 00:C1E9:  JSR $CC27  ; 000C37
; 1 refs via 000C6B
0x0001FC -Z-- 00:C1EC:  JSR $CCB2  ; 000CC2
; 1 refs via 000CE3
0x0001FF -Z-- 00:C1EF:  LDA #$00  ; 
0x000201 nZ-- 00:C1F1:  STA ram_004D  ; $004D
0x000203 nZ-- 00:C1F3:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x000206 -z-- 00:C1F6:  JSR $C331  ; 000341
; 2 refs via 000231 0003C4
0x000209 ---- 00:C1F9:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x00020C -z-- 00:C1FC:  LDA ram_006D  ; $006D
0x00020E ---- 00:C1FE:  BNE $C203  ; 000213
0x000210 -Z-- 00:C200:  JSR $C2E6  ; 0002F6
; 8 refs via 00020E 00032C 002A04 002A0A 002A16 002A26 002A4D 002A58
0x000213 ---- 00:C203:  JSR $E23B  ; 00224B
; 1 refs via 00228B
0x000216 ---- 00:C206:  JSR $E0D8  ; 0020E8
; 1 refs via 0020F5
0x000219 N--- 00:C209:  JSR $DEA6  ; 001EB6
; 1 refs via 001EC7
0x00021C ---- 00:C20C:  LDA ram_0008  ; $0008
0x00021E ---- 00:C20E:  AND #$08  ; 
0x000220 ---- 00:C210:  BEQ $C21B  ; 00022B
0x000222 -z-- 00:C212:  LDA #$01  ; 
0x000224 nz-- 00:C214:  EOR ram_006D  ; $006D
0x000226 ---- 00:C216:  STA ram_006D  ; $006D
0x000228 ---- 00:C218:  STA ram_0300  ; $0300
; 1 refs via 000220
0x00022B ---- 00:C21B:  JSR $C8F9  ; 000909
; 1 refs via 000956
0x00022E ---- 00:C21E:  JSR $C728  ; 000738 000765
; 3 refs via 000761 000764 0007BA
0x000231 ---- 00:C221:  BEQ $C1F9  ; 000209
0x000233 -z-- 00:C223:  LDA #$00  ; 
0x000235 nZ-- 00:C225:  STA ram_000A  ; $000A
0x000237 nZ-- 00:C227:  STA ram_000B  ; $000B
0x000239 nZ-- 00:C229:  STA ram_0311  ; $0311
0x00023C nZ-- 00:C22C:  STA ram_0312  ; $0312
0x00023F nZ-- 00:C22F:  LDA ram_0108  ; $0108
0x000242 ---- 00:C232:  BEQ $C238  ; 000248
0x000244 -z-- 00:C234:  LDA #$FE  ; 
0x000246 Nz-- 00:C236:  STA ram_000A  ; $000A
; 2 refs via 000242 000261
0x000248 ---- 00:C238:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x00024B -z-- 00:C23B:  JSR $C2A2  ; 0002B2
; 1 refs via 0002C2
0x00024E -Z-- 00:C23E:  JSR $C2E6  ; 0002F6
; 3 refs via 00032C 002A26 002A4D
0x000251 ---- 00:C241:  JSR $E23B  ; 00224B
; 1 refs via 00228B
0x000254 ---- 00:C244:  JSR $DEA6  ; 001EB6
; 1 refs via 001EC7
0x000257 -Z-- 00:C247:  JSR $E0D8  ; 0020E8
; 1 refs via 0020F5
0x00025A N--- 00:C24A:  JSR $C31D  ; 00032D
; 2 refs via 00033B 000340
0x00025D -z-- 00:C24D:  LDA ram_000A  ; $000A
0x00025F ---- 00:C24F:  CMP #$02  ; 
0x000261 ---- 00:C251:  BNE $C238  ; 000248
0x000263 -Z-- 00:C253:  JSR $EA51  ; 002A61
; 1 refs via 002A8D
0x000266 -Z-- 00:C256:  JSR $CCD4  ; 000CE4
; 1 refs via 000F06
0x000269 nZ-- 00:C259:  INC ram_0085  ; $0085
0x00026B ---- 00:C25B:  LDA ram_0085  ; $0085
0x00026D ---- 00:C25D:  CMP #$47  ; 
0x00026F ---- 00:C25F:  BNE $C269  ; 000279
0x000271 -Z-- 00:C261:  LDA #$01  ; 
0x000273 nz-- 00:C263:  STA ram_0085  ; $0085
0x000275 nz-- 00:C265:  LDA #$00  ; 
0x000277 nZ-- 00:C267:  STA ram_0046  ; $0046
; 1 refs via 00026F
0x000279 ---- 00:C269:  LDA ram_0085  ; $0085
0x00027B ---- 00:C26B:  CMP #$24  ; 
0x00027D ---- 00:C26D:  BNE $C273  ; 000283
0x00027F -Z-- 00:C26F:  LDA #$01  ; 
0x000281 nz-- 00:C271:  STA ram_0046  ; $0046
; 1 refs via 00027D
0x000283 -z-- 00:C273:  LDA ram_0051  ; $0051
0x000285 ---- 00:C275:  CLC  ; 
0x000286 --c- 00:C276:  ADC ram_0052  ; $0052
0x000288 ---- 00:C278:  BEQ $C283  ; 000293
0x00028A -z-- 00:C27A:  LDA ram_0068  ; $0068
0x00028C ---- 00:C27C:  CMP #$80  ; 
0x00028E ---- 00:C27E:  BNE $C283  ; 000293
0x000290 -Z-- 00:C280:  JMP $C159  ; 000169
; 2 refs via 000288 00028E
0x000293 ---- 00:C283:  JSR $C5D9  ; 0005E9
; 1 refs via 000651
0x000296 -Z-- 00:C286:  JSR $D97D  ; 00198D
; 1 refs via 0019CD
0x000299 -z-- 00:C289:  TYA  ; 
0x00029A ---- 00:C28A:  BEQ $C292  ; 0002A2
0x00029C -z-- 00:C28C:  JSR $C44B  ; 00045B
; 1 refs via 0004AB
0x00029F nZ-- 00:C28F:  JSR $C295  ; 0002A5
; 2 refs via 00029A 0002B1
0x0002A2 ---- 00:C292:  JMP $C095  ; 0000A5
; 1 refs via 00029F
0x0002A5 nZ-- 00:C295:  JSR $D470  ; 001480
; 1 refs via 00148D
0x0002A8 nz-- 00:C298:  JSR $D47E  ; 00148E
; 1 refs via 0014A0
0x0002AB -Z-- 00:C29B:  JSR $D7B4  ; 0017C4
; 1 refs via 0017DB
0x0002AE -Z-- 00:C29E:  JSR $D467  ; 001477
; 1 refs via 00147F
0x0002B1 Nz-- 00:C2A1:  RTS  ; 0002A2
; 1 refs via 00024B
0x0002B2 -z-- 00:C2A2:  LDA ram_0068  ; $0068
0x0002B4 ---- 00:C2A4:  CMP #$80  ; 
0x0002B6 ---- 00:C2A6:  BEQ $C2B2  ; 0002C2
0x0002B8 -z-- 00:C2A8:  LDA #$00  ; 
0x0002BA nZ-- 00:C2AA:  STA ram_0006  ; $0006
0x0002BC nZ-- 00:C2AC:  STA ram_0007  ; $0007
0x0002BE nZ-- 00:C2AE:  STA ram_0008  ; $0008
0x0002C0 nZ-- 00:C2B0:  STA ram_0009  ; $0009
; 1 refs via 0002B6
0x0002C2 -Z-- 00:C2B2:  RTS  ; 00024E
; 1 refs via 000A88
0x0002C3 nz-- 00:C2B3:  LDX #$15  ; 
0x0002C5 nz-- 00:C2B5:  JSR $D9FE  ; 001A0E
; 1 refs via 001A22
0x0002C8 Nz-- 00:C2B8:  LDX #$1D  ; 
0x0002CA nz-- 00:C2BA:  JSR $D9FE  ; 001A0E
; 2 refs via 0003CD 001A22
0x0002CD ---- 00:C2BD:  LDA #$00  ; 
0x0002CF nZ-- 00:C2BF:  STA ram_0101  ; $0101
0x0002D2 nZ-- 00:C2C2:  STA ram_0102  ; $0102
0x0002D5 nZ-- 00:C2C5:  LDA #$00  ; 
0x0002D7 nZ-- 00:C2C7:  STA ram_0066  ; $0066
0x0002D9 nZ-- 00:C2C9:  STA ram_0067  ; $0067
0x0002DB nZ-- 00:C2CB:  STA ram_004C  ; $004C
0x0002DD nZ-- 00:C2CD:  LDA #$03  ; 
0x0002DF nz-- 00:C2CF:  STA ram_0051  ; $0051
0x0002E1 nz-- 00:C2D1:  STA ram_0052  ; $0052
0x0002E3 nz-- 00:C2D3:  STA ram_006A  ; $006A
0x0002E5 nz-- 00:C2D5:  LDA ram_0083  ; $0083
0x0002E7 ---- 00:C2D7:  BNE $C2DD  ; 0002ED
0x0002E9 -Z-- 00:C2D9:  LDA #$00  ; 
0x0002EB nZ-- 00:C2DB:  STA ram_0052  ; $0052
; 1 refs via 0002E7
0x0002ED ---- 00:C2DD:  LDA #$01  ; 
0x0002EF nz-- 00:C2DF:  STA ram_0085  ; $0085
0x0002F1 nz-- 00:C2E1:  LDA #$00  ; 
0x0002F3 nZ-- 00:C2E3:  STA ram_0046  ; $0046
0x0002F5 nZ-- 00:C2E5:  RTS  ; 0003D0 000A8B
; 3 refs via 000210 00024E 000439
0x0002F6 ---- 00:C2E6:  JSR $E181  ; 002191
; 1 refs via 002202
0x0002F9 N--- 00:C2E9:  JSR $DB75  ; 001B85
; 1 refs via 001C00
0x0002FC ---- 00:C2EC:  JSR $DBF1  ; 001C01
; 1 refs via 001C4C
0x0002FF N--- 00:C2EF:  JSR $E1FA  ; 00220A
; 1 refs via 002243
0x000302 N--- 00:C2F2:  JSR $E02E  ; 00203E
; 1 refs via 00204B
0x000305 N--- 00:C2F5:  JSR $E2A9  ; 0022B9
; 5 refs via 001C00 002315 002337 002345 00234D
0x000308 ---- 00:C2F8:  JSR $E27C  ; 00228C
; 1 refs via 0022B8
0x00030B N--- 00:C2FB:  JSR $E122  ; 002132
; 1 refs via 002171
0x00030E N--- 00:C2FE:  JSR $E162  ; 002172
; 1 refs via 002190
0x000311 ---- 00:C301:  JSR $DB48  ; 001B58
; 3 refs via 001B5E 001B7B 001B84
0x000314 ---- 00:C304:  JSR $E604  ; 002614
; 1 refs via 0026A2
0x000317 N--- 00:C307:  JSR $E910  ; 002920
; 1 refs via 002981
0x00031A N--- 00:C30A:  JSR $E70C  ; 00271C
; 1 refs via 0028C9
0x00031D N--- 00:C30D:  JSR $E972  ; 002982
; 1 refs via 0029F1
0x000320 ---- 00:C310:  JSR $C972  ; 000982
; 1 refs via 0009BF
0x000323 ---- 00:C313:  JSR $DB0B  ; 001B1B
; 2 refs via 001B33 001B47
0x000326 n--- 00:C316:  JSR $C7C8  ; 0007D8
; 1 refs via 00083F
0x000329 nZ-- 00:C319:  JSR $C31D  ; 00032D
; 2 refs via 00033B 000340
0x00032C -z-- 00:C31C:  RTS  ; 000213 000251 00043C
; 2 refs via 00025A 000329
0x00032D ---- 00:C31D:  LDA ram_000B  ; $000B
0x00032F ---- 00:C31F:  AND #$3F  ; 
0x000331 ---- 00:C321:  BEQ $C32C  ; 00033C
0x000333 -z-- 00:C323:  CMP #$20  ; 
0x000335 ---- 00:C325:  BNE $C330  ; 000340
0x000337 -Z-- 00:C327:  LDA #$01  ; 
0x000339 nz-- 00:C329:  STA ram_004D  ; $004D
0x00033B nz-- 00:C32B:  RTS  ; 00025D 00032C
; 1 refs via 000331
0x00033C -Z-- 00:C32C:  LDA #$02  ; 
0x00033E nz-- 00:C32E:  STA ram_004D  ; $004D
; 1 refs via 000335
0x000340 -z-- 00:C330:  RTS  ; 00025D 00032C
; 2 refs via 000206 00041F
0x000341 -z-- 00:C331:  JSR $E409  ; 002419
; 1 refs via 002422
0x000344 N--- 00:C334:  JSR $E413  ; 002423
; 1 refs via 00242F
0x000347 N--- 00:C337:  LDA #$F0  ; 
0x000349 Nz-- 00:C339:  STA ram_0106  ; $0106
0x00034C Nz-- 00:C33C:  LDA #$00  ; 
0x00034E nZ-- 00:C33E:  STA ram_0108  ; $0108
0x000351 nZ-- 00:C341:  LDA ram_0051  ; $0051
0x000353 ---- 00:C343:  BEQ $C34A  ; 00035A
0x000355 -z-- 00:C345:  LDX #$00  ; 
0x000357 nZ-- 00:C347:  JSR $E363  ; 002373
; 2 refs via 000353 0023C7
0x00035A ---- 00:C34A:  LDA ram_0052  ; $0052
0x00035C ---- 00:C34C:  BEQ $C353  ; 000363
0x00035E -z-- 00:C34E:  LDX #$01  ; 
0x000360 nz-- 00:C350:  JSR $E363  ; 002373
; 2 refs via 00035C 0023C7
0x000363 ---- 00:C353:  LDA #$14  ; 
0x000365 nz-- 00:C355:  STA ram_007F  ; $007F
0x000367 nz-- 00:C357:  STA ram_0080  ; $0080
0x000369 nz-- 00:C359:  LDA #$00  ; 
0x00036B nZ-- 00:C35B:  STA ram_008F  ; $008F
0x00036D nZ-- 00:C35D:  STA ram_000A  ; $000A
0x00036F nZ-- 00:C35F:  STA ram_004B  ; $004B
0x000371 nZ-- 00:C361:  STA ram_0045  ; $0045
0x000373 nZ-- 00:C363:  STA ram_006F  ; $006F
0x000375 nZ-- 00:C365:  STA ram_0070  ; $0070
0x000377 nZ-- 00:C367:  STA ram_0089  ; $0089
0x000379 nZ-- 00:C369:  STA ram_008A  ; $008A
0x00037B nZ-- 00:C36B:  STA ram_0082  ; $0082
0x00037D nZ-- 00:C36D:  STA ram_0086  ; $0086
0x00037F nZ-- 00:C36F:  STA ram_0100  ; $0100
0x000382 nZ-- 00:C372:  STA ram_006A  ; $006A
0x000384 nZ-- 00:C374:  JSR $C71E  ; 00072E
; 1 refs via 000737
0x000387 N--- 00:C377:  JSR $C8C0  ; 0008D0
; 1 refs via 0008DF
0x00038A N--- 00:C37A:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x00038D -z-- 00:C37D:  JSR $C830  ; 000840
; 1 refs via 000868
0x000390 -Z-- 00:C380:  JSR $C859  ; 000869
; 1 refs via 0008A3
0x000393 nZ-- 00:C383:  JSR $E42B  ; 00243B
; 1 refs via 002460
0x000396 ---- 00:C386:  LDA #$80  ; 
0x000398 Nz-- 00:C388:  STA ram_0068  ; $0068
0x00039A Nz-- 00:C38A:  LDA #$01  ; 
0x00039C nz-- 00:C38C:  STA ram_0312  ; $0312
0x00039F nz-- 00:C38F:  STA ram_004C  ; $004C
0x0003A1 nz-- 00:C391:  LDA ram_0046  ; $0046
0x0003A3 ---- 00:C393:  CMP #$01  ; 
0x0003A5 ---- 00:C395:  BNE $C39C  ; 0003AC
0x0003A7 -Z-- 00:C397:  LDA #$23  ; 
0x0003A9 nz-- 00:C399:  JMP $C39E  ; 0003AE
; 1 refs via 0003A5
0x0003AC -z-- 00:C39C:  LDA ram_0085  ; $0085
; 1 refs via 0003A9
0x0003AE ---- 00:C39E:  ASL  ; 
0x0003AF ---- 00:C39F:  ASL  ; 
0x0003B0 ---- 00:C3A0:  STA ram_0000  ; $0000
0x0003B2 ---- 00:C3A2:  LDA #$BE  ; 
0x0003B4 Nz-- 00:C3A4:  SEC  ; 
0x0003B5 NzC- 00:C3A5:  SBC ram_0000  ; $0000
0x0003B7 ---- 00:C3A7:  STA ram_0084  ; $0084
0x0003B9 ---- 00:C3A9:  LDA ram_0083  ; $0083
0x0003BB ---- 00:C3AB:  BEQ $C3B4  ; 0003C4
0x0003BD -z-- 00:C3AD:  LDA ram_0084  ; $0084
0x0003BF ---- 00:C3AF:  SEC  ; 
0x0003C0 --C- 00:C3B0:  SBC #$14  ; 
0x0003C2 ---- 00:C3B2:  STA ram_0084  ; $0084
; 1 refs via 0003BB
0x0003C4 ---- 00:C3B4:  RTS  ; 000209 000422
; 1 refs via 0000B5
0x0003C5 -Z-- 00:C3B5:  LDA #$01  ; 
0x0003C7 nz-- 00:C3B7:  STA ram_006D  ; $006D
0x0003C9 nz-- 00:C3B9:  LDA #$00  ; 
0x0003CB nZ-- 00:C3BB:  STA ram_004D  ; $004D
0x0003CD nZ-- 00:C3BD:  JSR $C2BD  ; 0002CD
; 1 refs via 0002F5
0x0003D0 nZ-- 00:C3C0:  LDA #$03  ; 
0x0003D2 nz-- 00:C3C2:  STA ram_0052  ; $0052
0x0003D4 nz-- 00:C3C4:  LDA #$00  ; 
0x0003D6 nZ-- 00:C3C6:  STA ram_004F  ; $004F
0x0003D8 nZ-- 00:C3C8:  STA ram_0050  ; $0050
0x0003DA nZ-- 00:C3CA:  STA ram_000A  ; $000A
0x0003DC nZ-- 00:C3CC:  STA ram_000B  ; $000B
0x0003DE nZ-- 00:C3CE:  JSR $C9B0  ; 0009C0
; 1 refs via 0009CF
0x0003E1 -Z-- 00:C3D1:  LDA #$FF  ; 
0x0003E3 Nz-- 00:C3D3:  STA ram_0085  ; $0085
0x0003E5 Nz-- 00:C3D5:  JSR $F000  ; 003010
; 1 refs via 003089
0x0003E8 -Z-- 00:C3D8:  LDA #$1E  ; 
0x0003EA nz-- 00:C3DA:  STA ram_0085  ; $0085
0x0003EC nz-- 00:C3DC:  LDA #$02  ; 
0x0003EE nz-- 00:C3DE:  STA ram_0046  ; $0046
0x0003F0 nz-- 00:C3E0:  JSR $D470  ; 001480
; 1 refs via 00148D
0x0003F3 nz-- 00:C3E3:  LDX #$1A  ; 
0x0003F5 nz-- 00:C3E5:  STX ram_0056  ; $0056
0x0003F7 nz-- 00:C3E7:  LDY #$46  ; 
0x0003F9 nz-- 00:C3E9:  STY ram_0057  ; $0057
0x0003FB nz-- 00:C3EB:  LDA #$D2  ; 
0x0003FD Nz-- 00:C3ED:  STA ram_0014  ; $0014
0x0003FF Nz-- 00:C3EF:  LDA #$99  ; 
0x000401 Nz-- 00:C3F1:  STA ram_0013  ; $0013
0x000403 Nz-- 00:C3F3:  JSR $D8D2  ; 0018E2
; 1 refs via 001905
0x000406 -Z-- 00:C3F6:  LDX #$3C  ; 
0x000408 nz-- 00:C3F8:  STX ram_0056  ; $0056
0x00040A nz-- 00:C3FA:  LDY #$78  ; 
0x00040C nz-- 00:C3FC:  STY ram_0057  ; $0057
0x00040E nz-- 00:C3FE:  LDA #$D2  ; 
0x000410 Nz-- 00:C400:  STA ram_0014  ; $0014
0x000412 Nz-- 00:C402:  LDA #$A0  ; 
0x000414 Nz-- 00:C404:  STA ram_0013  ; $0013
0x000416 Nz-- 00:C406:  JSR $D8D2  ; 0018E2
; 1 refs via 001905
0x000419 -Z-- 00:C409:  JSR $D7B4  ; 0017C4
; 1 refs via 0017DB
0x00041C -Z-- 00:C40C:  JSR $D467  ; 001477
; 1 refs via 00147F
0x00041F Nz-- 00:C40F:  JSR $C331  ; 000341
; 1 refs via 0003C4
0x000422 ---- 00:C412:  JSR $CAF5  ; 000B05
; 1 refs via 000B6C
0x000425 ---- 00:C415:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x000428 -z-- 00:C418:  LDA #$05  ; 
0x00042A nz-- 00:C41A:  STA ram_006C  ; $006C
0x00042C nz-- 00:C41C:  RTS  ; 0000B8
; 2 refs via 0000B8 000448
0x00042D n--- 00:C41D:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x000430 -z-- 00:C420:  LDA ram_0008  ; $0008
0x000432 ---- 00:C422:  AND #$0C  ; 
0x000434 ---- 00:C424:  BNE $C43F  ; 00044F
0x000436 -Z-- 00:C426:  JSR $C642  ; 000652
; 1 refs via 0006D1
0x000439 N--- 00:C429:  JSR $C2E6  ; 0002F6
; 4 refs via 00032C 002A04 002A26 002A58
0x00043C ---- 00:C42C:  JSR $E23B  ; 00224B
; 1 refs via 00228B
0x00043F ---- 00:C42F:  JSR $DEA6  ; 001EB6
; 1 refs via 001EC7
0x000442 -Z-- 00:C432:  JSR $E0D8  ; 0020E8
; 1 refs via 0020F5
0x000445 N--- 00:C435:  JSR $C728  ; 000738
; 2 refs via 000761 000764
0x000448 n--- 00:C438:  BEQ $C41D  ; 00042D
0x00044A nz-- 00:C43A:  LDA #$00  ; 
0x00044C nZ-- 00:C43C:  STA ram_000C  ; $000C
0x00044E nZ-- 00:C43E:  RTS  ; 0000BB
0x00044F ---- 00:C43F:  .byte $68   ; 000434
0x000450 ---- xx:C440:  .byte $68   ; 
0x000451 ---- xx:C441:  .byte $A9   ; 
0x000452 ---- xx:C442:  .byte $00   ; 
0x000453 ---- xx:C443:  .byte $85   ; 
0x000454 ---- xx:C444:  .byte $0C   ; 
0x000455 ---- xx:C445:  .byte $20   ; 
0x000456 ---- xx:C446:  .byte $6A   ; 
0x000457 ---- xx:C447:  .byte $D1   ; 
0x000458 ---- xx:C448:  .byte $4C   ; 
0x000459 ---- xx:C449:  .byte $A2   ; 
0x00045A ---- xx:C44A:  .byte $C0   ; 
; 1 refs via 00029C
0x00045B -z-- 00:C44B:  JSR $D470  ; 001480
; 1 refs via 00148D
0x00045E nz-- 00:C44E:  LDA #$1C  ; 
0x000460 nz-- 00:C450:  STA ram_0005  ; $0005
0x000462 nz-- 00:C452:  LDA #$00  ; 
0x000464 nZ-- 00:C454:  STA ram_004F  ; $004F
0x000466 nZ-- 00:C456:  STA ram_0050  ; $0050
0x000468 nZ-- 00:C458:  JSR $D47E  ; 00148E
; 1 refs via 0014A0
0x00046B -Z-- 00:C45B:  LDX #$10  ; 
0x00046D nz-- 00:C45D:  STX ram_0056  ; $0056
0x00046F nz-- 00:C45F:  LDY #$32  ; 
0x000471 nz-- 00:C461:  STY ram_0057  ; $0057
0x000473 nz-- 00:C463:  LDA #$D2  ; 
0x000475 Nz-- 00:C465:  STA ram_0014  ; $0014
0x000477 Nz-- 00:C467:  LDA #$B5  ; 
0x000479 Nz-- 00:C469:  STA ram_0013  ; $0013
0x00047B Nz-- 00:C46B:  JSR $D8D2  ; 0018E2
; 1 refs via 001905
0x00047E -Z-- 00:C46E:  JSR $D951  ; 001961
; 1 refs via 00198C
0x000481 nZ-- 00:C471:  JSR $D7B4  ; 0017C4
; 1 refs via 0017DB
0x000484 -Z-- 00:C474:  JSR $D467  ; 001477
; 1 refs via 00147F
0x000487 Nz-- 00:C477:  LDA #$00  ; 
0x000489 nZ-- 00:C479:  STA ram_000A  ; $000A
0x00048B nZ-- 00:C47B:  LDA #$01  ; 
0x00048D nz-- 00:C47D:  STA ram_0315  ; $0315
0x000490 nz-- 00:C480:  STA ram_0316  ; $0316
0x000493 nz-- 00:C483:  STA ram_0317  ; $0317
; 1 refs via 0004A5
0x000496 -z-- 00:C486:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x000499 -z-- 00:C489:  LDA ram_000B  ; $000B
0x00049B ---- 00:C48B:  AND #$03  ; 
0x00049D ---- 00:C48D:  CLC  ; 
0x00049E --c- 00:C48E:  ADC #$05  ; 
0x0004A0 ---- 00:C490:  STA ram_004D  ; $004D
0x0004A2 ---- 00:C492:  LDA ram_0315  ; $0315
0x0004A5 ---- 00:C495:  BNE $C486  ; 000496
0x0004A7 -Z-- 00:C497:  LDA #$00  ; 
0x0004A9 nZ-- 00:C499:  STA ram_004D  ; $004D
0x0004AB nZ-- 00:C49B:  RTS  ; 00029F
; 1 refs via 000A5F
0x0004AC -Z-- 00:C49C:  JSR $D470  ; 001480
; 1 refs via 00148D
0x0004AF nz-- 00:C49F:  LDA #$1C  ; 
0x0004B1 nz-- 00:C4A1:  STA ram_0005  ; $0005
0x0004B3 nz-- 00:C4A3:  LDA #$00  ; 
0x0004B5 nZ-- 00:C4A5:  STA ram_004F  ; $004F
0x0004B7 nZ-- 00:C4A7:  STA ram_0050  ; $0050
0x0004B9 nZ-- 00:C4A9:  JSR $D47E  ; 00148E
; 1 refs via 0014A0
0x0004BC -Z-- 00:C4AC:  JSR $D7B4  ; 0017C4
; 1 refs via 0017DB
0x0004BF -Z-- 00:C4AF:  JSR $D467  ; 001477
; 1 refs via 00147F
0x0004C2 Nz-- 00:C4B2:  JSR $C567  ; 000577
; 1 refs via 000584
0x0004C5 -Z-- 00:C4B5:  JSR $C567  ; 000577
; 1 refs via 000584
0x0004C8 -Z-- 00:C4B8:  LDA #$D3  ; 
0x0004CA Nz-- 00:C4BA:  STA ram_0012  ; $0012
0x0004CC Nz-- 00:C4BC:  LDA #$0F  ; 
0x0004CE nz-- 00:C4BE:  STA ram_0011  ; $0011
0x0004D0 nz-- 00:C4C0:  LDX #$08  ; 
0x0004D2 nz-- 00:C4C2:  LDY #$08  ; 
0x0004D4 nz-- 00:C4C4:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x0004D7 -Z-- 00:C4C7:  JSR $C567  ; 000577
; 1 refs via 000584
0x0004DA -Z-- 00:C4CA:  LDA #$D2  ; 
0x0004DC Nz-- 00:C4CC:  STA ram_0012  ; $0012
0x0004DE Nz-- 00:C4CE:  LDA #$84  ; 
0x0004E0 Nz-- 00:C4D0:  STA ram_0011  ; $0011
0x0004E2 Nz-- 00:C4D2:  LDX #$08  ; 
0x0004E4 nz-- 00:C4D4:  LDY #$0A  ; 
0x0004E6 nz-- 00:C4D6:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x0004E9 -Z-- 00:C4D9:  JSR $C567  ; 000577
; 1 refs via 000584
0x0004EC -Z-- 00:C4DC:  LDA #$D3  ; 
0x0004EE Nz-- 00:C4DE:  STA ram_0012  ; $0012
0x0004F0 Nz-- 00:C4E0:  LDA #$34  ; 
0x0004F2 nz-- 00:C4E2:  STA ram_0011  ; $0011
0x0004F4 nz-- 00:C4E4:  LDX #$08  ; 
0x0004F6 nz-- 00:C4E6:  LDY #$0C  ; 
0x0004F8 nz-- 00:C4E8:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x0004FB -Z-- 00:C4EB:  JSR $C567  ; 000577
; 1 refs via 000584
0x0004FE -Z-- 00:C4EE:  LDA #$D3  ; 
0x000500 Nz-- 00:C4F0:  STA ram_0012  ; $0012
0x000502 Nz-- 00:C4F2:  LDA #$4D  ; 
0x000504 nz-- 00:C4F4:  STA ram_0011  ; $0011
0x000506 nz-- 00:C4F6:  LDX #$08  ; 
0x000508 nz-- 00:C4F8:  LDY #$0E  ; 
0x00050A nz-- 00:C4FA:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x00050D -Z-- 00:C4FD:  JSR $C567  ; 000577
; 1 refs via 000584
0x000510 -Z-- 00:C500:  LDA #$D3  ; 
0x000512 Nz-- 00:C502:  STA ram_0012  ; $0012
0x000514 Nz-- 00:C504:  LDA #$3F  ; 
0x000516 nz-- 00:C506:  STA ram_0011  ; $0011
0x000518 nz-- 00:C508:  LDX #$08  ; 
0x00051A nz-- 00:C50A:  LDY #$10  ; 
0x00051C nz-- 00:C50C:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x00051F -Z-- 00:C50F:  JSR $C567  ; 000577
; 1 refs via 000584
0x000522 -Z-- 00:C512:  LDA #$D3  ; 
0x000524 Nz-- 00:C514:  STA ram_0012  ; $0012
0x000526 Nz-- 00:C516:  LDA #$3F  ; 
0x000528 nz-- 00:C518:  STA ram_0011  ; $0011
0x00052A nz-- 00:C51A:  LDX #$09  ; 
0x00052C nz-- 00:C51C:  LDY #$10  ; 
0x00052E nz-- 00:C51E:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000531 -Z-- 00:C521:  JSR $C567  ; 000577
; 1 refs via 000584
0x000534 -Z-- 00:C524:  LDA #$D3  ; 
0x000536 Nz-- 00:C526:  STA ram_0012  ; $0012
0x000538 Nz-- 00:C528:  LDA #$3F  ; 
0x00053A nz-- 00:C52A:  STA ram_0011  ; $0011
0x00053C nz-- 00:C52C:  LDX #$0A  ; 
0x00053E nz-- 00:C52E:  LDY #$10  ; 
0x000540 nz-- 00:C530:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000543 -Z-- 00:C533:  JSR $C567  ; 000577
; 1 refs via 000584
0x000546 -Z-- 00:C536:  LDA #$D3  ; 
0x000548 Nz-- 00:C538:  STA ram_0012  ; $0012
0x00054A Nz-- 00:C53A:  LDA #$3F  ; 
0x00054C nz-- 00:C53C:  STA ram_0011  ; $0011
0x00054E nz-- 00:C53E:  LDX #$0B  ; 
0x000550 nz-- 00:C540:  LDY #$10  ; 
0x000552 nz-- 00:C542:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000555 -Z-- 00:C545:  JSR $C567  ; 000577
; 1 refs via 000584
0x000558 -Z-- 00:C548:  LDA #$D3  ; 
0x00055A Nz-- 00:C54A:  STA ram_0012  ; $0012
0x00055C Nz-- 00:C54C:  LDA #$3F  ; 
0x00055E nz-- 00:C54E:  STA ram_0011  ; $0011
0x000560 nz-- 00:C550:  LDX #$0C  ; 
0x000562 nz-- 00:C552:  LDY #$10  ; 
0x000564 nz-- 00:C554:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000567 -Z-- 00:C557:  JSR $C575  ; 000585
; 1 refs via 0005BF
0x00056A -Z-- 00:C55A:  JSR $D470  ; 001480
; 1 refs via 00148D
0x00056D nz-- 00:C55D:  JSR $C9B0  ; 0009C0
; 1 refs via 0009CF
0x000570 -Z-- 00:C560:  JSR $D7B4  ; 0017C4
; 1 refs via 0017DB
0x000573 -Z-- 00:C563:  JSR $D467  ; 001477
; 1 refs via 00147F
0x000576 Nz-- 00:C566:  RTS  ; 000A62
; 10 refs via 0004C2 0004C5 0004D7 0004E9 0004FB 00050D 00051F 000531 000543 000555
0x000577 ---- 00:C567:  LDA #$00  ; 
0x000579 nZ-- 00:C569:  STA ram_000B  ; $000B
; 1 refs via 000582
0x00057B ---- 00:C56B:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x00057E -z-- 00:C56E:  LDA ram_000B  ; $000B
0x000580 ---- 00:C570:  AND #$3F  ; 
0x000582 ---- 00:C572:  BNE $C56B  ; 00057B
0x000584 -Z-- 00:C574:  RTS  ; 0004C5 0004C8 0004DA 0004EC 0004FE 000510 000522 000534 000546 000558
; 1 refs via 000567
0x000585 -Z-- 00:C575:  LDA #$78  ; 
0x000587 nz-- 00:C577:  STA ram_0056  ; $0056
0x000589 nz-- 00:C579:  LDA #$1E  ; 
0x00058B nz-- 00:C57B:  STA ram_0057  ; $0057
0x00058D nz-- 00:C57D:  LDA #$00  ; 
0x00058F nZ-- 00:C57F:  STA ram_005A  ; $005A
; 1 refs via 0005A3
0x000591 ---- 00:C581:  JSR $C5B0  ; 0005C0
; 1 refs via 0005E8
0x000594 ---- 00:C584:  JSR $C5B0  ; 0005C0
; 1 refs via 0005E8
0x000597 ---- 00:C587:  JSR $C5B0  ; 0005C0
; 1 refs via 0005E8
0x00059A ---- 00:C58A:  JSR $C5B0  ; 0005C0
; 1 refs via 0005E8
0x00059D ---- 00:C58D:  INC ram_005A  ; $005A
0x00059F ---- 00:C58F:  LDA ram_005A  ; $005A
0x0005A1 ---- 00:C591:  CMP #$07  ; 
0x0005A3 ---- 00:C593:  BNE $C581  ; 000591
; 1 refs via 0005BD
0x0005A5 ---- 00:C595:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x0005A8 -z-- 00:C598:  INC ram_0057  ; $0057
0x0005AA ---- 00:C59A:  LDA #$9D  ; 
0x0005AC Nz-- 00:C59C:  STA ram_0053  ; $0053
0x0005AE Nz-- 00:C59E:  LDA #$01  ; 
0x0005B0 nz-- 00:C5A0:  STA ram_0004  ; $0004
0x0005B2 nz-- 00:C5A2:  LDX ram_0056  ; $0056
0x0005B4 ---- 00:C5A4:  LDY ram_0057  ; $0057
0x0005B6 ---- 00:C5A6:  JSR $DA7B  ; 001A8B
; 1 refs via 001AA2
0x0005B9 ---- 00:C5A9:  LDA ram_0057  ; $0057
0x0005BB ---- 00:C5AB:  CMP #$F8  ; 
0x0005BD ---- 00:C5AD:  BNE $C595  ; 0005A5
0x0005BF -Z-- 00:C5AF:  RTS  ; 00056A
; 4 refs via 000591 000594 000597 00059A
0x0005C0 ---- 00:C5B0:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x0005C3 -z-- 00:C5B3:  LDA #$03  ; 
0x0005C5 nz-- 00:C5B5:  STA ram_0004  ; $0004
0x0005C7 nz-- 00:C5B7:  LDA #$03  ; 
0x0005C9 nz-- 00:C5B9:  SEC  ; 
0x0005CA nzC- 00:C5BA:  SBC ram_005A  ; $005A
0x0005CC ---- 00:C5BC:  BPL $C5C3  ; 0005D3
0x0005CE N--- 00:C5BE:  EOR #$FF  ; 
0x0005D0 ---- 00:C5C0:  CLC  ; 
0x0005D1 --c- 00:C5C1:  ADC #$01  ; 
; 1 refs via 0005CC
0x0005D3 ---- 00:C5C3:  STA ram_0000  ; $0000
0x0005D5 ---- 00:C5C5:  LDA #$03  ; 
0x0005D7 nz-- 00:C5C7:  SEC  ; 
0x0005D8 nzC- 00:C5C8:  SBC ram_0000  ; $0000
0x0005DA ---- 00:C5CA:  ASL  ; 
0x0005DB ---- 00:C5CB:  ASL  ; 
0x0005DC ---- 00:C5CC:  CLC  ; 
0x0005DD --c- 00:C5CD:  ADC #$A1  ; 
0x0005DF ---- 00:C5CF:  STA ram_0053  ; $0053
0x0005E1 ---- 00:C5D1:  LDX ram_0056  ; $0056
0x0005E3 ---- 00:C5D3:  LDY ram_0057  ; $0057
0x0005E5 ---- 00:C5D5:  JSR $DA7B  ; 001A8B
; 1 refs via 001AA2
0x0005E8 ---- 00:C5D8:  RTS  ; 000594 000597 00059A 00059D
; 1 refs via 000293
0x0005E9 ---- 00:C5D9:  JSR $D470  ; 001480
; 1 refs via 00148D
0x0005EC nz-- 00:C5DC:  LDA #$1C  ; 
0x0005EE nz-- 00:C5DE:  STA ram_0005  ; $0005
0x0005F0 nz-- 00:C5E0:  LDA #$00  ; 
0x0005F2 nZ-- 00:C5E2:  STA ram_004F  ; $004F
0x0005F4 nZ-- 00:C5E4:  STA ram_0050  ; $0050
0x0005F6 nZ-- 00:C5E6:  JSR $D47E  ; 00148E
; 1 refs via 0014A0
0x0005F9 -Z-- 00:C5E9:  LDX #$3C  ; 
0x0005FB nz-- 00:C5EB:  STX ram_0056  ; $0056
0x0005FD nz-- 00:C5ED:  LDY #$46  ; 
0x0005FF nz-- 00:C5EF:  STY ram_0057  ; $0057
0x000601 nz-- 00:C5F1:  LDA #$D3  ; 
0x000603 Nz-- 00:C5F3:  STA ram_0014  ; $0014
0x000605 Nz-- 00:C5F5:  LDA #$43  ; 
0x000607 nz-- 00:C5F7:  STA ram_0013  ; $0013
0x000609 nz-- 00:C5F9:  JSR $D8D2  ; 0018E2
; 1 refs via 001905
0x00060C -Z-- 00:C5FC:  LDX #$3C  ; 
0x00060E nz-- 00:C5FE:  STX ram_0056  ; $0056
0x000610 nz-- 00:C600:  LDY #$78  ; 
0x000612 nz-- 00:C602:  STY ram_0057  ; $0057
0x000614 nz-- 00:C604:  LDA #$D3  ; 
0x000616 Nz-- 00:C606:  STA ram_0014  ; $0014
0x000618 Nz-- 00:C608:  LDA #$48  ; 
0x00061A nz-- 00:C60A:  STA ram_0013  ; $0013
0x00061C nz-- 00:C60C:  JSR $D8D2  ; 0018E2
; 1 refs via 001905
0x00061F -Z-- 00:C60F:  JSR $D7B4  ; 0017C4
; 1 refs via 0017DB
0x000622 -Z-- 00:C612:  JSR $D467  ; 001477
; 1 refs via 00147F
0x000625 Nz-- 00:C615:  LDA #$00  ; 
0x000627 nZ-- 00:C617:  STA ram_000A  ; $000A
0x000629 nZ-- 00:C619:  LDA #$01  ; 
0x00062B nz-- 00:C61B:  STA ram_0318  ; $0318
0x00062E nz-- 00:C61E:  STA ram_0319  ; $0319
0x000631 nz-- 00:C621:  STA ram_031A  ; $031A
; 1 refs via 000640
0x000634 -z-- 00:C624:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x000637 -z-- 00:C627:  LDA ram_0008  ; $0008
0x000639 ---- 00:C629:  AND #$0C  ; 
0x00063B ---- 00:C62B:  BNE $C632  ; 000642
0x00063D -Z-- 00:C62D:  LDA ram_0318  ; $0318
0x000640 ---- 00:C630:  BNE $C624  ; 000634
; 1 refs via 00063B
0x000642 ---- 00:C632:  JSR $D470  ; 001480
; 1 refs via 00148D
0x000645 nz-- 00:C635:  JSR $D47E  ; 00148E
; 1 refs via 0014A0
0x000648 -Z-- 00:C638:  JSR $D7B4  ; 0017C4
; 1 refs via 0017DB
0x00064B -Z-- 00:C63B:  JSR $D467  ; 001477
; 1 refs via 00147F
0x00064E Nz-- 00:C63E:  JSR $EA51  ; 002A61
; 1 refs via 002A8D
0x000651 -Z-- 00:C641:  RTS  ; 000296
; 1 refs via 000436
0x000652 -Z-- 00:C642:  LDA #$01  ; 
0x000654 nz-- 00:C644:  STA ram_005A  ; $005A
; 1 refs via 0006CF
0x000656 n--- 00:C646:  LDX ram_005A  ; $005A
0x000658 ---- 00:C648:  LDA ram_0086  ; $0086
0x00065A ---- 00:C64A:  BEQ $C65E  ; 00066E
0x00065C -z-- 00:C64C:  LDA ram_0062  ; $0062
0x00065E ---- 00:C64E:  BNE $C65E  ; 00066E
0x000660 -Z-- 00:C650:  LDA ram_0086  ; $0086
0x000662 ---- 00:C652:  STA ram_0071  ; $0071
0x000664 ---- 00:C654:  LDA ram_0087  ; $0087
0x000666 ---- 00:C656:  STA ram_0072  ; $0072
0x000668 ---- 00:C658:  JSR $DDA2  ; 001DB2
; 1 refs via 001DF9
0x00066B ---- 00:C65B:  JMP $C6A5  ; 0006B5
; 2 refs via 00065A 00065E
0x00066E ---- 00:C65E:  LDA ram_00A2,X  ; $00A2 $00A3
0x000670 ---- 00:C660:  BPL $C674  ; 000684
0x000672 N--- 00:C662:  CMP #$E0  ; 
0x000674 ---- 00:C664:  BCS $C674  ; 000684
0x000676 --c- 00:C666:  LDA ram_0092,X  ; $0092 $0093
0x000678 --c- 00:C668:  STA ram_0071  ; $0071
0x00067A --c- 00:C66A:  LDA ram_009A,X  ; $009A $009B
0x00067C --c- 00:C66C:  STA ram_0072  ; $0072
0x00067E --c- 00:C66E:  JSR $DDA2  ; 001DB2
; 1 refs via 001DF9
0x000681 ---- 00:C671:  JMP $C6A5  ; 0006B5
; 2 refs via 000670 000674
0x000684 ---- 00:C674:  LDA ram_00A4,X  ; $00A4 $00A5
0x000686 ---- 00:C676:  BPL $C68A  ; 00069A
0x000688 N--- 00:C678:  CMP #$E0  ; 
0x00068A ---- 00:C67A:  BCS $C68A  ; 00069A
0x00068C --c- 00:C67C:  LDA ram_0094,X  ; $0094 $0095
0x00068E --c- 00:C67E:  STA ram_0071  ; $0071
0x000690 --c- 00:C680:  LDA ram_009C,X  ; $009C $009D
0x000692 --c- 00:C682:  STA ram_0072  ; $0072
0x000694 --c- 00:C684:  JSR $DDA2  ; 001DB2
; 1 refs via 001DF9
0x000697 ---- 00:C687:  JMP $C6A5  ; 0006B5
; 2 refs via 000686 00068A
0x00069A ---- 00:C68A:  LDA ram_00A3,X  ; $00A3 $00A4
0x00069C ---- 00:C68C:  BPL $C6A0  ; 0006B0
0x00069E N--- 00:C68E:  CMP #$E0  ; 
0x0006A0 ---- 00:C690:  BCS $C6A0  ; 0006B0
0x0006A2 --c- 00:C692:  LDA ram_0093,X  ; $0094
0x0006A4 --c- 00:C694:  STA ram_0071  ; $0071
0x0006A6 --c- 00:C696:  LDA ram_009B,X  ; $009C
0x0006A8 --c- 00:C698:  STA ram_0072  ; $0072
0x0006AA --c- 00:C69A:  JSR $DDA2  ; 001DB2
; 1 refs via 001DF9
0x0006AD ---- 00:C69D:  JMP $C6A5  ; 0006B5
; 2 refs via 00069C 0006A0
0x0006B0 ---- 00:C6A0:  LDA #$00  ; 
0x0006B2 nZ-- 00:C6A2:  JMP $C6AB  ; 0006BB
; 4 refs via 00066B 000681 000697 0006AD
0x0006B5 ---- 00:C6A5:  AND #$03  ; 
0x0006B7 ---- 00:C6A7:  TAY  ; 
0x0006B8 ---- 00:C6A8:  LDA $C6C2,Y  ; 0006D2 0006D3 0006D4 0006D5
; 1 refs via 0006B2
0x0006BB ---- 00:C6AB:  LDX ram_005A  ; $005A
0x0006BD ---- 00:C6AD:  STA ram_0006,X  ; $0006 $0007
0x0006BF ---- 00:C6AF:  STA ram_0008,X  ; $0008 $0009
0x0006C1 ---- 00:C6B1:  LDA ram_0098,X  ; $0098 $0099
0x0006C3 ---- 00:C6B3:  CMP #$C8  ; 
0x0006C5 ---- 00:C6B5:  BCC $C6BD  ; 0006CD
0x0006C7 --C- 00:C6B7:  LDA ram_0008,X  ; $0008 $0009
0x0006C9 --C- 00:C6B9:  AND #$F0  ; 
0x0006CB --C- 00:C6BB:  STA ram_0008,X  ; $0008 $0009
; 1 refs via 0006C5
0x0006CD ---- 00:C6BD:  DEC ram_005A  ; $005A
0x0006CF ---- 00:C6BF:  BPL $C646  ; 000656
0x0006D1 N--- 00:C6C1:  RTS  ; 000439
0x0006D2 ---- 00:C6C2:  .byte $13   ; 0006B8
0x0006D3 ---- 00:C6C3:  .byte $43   ; 0006B8
0x0006D4 ---- 00:C6C4:  .byte $23   ; 0006B8
0x0006D5 ---- 00:C6C5:  .byte $83   ; 0006B8
; 1 refs via 000154
0x0006D6 ---- 00:C6C6:  LDA ram_005C  ; $005C
0x0006D8 ---- 00:C6C8:  AND #$0F  ; 
0x0006DA ---- 00:C6CA:  LDX ram_0090  ; $0090
0x0006DC ---- 00:C6CC:  LDY ram_0098  ; $0098
0x0006DE ---- 00:C6CE:  JSR $D80B  ; 00181B
; 1 refs via 00186D
0x0006E1 ---- 00:C6D1:  RTS  ; 000157
; 1 refs via 0000FD
0x0006E2 -z-- 00:C6D2:  LDA ram_0006  ; $0006
0x0006E4 ---- 00:C6D4:  AND #$F0  ; 
0x0006E6 ---- 00:C6D6:  BEQ $C6E1  ; 0006F1
0x0006E8 -z-- 00:C6D8:  INC ram_007B  ; $007B
0x0006EA ---- 00:C6DA:  LDA #$00  ; 
0x0006EC nZ-- 00:C6DC:  STA ram_0081  ; $0081
0x0006EE nZ-- 00:C6DE:  JMP $C6E5  ; 0006F5
; 1 refs via 0006E6
0x0006F1 -Z-- 00:C6E1:  LDA #$00  ; 
0x0006F3 nZ-- 00:C6E3:  STA ram_007B  ; $007B
; 1 refs via 0006EE
0x0006F5 nZ-- 00:C6E5:  LDA ram_007B  ; $007B
0x0006F7 ---- 00:C6E7:  CMP #$14  ; 
0x0006F9 ---- 00:C6E9:  BEQ $C6FB  ; 00070B
0x0006FB -z-- 00:C6EB:  LDA ram_0008  ; $0008
0x0006FD ---- 00:C6ED:  AND #$F0  ; 
0x0006FF ---- 00:C6EF:  BEQ $C71D  ; 00072D
0x000701 -z-- 00:C6F1:  LDA ram_0008  ; $0008
0x000703 ---- 00:C6F3:  JSR $E451  ; 002461
; 4 refs via 002466 00246C 002472 002478
0x000706 n-C- 00:C6F6:  BMI $C71D  ; 00072D
0x000708 n-C- 00:C6F8:  JMP $C704  ; 000714
; 1 refs via 0006F9
0x00070B -Z-- 00:C6FB:  LDA #$0F  ; 
0x00070D nz-- 00:C6FD:  STA ram_007B  ; $007B
0x00070F nz-- 00:C6FF:  LDA ram_0006  ; $0006
0x000711 ---- 00:C701:  JSR $E451  ; 002461
; 4 refs via 000708 002466 00246C 002472
0x000714 n-C- 00:C704:  TAY  ; 
0x000715 --C- 00:C705:  LDA $D3D5,Y  ; 0013E5 0013E6 0013E7 0013E8
0x000718 --C- 00:C708:  ASL  ; 
0x000719 ---- 00:C709:  ASL  ; 
0x00071A ---- 00:C70A:  ASL  ; 
0x00071B ---- 00:C70B:  ASL  ; 
0x00071C ---- 00:C70C:  CLC  ; 
0x00071D --c- 00:C70D:  ADC ram_0090  ; $0090
0x00071F ---- 00:C70F:  STA ram_0090  ; $0090
0x000721 ---- 00:C711:  LDA $D3D9,Y  ; 0013E9 0013EA 0013EB 0013EC
0x000724 ---- 00:C714:  ASL  ; 
0x000725 ---- 00:C715:  ASL  ; 
0x000726 ---- 00:C716:  ASL  ; 
0x000727 ---- 00:C717:  ASL  ; 
0x000728 ---- 00:C718:  CLC  ; 
0x000729 --c- 00:C719:  ADC ram_0098  ; $0098
0x00072B ---- 00:C71B:  STA ram_0098  ; $0098
; 2 refs via 0006FF 000706
0x00072D ---- 00:C71D:  RTS  ; 000100
; 1 refs via 000384
0x00072E nZ-- 00:C71E:  LDX #$07  ; 
0x000730 nz-- 00:C720:  LDA #$00  ; 
; 1 refs via 000735
0x000732 n--- 00:C722:  STA ram_0073,X  ; $0073 $0074 $0075 $0076 $0077 $0078 $0079 $007A
0x000734 n--- 00:C724:  DEX  ; 
0x000735 ---- 00:C725:  BPL $C722  ; 000732
0x000737 N--- 00:C727:  RTS  ; 000387
; 2 refs via 00022E 000445
0x000738 ---- 00:C728:  LDA ram_0068  ; $0068
0x00073A ---- 00:C72A:  BEQ $C737  ; 000747
0x00073C -z-- 00:C72C:  LDA ram_0080  ; $0080
0x00073E ---- 00:C72E:  BEQ $C74F  ; 00075F
0x000740 -z-- 00:C730:  LDA ram_0051  ; $0051
0x000742 ---- 00:C732:  CLC  ; 
0x000743 --c- 00:C733:  ADC ram_0052  ; $0052
0x000745 ---- 00:C735:  BNE $C752  ; 000762
; 1 refs via 00073A
0x000747 -Z-- 00:C737:  LDA #$70  ; 
0x000749 nz-- 00:C739:  STA ram_0105  ; $0105
0x00074C nz-- 00:C73C:  LDA #$F0  ; 
0x00074E Nz-- 00:C73E:  STA ram_0106  ; $0106
0x000751 Nz-- 00:C741:  LDA #$00  ; 
0x000753 nZ-- 00:C743:  STA ram_0107  ; $0107
0x000756 nZ-- 00:C746:  LDA #$11  ; 
0x000758 nz-- 00:C748:  STA ram_0108  ; $0108
0x00075B nz-- 00:C74B:  LDA #$00  ; 
0x00075D nZ-- 00:C74D:  STA ram_000B  ; $000B
; 1 refs via 00073E
0x00075F -Z-- 00:C74F:  LDA #$01  ; 
0x000761 nz-- 00:C751:  RTS  ; 000231 000448
; 1 refs via 000745
0x000762 ---- 00:C752:  LDA #$00  ; 
0x000764 nZ-- 00:C754:  RTS  ; 000231 000448
; 1 refs via 00022E
0x000765 ---- 00:C755:  LDA ram_0109  ; $0109
0x000768 ---- 00:C758:  JSR $D9E1  ; 0019F1
; 2 refs via 001A08 001A0D
0x00076B ---- 00:C75B:  LDA #$30  ; 
0x00076D nz-- 00:C75D:  STA ram_0060  ; $0060
0x00076F nz-- 00:C75F:  LDA #$00  ; 
0x000771 nZ-- 00:C761:  STA ram_0012  ; $0012
0x000773 nZ-- 00:C763:  LDA #$39  ; 
0x000775 nz-- 00:C765:  STA ram_0011  ; $0011
0x000777 nz-- 00:C767:  LDX #$09  ; 
0x000779 nz-- 00:C769:  LDY #$02  ; 
0x00077B nz-- 00:C76B:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x00077E -Z-- 00:C76E:  LDX ram_0109  ; $0109
0x000781 ---- 00:C771:  LDA ram_0000,X  ; $0000 $0001 $0002 $0003 $0004 $0005 $0006 $0007 $0008 $0009 $000A $000B $000C $000D $000E $000F $0010 $0011 $0012 $0013 $0014 $0015 $0016 $0017 $0018 $0019 $001A $001B $001C $001D $001E $001F $0020 $0021 $0022 $0023 $0024 $0025 $0026 $0027 $0028 $0029 $002A $002B $002C $002D $002E $002F $0030 $0031 $0032 $0033 $0034 $0035 $0036 $0037 $0038 $0039 $003A $003B $003C $003D $003E $003F $0040 $0041 $0042 $0043 $0044 $0045 $0046 $0047 $0048 $0049 $004A $004B $004C $004D $004E $004F $0050 $0051 $0052 $0053 $0054 $0055 $0056 $0057 $0058 $0059 $005A $005B $005C $005D $005E $005F $0060 $0061 $0062 $0063 $0064 $0065 $0066 $0067 $0068 $0069 $006A $006B $006C $006D $006E $006F $0070 $0071 $0072 $0073 $0074 $0075 $0076 $0077 $0078 $0079 $007A $007B $007C $007D $007E $007F $0080 $0081 $0082 $0083 $0084 $0085 $0086 $0087 $0088 $0089 $008A $008B $008C $008D $008E $008F $0090 $0091 $0092 $0093 $0094 $0095 $0096 $0097 $0098 $0099 $009A $009B $009C $009D $009E $009F $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7 $00A8 $00A9 $00AA $00AB $00AC $00AD $00AE $00AF $00B0 $00B1 $00B2 $00B3 $00B4 $00B5 $00B6 $00B7 $00B8 $00B9 $00BA $00BB $00BC $00BD $00BE $00BF $00C0 $00C1 $00C2 $00C3 $00C4 $00C5 $00C6 $00C7 $00C8 $00C9 $00CA $00CB $00CC $00CD $00CE $00CF $00D0 $00D1 $00D2 $00D3 $00D4 $00D5 $00D6 $00D7 $00D8 $00D9 $00DA $00DB $00DC $00DD $00DE $00DF $00E0 $00E1 $00E2 $00E3 $00E4 $00E5 $00E6 $00E7 $00E8 $00E9 $00EA $00EB $00EC $00ED $00EE $00EF $00F0 $00F1 $00F2 $00F3 $00F4 $00F5 $00F6 $00F7 $00F8 $00F9 $00FA $00FB $00FC $00FD $00FE $00FF
0x000783 ---- 00:C773:  JSR $D9E1  ; 0019F1
; 2 refs via 001A08 001A0D
0x000786 ---- 00:C776:  LDA #$00  ; 
0x000788 nZ-- 00:C778:  STA ram_0012  ; $0012
0x00078A nZ-- 00:C77A:  LDA #$39  ; 
0x00078C nz-- 00:C77C:  STA ram_0011  ; $0011
0x00078E nz-- 00:C77E:  LDX #$0D  ; 
0x000790 nz-- 00:C780:  LDY #$02  ; 
0x000792 nz-- 00:C782:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x000795 -Z-- 00:C785:  LDA #$00  ; 
0x000797 nZ-- 00:C787:  STA ram_0060  ; $0060
0x000799 nZ-- 00:C789:  LDA ram_0008  ; $0008
0x00079B ---- 00:C78B:  AND #$04  ; 
0x00079D ---- 00:C78D:  BEQ $C792  ; 0007A2
0x00079F -z-- 00:C78F:  INC ram_0109  ; $0109
; 1 refs via 00079D
0x0007A2 ---- 00:C792:  LDA ram_0008  ; $0008
0x0007A4 ---- 00:C794:  AND #$02  ; 
0x0007A6 ---- 00:C796:  BEQ $C79B  ; 0007AB
0x0007A8 -z-- 00:C798:  DEC ram_0109  ; $0109
; 1 refs via 0007A6
0x0007AB ---- 00:C79B:  LDA ram_0008  ; $0008
0x0007AD ---- 00:C79D:  AND #$01  ; 
0x0007AF ---- 00:C79F:  BEQ $C7AA  ; 0007BA
0x0007B1 -z-- 00:C7A1:  LDA ram_0109  ; $0109
0x0007B4 ---- 00:C7A4:  CLC  ; 
0x0007B5 --c- 00:C7A5:  ADC #$10  ; 
0x0007B7 ---- 00:C7A7:  STA ram_0109  ; $0109
; 1 refs via 0007AF
0x0007BA ---- 00:C7AA:  RTS  ; 000231
; 1 refs via 0000AF
0x0007BB Nz-- 00:C7AB:  LDA #$00  ; 
0x0007BD nZ-- 00:C7AD:  STA ram_004F  ; $004F
0x0007BF nZ-- 00:C7AF:  STA ram_0050  ; $0050
; 1 refs via 0007D0
0x0007C1 ---- 00:C7B1:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x0007C4 -z-- 00:C7B4:  INC ram_004F  ; $004F
0x0007C6 ---- 00:C7B6:  LDA ram_0008  ; $0008
0x0007C8 ---- 00:C7B8:  AND #$0C  ; 
0x0007CA ---- 00:C7BA:  BNE $C7C3  ; 0007D3
0x0007CC -Z-- 00:C7BC:  LDA ram_004F  ; $004F
0x0007CE ---- 00:C7BE:  CMP #$F0  ; 
0x0007D0 ---- 00:C7C0:  BNE $C7B1  ; 0007C1
0x0007D2 -Z-- 00:C7C2:  RTS  ; 0000B2
; 1 refs via 0007CA
0x0007D3 -z-- 00:C7C3:  PLA  ; 
0x0007D4 ---- 00:C7C4:  PLA  ; 
0x0007D5 ---- 00:C7C5:  JMP $C0A2  ; 0000B2
; 1 refs via 000326
0x0007D8 n--- 00:C7C8:  LDA #$01  ; 
0x0007DA nz-- 00:C7CA:  STA ram_005A  ; $005A
0x0007DC nz-- 00:C7CC:  STA ram_006B  ; $006B
0x0007DE nz-- 00:C7CE:  LDA #$6E  ; 
0x0007E0 nz-- 00:C7D0:  STA ram_0060  ; $0060
0x0007E2 nz-- 00:C7D2:  LDA #$D3  ; 
0x0007E4 Nz-- 00:C7D4:  STA ram_0012  ; $0012
0x0007E6 Nz-- 00:C7D6:  LDA #$41  ; 
0x0007E8 nz-- 00:C7D8:  STA ram_0011  ; $0011
0x0007EA nz-- 00:C7DA:  LDX #$1D  ; 
0x0007EC nz-- 00:C7DC:  LDY #$12  ; 
0x0007EE nz-- 00:C7DE:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x0007F1 -Z-- 00:C7E1:  LDA ram_0046  ; $0046
0x0007F3 ---- 00:C7E3:  CMP #$02  ; 
0x0007F5 ---- 00:C7E5:  BEQ $C7F2  ; 000802
0x0007F7 -z-- 00:C7E7:  LDA ram_0083  ; $0083
0x0007F9 ---- 00:C7E9:  BNE $C7F2  ; 000802
0x0007FB -Z-- 00:C7EB:  LDA #$00  ; 
0x0007FD nZ-- 00:C7ED:  STA ram_005A  ; $005A
0x0007FF nZ-- 00:C7EF:  JMP $C801  ; 000811
; 2 refs via 0007F5 0007F9
0x000802 ---- 00:C7F2:  LDA #$D3  ; 
0x000804 Nz-- 00:C7F4:  STA ram_0012  ; $0012
0x000806 Nz-- 00:C7F6:  LDA #$41  ; 
0x000808 nz-- 00:C7F8:  STA ram_0011  ; $0011
0x00080A nz-- 00:C7FA:  LDX #$1D  ; 
0x00080C nz-- 00:C7FC:  LDY #$15  ; 
0x00080E nz-- 00:C7FE:  JSR $D6B3  ; 0016C3
; 3 refs via 0007FF 000837 0016EC
0x000811 ---- 00:C801:  LDX ram_005A  ; $005A
0x000813 ---- 00:C803:  LDA ram_0051,X  ; $0051 $0052
0x000815 ---- 00:C805:  SEC  ; 
0x000816 --C- 00:C806:  SBC #$01  ; 
0x000818 ---- 00:C808:  BPL $C80C  ; 00081C
0x00081A N--- 00:C80A:  LDA #$00  ; 
; 1 refs via 000818
0x00081C n--- 00:C80C:  JSR $DA13  ; 001A23
; 1 refs via 001A3A
0x00081F --c- 00:C80F:  LDY #$36  ; 
0x000821 nzc- 00:C811:  LDX #$19  ; 
0x000823 nzc- 00:C813:  JSR $D934  ; 001944
; 1 refs via 001960
0x000826 nZ-- 00:C816:  LDA ram_005A  ; $005A
0x000828 ---- 00:C818:  STA ram_0000  ; $0000
0x00082A ---- 00:C81A:  ASL  ; 
0x00082B ---- 00:C81B:  CLC  ; 
0x00082C --c- 00:C81C:  ADC ram_0000  ; $0000
0x00082E ---- 00:C81E:  CLC  ; 
0x00082F --c- 00:C81F:  ADC #$12  ; 
0x000831 ---- 00:C821:  TAY  ; 
0x000832 ---- 00:C822:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x000835 -Z-- 00:C825:  DEC ram_005A  ; $005A
0x000837 ---- 00:C827:  BPL $C801  ; 000811
0x000839 N--- 00:C829:  LDA #$00  ; 
0x00083B nZ-- 00:C82B:  STA ram_0060  ; $0060
0x00083D nZ-- 00:C82D:  STA ram_006B  ; $006B
0x00083F nZ-- 00:C82F:  RTS  ; 000329
; 1 refs via 00038D
0x000840 -z-- 00:C830:  LDA #$D2  ; 
0x000842 Nz-- 00:C832:  STA ram_0012  ; $0012
0x000844 Nz-- 00:C834:  LDA #$AB  ; 
0x000846 Nz-- 00:C836:  STA ram_0011  ; $0011
0x000848 Nz-- 00:C838:  LDX #$1D  ; 
0x00084A nz-- 00:C83A:  LDY #$11  ; 
0x00084C nz-- 00:C83C:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x00084F -Z-- 00:C83F:  LDA ram_0046  ; $0046
0x000851 ---- 00:C841:  CMP #$02  ; 
0x000853 ---- 00:C843:  BEQ $C849  ; 000859
0x000855 -z-- 00:C845:  LDA ram_0083  ; $0083
0x000857 ---- 00:C847:  BEQ $C858  ; 000868
; 1 refs via 000853
0x000859 ---- 00:C849:  LDA #$D2  ; 
0x00085B Nz-- 00:C84B:  STA ram_0012  ; $0012
0x00085D Nz-- 00:C84D:  LDA #$AE  ; 
0x00085F Nz-- 00:C84F:  STA ram_0011  ; $0011
0x000861 Nz-- 00:C851:  LDX #$1D  ; 
0x000863 nz-- 00:C853:  LDY #$14  ; 
0x000865 nz-- 00:C855:  JSR $D6B3  ; 0016C3
; 2 refs via 000857 0016EC
0x000868 -Z-- 00:C858:  RTS  ; 000390
; 1 refs via 000390
0x000869 -Z-- 00:C859:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x00086C -z-- 00:C85C:  LDA #$D3  ; 
0x00086E Nz-- 00:C85E:  STA ram_0012  ; $0012
0x000870 Nz-- 00:C860:  LDA #$65  ; 
0x000872 nz-- 00:C862:  STA ram_0011  ; $0011
0x000874 nz-- 00:C864:  LDX #$1D  ; 
0x000876 nz-- 00:C866:  LDY #$17  ; 
0x000878 nz-- 00:C868:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x00087B -Z-- 00:C86B:  LDA #$D3  ; 
0x00087D Nz-- 00:C86D:  STA ram_0012  ; $0012
0x00087F Nz-- 00:C86F:  LDA #$68  ; 
0x000881 nz-- 00:C871:  STA ram_0011  ; $0011
0x000883 nz-- 00:C873:  LDX #$1D  ; 
0x000885 nz-- 00:C875:  LDY #$18  ; 
0x000887 nz-- 00:C877:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x00088A -Z-- 00:C87A:  LDA #$6E  ; 
0x00088C nz-- 00:C87C:  STA ram_0060  ; $0060
0x00088E nz-- 00:C87E:  LDA ram_0085  ; $0085
0x000890 ---- 00:C880:  JSR $DA13  ; 001A23
; 1 refs via 001A3A
0x000893 --c- 00:C883:  LDY #$36  ; 
0x000895 nzc- 00:C885:  LDX #$19  ; 
0x000897 nzc- 00:C887:  JSR $D934  ; 001944
; 1 refs via 001960
0x00089A nZ-- 00:C88A:  LDY #$19  ; 
0x00089C nz-- 00:C88C:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x00089F -Z-- 00:C88F:  LDA #$00  ; 
0x0008A1 nZ-- 00:C891:  STA ram_0060  ; $0060
0x0008A3 nZ-- 00:C893:  RTS  ; 000393
; 2 refs via 0008B2 0008C1
0x0008A4 ---- 00:C894:  PHA  ; 
0x0008A5 ---- 00:C895:  AND #$01  ; 
0x0008A7 ---- 00:C897:  CLC  ; 
0x0008A8 --c- 00:C898:  ADC #$1D  ; 
0x0008AA ---- 00:C89A:  TAX  ; 
0x0008AB ---- 00:C89B:  PLA  ; 
0x0008AC ---- 00:C89C:  LSR  ; 
0x0008AD ---- 00:C89D:  CLC  ; 
0x0008AE --c- 00:C89E:  ADC #$03  ; 
0x0008B0 ---- 00:C8A0:  TAY  ; 
0x0008B1 ---- 00:C8A1:  RTS  ; 0008B5 0008C4
; 1 refs via 0008D6
0x0008B2 ---- 00:C8A2:  JSR $C894  ; 0008A4
; 1 refs via 0008B1
0x0008B5 ---- 00:C8A5:  LDA #$D3  ; 
0x0008B7 Nz-- 00:C8A7:  STA ram_0012  ; $0012
0x0008B9 Nz-- 00:C8A9:  LDA #$62  ; 
0x0008BB nz-- 00:C8AB:  STA ram_0011  ; $0011
0x0008BD nz-- 00:C8AD:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x0008C0 -Z-- 00:C8B0:  RTS  ; 0008D9
; 1 refs via 001B78
0x0008C1 ---- 00:C8B1:  JSR $C894  ; 0008A4
; 1 refs via 0008B1
0x0008C4 ---- 00:C8B4:  LDA #$D3  ; 
0x0008C6 Nz-- 00:C8B6:  STA ram_0012  ; $0012
0x0008C8 Nz-- 00:C8B8:  LDA #$6B  ; 
0x0008CA nz-- 00:C8BA:  STA ram_0011  ; $0011
0x0008CC nz-- 00:C8BC:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x0008CF -Z-- 00:C8BF:  RTS  ; 001B7B
; 1 refs via 000387
0x0008D0 N--- 00:C8C0:  LDA #$12  ; 
0x0008D2 nz-- 00:C8C2:  STA ram_005A  ; $005A
; 1 refs via 0008DD
0x0008D4 n--- 00:C8C4:  LDA ram_005A  ; $005A
0x0008D6 ---- 00:C8C6:  JSR $C8A2  ; 0008B2
; 1 refs via 0008C0
0x0008D9 -Z-- 00:C8C9:  DEC ram_005A  ; $005A
0x0008DB ---- 00:C8CB:  DEC ram_005A  ; $005A
0x0008DD ---- 00:C8CD:  BPL $C8C4  ; 0008D4
0x0008DF N--- 00:C8CF:  RTS  ; 00038A
; 1 refs via 000100
0x0008E0 ---- 00:C8D0:  LDA ram_0090  ; $0090
0x0008E2 ---- 00:C8D2:  CMP #$D8  ; 
0x0008E4 ---- 00:C8D4:  BCC $C8DA  ; 0008EA
0x0008E6 --C- 00:C8D6:  LDA #$D8  ; 
0x0008E8 NzC- 00:C8D8:  STA ram_0090  ; $0090
; 1 refs via 0008E4
0x0008EA ---- 00:C8DA:  LDA ram_0090  ; $0090
0x0008EC ---- 00:C8DC:  CMP #$18  ; 
0x0008EE ---- 00:C8DE:  BCS $C8E4  ; 0008F4
0x0008F0 --c- 00:C8E0:  LDA #$18  ; 
0x0008F2 nzc- 00:C8E2:  STA ram_0090  ; $0090
; 1 refs via 0008EE
0x0008F4 ---- 00:C8E4:  LDA ram_0098  ; $0098
0x0008F6 ---- 00:C8E6:  CMP #$D8  ; 
0x0008F8 ---- 00:C8E8:  BCC $C8EE  ; 0008FE
0x0008FA --C- 00:C8EA:  LDA #$D8  ; 
0x0008FC NzC- 00:C8EC:  STA ram_0098  ; $0098
; 1 refs via 0008F8
0x0008FE ---- 00:C8EE:  LDA ram_0098  ; $0098
0x000900 ---- 00:C8F0:  CMP #$18  ; 
0x000902 ---- 00:C8F2:  BCS $C8F8  ; 000908
0x000904 ---- xx:C8F4:  .byte $A9   ; 
0x000905 ---- xx:C8F5:  .byte $18   ; 
0x000906 ---- xx:C8F6:  .byte $85   ; 
0x000907 ---- xx:C8F7:  .byte $98   ; 
; 1 refs via 000902
0x000908 --C- 00:C8F8:  RTS  ; 000103
; 1 refs via 00022B
0x000909 ---- 00:C8F9:  LDA ram_006D  ; $006D
0x00090B ---- 00:C8FB:  BEQ $C946  ; 000956
0x00090D -z-- 00:C8FD:  LDA ram_000B  ; $000B
0x00090F ---- 00:C8FF:  AND #$10  ; 
0x000911 ---- 00:C901:  BEQ $C946  ; 000956
0x000913 -z-- 00:C903:  LDA #$03  ; 
0x000915 nz-- 00:C905:  STA ram_0004  ; $0004
0x000917 nz-- 00:C907:  LDA #$00  ; 
0x000919 nZ-- 00:C909:  STA ram_006E  ; $006E
0x00091B nZ-- 00:C90B:  LDX #$64  ; 
0x00091D nz-- 00:C90D:  LDY #$80  ; 
0x00091F Nz-- 00:C90F:  LDA #$17  ; 
0x000921 nz-- 00:C911:  STA ram_0053  ; $0053
0x000923 nz-- 00:C913:  JSR $DA2B  ; 001A3B
; 1 refs via 001A73
0x000926 ---- 00:C916:  LDX #$6C  ; 
0x000928 nz-- 00:C918:  LDY #$80  ; 
0x00092A Nz-- 00:C91A:  LDA #$19  ; 
0x00092C nz-- 00:C91C:  STA ram_0053  ; $0053
0x00092E nz-- 00:C91E:  JSR $DA2B  ; 001A3B
; 1 refs via 001A73
0x000931 ---- 00:C921:  LDX #$74  ; 
0x000933 nz-- 00:C923:  LDY #$80  ; 
0x000935 Nz-- 00:C925:  LDA #$1B  ; 
0x000937 nz-- 00:C927:  STA ram_0053  ; $0053
0x000939 nz-- 00:C929:  JSR $DA2B  ; 001A3B
; 1 refs via 001A73
0x00093C ---- 00:C92C:  LDX #$7C  ; 
0x00093E nz-- 00:C92E:  LDY #$80  ; 
0x000940 Nz-- 00:C930:  LDA #$1D  ; 
0x000942 nz-- 00:C932:  STA ram_0053  ; $0053
0x000944 nz-- 00:C934:  JSR $DA2B  ; 001A3B
; 1 refs via 001A73
0x000947 ---- 00:C937:  LDX #$84  ; 
0x000949 Nz-- 00:C939:  LDY #$80  ; 
0x00094B Nz-- 00:C93B:  LDA #$1F  ; 
0x00094D nz-- 00:C93D:  STA ram_0053  ; $0053
0x00094F nz-- 00:C93F:  JSR $DA2B  ; 001A3B
; 1 refs via 001A73
0x000952 ---- 00:C942:  LDA #$20  ; 
0x000954 nz-- 00:C944:  STA ram_006E  ; $006E
; 2 refs via 00090B 000911
0x000956 ---- 00:C946:  RTS  ; 00022E
; 1 refs via 0009BC
0x000957 ---- 00:C947:  LDA #$03  ; 
0x000959 nz-- 00:C949:  STA ram_0004  ; $0004
0x00095B nz-- 00:C94B:  LDA #$00  ; 
0x00095D nZ-- 00:C94D:  STA ram_006E  ; $006E
0x00095F nZ-- 00:C94F:  LDX ram_0105  ; $0105
0x000962 ---- 00:C952:  LDY ram_0106  ; $0106
0x000965 ---- 00:C955:  LDA #$79  ; 
0x000967 nz-- 00:C957:  STA ram_0053  ; $0053
0x000969 nz-- 00:C959:  JSR $DA7B  ; 001A8B
; 1 refs via 001AA2
0x00096C ---- 00:C95C:  LDA ram_0105  ; $0105
0x00096F ---- 00:C95F:  CLC  ; 
0x000970 --c- 00:C960:  ADC #$10  ; 
0x000972 ---- 00:C962:  TAX  ; 
0x000973 ---- 00:C963:  LDY ram_0106  ; $0106
0x000976 ---- 00:C966:  LDA #$7D  ; 
0x000978 nz-- 00:C968:  STA ram_0053  ; $0053
0x00097A nz-- 00:C96A:  JSR $DA7B  ; 001A8B
; 1 refs via 001AA2
0x00097D ---- 00:C96D:  LDA #$20  ; 
0x00097F nz-- 00:C96F:  STA ram_006E  ; $006E
0x000981 nz-- 00:C971:  RTS  ; 0009BF
; 1 refs via 000320
0x000982 ---- 00:C972:  LDA ram_0108  ; $0108
0x000985 ---- 00:C975:  BEQ $C9AF  ; 0009BF
0x000987 -z-- 00:C977:  LDA ram_0046  ; $0046
0x000989 ---- 00:C979:  CMP #$02  ; 
0x00098B ---- 00:C97B:  BEQ $C9AF  ; 0009BF
0x00098D -z-- 00:C97D:  LDA ram_000B  ; $000B
0x00098F ---- 00:C97F:  AND #$0F  ; 
0x000991 ---- 00:C981:  BNE $C98D  ; 00099D
0x000993 -Z-- 00:C983:  DEC ram_0108  ; $0108
0x000996 ---- 00:C986:  BNE $C98D  ; 00099D
0x000998 -Z-- 00:C988:  LDA #$F0  ; 
0x00099A Nz-- 00:C98A:  STA ram_0106  ; $0106
; 2 refs via 000991 000996
0x00099D -z-- 00:C98D:  LDA ram_0108  ; $0108
0x0009A0 ---- 00:C990:  CMP #$0A  ; 
0x0009A2 ---- 00:C992:  BCC $C9AC  ; 0009BC
0x0009A4 --C- 00:C994:  LDA ram_0107  ; $0107
0x0009A7 --C- 00:C997:  TAY  ; 
0x0009A8 --C- 00:C998:  LDA $D3D5,Y  ; 0013E5 0013E6 0013E8
0x0009AB --C- 00:C99B:  CLC  ; 
0x0009AC --c- 00:C99C:  ADC ram_0105  ; $0105
0x0009AF ---- 00:C99F:  STA ram_0105  ; $0105
0x0009B2 ---- 00:C9A2:  LDA $D3D9,Y  ; 0013E9 0013EA 0013EC
0x0009B5 ---- 00:C9A5:  CLC  ; 
0x0009B6 --c- 00:C9A6:  ADC ram_0106  ; $0106
0x0009B9 ---- 00:C9A9:  STA ram_0106  ; $0106
; 1 refs via 0009A2
0x0009BC ---- 00:C9AC:  JSR $C947  ; 000957
; 3 refs via 000981 000985 00098B
0x0009BF ---- 00:C9AF:  RTS  ; 000323
; 4 refs via 0000C5 0001E4 0003DE 00056D
0x0009C0 ---- 00:C9B0:  LDA #$02  ; 
0x0009C2 nz-- 00:C9B2:  STA ram_0056  ; $0056
0x0009C4 nz-- 00:C9B4:  STA ram_0057  ; $0057
0x0009C6 nz-- 00:C9B6:  LDA #$1A  ; 
0x0009C8 nz-- 00:C9B8:  STA ram_005A  ; $005A
0x0009CA nz-- 00:C9BA:  STA ram_005B  ; $005B
0x0009CC nz-- 00:C9BC:  JSR $D7CC  ; 0017DC
; 1 refs via 00181A
0x0009CF -Z-- 00:C9BF:  RTS  ; 0000C8 0001E7 0003E1 000570
; 1 refs via 0000B2
0x0009D0 ---- 00:C9C0:  LDA #$03  ; 
0x0009D2 nz-- 00:C9C2:  STA ram_004D  ; $004D
0x0009D4 nz-- 00:C9C4:  JSR $E413  ; 002423
; 1 refs via 00242F
0x0009D7 N--- 00:C9C7:  LDA #$48  ; 
0x0009D9 nz-- 00:C9C9:  STA ram_0090  ; $0090
0x0009DB nz-- 00:C9CB:  JSR $CA85  ; 000A95
; 1 refs via 000AA0
0x0009DE ---- 00:C9CE:  LDA #$83  ; 
0x0009E0 Nz-- 00:C9D0:  STA ram_00A0  ; $00A0
0x0009E2 Nz-- 00:C9D2:  LDA #$00  ; 
0x0009E4 nZ-- 00:C9D4:  STA ram_000A  ; $000A
0x0009E6 nZ-- 00:C9D6:  STA ram_00A8  ; $00A8
0x0009E8 nZ-- 00:C9D8:  STA ram_00B0  ; $00B0
0x0009EA nZ-- 00:C9DA:  STA ram_006F  ; $006F
0x0009EC nZ-- 00:C9DC:  STA ram_0070  ; $0070
0x0009EE nZ-- 00:C9DE:  STA ram_004F  ; $004F
0x0009F0 nZ-- 00:C9E0:  STA ram_004A  ; $004A
0x0009F2 nZ-- 00:C9E2:  LDA #$02  ; 
0x0009F4 nz-- 00:C9E4:  STA ram_0050  ; $0050
; 1 refs via 000A51
0x0009F6 ---- 00:C9E6:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x0009F9 -z-- 00:C9E9:  LDA ram_000B  ; $000B
0x0009FB ---- 00:C9EB:  AND #$03  ; 
0x0009FD ---- 00:C9ED:  BNE $C9F5  ; 000A05
0x0009FF -Z-- 00:C9EF:  LDA ram_00B0  ; $00B0
0x000A01 ---- 00:C9F1:  EOR #$04  ; 
0x000A03 ---- 00:C9F3:  STA ram_00B0  ; $00B0
; 1 refs via 0009FD
0x000A05 ---- 00:C9F5:  JSR $DEA6  ; 001EB6
; 1 refs via 001EC7
0x000A08 -Z-- 00:C9F8:  LDA ram_0008  ; $0008
0x000A0A ---- 00:C9FA:  AND #$04  ; 
0x000A0C ---- 00:C9FC:  BEQ $CA04  ; 000A14
0x000A0E -z-- 00:C9FE:  INC ram_0083  ; $0083
0x000A10 ---- 00:CA00:  LDA #$00  ; 
0x000A12 nZ-- 00:CA02:  STA ram_000A  ; $000A
; 1 refs via 000A0C
0x000A14 -Z-- 00:CA04:  LDA ram_0006  ; $0006
0x000A16 ---- 00:CA06:  AND #$20  ; 
0x000A18 ---- 00:CA08:  BEQ $CA17  ; 000A27
0x000A1A -z-- 00:CA0A:  LDA ram_0009  ; $0009
0x000A1C ---- 00:CA0C:  AND #$01  ; 
0x000A1E ---- 00:CA0E:  BEQ $CA17  ; 000A27
0x000A20 -z-- 00:CA10:  LDA #$10  ; 
0x000A22 nz-- 00:CA12:  CLC  ; 
0x000A23 nzc- 00:CA13:  ADC ram_004A  ; $004A
0x000A25 ---- 00:CA15:  STA ram_004A  ; $004A
; 2 refs via 000A18 000A1E
0x000A27 ---- 00:CA17:  LDA ram_0006  ; $0006
0x000A29 ---- 00:CA19:  AND #$80  ; 
0x000A2B ---- 00:CA1B:  BEQ $CA25  ; 000A35
0x000A2D -z-- 00:CA1D:  LDA ram_0009  ; $0009
0x000A2F ---- 00:CA1F:  AND #$02  ; 
0x000A31 ---- 00:CA21:  BEQ $CA25  ; 000A35
0x000A33 -z-- 00:CA23:  DEC ram_004A  ; $004A
; 2 refs via 000A2B 000A31
0x000A35 ---- 00:CA25:  LDA ram_0083  ; $0083
0x000A37 ---- 00:CA27:  CMP #$03  ; 
0x000A39 ---- 00:CA29:  BCC $CA2F  ; 000A3F
0x000A3B --C- 00:CA2B:  LDA #$00  ; 
0x000A3D nZC- 00:CA2D:  STA ram_0083  ; $0083
; 1 refs via 000A39
0x000A3F ---- 00:CA2F:  JSR $CA85  ; 000A95
; 1 refs via 000AA0
0x000A42 ---- 00:CA32:  LDA ram_000A  ; $000A
0x000A44 ---- 00:CA34:  CMP #$0A  ; 
0x000A46 ---- 00:CA36:  BNE $CA3D  ; 000A4D
0x000A48 -Z-- 00:CA38:  LDA ram_004B  ; $004B
0x000A4A ---- 00:CA3A:  BNE $CA3D  ; 000A4D
0x000A4C -Z-- 00:CA3C:  RTS  ; 0000B5
; 2 refs via 000A46 000A4A
0x000A4D -z-- 00:CA3D:  LDA ram_0008  ; $0008
0x000A4F ---- 00:CA3F:  AND #$08  ; 
0x000A51 ---- 00:CA41:  BEQ $C9E6  ; 0009F6
0x000A53 -z-- 00:CA43:  LDA ram_004B  ; $004B
0x000A55 ---- 00:CA45:  CMP #$07  ; 
0x000A57 ---- 00:CA47:  BNE $CA52  ; 000A62
0x000A59 -Z-- 00:CA49:  LDA ram_004A  ; $004A
0x000A5B ---- 00:CA4B:  CMP #$74  ; 
0x000A5D ---- 00:CA4D:  BNE $CA52  ; 000A62
0x000A5F -Z-- 00:CA4F:  JSR $C49C  ; 0004AC
; 3 refs via 000576 000A57 000A5D
0x000A62 -z-- 00:CA52:  LDA #$00  ; 
0x000A64 nZ-- 00:CA54:  STA ram_004D  ; $004D
0x000A66 nZ-- 00:CA56:  PLA  ; 
0x000A67 ---- 00:CA57:  PLA  ; 
0x000A68 ---- 00:CA58:  LDA ram_0083  ; $0083
0x000A6A ---- 00:CA5A:  ASL  ; 
0x000A6B ---- 00:CA5B:  TAY  ; 
0x000A6C ---- 00:CA5C:  LDA $CA69,Y  ; 000A79 000A7B 000A7D
0x000A6F ---- 00:CA5F:  STA ram_0011  ; $0011
0x000A71 ---- 00:CA61:  LDA $CA6A,Y  ; 000A7A 000A7C 000A7E
0x000A74 ---- 00:CA64:  STA ram_0012  ; $0012
0x000A76 ---- 00:CA66:  JMP (ram_0011)  ; 000A7F 000A84 000A8E
0x000A79 ---- 00:CA69:  .byte $6F   ; 000A6C
0x000A7A ---- 00:CA6A:  .byte $CA   ; 000A71
0x000A7B ---- 00:CA6B:  .byte $74   ; 000A6C
0x000A7C ---- 00:CA6C:  .byte $CA   ; 000A71
0x000A7D ---- 00:CA6D:  .byte $7E   ; 000A6C
0x000A7E ---- 00:CA6E:  .byte $CA   ; 000A71
; 1 refs via 000A76
0x000A7F ---- 00:CA6F:  LDA #$05  ; 
0x000A81 nz-- 00:CA71:  JMP $CA76  ; 000A86
; 1 refs via 000A76
0x000A84 ---- 00:CA74:  LDA #$07  ; 
; 1 refs via 000A81
0x000A86 nz-- 00:CA76:  STA ram_006C  ; $006C
0x000A88 nz-- 00:CA78:  JSR $C2B3  ; 0002C3
; 1 refs via 0002F5
0x000A8B nZ-- 00:CA7B:  JMP $C159  ; 000169
; 1 refs via 000A76
0x000A8E ---- 00:CA7E:  LDA #$07  ; 
0x000A90 nz-- 00:CA80:  STA ram_006C  ; $006C
0x000A92 nz-- 00:CA82:  JMP $C0AE  ; 0000BE
; 2 refs via 0009DB 000A3F
0x000A95 ---- 00:CA85:  LDA ram_0083  ; $0083
0x000A97 ---- 00:CA87:  ASL  ; 
0x000A98 ---- 00:CA88:  ASL  ; 
0x000A99 ---- 00:CA89:  ASL  ; 
0x000A9A ---- 00:CA8A:  ASL  ; 
0x000A9B ---- 00:CA8B:  CLC  ; 
0x000A9C --c- 00:CA8C:  ADC #$8B  ; 
0x000A9E ---- 00:CA8E:  STA ram_0098  ; $0098
0x000AA0 ---- 00:CA90:  RTS  ; 0009DE 000A42
; 1 refs via 000182
0x000AA1 ---- 00:CA91:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x000AA4 -z-- 00:CA94:  LDX #$0C  ; 
0x000AA6 nz-- 00:CA96:  LDY #$0E  ; 
0x000AA8 nz-- 00:CA98:  JSR $D5FB  ; 00160B
; 1 refs via 001621
0x000AAB -z-- 00:CA9B:  LDX ram_000C  ; $000C
0x000AAD ---- 00:CA9D:  CLC  ; 
0x000AAE --c- 00:CA9E:  ADC #$1C  ; 
0x000AB0 ---- 00:CAA0:  STA ram_0180,X  ; $0180
0x000AB3 ---- 00:CAA3:  INX  ; 
0x000AB4 ---- 00:CAA4:  TYA  ; 
0x000AB5 ---- 00:CAA5:  STA ram_0180,X  ; $0181
0x000AB8 ---- 00:CAA8:  INX  ; 
0x000AB9 ---- 00:CAA9:  LDA #$23  ; 
0x000ABB nz-- 00:CAAB:  STA ram_0180,X  ; $0182
0x000ABE nz-- 00:CAAE:  INX  ; 
0x000ABF ---- 00:CAAF:  LDA #$24  ; 
0x000AC1 nz-- 00:CAB1:  STA ram_0180,X  ; $0183
0x000AC4 nz-- 00:CAB4:  INX  ; 
0x000AC5 ---- 00:CAB5:  LDA #$25  ; 
0x000AC7 nz-- 00:CAB7:  STA ram_0180,X  ; $0184
0x000ACA nz-- 00:CABA:  INX  ; 
0x000ACB ---- 00:CABB:  LDA #$26  ; 
0x000ACD nz-- 00:CABD:  STA ram_0180,X  ; $0185
0x000AD0 nz-- 00:CAC0:  INX  ; 
0x000AD1 ---- 00:CAC1:  LDA #$27  ; 
0x000AD3 nz-- 00:CAC3:  STA ram_0180,X  ; $0186
0x000AD6 nz-- 00:CAC6:  INX  ; 
0x000AD7 ---- 00:CAC7:  LDA #$11  ; 
0x000AD9 nz-- 00:CAC9:  STA ram_0180,X  ; $0187
0x000ADC nz-- 00:CACC:  INX  ; 
0x000ADD ---- 00:CACD:  LDA #$11  ; 
0x000ADF nz-- 00:CACF:  STA ram_0180,X  ; $0188
0x000AE2 nz-- 00:CAD2:  INX  ; 
0x000AE3 ---- 00:CAD3:  LDA #$FF  ; 
0x000AE5 Nz-- 00:CAD5:  STA ram_0180,X  ; $0189
0x000AE8 Nz-- 00:CAD8:  INX  ; 
0x000AE9 ---- 00:CAD9:  STX ram_000C  ; $000C
0x000AEB ---- 00:CADB:  LDA #$6E  ; 
0x000AED nz-- 00:CADD:  STA ram_0060  ; $0060
0x000AEF nz-- 00:CADF:  LDA ram_0085  ; $0085
0x000AF1 ---- 00:CAE1:  JSR $DA13  ; 001A23
; 1 refs via 001A3A
0x000AF4 --c- 00:CAE4:  LDY #$36  ; 
0x000AF6 nzc- 00:CAE6:  LDX #$0E  ; 
0x000AF8 nzc- 00:CAE8:  JSR $D934  ; 001944
; 1 refs via 001960
0x000AFB nZ-- 00:CAEB:  LDY #$0E  ; 
0x000AFD nz-- 00:CAED:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x000B00 -Z-- 00:CAF0:  LDA #$00  ; 
0x000B02 nZ-- 00:CAF2:  STA ram_0060  ; $0060
0x000B04 nZ-- 00:CAF4:  RTS  ; 000185
; 4 refs via 0000F7 0001EC 000422 0022DF
0x000B05 ---- 00:CAF5:  LDA #$D3  ; 
0x000B07 Nz-- 00:CAF7:  STA ram_0012  ; $0012
0x000B09 Nz-- 00:CAF9:  LDA #$6D  ; 
0x000B0B nz-- 00:CAFB:  STA ram_0011  ; $0011
0x000B0D nz-- 00:CAFD:  LDX #$0C  ; 
0x000B0F nz-- 00:CAFF:  LDY #$18  ; 
0x000B11 nz-- 00:CB01:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000B14 -Z-- 00:CB04:  LDA #$D3  ; 
0x000B16 Nz-- 00:CB06:  STA ram_0012  ; $0012
0x000B18 Nz-- 00:CB08:  LDA #$74  ; 
0x000B1A nz-- 00:CB0A:  STA ram_0011  ; $0011
0x000B1C nz-- 00:CB0C:  LDX #$0C  ; 
0x000B1E nz-- 00:CB0E:  LDY #$19  ; 
0x000B20 nz-- 00:CB10:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000B23 -Z-- 00:CB13:  LDA #$D3  ; 
0x000B25 Nz-- 00:CB15:  STA ram_0012  ; $0012
0x000B27 Nz-- 00:CB17:  LDA #$7B  ; 
0x000B29 nz-- 00:CB19:  STA ram_0011  ; $0011
0x000B2B nz-- 00:CB1B:  LDX #$0C  ; 
0x000B2D nz-- 00:CB1D:  LDY #$1A  ; 
0x000B2F nz-- 00:CB1F:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000B32 -Z-- 00:CB22:  LDA #$D3  ; 
0x000B34 Nz-- 00:CB24:  STA ram_0012  ; $0012
0x000B36 Nz-- 00:CB26:  LDA #$82  ; 
0x000B38 Nz-- 00:CB28:  STA ram_0011  ; $0011
0x000B3A Nz-- 00:CB2A:  LDX #$0C  ; 
0x000B3C nz-- 00:CB2C:  LDY #$1B  ; 
0x000B3E nz-- 00:CB2E:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000B41 -Z-- 00:CB31:  LDX ram_000C  ; $000C
0x000B43 ---- 00:CB33:  LDA #$23  ; 
0x000B45 nz-- 00:CB35:  STA ram_0180,X  ; $01A4 $01B3
0x000B48 nz-- 00:CB38:  INX  ; 
0x000B49 ---- 00:CB39:  LDA #$F3  ; 
0x000B4B Nz-- 00:CB3B:  STA ram_0180,X  ; $01A5 $01B4
0x000B4E Nz-- 00:CB3E:  INX  ; 
0x000B4F ---- 00:CB3F:  LDA #$00  ; 
0x000B51 nZ-- 00:CB41:  STA ram_07F3  ; $07F3
0x000B54 nZ-- 00:CB44:  STA ram_0180,X  ; $01A6 $01B5
0x000B57 nZ-- 00:CB47:  INX  ; 
0x000B58 ---- 00:CB48:  LDA ram_07F4  ; $07F4
0x000B5B ---- 00:CB4B:  AND #$CC  ; 
0x000B5D ---- 00:CB4D:  STA ram_07F4  ; $07F4
0x000B60 ---- 00:CB50:  STA ram_0180,X  ; $01A7 $01B6
0x000B63 ---- 00:CB53:  INX  ; 
0x000B64 ---- 00:CB54:  LDA #$FF  ; 
0x000B66 Nz-- 00:CB56:  STA ram_0180,X  ; $01A8 $01B7
0x000B69 Nz-- 00:CB59:  INX  ; 
0x000B6A ---- 00:CB5A:  STX ram_000C  ; $000C
0x000B6C ---- 00:CB5C:  RTS  ; 0000FA 0001EF 000425 0022E2
; 1 refs via 0001F2
0x000B6D -z-- 00:CB5D:  LDA #$D3  ; 
0x000B6F Nz-- 00:CB5F:  STA ram_0012  ; $0012
0x000B71 Nz-- 00:CB61:  LDA #$A5  ; 
0x000B73 Nz-- 00:CB63:  STA ram_0011  ; $0011
0x000B75 Nz-- 00:CB65:  LDX #$0E  ; 
0x000B77 nz-- 00:CB67:  LDY #$1A  ; 
0x000B79 nz-- 00:CB69:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000B7C -Z-- 00:CB6C:  LDA #$D3  ; 
0x000B7E Nz-- 00:CB6E:  STA ram_0012  ; $0012
0x000B80 Nz-- 00:CB70:  LDA #$A8  ; 
0x000B82 Nz-- 00:CB72:  STA ram_0011  ; $0011
0x000B84 Nz-- 00:CB74:  LDX #$0E  ; 
0x000B86 nz-- 00:CB76:  LDY #$1B  ; 
0x000B88 nz-- 00:CB78:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000B8B -Z-- 00:CB7B:  LDX ram_000C  ; $000C
0x000B8D ---- 00:CB7D:  LDA #$23  ; 
0x000B8F nz-- 00:CB7F:  STA ram_0180,X  ; $0198
0x000B92 nz-- 00:CB82:  INX  ; 
0x000B93 ---- 00:CB83:  LDA #$F3  ; 
0x000B95 Nz-- 00:CB85:  STA ram_0180,X  ; $0199
0x000B98 Nz-- 00:CB88:  INX  ; 
0x000B99 ---- 00:CB89:  LDA ram_07F3  ; $07F3
0x000B9C ---- 00:CB8C:  AND #$3F  ; 
0x000B9E ---- 00:CB8E:  STA ram_07F3  ; $07F3
0x000BA1 ---- 00:CB91:  STA ram_0180,X  ; $019A
0x000BA4 ---- 00:CB94:  INX  ; 
0x000BA5 ---- 00:CB95:  LDA #$FF  ; 
0x000BA7 Nz-- 00:CB97:  STA ram_0180,X  ; $019B
0x000BAA Nz-- 00:CB9A:  INX  ; 
0x000BAB ---- 00:CB9B:  STX ram_000C  ; $000C
0x000BAD ---- 00:CB9D:  RTS  ; 0001F5
; 2 refs via 0022D9 002A0F
0x000BAE ---- 00:CB9E:  LDA #$D3  ; 
0x000BB0 Nz-- 00:CBA0:  STA ram_0012  ; $0012
0x000BB2 Nz-- 00:CBA2:  LDA #$89  ; 
0x000BB4 Nz-- 00:CBA4:  STA ram_0011  ; $0011
0x000BB6 Nz-- 00:CBA6:  LDX #$0C  ; 
0x000BB8 nz-- 00:CBA8:  LDY #$18  ; 
0x000BBA nz-- 00:CBAA:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000BBD -Z-- 00:CBAD:  LDA #$D3  ; 
0x000BBF Nz-- 00:CBAF:  STA ram_0012  ; $0012
0x000BC1 Nz-- 00:CBB1:  LDA #$90  ; 
0x000BC3 Nz-- 00:CBB3:  STA ram_0011  ; $0011
0x000BC5 Nz-- 00:CBB5:  LDX #$0C  ; 
0x000BC7 nz-- 00:CBB7:  LDY #$19  ; 
0x000BC9 nz-- 00:CBB9:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000BCC -Z-- 00:CBBC:  LDA #$D3  ; 
0x000BCE Nz-- 00:CBBE:  STA ram_0012  ; $0012
0x000BD0 Nz-- 00:CBC0:  LDA #$97  ; 
0x000BD2 Nz-- 00:CBC2:  STA ram_0011  ; $0011
0x000BD4 Nz-- 00:CBC4:  LDX #$0C  ; 
0x000BD6 nz-- 00:CBC6:  LDY #$1A  ; 
0x000BD8 nz-- 00:CBC8:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000BDB -Z-- 00:CBCB:  LDA #$D3  ; 
0x000BDD Nz-- 00:CBCD:  STA ram_0012  ; $0012
0x000BDF Nz-- 00:CBCF:  LDA #$9E  ; 
0x000BE1 Nz-- 00:CBD1:  STA ram_0011  ; $0011
0x000BE3 Nz-- 00:CBD3:  LDX #$0C  ; 
0x000BE5 nz-- 00:CBD5:  LDY #$1B  ; 
0x000BE7 nz-- 00:CBD7:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000BEA -Z-- 00:CBDA:  LDX ram_000C  ; $000C
0x000BEC ---- 00:CBDC:  LDA #$23  ; 
0x000BEE nz-- 00:CBDE:  STA ram_0180,X  ; $01A4
0x000BF1 nz-- 00:CBE1:  INX  ; 
0x000BF2 ---- 00:CBE2:  LDA #$F3  ; 
0x000BF4 Nz-- 00:CBE4:  STA ram_0180,X  ; $01A5
0x000BF7 Nz-- 00:CBE7:  INX  ; 
0x000BF8 ---- 00:CBE8:  LDA #$3F  ; 
0x000BFA nz-- 00:CBEA:  STA ram_07F3  ; $07F3
0x000BFD nz-- 00:CBED:  STA ram_0180,X  ; $01A6
0x000C00 nz-- 00:CBF0:  INX  ; 
0x000C01 ---- 00:CBF1:  LDA ram_07F4  ; $07F4
0x000C04 ---- 00:CBF4:  AND #$CC  ; 
0x000C06 ---- 00:CBF6:  ORA #$33  ; 
0x000C08 -z-- 00:CBF8:  STA ram_07F4  ; $07F4
0x000C0B -z-- 00:CBFB:  STA ram_0180,X  ; $01A7
0x000C0E -z-- 00:CBFE:  INX  ; 
0x000C0F ---- 00:CBFF:  LDA #$FF  ; 
0x000C11 Nz-- 00:CC01:  STA ram_0180,X  ; $01A8
0x000C14 Nz-- 00:CC04:  INX  ; 
0x000C15 ---- 00:CC05:  STX ram_000C  ; $000C
0x000C17 ---- 00:CC07:  RTS  ; 0022DC 002A12
; 1 refs via 0026CA
0x000C18 nz-- 00:CC08:  LDA #$D3  ; 
0x000C1A Nz-- 00:CC0A:  STA ram_0012  ; $0012
0x000C1C Nz-- 00:CC0C:  LDA #$AB  ; 
0x000C1E Nz-- 00:CC0E:  STA ram_0011  ; $0011
0x000C20 Nz-- 00:CC10:  LDX #$0E  ; 
0x000C22 nz-- 00:CC12:  LDY #$1A  ; 
0x000C24 nz-- 00:CC14:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000C27 -Z-- 00:CC17:  LDA #$D3  ; 
0x000C29 Nz-- 00:CC19:  STA ram_0012  ; $0012
0x000C2B Nz-- 00:CC1B:  LDA #$AE  ; 
0x000C2D Nz-- 00:CC1D:  STA ram_0011  ; $0011
0x000C2F Nz-- 00:CC1F:  LDX #$0E  ; 
0x000C31 nz-- 00:CC21:  LDY #$1B  ; 
0x000C33 nz-- 00:CC23:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000C36 -Z-- 00:CC26:  RTS  ; 0026CD
; 1 refs via 0001F9
0x000C37 nZ-- 00:CC27:  LDY #$00  ; 
0x000C39 nZ-- 00:CC29:  LDA #$23  ; 
0x000C3B nz-- 00:CC2B:  STA ram_0012  ; $0012
0x000C3D nz-- 00:CC2D:  LDA #$C0  ; 
0x000C3F Nz-- 00:CC2F:  STA ram_0011  ; $0011
; 1 refs via 000C69
0x000C41 -z-- 00:CC31:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x000C44 -z-- 00:CC34:  LDX ram_000C  ; $000C
0x000C46 ---- 00:CC36:  LDA ram_0012  ; $0012
0x000C48 ---- 00:CC38:  STA ram_0180,X  ; $0180
0x000C4B ---- 00:CC3B:  INX  ; 
0x000C4C ---- 00:CC3C:  LDA ram_0011  ; $0011
0x000C4E ---- 00:CC3E:  STA ram_0180,X  ; $0181
0x000C51 ---- 00:CC41:  INX  ; 
0x000C52 ---- 00:CC42:  LDA ram_07C0,Y  ; $07C0 $07C1 $07C2 $07C3 $07C4 $07C5 $07C6 $07C7 $07C8 $07C9 $07CA $07CB $07CC $07CD $07CE $07CF $07D0 $07D1 $07D2 $07D3 $07D4 $07D5 $07D6 $07D7 $07D8 $07D9 $07DA $07DB $07DC $07DD $07DE $07DF $07E0 $07E1 $07E2 $07E3 $07E4 $07E5 $07E6 $07E7 $07E8 $07E9 $07EA $07EB $07EC $07ED $07EE $07EF $07F0 $07F1 $07F2 $07F3 $07F4 $07F5 $07F6 $07F7 $07F8 $07F9 $07FA $07FB $07FC $07FD $07FE $07FF
0x000C55 ---- 00:CC45:  INY  ; 
0x000C56 ---- 00:CC46:  STA ram_0180,X  ; $0182
0x000C59 ---- 00:CC49:  INX  ; 
0x000C5A ---- 00:CC4A:  LDA #$FF  ; 
0x000C5C Nz-- 00:CC4C:  STA ram_0180,X  ; $0183
0x000C5F Nz-- 00:CC4F:  INX  ; 
0x000C60 ---- 00:CC50:  STX ram_000C  ; $000C
0x000C62 ---- 00:CC52:  LDA #$01  ; 
0x000C64 nz-- 00:CC54:  JSR $D7AA  ; 0017BA
; 1 refs via 0017C3
0x000C67 ---- 00:CC57:  CPY #$40  ; 
0x000C69 ---- 00:CC59:  BNE $CC31  ; 000C41
0x000C6B -Z-- 00:CC5B:  RTS  ; 0001FC
; 4 refs via 000CAD 000CB6 000CCF 000CD8
0x000C6C ---- 00:CC5C:  LDX #$00  ; 
0x000C6E nZ-- 00:CC5E:  JSR $D5FB  ; 00160B
; 1 refs via 001621
0x000C71 -z-- 00:CC61:  STA ram_0012  ; $0012
0x000C73 -z-- 00:CC63:  STY ram_0011  ; $0011
0x000C75 -z-- 00:CC65:  LDX ram_000C  ; $000C
0x000C77 ---- 00:CC67:  LDA ram_0012  ; $0012
0x000C79 ---- 00:CC69:  CLC  ; 
0x000C7A --c- 00:CC6A:  ADC #$1C  ; 
0x000C7C ---- 00:CC6C:  STA ram_0180,X  ; $0180 $01A3
0x000C7F ---- 00:CC6F:  INX  ; 
0x000C80 ---- 00:CC70:  LDA ram_0011  ; $0011
0x000C82 ---- 00:CC72:  STA ram_0180,X  ; $0181 $01A4
0x000C85 ---- 00:CC75:  INX  ; 
0x000C86 ---- 00:CC76:  LDY #$00  ; 
; 1 refs via 000C95
0x000C88 ---- 00:CC78:  LDA ram_0063  ; $0063
0x000C8A ---- 00:CC7A:  BNE $CC7E  ; 000C8E
0x000C8C -Z-- 00:CC7C:  LDA (ram_0011),Y  ; $0400 $0401 $0402 $0403 $0404 $0405 $0406 $0407 $0408 $0409 $040A $040B $040C $040D $040E $040F $0410 $0411 $0412 $0413 $0414 $0415 $0416 $0417 $0418 $0419 $041A $041B $041C $041D $041E $041F $0420 $0421 $0422 $0423 $0424 $0425 $0426 $0427 $0428 $0429 $042A $042B $042C $042D $042E $042F $0430 $0431 $0432 $0433 $0434 $0435 $0436 $0437 $0438 $0439 $043A $043B $043C $043D $043E $043F $0440 $0441 $0442 $0443 $0444 $0445 $0446 $0447 $0448 $0449 $044A $044B $044C $044D $044E $044F $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0458 $0459 $045A $045B $045C $045D $045E $045F $0460 $0461 $0462 $0463 $0464 $0465 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $046E $046F $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $047A $047B $047C $047D $047E $047F $0480 $0481 $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $049C $049D $049E $049F $04A0 $04A1 $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04BC $04BD $04BE $04BF $04C0 $04C1 $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04DC $04DD $04DE $04DF $04E0 $04E1 $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $04FC $04FD $04FE $04FF $0500 $0501 $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $051C $051D $051E $051F $0520 $0521 $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $053C $053D $053E $053F $0540 $0541 $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $055C $055D $055E $055F $0560 $0561 $0562 $0563 $0564 $0565 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $057C $057D $057E $057F $0580 $0581 $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $059C $059D $059E $059F $05A0 $05A1 $05A2 $05A3 $05A4 $05A5 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05BC $05BD $05BE $05BF $05C0 $05C1 $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05DC $05DD $05DE $05DF $05E0 $05E1 $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $05FC $05FD $05FE $05FF $0600 $0601 $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $061C $061D $061E $061F $0620 $0621 $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $0639 $063A $063B $063C $063D $063E $063F $0640 $0641 $0642 $0643 $0644 $0645 $0646 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $065C $065D $065E $065F $0660 $0661 $0662 $0663 $0664 $0665 $0666 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $067C $067D $067E $067F $0680 $0681 $0682 $0683 $0684 $0685 $0686 $0687 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0692 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $069C $069D $069E $069F $06A0 $06A1 $06A2 $06A3 $06A4 $06A5 $06A6 $06A7 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B7 $06B8 $06B9 $06BA $06BB $06BC $06BD $06BE $06BF $06C0 $06C1 $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06DC $06DD $06DE $06DF $06E0 $06E1 $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $06FA $06FB $06FC $06FD $06FE $06FF $0700 $0701 $0702 $0703 $0704 $0705 $0706 $0707 $0708 $0709 $070A $070B $070C $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0717 $0718 $0719 $071A $071B $071C $071D $071E $071F $0720 $0721 $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072C $072D $072E $072F $0730 $0731 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $073C $073D $073E $073F $0740 $0741 $0742 $0743 $0744 $0745 $0746 $0747 $0748 $0749 $074A $074B $074C $074D $074E $074F $0750 $0751 $0752 $0753 $0754 $0755 $0756 $0757 $0758 $0759 $075A $075B $075C $075D $075E $075F $0760 $0761 $0762 $0763 $0764 $0765 $0766 $0767 $0768 $0769 $076A $076B $076C $076D $076E $076F $0770 $0771 $0772 $0773 $0774 $0775 $0776 $0777 $0778 $0779 $077A $077B $077C $077D $077E $077F $0780 $0781 $0782 $0783 $0784 $0785 $0786 $0787 $0788 $0789 $078A $078B $078C $078D $078E $078F $0790 $0791 $0792 $0793 $0794 $0795 $0796 $0797 $0798 $0799 $079A $079B $079C $079D $079E $079F $07A0 $07A1 $07A2 $07A3 $07A4 $07A5 $07A6 $07A7 $07A8 $07A9 $07AA $07AB $07AC $07AD $07AE $07AF $07B0 $07B1 $07B2 $07B3 $07B4 $07B5 $07B6 $07B7 $07B8 $07B9 $07BA $07BB $07BC $07BD $07BE $07BF
; 1 refs via 000C8A
0x000C8E ---- 00:CC7E:  STA ram_0180,X  ; $0182 $0183 $0184 $0185 $0186 $0187 $0188 $0189 $018A $018B $018C $018D $018E $018F $0190 $0191 $0192 $0193 $0194 $0195 $0196 $0197 $0198 $0199 $019A $019B $019C $019D $019E $019F $01A0 $01A1 $01A5 $01A6 $01A7 $01A8 $01A9 $01AA $01AB $01AC $01AD $01AE $01AF $01B0 $01B1 $01B2 $01B3 $01B4 $01B5 $01B6 $01B7 $01B8 $01B9 $01BA $01BB $01BC $01BD $01BE $01BF $01C0 $01C1 $01C2 $01C3 $01C4
0x000C91 ---- 00:CC81:  INX  ; 
0x000C92 ---- 00:CC82:  INY  ; 
0x000C93 ---- 00:CC83:  CPY #$20  ; 
0x000C95 ---- 00:CC85:  BNE $CC78  ; 000C88
0x000C97 -Z-- 00:CC87:  LDA #$FF  ; 
0x000C99 Nz-- 00:CC89:  STA ram_0180,X  ; $01A2 $01C5
0x000C9C Nz-- 00:CC8C:  INX  ; 
0x000C9D ---- 00:CC8D:  STX ram_000C  ; $000C
0x000C9F ---- 00:CC8F:  RTS  ; 000CB0 000CB9 000CD2 000CDB
; 1 refs via 00017F
0x000CA0 nz-- 00:CC90:  LDA #$11  ; 
0x000CA2 nz-- 00:CC92:  STA ram_0063  ; $0063
0x000CA4 nz-- 00:CC94:  LDA #$00  ; 
0x000CA6 nZ-- 00:CC96:  STA ram_0057  ; $0057
; 1 refs via 000CBF
0x000CA8 ---- 00:CC98:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x000CAB -z-- 00:CC9B:  LDY ram_0057  ; $0057
0x000CAD ---- 00:CC9D:  JSR $CC5C  ; 000C6C
; 1 refs via 000C9F
0x000CB0 ---- 00:CCA0:  LDA #$1D  ; 
0x000CB2 nz-- 00:CCA2:  SEC  ; 
0x000CB3 nzC- 00:CCA3:  SBC ram_0057  ; $0057
0x000CB5 ---- 00:CCA5:  TAY  ; 
0x000CB6 ---- 00:CCA6:  JSR $CC5C  ; 000C6C
; 1 refs via 000C9F
0x000CB9 ---- 00:CCA9:  INC ram_0057  ; $0057
0x000CBB ---- 00:CCAB:  LDA ram_0057  ; $0057
0x000CBD ---- 00:CCAD:  CMP #$10  ; 
0x000CBF ---- 00:CCAF:  BNE $CC98  ; 000CA8
0x000CC1 -Z-- 00:CCB1:  RTS  ; 000182
; 1 refs via 0001FC
0x000CC2 -Z-- 00:CCB2:  LDA #$00  ; 
0x000CC4 nZ-- 00:CCB4:  STA ram_0063  ; $0063
0x000CC6 nZ-- 00:CCB6:  LDA #$0F  ; 
0x000CC8 nz-- 00:CCB8:  STA ram_0057  ; $0057
; 1 refs via 000CE1
0x000CCA -z-- 00:CCBA:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x000CCD -z-- 00:CCBD:  LDY ram_0057  ; $0057
0x000CCF ---- 00:CCBF:  JSR $CC5C  ; 000C6C
; 1 refs via 000C9F
0x000CD2 ---- 00:CCC2:  LDA #$1D  ; 
0x000CD4 nz-- 00:CCC4:  SEC  ; 
0x000CD5 nzC- 00:CCC5:  SBC ram_0057  ; $0057
0x000CD7 ---- 00:CCC7:  TAY  ; 
0x000CD8 ---- 00:CCC8:  JSR $CC5C  ; 000C6C
; 1 refs via 000C9F
0x000CDB ---- 00:CCCB:  DEC ram_0057  ; $0057
0x000CDD ---- 00:CCCD:  LDA ram_0057  ; $0057
0x000CDF ---- 00:CCCF:  CMP #$FF  ; 
0x000CE1 ---- 00:CCD1:  BNE $CCBA  ; 000CCA
0x000CE3 -Z-- 00:CCD3:  RTS  ; 0001FF
; 1 refs via 000266
0x000CE4 -Z-- 00:CCD4:  JSR $CEF7  ; 000F07
; 1 refs via 0010C7
0x000CE7 -Z-- 00:CCD7:  LDX #$1E  ; 
0x000CE9 nz-- 00:CCD9:  JSR $D276  ; 001286
; 1 refs via 001293
0x000CEC -Z-- 00:CCDC:  LDA ram_0073  ; $0073
0x000CEE ---- 00:CCDE:  CLC  ; 
0x000CEF --c- 00:CCDF:  ADC ram_0074  ; $0074
0x000CF1 ---- 00:CCE1:  CLC  ; 
0x000CF2 --c- 00:CCE2:  ADC ram_0075  ; $0075
0x000CF4 ---- 00:CCE4:  CLC  ; 
0x000CF5 --c- 00:CCE5:  ADC ram_0076  ; $0076
0x000CF7 ---- 00:CCE7:  STA ram_007D  ; $007D
0x000CF9 ---- 00:CCE9:  LDA ram_0077  ; $0077
0x000CFB ---- 00:CCEB:  CLC  ; 
0x000CFC --c- 00:CCEC:  ADC ram_0078  ; $0078
0x000CFE ---- 00:CCEE:  CLC  ; 
0x000CFF --c- 00:CCEF:  ADC ram_0079  ; $0079
0x000D01 ---- 00:CCF1:  CLC  ; 
0x000D02 --c- 00:CCF2:  ADC ram_007A  ; $007A
0x000D04 ---- 00:CCF4:  STA ram_007E  ; $007E
0x000D06 ---- 00:CCF6:  LDA #$00  ; 
0x000D08 nZ-- 00:CCF8:  STA ram_005A  ; $005A
; 1 refs via 000E01
0x000D0A -Z-- 00:CCFA:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x000D0D -z-- 00:CCFD:  JSR $D0B8  ; 0010C8
; 1 refs via 0010E8
0x000D10 ---- 00:CD00:  LDX #$25  ; 
0x000D12 nz-- 00:CD02:  JSR $D9FE  ; 001A0E
; 1 refs via 001A22
0x000D15 Nz-- 00:CD05:  LDX #$2D  ; 
0x000D17 nz-- 00:CD07:  JSR $D9FE  ; 001A0E
; 1 refs via 001A22
0x000D1A Nz-- 00:CD0A:  LDA #$00  ; 
0x000D1C nZ-- 00:CD0C:  STA ram_005D  ; $005D
0x000D1E nZ-- 00:CD0E:  STA ram_005E  ; $005E
; 1 refs via 000DF1
0x000D20 ---- 00:CD10:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x000D23 -z-- 00:CD13:  JSR $D0B8  ; 0010C8
; 1 refs via 0010E8
0x000D26 ---- 00:CD16:  LDA #$00  ; 
0x000D28 nZ-- 00:CD18:  STA ram_007C  ; $007C
0x000D2A nZ-- 00:CD1A:  LDX ram_005A  ; $005A
0x000D2C ---- 00:CD1C:  LDA $D3D1,X  ; 0013E1 0013E2 0013E3 0013E4
0x000D2F ---- 00:CD1F:  JSR $D9E1  ; 0019F1
; 1 refs via 001A08
0x000D32 ---- 00:CD22:  LDX ram_005A  ; $005A
0x000D34 ---- 00:CD24:  LDA ram_0073,X  ; $0073 $0074 $0075 $0076
0x000D36 ---- 00:CD26:  BEQ $CD40  ; 000D50
0x000D38 -z-- 00:CD28:  LDA #$01  ; 
0x000D3A nz-- 00:CD2A:  STA ram_0313  ; $0313
0x000D3D nz-- 00:CD2D:  STA ram_0314  ; $0314
0x000D40 nz-- 00:CD30:  DEC ram_0073,X  ; $0073 $0074 $0075 $0076
0x000D42 ---- 00:CD32:  INC ram_005D  ; $005D
0x000D44 ---- 00:CD34:  LDX #$02  ; 
0x000D46 nz-- 00:CD36:  JSR $D9BE  ; 0019CE
; 1 refs via 0019F0
0x000D49 N--- 00:CD39:  LDA #$01  ; 
0x000D4B nz-- 00:CD3B:  STA ram_007C  ; $007C
0x000D4D nz-- 00:CD3D:  JSR $D138  ; 001148
; 2 refs via 000D36 001179
0x000D50 ---- 00:CD40:  LDX ram_005A  ; $005A
0x000D52 ---- 00:CD42:  LDA ram_0077,X  ; $0077 $0078 $0079 $007A
0x000D54 ---- 00:CD44:  BEQ $CD5E  ; 000D6E
0x000D56 -z-- 00:CD46:  LDA #$01  ; 
0x000D58 nz-- 00:CD48:  STA ram_0313  ; $0313
0x000D5B nz-- 00:CD4B:  STA ram_0314  ; $0314
0x000D5E nz-- 00:CD4E:  DEC ram_0077,X  ; $0078 $0079 $007A
0x000D60 ---- 00:CD50:  INC ram_005E  ; $005E
0x000D62 ---- 00:CD52:  LDX #$03  ; 
0x000D64 nz-- 00:CD54:  JSR $D9BE  ; 0019CE
; 1 refs via 0019F0
0x000D67 N--- 00:CD57:  LDA #$01  ; 
0x000D69 nz-- 00:CD59:  STA ram_007C  ; $007C
0x000D6B nz-- 00:CD5B:  JSR $D138  ; 001148
; 2 refs via 000D54 001179
0x000D6E ---- 00:CD5E:  LDY #$16  ; 
0x000D70 nz-- 00:CD60:  LDX #$05  ; 
0x000D72 nz-- 00:CD62:  JSR $D934  ; 001944
; 1 refs via 001960
0x000D75 nZ-- 00:CD65:  LDY #$09  ; 
0x000D77 nz-- 00:CD67:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x000D7A -Z-- 00:CD6A:  LDX #$01  ; 
0x000D7C nz-- 00:CD6C:  LDY #$26  ; 
0x000D7E nz-- 00:CD6E:  JSR $D934  ; 001944
; 1 refs via 001960
0x000D81 nZ-- 00:CD71:  LDA ram_005A  ; $005A
0x000D83 ---- 00:CD73:  ASL  ; 
0x000D84 ---- 00:CD74:  CLC  ; 
0x000D85 --c- 00:CD75:  ADC ram_005A  ; $005A
0x000D87 ---- 00:CD77:  CLC  ; 
0x000D88 --c- 00:CD78:  ADC #$0C  ; 
0x000D8A ---- 00:CD7A:  TAY  ; 
0x000D8B ---- 00:CD7B:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x000D8E -Z-- 00:CD7E:  LDX ram_005A  ; $005A
0x000D90 ---- 00:CD80:  LDA ram_005D  ; $005D
0x000D92 ---- 00:CD82:  JSR $DA13  ; 001A23
; 1 refs via 001A3A
0x000D95 --c- 00:CD85:  LDX #$08  ; 
0x000D97 nzc- 00:CD87:  LDY #$36  ; 
0x000D99 nzc- 00:CD89:  JSR $D934  ; 001944
; 1 refs via 001960
0x000D9C nZ-- 00:CD8C:  LDA ram_005A  ; $005A
0x000D9E ---- 00:CD8E:  ASL  ; 
0x000D9F ---- 00:CD8F:  CLC  ; 
0x000DA0 --c- 00:CD90:  ADC ram_005A  ; $005A
0x000DA2 ---- 00:CD92:  CLC  ; 
0x000DA3 --c- 00:CD93:  ADC #$0C  ; 
0x000DA5 ---- 00:CD95:  TAY  ; 
0x000DA6 ---- 00:CD96:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x000DA9 -Z-- 00:CD99:  LDA ram_0083  ; $0083
0x000DAB ---- 00:CD9B:  BEQ $CDD8  ; 000DE8
0x000DAD -z-- 00:CD9D:  LDY #$1E  ; 
0x000DAF nz-- 00:CD9F:  LDX #$17  ; 
0x000DB1 nz-- 00:CDA1:  JSR $D934  ; 001944
; 1 refs via 001960
0x000DB4 nZ-- 00:CDA4:  LDY #$09  ; 
0x000DB6 nz-- 00:CDA6:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x000DB9 -Z-- 00:CDA9:  LDX #$13  ; 
0x000DBB nz-- 00:CDAB:  LDY #$2E  ; 
0x000DBD nz-- 00:CDAD:  JSR $D934  ; 001944
; 1 refs via 001960
0x000DC0 nZ-- 00:CDB0:  LDA ram_005A  ; $005A
0x000DC2 ---- 00:CDB2:  ASL  ; 
0x000DC3 ---- 00:CDB3:  CLC  ; 
0x000DC4 --c- 00:CDB4:  ADC ram_005A  ; $005A
0x000DC6 ---- 00:CDB6:  CLC  ; 
0x000DC7 --c- 00:CDB7:  ADC #$0C  ; 
0x000DC9 ---- 00:CDB9:  TAY  ; 
0x000DCA ---- 00:CDBA:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x000DCD -Z-- 00:CDBD:  LDX ram_005A  ; $005A
0x000DCF ---- 00:CDBF:  LDA ram_005E  ; $005E
0x000DD1 ---- 00:CDC1:  JSR $DA13  ; 001A23
; 1 refs via 001A3A
0x000DD4 --c- 00:CDC4:  LDX #$0E  ; 
0x000DD6 nzc- 00:CDC6:  LDY #$36  ; 
0x000DD8 nzc- 00:CDC8:  JSR $D934  ; 001944
; 1 refs via 001960
0x000DDB nZ-- 00:CDCB:  LDA ram_005A  ; $005A
0x000DDD ---- 00:CDCD:  ASL  ; 
0x000DDE ---- 00:CDCE:  CLC  ; 
0x000DDF --c- 00:CDCF:  ADC ram_005A  ; $005A
0x000DE1 ---- 00:CDD1:  CLC  ; 
0x000DE2 --c- 00:CDD2:  ADC #$0C  ; 
0x000DE4 ---- 00:CDD4:  TAY  ; 
0x000DE5 ---- 00:CDD5:  JSR $D6DD  ; 0016ED
; 2 refs via 000DAB 001715
0x000DE8 -Z-- 00:CDD8:  LDX #$08  ; 
0x000DEA nz-- 00:CDDA:  JSR $D276  ; 001286
; 1 refs via 001293
0x000DED -Z-- 00:CDDD:  LDA ram_007C  ; $007C
0x000DEF ---- 00:CDDF:  BEQ $CDE4  ; 000DF4
0x000DF1 -z-- 00:CDE1:  JMP $CD10  ; 000D20
; 1 refs via 000DEF
0x000DF4 -Z-- 00:CDE4:  INC ram_005A  ; $005A
0x000DF6 ---- 00:CDE6:  LDA ram_005A  ; $005A
0x000DF8 ---- 00:CDE8:  CMP #$04  ; 
0x000DFA ---- 00:CDEA:  BEQ $CDF4  ; 000E04
0x000DFC -z-- 00:CDEC:  LDX #$14  ; 
0x000DFE nz-- 00:CDEE:  JSR $D276  ; 001286
; 1 refs via 001293
0x000E01 -Z-- 00:CDF1:  JMP $CCFA  ; 000D0A
; 1 refs via 000DFA
0x000E04 -Z-- 00:CDF4:  LDX #$1E  ; 
0x000E06 nz-- 00:CDF6:  JSR $D276  ; 001286
; 1 refs via 001293
0x000E09 -Z-- 00:CDF9:  LDA ram_007D  ; $007D
0x000E0B ---- 00:CDFB:  JSR $DA13  ; 001A23
; 1 refs via 001A3A
0x000E0E --c- 00:CDFE:  LDY #$36  ; 
0x000E10 nzc- 00:CE00:  LDX #$08  ; 
0x000E12 nzc- 00:CE02:  JSR $D934  ; 001944
; 1 refs via 001960
0x000E15 nZ-- 00:CE05:  LDY #$17  ; 
0x000E17 nz-- 00:CE07:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x000E1A -Z-- 00:CE0A:  LDA ram_0083  ; $0083
0x000E1C ---- 00:CE0C:  BEQ $CE1F  ; 000E2F
0x000E1E -z-- 00:CE0E:  LDA ram_007E  ; $007E
0x000E20 ---- 00:CE10:  JSR $DA13  ; 001A23
; 1 refs via 001A3A
0x000E23 --c- 00:CE13:  LDY #$36  ; 
0x000E25 nzc- 00:CE15:  LDX #$0E  ; 
0x000E27 nzc- 00:CE17:  JSR $D934  ; 001944
; 1 refs via 001960
0x000E2A nZ-- 00:CE1A:  LDY #$17  ; 
0x000E2C nz-- 00:CE1C:  JSR $D6DD  ; 0016ED
; 2 refs via 000E1C 001715
0x000E2F -Z-- 00:CE1F:  LDX #$0F  ; 
0x000E31 nz-- 00:CE21:  JSR $D276  ; 001286
; 1 refs via 001293
0x000E34 -Z-- 00:CE24:  LDA ram_0083  ; $0083
0x000E36 ---- 00:CE26:  BNE $CE2B  ; 000E3B
0x000E38 -Z-- 00:CE28:  JMP $CEE5  ; 000EF5
; 1 refs via 000E36
0x000E3B -z-- 00:CE2B:  LDA ram_0068  ; $0068
0x000E3D ---- 00:CE2D:  BNE $CE32  ; 000E42
0x000E3F -Z-- 00:CE2F:  JMP $CEE5  ; 000EF5
; 1 refs via 000E3D
0x000E42 -z-- 00:CE32:  LDA ram_007E  ; $007E
0x000E44 ---- 00:CE34:  CMP ram_007D  ; $007D
0x000E46 ---- 00:CE36:  BCS $CE8D  ; 000E9D
0x000E48 --c- 00:CE38:  LDA ram_0051  ; $0051
0x000E4A --c- 00:CE3A:  BEQ $CE8D  ; 000E9D
0x000E4C -zc- 00:CE3C:  LDA #$00  ; 
0x000E4E nZc- 00:CE3E:  JSR $D9E1  ; 0019F1
; 1 refs via 001A0D
0x000E51 nz-- 00:CE41:  LDX #$00  ; 
0x000E53 nZ-- 00:CE43:  JSR $D9BE  ; 0019CE
; 1 refs via 0019F0
0x000E56 N--- 00:CE46:  LDY #$16  ; 
0x000E58 nz-- 00:CE48:  LDX #$05  ; 
0x000E5A nz-- 00:CE4A:  JSR $D934  ; 001944
; 1 refs via 001960
0x000E5D nZ-- 00:CE4D:  LDY #$09  ; 
0x000E5F nz-- 00:CE4F:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x000E62 -Z-- 00:CE52:  LDY #$36  ; 
0x000E64 nz-- 00:CE54:  LDX #$01  ; 
0x000E66 nz-- 00:CE56:  JSR $D934  ; 001944
; 1 refs via 001960
0x000E69 nZ-- 00:CE59:  LDY #$1A  ; 
0x000E6B nz-- 00:CE5B:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x000E6E -Z-- 00:CE5E:  LDA #$D3  ; 
0x000E70 Nz-- 00:CE60:  STA ram_0012  ; $0012
0x000E72 Nz-- 00:CE62:  LDA #$C4  ; 
0x000E74 Nz-- 00:CE64:  STA ram_0011  ; $0011
0x000E76 Nz-- 00:CE66:  LDX #$03  ; 
0x000E78 nz-- 00:CE68:  LDY #$19  ; 
0x000E7A nz-- 00:CE6A:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000E7D -Z-- 00:CE6D:  LDA #$D3  ; 
0x000E7F Nz-- 00:CE6F:  STA ram_0012  ; $0012
0x000E81 Nz-- 00:CE71:  LDA #$5E  ; 
0x000E83 nz-- 00:CE73:  STA ram_0011  ; $0011
0x000E85 nz-- 00:CE75:  LDX #$08  ; 
0x000E87 nz-- 00:CE77:  LDY #$1A  ; 
0x000E89 nz-- 00:CE79:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000E8C -Z-- 00:CE7C:  LDA #$01  ; 
0x000E8E nz-- 00:CE7E:  STA ram_031B  ; $031B
0x000E91 nz-- 00:CE81:  STA ram_031C  ; $031C
0x000E94 nz-- 00:CE84:  STA ram_031D  ; $031D
0x000E97 nz-- 00:CE87:  JSR $D138  ; 001148
; 1 refs via 001179
0x000E9A ---- 00:CE8A:  JMP $CEE5  ; 000EF5
; 2 refs via 000E46 000E4A
0x000E9D ---- 00:CE8D:  LDA ram_007D  ; $007D
0x000E9F ---- 00:CE8F:  CMP ram_007E  ; $007E
0x000EA1 ---- 00:CE91:  BCS $CEE5  ; 000EF5
0x000EA3 --c- 00:CE93:  LDA ram_0052  ; $0052
0x000EA5 --c- 00:CE95:  BEQ $CEE5  ; 000EF5
0x000EA7 -zc- 00:CE97:  LDA #$00  ; 
0x000EA9 nZc- 00:CE99:  JSR $D9E1  ; 0019F1
; 1 refs via 001A0D
0x000EAC nz-- 00:CE9C:  LDX #$01  ; 
0x000EAE nz-- 00:CE9E:  JSR $D9BE  ; 0019CE
; 1 refs via 0019F0
0x000EB1 N--- 00:CEA1:  LDY #$1E  ; 
0x000EB3 nz-- 00:CEA3:  LDX #$17  ; 
0x000EB5 nz-- 00:CEA5:  JSR $D934  ; 001944
; 1 refs via 001960
0x000EB8 nZ-- 00:CEA8:  LDY #$09  ; 
0x000EBA nz-- 00:CEAA:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x000EBD -Z-- 00:CEAD:  LDY #$36  ; 
0x000EBF nz-- 00:CEAF:  LDX #$14  ; 
0x000EC1 nz-- 00:CEB1:  JSR $D934  ; 001944
; 1 refs via 001960
0x000EC4 nZ-- 00:CEB4:  LDY #$1A  ; 
0x000EC6 nz-- 00:CEB6:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x000EC9 -Z-- 00:CEB9:  LDA #$D3  ; 
0x000ECB Nz-- 00:CEBB:  STA ram_0012  ; $0012
0x000ECD Nz-- 00:CEBD:  LDA #$C4  ; 
0x000ECF Nz-- 00:CEBF:  STA ram_0011  ; $0011
0x000ED1 Nz-- 00:CEC1:  LDX #$16  ; 
0x000ED3 nz-- 00:CEC3:  LDY #$19  ; 
0x000ED5 nz-- 00:CEC5:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000ED8 -Z-- 00:CEC8:  LDA #$D3  ; 
0x000EDA Nz-- 00:CECA:  STA ram_0012  ; $0012
0x000EDC Nz-- 00:CECC:  LDA #$5E  ; 
0x000EDE nz-- 00:CECE:  STA ram_0011  ; $0011
0x000EE0 nz-- 00:CED0:  LDX #$1B  ; 
0x000EE2 nz-- 00:CED2:  LDY #$1A  ; 
0x000EE4 nz-- 00:CED4:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000EE7 -Z-- 00:CED7:  LDA #$01  ; 
0x000EE9 nz-- 00:CED9:  STA ram_031B  ; $031B
0x000EEC nz-- 00:CEDC:  STA ram_031C  ; $031C
0x000EEF nz-- 00:CEDF:  STA ram_031D  ; $031D
0x000EF2 nz-- 00:CEE2:  JSR $D138  ; 001148
; 6 refs via 000E38 000E3F 000E9A 000EA1 000EA5 001179
0x000EF5 ---- 00:CEE5:  LDX #$78  ; 
0x000EF7 nz-- 00:CEE7:  JSR $D276  ; 001286
; 1 refs via 001293
0x000EFA -Z-- 00:CEEA:  LDA #$00  ; 
0x000EFC nZ-- 00:CEEC:  STA ram_0050  ; $0050
0x000EFE nZ-- 00:CEEE:  STA ram_0060  ; $0060
0x000F00 nZ-- 00:CEF0:  STA ram_006B  ; $006B
0x000F02 nZ-- 00:CEF2:  LDA #$00  ; 
0x000F04 nZ-- 00:CEF4:  STA ram_004D  ; $004D
0x000F06 nZ-- 00:CEF6:  RTS  ; 000269
; 1 refs via 000CE4
0x000F07 -Z-- 00:CEF7:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x000F0A -z-- 00:CEFA:  LDA #$01  ; 
0x000F0C nz-- 00:CEFC:  STA ram_006B  ; $006B
0x000F0E nz-- 00:CEFE:  LDA #$24  ; 
0x000F10 nz-- 00:CF00:  STA ram_0005  ; $0005
0x000F12 nz-- 00:CF02:  LDA #$00  ; 
0x000F14 nZ-- 00:CF04:  STA ram_004F  ; $004F
0x000F16 nZ-- 00:CF06:  LDA #$02  ; 
0x000F18 nz-- 00:CF08:  STA ram_0050  ; $0050
0x000F1A nz-- 00:CF0A:  LDA #$30  ; 
0x000F1C nz-- 00:CF0C:  STA ram_0060  ; $0060
0x000F1E nz-- 00:CF0E:  LDA #$03  ; 
0x000F20 nz-- 00:CF10:  STA ram_004D  ; $004D
0x000F22 nz-- 00:CF12:  JSR $D470  ; 001480
; 1 refs via 00148D
0x000F25 nz-- 00:CF15:  JSR $D47E  ; 00148E
; 1 refs via 0014A0
0x000F28 -Z-- 00:CF18:  JSR $D0D9  ; 0010E9
; 1 refs via 00113F
0x000F2B nz-- 00:CF1B:  JSR $D7B4  ; 0017C4
; 1 refs via 0017DB
0x000F2E -Z-- 00:CF1E:  JSR $D467  ; 001477
; 1 refs via 00147F
0x000F31 Nz-- 00:CF21:  LDA #$D2  ; 
0x000F33 Nz-- 00:CF23:  STA ram_0012  ; $0012
0x000F35 Nz-- 00:CF25:  LDA #$BD  ; 
0x000F37 Nz-- 00:CF27:  STA ram_0011  ; $0011
0x000F39 Nz-- 00:CF29:  LDX #$08  ; 
0x000F3B nz-- 00:CF2B:  LDY #$03  ; 
0x000F3D nz-- 00:CF2D:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000F40 -Z-- 00:CF30:  LDY #$3E  ; 
0x000F42 nz-- 00:CF32:  LDX #$12  ; 
0x000F44 nz-- 00:CF34:  JSR $D934  ; 001944
; 1 refs via 001960
0x000F47 nZ-- 00:CF37:  LDY #$03  ; 
0x000F49 nz-- 00:CF39:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x000F4C -Z-- 00:CF3C:  LDA #$D3  ; 
0x000F4E Nz-- 00:CF3E:  STA ram_0012  ; $0012
0x000F50 Nz-- 00:CF40:  LDA #$CB  ; 
0x000F52 Nz-- 00:CF42:  STA ram_0011  ; $0011
0x000F54 Nz-- 00:CF44:  LDX #$0C  ; 
0x000F56 nz-- 00:CF46:  LDY #$05  ; 
0x000F58 nz-- 00:CF48:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000F5B -Z-- 00:CF4B:  LDA ram_0085  ; $0085
0x000F5D ---- 00:CF4D:  JSR $DA13  ; 001A23
; 1 refs via 001A3A
0x000F60 --c- 00:CF50:  LDY #$36  ; 
0x000F62 nzc- 00:CF52:  LDX #$0E  ; 
0x000F64 nzc- 00:CF54:  JSR $D934  ; 001944
; 1 refs via 001960
0x000F67 nZ-- 00:CF57:  LDY #$05  ; 
0x000F69 nz-- 00:CF59:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x000F6C -Z-- 00:CF5C:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x000F6F -z-- 00:CF5F:  LDA #$D2  ; 
0x000F71 Nz-- 00:CF61:  STA ram_0012  ; $0012
0x000F73 Nz-- 00:CF63:  LDA #$D9  ; 
0x000F75 Nz-- 00:CF65:  STA ram_0011  ; $0011
0x000F77 Nz-- 00:CF67:  LDX #$03  ; 
0x000F79 nz-- 00:CF69:  LDY #$07  ; 
0x000F7B nz-- 00:CF6B:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000F7E -Z-- 00:CF6E:  LDY #$16  ; 
0x000F80 nz-- 00:CF70:  LDX #$05  ; 
0x000F82 nz-- 00:CF72:  JSR $D934  ; 001944
; 1 refs via 001960
0x000F85 nZ-- 00:CF75:  LDY #$09  ; 
0x000F87 nz-- 00:CF77:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x000F8A -Z-- 00:CF7A:  LDA #$D3  ; 
0x000F8C Nz-- 00:CF7C:  STA ram_0012  ; $0012
0x000F8E Nz-- 00:CF7E:  LDA #$B1  ; 
0x000F90 Nz-- 00:CF80:  STA ram_0011  ; $0011
0x000F92 Nz-- 00:CF82:  LDX #$0E  ; 
0x000F94 nz-- 00:CF84:  LDY #$0C  ; 
0x000F96 nz-- 00:CF86:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000F99 -Z-- 00:CF89:  LDA #$D3  ; 
0x000F9B Nz-- 00:CF8B:  STA ram_0012  ; $0012
0x000F9D Nz-- 00:CF8D:  LDA #$B1  ; 
0x000F9F Nz-- 00:CF8F:  STA ram_0011  ; $0011
0x000FA1 Nz-- 00:CF91:  LDX #$0E  ; 
0x000FA3 nz-- 00:CF93:  LDY #$0F  ; 
0x000FA5 nz-- 00:CF95:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000FA8 -Z-- 00:CF98:  LDA #$D3  ; 
0x000FAA Nz-- 00:CF9A:  STA ram_0012  ; $0012
0x000FAC Nz-- 00:CF9C:  LDA #$B1  ; 
0x000FAE Nz-- 00:CF9E:  STA ram_0011  ; $0011
0x000FB0 Nz-- 00:CFA0:  LDX #$0E  ; 
0x000FB2 nz-- 00:CFA2:  LDY #$12  ; 
0x000FB4 nz-- 00:CFA4:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000FB7 -Z-- 00:CFA7:  LDA #$D3  ; 
0x000FB9 Nz-- 00:CFA9:  STA ram_0012  ; $0012
0x000FBB Nz-- 00:CFAB:  LDA #$B1  ; 
0x000FBD Nz-- 00:CFAD:  STA ram_0011  ; $0011
0x000FBF Nz-- 00:CFAF:  LDX #$0E  ; 
0x000FC1 nz-- 00:CFB1:  LDY #$15  ; 
0x000FC3 nz-- 00:CFB3:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000FC6 -Z-- 00:CFB6:  LDA ram_0083  ; $0083
0x000FC8 ---- 00:CFB8:  BEQ $D014  ; 001024
0x000FCA -z-- 00:CFBA:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x000FCD -z-- 00:CFBD:  LDA #$D2  ; 
0x000FCF Nz-- 00:CFBF:  STA ram_0012  ; $0012
0x000FD1 Nz-- 00:CFC1:  LDA #$E2  ; 
0x000FD3 Nz-- 00:CFC3:  STA ram_0011  ; $0011
0x000FD5 Nz-- 00:CFC5:  LDX #$15  ; 
0x000FD7 nz-- 00:CFC7:  LDY #$07  ; 
0x000FD9 nz-- 00:CFC9:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000FDC -Z-- 00:CFCC:  LDY #$1E  ; 
0x000FDE nz-- 00:CFCE:  LDX #$17  ; 
0x000FE0 nz-- 00:CFD0:  JSR $D934  ; 001944
; 1 refs via 001960
0x000FE3 nZ-- 00:CFD3:  LDY #$09  ; 
0x000FE5 nz-- 00:CFD5:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x000FE8 -Z-- 00:CFD8:  LDA #$D3  ; 
0x000FEA Nz-- 00:CFDA:  STA ram_0012  ; $0012
0x000FEC Nz-- 00:CFDC:  LDA #$B3  ; 
0x000FEE Nz-- 00:CFDE:  STA ram_0011  ; $0011
0x000FF0 Nz-- 00:CFE0:  LDX #$11  ; 
0x000FF2 nz-- 00:CFE2:  LDY #$0C  ; 
0x000FF4 nz-- 00:CFE4:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x000FF7 -Z-- 00:CFE7:  LDA #$D3  ; 
0x000FF9 Nz-- 00:CFE9:  STA ram_0012  ; $0012
0x000FFB Nz-- 00:CFEB:  LDA #$B3  ; 
0x000FFD Nz-- 00:CFED:  STA ram_0011  ; $0011
0x000FFF Nz-- 00:CFEF:  LDX #$11  ; 
0x001001 nz-- 00:CFF1:  LDY #$0F  ; 
0x001003 nz-- 00:CFF3:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x001006 -Z-- 00:CFF6:  LDA #$D3  ; 
0x001008 Nz-- 00:CFF8:  STA ram_0012  ; $0012
0x00100A Nz-- 00:CFFA:  LDA #$B3  ; 
0x00100C Nz-- 00:CFFC:  STA ram_0011  ; $0011
0x00100E Nz-- 00:CFFE:  LDX #$11  ; 
0x001010 nz-- 00:D000:  LDY #$12  ; 
0x001012 nz-- 00:D002:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x001015 -Z-- 00:D005:  LDA #$D3  ; 
0x001017 Nz-- 00:D007:  STA ram_0012  ; $0012
0x001019 Nz-- 00:D009:  LDA #$B3  ; 
0x00101B Nz-- 00:D00B:  STA ram_0011  ; $0011
0x00101D Nz-- 00:D00D:  LDX #$11  ; 
0x00101F nz-- 00:D00F:  LDY #$15  ; 
0x001021 nz-- 00:D011:  JSR $D6B3  ; 0016C3
; 2 refs via 000FC8 0016EC
0x001024 -Z-- 00:D014:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x001027 -z-- 00:D017:  LDA #$D3  ; 
0x001029 Nz-- 00:D019:  STA ram_0012  ; $0012
0x00102B Nz-- 00:D01B:  LDA #$5E  ; 
0x00102D nz-- 00:D01D:  STA ram_0011  ; $0011
0x00102F nz-- 00:D01F:  LDX #$08  ; 
0x001031 nz-- 00:D021:  LDY #$0C  ; 
0x001033 nz-- 00:D023:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x001036 -Z-- 00:D026:  LDA #$D3  ; 
0x001038 Nz-- 00:D028:  STA ram_0012  ; $0012
0x00103A Nz-- 00:D02A:  LDA #$5E  ; 
0x00103C nz-- 00:D02C:  STA ram_0011  ; $0011
0x00103E nz-- 00:D02E:  LDX #$08  ; 
0x001040 nz-- 00:D030:  LDY #$0F  ; 
0x001042 nz-- 00:D032:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x001045 -Z-- 00:D035:  LDA #$D3  ; 
0x001047 Nz-- 00:D037:  STA ram_0012  ; $0012
0x001049 Nz-- 00:D039:  LDA #$5E  ; 
0x00104B nz-- 00:D03B:  STA ram_0011  ; $0011
0x00104D nz-- 00:D03D:  LDX #$08  ; 
0x00104F nz-- 00:D03F:  LDY #$12  ; 
0x001051 nz-- 00:D041:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x001054 -Z-- 00:D044:  LDA #$D3  ; 
0x001056 Nz-- 00:D046:  STA ram_0012  ; $0012
0x001058 Nz-- 00:D048:  LDA #$5E  ; 
0x00105A nz-- 00:D04A:  STA ram_0011  ; $0011
0x00105C nz-- 00:D04C:  LDX #$08  ; 
0x00105E nz-- 00:D04E:  LDY #$15  ; 
0x001060 nz-- 00:D050:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x001063 -Z-- 00:D053:  LDA ram_0083  ; $0083
0x001065 ---- 00:D055:  BEQ $D096  ; 0010A6
0x001067 -z-- 00:D057:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x00106A -z-- 00:D05A:  LDA #$D3  ; 
0x00106C Nz-- 00:D05C:  STA ram_0012  ; $0012
0x00106E Nz-- 00:D05E:  LDA #$5E  ; 
0x001070 nz-- 00:D060:  STA ram_0011  ; $0011
0x001072 nz-- 00:D062:  LDX #$1A  ; 
0x001074 nz-- 00:D064:  LDY #$0C  ; 
0x001076 nz-- 00:D066:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x001079 -Z-- 00:D069:  LDA #$D3  ; 
0x00107B Nz-- 00:D06B:  STA ram_0012  ; $0012
0x00107D Nz-- 00:D06D:  LDA #$5E  ; 
0x00107F nz-- 00:D06F:  STA ram_0011  ; $0011
0x001081 nz-- 00:D071:  LDX #$1A  ; 
0x001083 nz-- 00:D073:  LDY #$0F  ; 
0x001085 nz-- 00:D075:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x001088 -Z-- 00:D078:  LDA #$D3  ; 
0x00108A Nz-- 00:D07A:  STA ram_0012  ; $0012
0x00108C Nz-- 00:D07C:  LDA #$5E  ; 
0x00108E nz-- 00:D07E:  STA ram_0011  ; $0011
0x001090 nz-- 00:D080:  LDX #$1A  ; 
0x001092 nz-- 00:D082:  LDY #$12  ; 
0x001094 nz-- 00:D084:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x001097 -Z-- 00:D087:  LDA #$D3  ; 
0x001099 Nz-- 00:D089:  STA ram_0012  ; $0012
0x00109B Nz-- 00:D08B:  LDA #$5E  ; 
0x00109D nz-- 00:D08D:  STA ram_0011  ; $0011
0x00109F nz-- 00:D08F:  LDX #$1A  ; 
0x0010A1 nz-- 00:D091:  LDY #$15  ; 
0x0010A3 nz-- 00:D093:  JSR $D6B3  ; 0016C3
; 2 refs via 001065 0016EC
0x0010A6 -Z-- 00:D096:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x0010A9 -z-- 00:D099:  LDA #$D3  ; 
0x0010AB Nz-- 00:D09B:  STA ram_0012  ; $0012
0x0010AD Nz-- 00:D09D:  LDA #$BB  ; 
0x0010AF Nz-- 00:D09F:  STA ram_0011  ; $0011
0x0010B1 Nz-- 00:D0A1:  LDX #$0C  ; 
0x0010B3 nz-- 00:D0A3:  LDY #$16  ; 
0x0010B5 nz-- 00:D0A5:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x0010B8 -Z-- 00:D0A8:  LDA #$D3  ; 
0x0010BA Nz-- 00:D0AA:  STA ram_0012  ; $0012
0x0010BC Nz-- 00:D0AC:  LDA #$B5  ; 
0x0010BE Nz-- 00:D0AE:  STA ram_0011  ; $0011
0x0010C0 Nz-- 00:D0B0:  LDX #$06  ; 
0x0010C2 nz-- 00:D0B2:  LDY #$17  ; 
0x0010C4 nz-- 00:D0B4:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x0010C7 -Z-- 00:D0B7:  RTS  ; 000CE7
; 3 refs via 000D0D 000D23 00128B
0x0010C8 ---- 00:D0B8:  LDA #$02  ; 
0x0010CA nz-- 00:D0BA:  STA ram_0004  ; $0004
0x0010CC nz-- 00:D0BC:  LDY #$64  ; 
0x0010CE nz-- 00:D0BE:  LDA #$80  ; 
0x0010D0 Nz-- 00:D0C0:  JSR $D130  ; 001140
; 1 refs via 001147
0x0010D3 ---- 00:D0C3:  LDY #$7C  ; 
0x0010D5 nz-- 00:D0C5:  LDA #$A0  ; 
0x0010D7 Nz-- 00:D0C7:  JSR $D130  ; 001140
; 1 refs via 001147
0x0010DA ---- 00:D0CA:  LDY #$94  ; 
0x0010DC Nz-- 00:D0CC:  LDA #$C0  ; 
0x0010DE Nz-- 00:D0CE:  JSR $D130  ; 001140
; 1 refs via 001147
0x0010E1 ---- 00:D0D1:  LDY #$AC  ; 
0x0010E3 Nz-- 00:D0D3:  LDA #$E0  ; 
0x0010E5 Nz-- 00:D0D5:  JSR $D130  ; 001140
; 1 refs via 001147
0x0010E8 ---- 00:D0D8:  RTS  ; 000D10 000D26 00128E
; 1 refs via 000F28
0x0010E9 -Z-- 00:D0D9:  LDA #$50  ; 
0x0010EB nz-- 00:D0DB:  STA ram_07C0  ; $07C0
0x0010EE nz-- 00:D0DE:  STA ram_07C1  ; $07C1
0x0010F1 nz-- 00:D0E1:  STA ram_07C2  ; $07C2
0x0010F4 nz-- 00:D0E4:  STA ram_07C3  ; $07C3
0x0010F7 nz-- 00:D0E7:  STA ram_07C8  ; $07C8
0x0010FA nz-- 00:D0EA:  STA ram_07C9  ; $07C9
0x0010FD nz-- 00:D0ED:  STA ram_07CA  ; $07CA
0x001100 nz-- 00:D0F0:  STA ram_07CD  ; $07CD
0x001103 nz-- 00:D0F3:  STA ram_07CE  ; $07CE
0x001106 nz-- 00:D0F6:  STA ram_07CF  ; $07CF
0x001109 nz-- 00:D0F9:  LDA #$A0  ; 
0x00110B Nz-- 00:D0FB:  STA ram_07C4  ; $07C4
0x00110E Nz-- 00:D0FE:  STA ram_07C5  ; $07C5
0x001111 Nz-- 00:D101:  STA ram_07C6  ; $07C6
0x001114 Nz-- 00:D104:  STA ram_07C7  ; $07C7
0x001117 Nz-- 00:D107:  LDA #$0A  ; 
0x001119 nz-- 00:D109:  STA ram_07D0  ; $07D0
0x00111C nz-- 00:D10C:  STA ram_07D1  ; $07D1
0x00111F nz-- 00:D10F:  STA ram_07D2  ; $07D2
0x001122 nz-- 00:D112:  STA ram_07D5  ; $07D5
0x001125 nz-- 00:D115:  STA ram_07D6  ; $07D6
0x001128 nz-- 00:D118:  STA ram_07D7  ; $07D7
0x00112B nz-- 00:D11B:  LDA #$05  ; 
0x00112D nz-- 00:D11D:  STA ram_07F0  ; $07F0
0x001130 nz-- 00:D120:  STA ram_07F1  ; $07F1
0x001133 nz-- 00:D123:  STA ram_07F2  ; $07F2
0x001136 nz-- 00:D126:  STA ram_07F5  ; $07F5
0x001139 nz-- 00:D129:  STA ram_07F6  ; $07F6
0x00113C nz-- 00:D12C:  STA ram_07F7  ; $07F7
0x00113F nz-- 00:D12F:  RTS  ; 000F2B
; 4 refs via 0010D0 0010D7 0010DE 0010E5
0x001140 Nz-- 00:D130:  STA ram_0053  ; $0053
0x001142 Nz-- 00:D132:  LDX #$81  ; 
0x001144 Nz-- 00:D134:  JSR $DA7B  ; 001A8B
; 1 refs via 001AA2
0x001147 ---- 00:D137:  RTS  ; 0010D3 0010DA 0010E1 0010E8
; 6 refs via 000D4D 000D6B 000E97 000EF2 002837 0029D0
0x001148 ---- 00:D138:  LDA ram_0068  ; $0068
0x00114A ---- 00:D13A:  CMP #$80  ; 
0x00114C ---- 00:D13C:  BNE $D169  ; 001179
0x00114E -Z-- 00:D13E:  LDA ram_0066  ; $0066
0x001150 ---- 00:D140:  BNE $D14F  ; 00115F
0x001152 -Z-- 00:D142:  LDA ram_0017  ; $0017
0x001154 ---- 00:D144:  CMP #$02  ; 
0x001156 ---- 00:D146:  BCC $D14F  ; 00115F
0x001158 --C- 00:D148:  INC ram_0051  ; $0051
0x00115A --C- 00:D14A:  INC ram_0066  ; $0066
0x00115C --C- 00:D14C:  JMP $D161  ; 001171
; 2 refs via 001150 001156
0x00115F ---- 00:D14F:  LDA ram_0083  ; $0083
0x001161 ---- 00:D151:  BEQ $D169  ; 001179
0x001163 -z-- 00:D153:  LDA ram_0067  ; $0067
0x001165 ---- 00:D155:  BNE $D169  ; 001179
0x001167 -Z-- 00:D157:  LDA ram_001F  ; $001F
0x001169 ---- 00:D159:  CMP #$02  ; 
0x00116B ---- 00:D15B:  BCC $D169  ; 001179
0x00116D --C- 00:D15D:  INC ram_0052  ; $0052
0x00116F --C- 00:D15F:  INC ram_0067  ; $0067
; 1 refs via 00115C
0x001171 --C- 00:D161:  LDA #$01  ; 
0x001173 nzC- 00:D163:  STA ram_0304  ; $0304
0x001176 nzC- 00:D166:  STA ram_0305  ; $0305
; 4 refs via 00114C 001161 001165 00116B
0x001179 ---- 00:D169:  RTS  ; 000D50 000D6E 000E9A 000EF5 00283A 0029D3
; 1 refs via 0000AC
0x00117A nZ-- 00:D16A:  JSR $D470  ; 001480
; 1 refs via 00148D
0x00117D nz-- 00:D16D:  LDA #$03  ; 
0x00117F nz-- 00:D16F:  STA ram_004D  ; $004D
0x001181 nz-- 00:D171:  LDA #$1C  ; 
0x001183 nz-- 00:D173:  STA ram_0005  ; $0005
0x001185 nz-- 00:D175:  JSR $D47E  ; 00148E
; 1 refs via 0014A0
0x001188 -Z-- 00:D178:  JSR $D7B4  ; 0017C4
; 1 refs via 0017DB
0x00118B -Z-- 00:D17B:  JSR $D467  ; 001477
; 1 refs via 00147F
0x00118E Nz-- 00:D17E:  RTS  ; 0000AF
; 1 refs via 0000A5
0x00118F ---- 00:D17F:  JSR $D470  ; 001480
; 1 refs via 00148D
0x001192 nz-- 00:D182:  LDA #$24  ; 
0x001194 nz-- 00:D184:  STA ram_0005  ; $0005
0x001196 nz-- 00:D186:  JSR $D47E  ; 00148E
; 1 refs via 0014A0
0x001199 -Z-- 00:D189:  LDX #$1A  ; 
0x00119B nz-- 00:D18B:  STX ram_0056  ; $0056
0x00119D nz-- 00:D18D:  LDY #$2E  ; 
0x00119F nz-- 00:D18F:  STY ram_0057  ; $0057
0x0011A1 nz-- 00:D191:  LDA #$D2  ; 
0x0011A3 Nz-- 00:D193:  STA ram_0014  ; $0014
0x0011A5 Nz-- 00:D195:  LDA #$99  ; 
0x0011A7 Nz-- 00:D197:  STA ram_0013  ; $0013
0x0011A9 Nz-- 00:D199:  JSR $D8D2  ; 0018E2
; 1 refs via 001905
0x0011AC -Z-- 00:D19C:  LDX #$3C  ; 
0x0011AE nz-- 00:D19E:  STX ram_0056  ; $0056
0x0011B0 nz-- 00:D1A0:  LDY #$56  ; 
0x0011B2 nz-- 00:D1A2:  STY ram_0057  ; $0057
0x0011B4 nz-- 00:D1A4:  LDA #$D2  ; 
0x0011B6 Nz-- 00:D1A6:  STA ram_0014  ; $0014
0x0011B8 Nz-- 00:D1A8:  LDA #$A0  ; 
0x0011BA Nz-- 00:D1AA:  STA ram_0013  ; $0013
0x0011BC Nz-- 00:D1AC:  JSR $D8D2  ; 0018E2
; 1 refs via 001905
0x0011BF -Z-- 00:D1AF:  JSR $D7B4  ; 0017C4
; 1 refs via 0017DB
0x0011C2 -Z-- 00:D1B2:  JSR $D467  ; 001477
; 1 refs via 00147F
0x0011C5 Nz-- 00:D1B5:  LDA #$30  ; 
0x0011C7 nz-- 00:D1B7:  STA ram_0060  ; $0060
0x0011C9 nz-- 00:D1B9:  LDA #$D2  ; 
0x0011CB Nz-- 00:D1BB:  STA ram_0012  ; $0012
0x0011CD Nz-- 00:D1BD:  LDA #$A5  ; 
0x0011CF Nz-- 00:D1BF:  STA ram_0011  ; $0011
0x0011D1 Nz-- 00:D1C1:  LDX #$02  ; 
0x0011D3 nz-- 00:D1C3:  LDY #$03  ; 
0x0011D5 nz-- 00:D1C5:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x0011D8 -Z-- 00:D1C8:  LDY #$16  ; 
0x0011DA nz-- 00:D1CA:  LDX #$04  ; 
0x0011DC nz-- 00:D1CC:  JSR $D934  ; 001944
; 1 refs via 001960
0x0011DF nZ-- 00:D1CF:  LDY #$03  ; 
0x0011E1 nz-- 00:D1D1:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x0011E4 -Z-- 00:D1D4:  LDA #$D2  ; 
0x0011E6 Nz-- 00:D1D6:  STA ram_0012  ; $0012
0x0011E8 Nz-- 00:D1D8:  LDA #$B1  ; 
0x0011EA Nz-- 00:D1DA:  STA ram_0011  ; $0011
0x0011EC Nz-- 00:D1DC:  LDX #$0B  ; 
0x0011EE nz-- 00:D1DE:  LDY #$03  ; 
0x0011F0 nz-- 00:D1E0:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x0011F3 -Z-- 00:D1E3:  LDY #$3E  ; 
0x0011F5 nz-- 00:D1E5:  LDX #$0E  ; 
0x0011F7 nz-- 00:D1E7:  JSR $D934  ; 001944
; 1 refs via 001960
0x0011FA nZ-- 00:D1EA:  LDY #$03  ; 
0x0011FC nz-- 00:D1EC:  JSR $D6DD  ; 0016ED
; 1 refs via 001715
0x0011FF -Z-- 00:D1EF:  LDA ram_0083  ; $0083
0x001201 ---- 00:D1F1:  BEQ $D20E  ; 00121E
0x001203 -z-- 00:D1F3:  LDA #$D2  ; 
0x001205 Nz-- 00:D1F5:  STA ram_0012  ; $0012
0x001207 Nz-- 00:D1F7:  LDA #$A8  ; 
0x001209 Nz-- 00:D1F9:  STA ram_0011  ; $0011
0x00120B Nz-- 00:D1FB:  LDX #$15  ; 
0x00120D nz-- 00:D1FD:  LDY #$03  ; 
0x00120F nz-- 00:D1FF:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x001212 -Z-- 00:D202:  LDY #$1E  ; 
0x001214 nz-- 00:D204:  LDX #$17  ; 
0x001216 nz-- 00:D206:  JSR $D934  ; 001944
; 1 refs via 001960
0x001219 nZ-- 00:D209:  LDY #$03  ; 
0x00121B nz-- 00:D20B:  JSR $D6DD  ; 0016ED
; 2 refs via 001201 001715
0x00121E -Z-- 00:D20E:  LDA #$00  ; 
0x001220 nZ-- 00:D210:  STA ram_0060  ; $0060
0x001222 nZ-- 00:D212:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x001225 -z-- 00:D215:  LDA #$D2  ; 
0x001227 Nz-- 00:D217:  STA ram_0012  ; $0012
0x001229 Nz-- 00:D219:  LDA #$C6  ; 
0x00122B Nz-- 00:D21B:  STA ram_0011  ; $0011
0x00122D Nz-- 00:D21D:  LDX #$0B  ; 
0x00122F nz-- 00:D21F:  LDY #$11  ; 
0x001231 nz-- 00:D221:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x001234 -Z-- 00:D224:  LDA #$D2  ; 
0x001236 Nz-- 00:D226:  STA ram_0012  ; $0012
0x001238 Nz-- 00:D228:  LDA #$CF  ; 
0x00123A Nz-- 00:D22A:  STA ram_0011  ; $0011
0x00123C Nz-- 00:D22C:  LDX #$0B  ; 
0x00123E nz-- 00:D22E:  LDY #$13  ; 
0x001240 nz-- 00:D230:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x001243 -Z-- 00:D233:  LDA #$D2  ; 
0x001245 Nz-- 00:D235:  STA ram_0012  ; $0012
0x001247 Nz-- 00:D237:  LDA #$EB  ; 
0x001249 Nz-- 00:D239:  STA ram_0011  ; $0011
0x00124B Nz-- 00:D23B:  LDX #$0B  ; 
0x00124D nz-- 00:D23D:  LDY #$15  ; 
0x00124F nz-- 00:D23F:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x001252 -Z-- 00:D242:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x001255 -z-- 00:D245:  LDA #$D2  ; 
0x001257 Nz-- 00:D247:  STA ram_0012  ; $0012
0x001259 Nz-- 00:D249:  LDA #$8F  ; 
0x00125B Nz-- 00:D24B:  STA ram_0011  ; $0011
0x00125D Nz-- 00:D24D:  LDX #$0B  ; 
0x00125F nz-- 00:D24F:  LDY #$17  ; 
0x001261 nz-- 00:D251:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x001264 -Z-- 00:D254:  LDA #$D2  ; 
0x001266 Nz-- 00:D256:  STA ram_0012  ; $0012
0x001268 Nz-- 00:D258:  LDA #$F8  ; 
0x00126A Nz-- 00:D25A:  STA ram_0011  ; $0011
0x00126C Nz-- 00:D25C:  LDX #$04  ; 
0x00126E nz-- 00:D25E:  LDY #$19  ; 
0x001270 nz-- 00:D260:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x001273 -Z-- 00:D263:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x001276 -z-- 00:D266:  LDA #$D3  ; 
0x001278 Nz-- 00:D268:  STA ram_0012  ; $0012
0x00127A Nz-- 00:D26A:  LDA #$20  ; 
0x00127C nz-- 00:D26C:  STA ram_0011  ; $0011
0x00127E nz-- 00:D26E:  LDX #$06  ; 
0x001280 nz-- 00:D270:  LDY #$1B  ; 
0x001282 nz-- 00:D272:  JSR $D6B3  ; 0016C3
; 1 refs via 0016EC
0x001285 -Z-- 00:D275:  RTS  ; 0000A8
; 7 refs via 000CE9 000DEA 000DFE 000E06 000E31 000EF7 001291
0x001286 -z-- 00:D276:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x001289 -z-- 00:D279:  TXA  ; 
0x00128A ---- 00:D27A:  PHA  ; 
0x00128B ---- 00:D27B:  JSR $D0B8  ; 0010C8
; 1 refs via 0010E8
0x00128E ---- 00:D27E:  PLA  ; 
0x00128F ---- 00:D27F:  TAX  ; 
0x001290 ---- 00:D280:  DEX  ; 
0x001291 ---- 00:D281:  BNE $D276  ; 001286
0x001293 -Z-- 00:D283:  RTS  ; 000CEC 000DED 000E01 000E09 000E34 000EFA
0x001294 ---- 00:D284:  .byte $57   ; 0016DA
0x001295 ---- 00:D285:  .byte $52   ; 0016DA
0x001296 ---- 00:D286:  .byte $49   ; 0016DA
0x001297 ---- 00:D287:  .byte $54   ; 0016DA
0x001298 ---- 00:D288:  .byte $54   ; 0016DA
0x001299 ---- 00:D289:  .byte $45   ; 0016DA
0x00129A ---- 00:D28A:  .byte $4E   ; 0016DA
0x00129B ---- 00:D28B:  .byte $20   ; 0016DA
0x00129C ---- 00:D28C:  .byte $42   ; 0016DA
0x00129D ---- 00:D28D:  .byte $59   ; 0016DA
0x00129E ---- 00:D28E:  .byte $FF   ; 0016DA
0x00129F ---- 00:D28F:  .byte $60   ; 0016DA
0x0012A0 ---- 00:D290:  .byte $61   ; 0016DA
0x0012A1 ---- 00:D291:  .byte $62   ; 0016DA
0x0012A2 ---- 00:D292:  .byte $63   ; 0016DA
0x0012A3 ---- 00:D293:  .byte $64   ; 0016DA
0x0012A4 ---- 00:D294:  .byte $65   ; 0016DA
0x0012A5 ---- 00:D295:  .byte $66   ; 0016DA
0x0012A6 ---- 00:D296:  .byte $67   ; 0016DA
0x0012A7 ---- 00:D297:  .byte $68   ; 0016DA
0x0012A8 ---- 00:D298:  .byte $FF   ; 0016DA
0x0012A9 ---- 00:D299:  .byte $42   ; 0018E6
0x0012AA ---- 00:D29A:  .byte $41   ; 0018E6
0x0012AB ---- 00:D29B:  .byte $54   ; 0018E6
0x0012AC ---- 00:D29C:  .byte $54   ; 0018E6
0x0012AD ---- 00:D29D:  .byte $4C   ; 0018E6
0x0012AE ---- 00:D29E:  .byte $45   ; 0018E6
0x0012AF ---- 00:D29F:  .byte $FF   ; 0018E6
0x0012B0 ---- 00:D2A0:  .byte $43   ; 0018E6
0x0012B1 ---- 00:D2A1:  .byte $49   ; 0018E6
0x0012B2 ---- 00:D2A2:  .byte $54   ; 0018E6
0x0012B3 ---- 00:D2A3:  .byte $59   ; 0018E6
0x0012B4 ---- 00:D2A4:  .byte $FF   ; 0018E6
0x0012B5 ---- 00:D2A5:  .byte $5E   ; 0016DA
0x0012B6 ---- 00:D2A6:  .byte $6B   ; 0016DA
0x0012B7 ---- 00:D2A7:  .byte $FF   ; 0016DA
0x0012B8 ---- 00:D2A8:  .byte $5F   ; 0016DA
0x0012B9 ---- 00:D2A9:  .byte $6B   ; 0016DA
0x0012BA ---- 00:D2AA:  .byte $FF   ; 0016DA
0x0012BB ---- 00:D2AB:  .byte $58   ; 0016DA
0x0012BC ---- 00:D2AC:  .byte $13   ; 0016DA
0x0012BD ---- 00:D2AD:  .byte $FF   ; 0016DA
0x0012BE ---- 00:D2AE:  .byte $5A   ; 0016DA
0x0012BF ---- 00:D2AF:  .byte $13   ; 0016DA
0x0012C0 ---- 00:D2B0:  .byte $FF   ; 0016DA
0x0012C1 ---- 00:D2B1:  .byte $48   ; 0016DA
0x0012C2 ---- 00:D2B2:  .byte $49   ; 0016DA
0x0012C3 ---- 00:D2B3:  .byte $6B   ; 0016DA
0x0012C4 ---- 00:D2B4:  .byte $FF   ; 0016DA
0x0012C5 ---- 00:D2B5:  .byte $48   ; 0018E6
0x0012C6 ---- 00:D2B6:  .byte $49   ; 0018E6
0x0012C7 ---- 00:D2B7:  .byte $53   ; 0018E6
0x0012C8 ---- 00:D2B8:  .byte $43   ; 0018E6
0x0012C9 ---- 00:D2B9:  .byte $4F   ; 0018E6
0x0012CA ---- 00:D2BA:  .byte $52   ; 0018E6
0x0012CB ---- 00:D2BB:  .byte $45   ; 0018E6
0x0012CC ---- 00:D2BC:  .byte $FF   ; 0018E6
0x0012CD ---- 00:D2BD:  .byte $48   ; 0016DA
0x0012CE ---- 00:D2BE:  .byte $49   ; 0016DA
0x0012CF ---- 00:D2BF:  .byte $6B   ; 0016DA
0x0012D0 ---- 00:D2C0:  .byte $53   ; 0016DA
0x0012D1 ---- 00:D2C1:  .byte $43   ; 0016DA
0x0012D2 ---- 00:D2C2:  .byte $4F   ; 0016DA
0x0012D3 ---- 00:D2C3:  .byte $52   ; 0016DA
0x0012D4 ---- 00:D2C4:  .byte $45   ; 0016DA
0x0012D5 ---- 00:D2C5:  .byte $FF   ; 0016DA
0x0012D6 ---- 00:D2C6:  .byte $31   ; 0016DA
0x0012D7 ---- 00:D2C7:  .byte $20   ; 0016DA
0x0012D8 ---- 00:D2C8:  .byte $50   ; 0016DA
0x0012D9 ---- 00:D2C9:  .byte $4C   ; 0016DA
0x0012DA ---- 00:D2CA:  .byte $41   ; 0016DA
0x0012DB ---- 00:D2CB:  .byte $59   ; 0016DA
0x0012DC ---- 00:D2CC:  .byte $45   ; 0016DA
0x0012DD ---- 00:D2CD:  .byte $52   ; 0016DA
0x0012DE ---- 00:D2CE:  .byte $FF   ; 0016DA
0x0012DF ---- 00:D2CF:  .byte $32   ; 0016DA
0x0012E0 ---- 00:D2D0:  .byte $20   ; 0016DA
0x0012E1 ---- 00:D2D1:  .byte $50   ; 0016DA
0x0012E2 ---- 00:D2D2:  .byte $4C   ; 0016DA
0x0012E3 ---- 00:D2D3:  .byte $41   ; 0016DA
0x0012E4 ---- 00:D2D4:  .byte $59   ; 0016DA
0x0012E5 ---- 00:D2D5:  .byte $45   ; 0016DA
0x0012E6 ---- 00:D2D6:  .byte $52   ; 0016DA
0x0012E7 ---- 00:D2D7:  .byte $53   ; 0016DA
0x0012E8 ---- 00:D2D8:  .byte $FF   ; 0016DA
0x0012E9 ---- 00:D2D9:  .byte $5E   ; 0016DA
0x0012EA ---- 00:D2DA:  .byte $6B   ; 0016DA
0x0012EB ---- 00:D2DB:  .byte $50   ; 0016DA
0x0012EC ---- 00:D2DC:  .byte $4C   ; 0016DA
0x0012ED ---- 00:D2DD:  .byte $41   ; 0016DA
0x0012EE ---- 00:D2DE:  .byte $59   ; 0016DA
0x0012EF ---- 00:D2DF:  .byte $45   ; 0016DA
0x0012F0 ---- 00:D2E0:  .byte $52   ; 0016DA
0x0012F1 ---- 00:D2E1:  .byte $FF   ; 0016DA
0x0012F2 ---- 00:D2E2:  .byte $5F   ; 0016DA
0x0012F3 ---- 00:D2E3:  .byte $6B   ; 0016DA
0x0012F4 ---- 00:D2E4:  .byte $50   ; 0016DA
0x0012F5 ---- 00:D2E5:  .byte $4C   ; 0016DA
0x0012F6 ---- 00:D2E6:  .byte $41   ; 0016DA
0x0012F7 ---- 00:D2E7:  .byte $59   ; 0016DA
0x0012F8 ---- 00:D2E8:  .byte $45   ; 0016DA
0x0012F9 ---- 00:D2E9:  .byte $52   ; 0016DA
0x0012FA ---- 00:D2EA:  .byte $FF   ; 0016DA
0x0012FB ---- 00:D2EB:  .byte $43   ; 0016DA
0x0012FC ---- 00:D2EC:  .byte $4F   ; 0016DA
0x0012FD ---- 00:D2ED:  .byte $4E   ; 0016DA
0x0012FE ---- 00:D2EE:  .byte $53   ; 0016DA
0x0012FF ---- 00:D2EF:  .byte $54   ; 0016DA
0x001300 ---- 00:D2F0:  .byte $52   ; 0016DA
0x001301 ---- 00:D2F1:  .byte $55   ; 0016DA
0x001302 ---- 00:D2F2:  .byte $43   ; 0016DA
0x001303 ---- 00:D2F3:  .byte $54   ; 0016DA
0x001304 ---- 00:D2F4:  .byte $49   ; 0016DA
0x001305 ---- 00:D2F5:  .byte $4F   ; 0016DA
0x001306 ---- 00:D2F6:  .byte $4E   ; 0016DA
0x001307 ---- 00:D2F7:  .byte $FF   ; 0016DA
0x001308 ---- 00:D2F8:  .byte $40   ; 0016DA
0x001309 ---- 00:D2F9:  .byte $20   ; 0016DA
0x00130A ---- 00:D2FA:  .byte $31   ; 0016DA
0x00130B ---- 00:D2FB:  .byte $39   ; 0016DA
0x00130C ---- 00:D2FC:  .byte $38   ; 0016DA
0x00130D ---- 00:D2FD:  .byte $30   ; 0016DA
0x00130E ---- 00:D2FE:  .byte $20   ; 0016DA
0x00130F ---- 00:D2FF:  .byte $31   ; 0016DA
0x001310 ---- 00:D300:  .byte $39   ; 0016DA
0x001311 ---- 00:D301:  .byte $38   ; 0016DA
0x001312 ---- 00:D302:  .byte $35   ; 0016DA
0x001313 ---- 00:D303:  .byte $20   ; 0016DA
0x001314 ---- 00:D304:  .byte $4E   ; 0016DA
0x001315 ---- 00:D305:  .byte $41   ; 0016DA
0x001316 ---- 00:D306:  .byte $4D   ; 0016DA
0x001317 ---- 00:D307:  .byte $43   ; 0016DA
0x001318 ---- 00:D308:  .byte $4F   ; 0016DA
0x001319 ---- 00:D309:  .byte $20   ; 0016DA
0x00131A ---- 00:D30A:  .byte $4C   ; 0016DA
0x00131B ---- 00:D30B:  .byte $54   ; 0016DA
0x00131C ---- 00:D30C:  .byte $44   ; 0016DA
0x00131D ---- 00:D30D:  .byte $69   ; 0016DA
0x00131E ---- 00:D30E:  .byte $FF   ; 0016DA
0x00131F ---- 00:D30F:  .byte $54   ; 0016DA
0x001320 ---- 00:D310:  .byte $48   ; 0016DA
0x001321 ---- 00:D311:  .byte $49   ; 0016DA
0x001322 ---- 00:D312:  .byte $53   ; 0016DA
0x001323 ---- 00:D313:  .byte $20   ; 0016DA
0x001324 ---- 00:D314:  .byte $50   ; 0016DA
0x001325 ---- 00:D315:  .byte $52   ; 0016DA
0x001326 ---- 00:D316:  .byte $4F   ; 0016DA
0x001327 ---- 00:D317:  .byte $47   ; 0016DA
0x001328 ---- 00:D318:  .byte $52   ; 0016DA
0x001329 ---- 00:D319:  .byte $41   ; 0016DA
0x00132A ---- 00:D31A:  .byte $4D   ; 0016DA
0x00132B ---- 00:D31B:  .byte $20   ; 0016DA
0x00132C ---- 00:D31C:  .byte $57   ; 0016DA
0x00132D ---- 00:D31D:  .byte $41   ; 0016DA
0x00132E ---- 00:D31E:  .byte $53   ; 0016DA
0x00132F ---- 00:D31F:  .byte $FF   ; 0016DA
0x001330 ---- 00:D320:  .byte $41   ; 0016DA
0x001331 ---- 00:D321:  .byte $4C   ; 0016DA
0x001332 ---- 00:D322:  .byte $4C   ; 0016DA
0x001333 ---- 00:D323:  .byte $20   ; 0016DA
0x001334 ---- 00:D324:  .byte $52   ; 0016DA
0x001335 ---- 00:D325:  .byte $49   ; 0016DA
0x001336 ---- 00:D326:  .byte $47   ; 0016DA
0x001337 ---- 00:D327:  .byte $48   ; 0016DA
0x001338 ---- 00:D328:  .byte $54   ; 0016DA
0x001339 ---- 00:D329:  .byte $53   ; 0016DA
0x00133A ---- 00:D32A:  .byte $20   ; 0016DA
0x00133B ---- 00:D32B:  .byte $52   ; 0016DA
0x00133C ---- 00:D32C:  .byte $45   ; 0016DA
0x00133D ---- 00:D32D:  .byte $53   ; 0016DA
0x00133E ---- 00:D32E:  .byte $45   ; 0016DA
0x00133F ---- 00:D32F:  .byte $52   ; 0016DA
0x001340 ---- 00:D330:  .byte $56   ; 0016DA
0x001341 ---- 00:D331:  .byte $45   ; 0016DA
0x001342 ---- 00:D332:  .byte $44   ; 0016DA
0x001343 ---- 00:D333:  .byte $FF   ; 0016DA
0x001344 ---- 00:D334:  .byte $4F   ; 0016DA
0x001345 ---- 00:D335:  .byte $50   ; 0016DA
0x001346 ---- 00:D336:  .byte $45   ; 0016DA
0x001347 ---- 00:D337:  .byte $4E   ; 0016DA
0x001348 ---- 00:D338:  .byte $6B   ; 0016DA
0x001349 ---- 00:D339:  .byte $52   ; 0016DA
0x00134A ---- 00:D33A:  .byte $45   ; 0016DA
0x00134B ---- 00:D33B:  .byte $41   ; 0016DA
0x00134C ---- 00:D33C:  .byte $43   ; 0016DA
0x00134D ---- 00:D33D:  .byte $48   ; 0016DA
0x00134E ---- 00:D33E:  .byte $FF   ; 0016DA
0x00134F ---- 00:D33F:  .byte $69   ; 0016DA
0x001350 ---- 00:D340:  .byte $FF   ; 0016DA
0x001351 ---- 00:D341:  .byte $14   ; 0016DA
0x001352 ---- 00:D342:  .byte $FF   ; 0016DA
0x001353 ---- 00:D343:  .byte $47   ; 0018E6
0x001354 ---- 00:D344:  .byte $41   ; 0018E6
0x001355 ---- 00:D345:  .byte $4D   ; 0018E6
0x001356 ---- 00:D346:  .byte $45   ; 0018E6
0x001357 ---- 00:D347:  .byte $FF   ; 0018E6
0x001358 ---- 00:D348:  .byte $4F   ; 0018E6
0x001359 ---- 00:D349:  .byte $56   ; 0018E6
0x00135A ---- 00:D34A:  .byte $45   ; 0018E6
0x00135B ---- 00:D34B:  .byte $52   ; 0018E6
0x00135C ---- 00:D34C:  .byte $FF   ; 0018E6
0x00135D ---- 00:D34D:  .byte $57   ; 0016DA
0x00135E ---- 00:D34E:  .byte $48   ; 0016DA
0x00135F ---- 00:D34F:  .byte $4F   ; 0016DA
0x001360 ---- 00:D350:  .byte $20   ; 0016DA
0x001361 ---- 00:D351:  .byte $4C   ; 0016DA
0x001362 ---- 00:D352:  .byte $4F   ; 0016DA
0x001363 ---- 00:D353:  .byte $56   ; 0016DA
0x001364 ---- 00:D354:  .byte $45   ; 0016DA
0x001365 ---- 00:D355:  .byte $53   ; 0016DA
0x001366 ---- 00:D356:  .byte $20   ; 0016DA
0x001367 ---- 00:D357:  .byte $4E   ; 0016DA
0x001368 ---- 00:D358:  .byte $4F   ; 0016DA
0x001369 ---- 00:D359:  .byte $52   ; 0016DA
0x00136A ---- 00:D35A:  .byte $49   ; 0016DA
0x00136B ---- 00:D35B:  .byte $4B   ; 0016DA
0x00136C ---- 00:D35C:  .byte $4F   ; 0016DA
0x00136D ---- 00:D35D:  .byte $FF   ; 0016DA
0x00136E ---- 00:D35E:  .byte $50   ; 0016DA
0x00136F ---- 00:D35F:  .byte $54   ; 0016DA
0x001370 ---- 00:D360:  .byte $53   ; 0016DA
0x001371 ---- 00:D361:  .byte $FF   ; 0016DA
0x001372 ---- 00:D362:  .byte $6A   ; 0016DA
0x001373 ---- 00:D363:  .byte $6A   ; 0016DA
0x001374 ---- 00:D364:  .byte $FF   ; 0016DA
0x001375 ---- 00:D365:  .byte $6C   ; 0016DA
0x001376 ---- 00:D366:  .byte $FC   ; 0016DA
0x001377 ---- 00:D367:  .byte $FF   ; 0016DA
0x001378 ---- 00:D368:  .byte $6D   ; 0016DA
0x001379 ---- 00:D369:  .byte $FD   ; 0016DA
0x00137A ---- 00:D36A:  .byte $FF   ; 0016DA
0x00137B ---- 00:D36B:  .byte $11   ; 0016DA
0x00137C ---- 00:D36C:  .byte $FF   ; 0016DA
0x00137D ---- 00:D36D:  .byte $00   ; 0016DA
0x00137E ---- 00:D36E:  .byte $00   ; 0016DA
0x00137F ---- 00:D36F:  .byte $00   ; 0016DA
0x001380 ---- 00:D370:  .byte $00   ; 0016DA
0x001381 ---- 00:D371:  .byte $00   ; 0016DA
0x001382 ---- 00:D372:  .byte $00   ; 0016DA
0x001383 ---- 00:D373:  .byte $FF   ; 0016DA
0x001384 ---- 00:D374:  .byte $00   ; 0016DA
0x001385 ---- 00:D375:  .byte $0F   ; 0016DA
0x001386 ---- 00:D376:  .byte $0F   ; 0016DA
0x001387 ---- 00:D377:  .byte $0F   ; 0016DA
0x001388 ---- 00:D378:  .byte $0F   ; 0016DA
0x001389 ---- 00:D379:  .byte $00   ; 0016DA
0x00138A ---- 00:D37A:  .byte $FF   ; 0016DA
0x00138B ---- 00:D37B:  .byte $00   ; 0016DA
0x00138C ---- 00:D37C:  .byte $0F   ; 0016DA
0x00138D ---- 00:D37D:  .byte $C8   ; 0016DA
0x00138E ---- 00:D37E:  .byte $CA   ; 0016DA
0x00138F ---- 00:D37F:  .byte $0F   ; 0016DA
0x001390 ---- 00:D380:  .byte $00   ; 0016DA
0x001391 ---- 00:D381:  .byte $FF   ; 0016DA
0x001392 ---- 00:D382:  .byte $00   ; 0016DA
0x001393 ---- 00:D383:  .byte $0F   ; 0016DA
0x001394 ---- 00:D384:  .byte $C9   ; 0016DA
0x001395 ---- 00:D385:  .byte $CB   ; 0016DA
0x001396 ---- 00:D386:  .byte $0F   ; 0016DA
0x001397 ---- 00:D387:  .byte $00   ; 0016DA
0x001398 ---- 00:D388:  .byte $FF   ; 0016DA
0x001399 ---- 00:D389:  .byte $00   ; 0016DA
0x00139A ---- 00:D38A:  .byte $00   ; 0016DA
0x00139B ---- 00:D38B:  .byte $00   ; 0016DA
0x00139C ---- 00:D38C:  .byte $00   ; 0016DA
0x00139D ---- 00:D38D:  .byte $00   ; 0016DA
0x00139E ---- 00:D38E:  .byte $00   ; 0016DA
0x00139F ---- 00:D38F:  .byte $FF   ; 0016DA
0x0013A0 ---- 00:D390:  .byte $00   ; 0016DA
0x0013A1 ---- 00:D391:  .byte $10   ; 0016DA
0x0013A2 ---- 00:D392:  .byte $10   ; 0016DA
0x0013A3 ---- 00:D393:  .byte $10   ; 0016DA
0x0013A4 ---- 00:D394:  .byte $10   ; 0016DA
0x0013A5 ---- 00:D395:  .byte $00   ; 0016DA
0x0013A6 ---- 00:D396:  .byte $FF   ; 0016DA
0x0013A7 ---- 00:D397:  .byte $00   ; 0016DA
0x0013A8 ---- 00:D398:  .byte $10   ; 0016DA
0x0013A9 ---- 00:D399:  .byte $C8   ; 0016DA
0x0013AA ---- 00:D39A:  .byte $CA   ; 0016DA
0x0013AB ---- 00:D39B:  .byte $10   ; 0016DA
0x0013AC ---- 00:D39C:  .byte $00   ; 0016DA
0x0013AD ---- 00:D39D:  .byte $FF   ; 0016DA
0x0013AE ---- 00:D39E:  .byte $00   ; 0016DA
0x0013AF ---- 00:D39F:  .byte $10   ; 0016DA
0x0013B0 ---- 00:D3A0:  .byte $C9   ; 0016DA
0x0013B1 ---- 00:D3A1:  .byte $CB   ; 0016DA
0x0013B2 ---- 00:D3A2:  .byte $10   ; 0016DA
0x0013B3 ---- 00:D3A3:  .byte $00   ; 0016DA
0x0013B4 ---- 00:D3A4:  .byte $FF   ; 0016DA
0x0013B5 ---- 00:D3A5:  .byte $C8   ; 0016DA
0x0013B6 ---- 00:D3A6:  .byte $CA   ; 0016DA
0x0013B7 ---- 00:D3A7:  .byte $FF   ; 0016DA
0x0013B8 ---- 00:D3A8:  .byte $C9   ; 0016DA
0x0013B9 ---- 00:D3A9:  .byte $CB   ; 0016DA
0x0013BA ---- 00:D3AA:  .byte $FF   ; 0016DA
0x0013BB ---- 00:D3AB:  .byte $CC   ; 0016DA
0x0013BC ---- 00:D3AC:  .byte $CE   ; 0016DA
0x0013BD ---- 00:D3AD:  .byte $FF   ; 0016DA
0x0013BE ---- 00:D3AE:  .byte $CD   ; 0016DA
0x0013BF ---- 00:D3AF:  .byte $CF   ; 0016DA
0x0013C0 ---- 00:D3B0:  .byte $FF   ; 0016DA
0x0013C1 ---- 00:D3B1:  .byte $5B   ; 0016DA
0x0013C2 ---- 00:D3B2:  .byte $FF   ; 0016DA
0x0013C3 ---- 00:D3B3:  .byte $5D   ; 0016DA
0x0013C4 ---- 00:D3B4:  .byte $FF   ; 0016DA
0x0013C5 ---- 00:D3B5:  .byte $54   ; 0016DA
0x0013C6 ---- 00:D3B6:  .byte $4F   ; 0016DA
0x0013C7 ---- 00:D3B7:  .byte $54   ; 0016DA
0x0013C8 ---- 00:D3B8:  .byte $41   ; 0016DA
0x0013C9 ---- 00:D3B9:  .byte $4C   ; 0016DA
0x0013CA ---- 00:D3BA:  .byte $FF   ; 0016DA
0x0013CB ---- 00:D3BB:  .byte $5C   ; 0016DA
0x0013CC ---- 00:D3BC:  .byte $5C   ; 0016DA
0x0013CD ---- 00:D3BD:  .byte $5C   ; 0016DA
0x0013CE ---- 00:D3BE:  .byte $5C   ; 0016DA
0x0013CF ---- 00:D3BF:  .byte $5C   ; 0016DA
0x0013D0 ---- 00:D3C0:  .byte $5C   ; 0016DA
0x0013D1 ---- 00:D3C1:  .byte $5C   ; 0016DA
0x0013D2 ---- 00:D3C2:  .byte $5C   ; 0016DA
0x0013D3 ---- 00:D3C3:  .byte $FF   ; 0016DA
0x0013D4 ---- 00:D3C4:  .byte $42   ; 0016DA
0x0013D5 ---- 00:D3C5:  .byte $4F   ; 0016DA
0x0013D6 ---- 00:D3C6:  .byte $4E   ; 0016DA
0x0013D7 ---- 00:D3C7:  .byte $55   ; 0016DA
0x0013D8 ---- 00:D3C8:  .byte $53   ; 0016DA
0x0013D9 ---- 00:D3C9:  .byte $15   ; 0016DA
0x0013DA ---- 00:D3CA:  .byte $FF   ; 0016DA
0x0013DB ---- 00:D3CB:  .byte $53   ; 0016DA
0x0013DC ---- 00:D3CC:  .byte $54   ; 0016DA
0x0013DD ---- 00:D3CD:  .byte $41   ; 0016DA
0x0013DE ---- 00:D3CE:  .byte $47   ; 0016DA
0x0013DF ---- 00:D3CF:  .byte $45   ; 0016DA
0x0013E0 ---- 00:D3D0:  .byte $FF   ; 0016DA
0x0013E1 ---- 00:D3D1:  .byte $10   ; 000D2C
0x0013E2 ---- 00:D3D2:  .byte $20   ; 000D2C
0x0013E3 ---- 00:D3D3:  .byte $30   ; 000D2C
0x0013E4 ---- 00:D3D4:  .byte $40   ; 000D2C
0x0013E5 ---- 00:D3D5:  .byte $00   ; 000715 0009A8
0x0013E6 ---- 00:D3D6:  .byte $FF   ; 000715 0009A8
0x0013E7 ---- 00:D3D7:  .byte $00   ; 000715
0x0013E8 ---- 00:D3D8:  .byte $01   ; 000715 0009A8
0x0013E9 ---- 00:D3D9:  .byte $FF   ; 000721 0009B2
0x0013EA ---- 00:D3DA:  .byte $00   ; 000721 0009B2
0x0013EB ---- 00:D3DB:  .byte $01   ; 000721
0x0013EC ---- 00:D3DC:  .byte $00   ; 000721 0009B2
0x0013ED ---- xx:D3DD:  .byte $FF   ; 
0x0013EE ---- xx:D3DE:  .byte $FF   ; 
0x0013EF ---- xx:D3DF:  .byte $FF   ; 
0x0013F0 ---- xx:D3E0:  .byte $FF   ; 
0x0013F1 ---- xx:D3E1:  .byte $FF   ; 
0x0013F2 ---- xx:D3E2:  .byte $FF   ; 
0x0013F3 ---- xx:D3E3:  .byte $FF   ; 
0x0013F4 ---- xx:D3E4:  .byte $FF   ; 
0x0013F5 ---- xx:D3E5:  .byte $FF   ; 
0x0013F6 ---- xx:D3E6:  .byte $FF   ; 
0x0013F7 ---- xx:D3E7:  .byte $FF   ; 
0x0013F8 ---- xx:D3E8:  .byte $FF   ; 
0x0013F9 ---- xx:D3E9:  .byte $FF   ; 
0x0013FA ---- xx:D3EA:  .byte $FF   ; 
0x0013FB ---- xx:D3EB:  .byte $FF   ; 
0x0013FC ---- xx:D3EC:  .byte $FF   ; 
0x0013FD ---- xx:D3ED:  .byte $FF   ; 
0x0013FE ---- xx:D3EE:  .byte $FF   ; 
0x0013FF ---- xx:D3EF:  .byte $FF   ; 
0x001400 ---- xx:D3F0:  .byte $FF   ; 
0x001401 ---- xx:D3F1:  .byte $FF   ; 
0x001402 ---- xx:D3F2:  .byte $FF   ; 
0x001403 ---- xx:D3F3:  .byte $FF   ; 
0x001404 ---- xx:D3F4:  .byte $FF   ; 
0x001405 ---- xx:D3F5:  .byte $FF   ; 
0x001406 ---- xx:D3F6:  .byte $FF   ; 
0x001407 ---- xx:D3F7:  .byte $FF   ; 
0x001408 ---- xx:D3F8:  .byte $FF   ; 
0x001409 ---- xx:D3F9:  .byte $FF   ; 
0x00140A ---- xx:D3FA:  .byte $FF   ; 
0x00140B ---- xx:D3FB:  .byte $FF   ; 
0x00140C ---- xx:D3FC:  .byte $FF   ; 
0x00140D ---- xx:D3FD:  .byte $FF   ; 
0x00140E ---- xx:D3FE:  .byte $FF   ; 
0x00140F ---- xx:D3FF:  .byte $FF   ; 
0x001410 ---- 00:D400:  PHA  ; 
0x001411 ---- 00:D401:  TXA  ; 
0x001412 ---- 00:D402:  PHA  ; 
0x001413 ---- 00:D403:  TYA  ; 
0x001414 ---- 00:D404:  PHA  ; 
0x001415 ---- 00:D405:  PHP  ; 
0x001416 ---- 00:D406:  LDA #$00  ; 
0x001418 nZ-- 00:D408:  STA $2003  ; $2003
0x00141B nZ-- 00:D40B:  LDA #$02  ; 
0x00141D nz-- 00:D40D:  STA $4014  ; $4014
0x001420 nz-- 00:D410:  LDA $2002  ; $2002
0x001423 ---- 00:D413:  JSR $D8FD  ; 00190D
; 1 refs via 001943
0x001426 nZ-- 00:D416:  LDA ram_004D  ; $004D
0x001428 ---- 00:D418:  BMI $D41D  ; 00142D
0x00142A n--- 00:D41A:  JSR $D50E  ; 00151E
; 2 refs via 001428 00154D
0x00142D ---- 00:D41D:  LDA ram_0050  ; $0050
0x00142F ---- 00:D41F:  ORA #$B0  ; 
0x001431 Nz-- 00:D421:  STA $2000  ; $2000
0x001434 Nz-- 00:D424:  LDA #$00  ; 
0x001436 nZ-- 00:D426:  STA $2005  ; $2005
0x001439 nZ-- 00:D429:  LDA ram_004F  ; $004F
0x00143B ---- 00:D42B:  STA $2005  ; $2005
0x00143E ---- 00:D42E:  LDA #$1E  ; 
0x001440 nz-- 00:D430:  STA $2001  ; $2001
0x001443 nz-- 00:D433:  JSR $D689  ; 001699
; 1 refs via 0016C2
0x001446 N--- 00:D436:  JSR $DA93  ; 001AA3
; 1 refs via 001ABE
0x001449 -Z-- 00:D439:  JSR $EA7E  ; 002A8E
; 1 refs via 002B51
0x00144C --C- 00:D43C:  INC ram_000B  ; $000B
0x00144E --C- 00:D43E:  LDA ram_000B  ; $000B
0x001450 --C- 00:D440:  AND #$3F  ; 
0x001452 --C- 00:D442:  BNE $D446  ; 001456
0x001454 -ZC- 00:D444:  INC ram_000A  ; $000A
; 1 refs via 001452
0x001456 --C- 00:D446:  PLP  ; 
0x001457 ---- 00:D447:  PLA  ; 
0x001458 ---- 00:D448:  TAY  ; 
0x001459 ---- 00:D449:  PLA  ; 
0x00145A ---- 00:D44A:  TAX  ; 
0x00145B ---- 00:D44B:  PLA  ; 
0x00145C ---- 00:D44C:  RTI  ; 00021C 00022E 000231 000738 00073E 000745 000762 000909 000956 00160B 00160F 001614 001619 00161D 00161F 001719 00171C 001723 001724 00172C 001908 00190A 001A3B 001A3E 001A43 001A44 001A46 001A48 001A4B 001A4D 001A4F 001A57 001A59 001A5B 001A63 001A68 001A6D 001A6E 001A71 001A73 001A91 001A94 001A97 001A9B 001EC1 001FAD 001FB2 001FB4
; 10 refs via 001C9C 001D27 001D58 001D5F 001DE4 001E94 002181 0028D3 0028DD 0028F6
0x00145D ---- 00:D44D:  TXA  ; 
0x00145E ---- 00:D44E:  PHA  ; 
0x00145F ---- 00:D44F:  LDA ram_000F  ; $000F
0x001461 ---- 00:D451:  ASL  ; 
0x001462 ---- 00:D452:  ASL  ; 
0x001463 ---- 00:D453:  ASL  ; 
0x001464 ---- 00:D454:  SEC  ; 
0x001465 --C- 00:D455:  SBC ram_000F  ; $000F
0x001467 ---- 00:D457:  CLC  ; 
0x001468 --c- 00:D458:  ADC ram_000A  ; $000A
0x00146A ---- 00:D45A:  INC ram_0010  ; $0010
0x00146C ---- 00:D45C:  LDX ram_0010  ; $0010
0x00146E ---- 00:D45E:  ADC ram_0000,X  ; $0000 $0001 $0002 $0003 $0004 $0005 $0006 $0007 $0008 $0009 $000A $000B $000C $000D $000E $000F $0010 $0011 $0012 $0013 $0014 $0015 $0016 $0017 $0018 $0019 $001A $001B $001C $001D $001E $001F $0020 $0021 $0022 $0023 $0024 $0025 $0026 $0027 $0028 $0029 $002A $002B $002C $002D $002E $002F $0030 $0031 $0032 $0033 $0034 $0035 $0036 $0037 $0038 $0039 $003A $003B $003C $003D $003E $003F $0040 $0041 $0042 $0043 $0044 $0045 $0046 $0047 $0048 $0049 $004A $004B $004C $004D $004E $004F $0050 $0051 $0052 $0053 $0054 $0055 $0056 $0057 $0058 $0059 $005A $005B $005C $005D $005E $005F $0060 $0061 $0062 $0063 $0064 $0065 $0066 $0067 $0068 $0069 $006A $006B $006C $006D $006E $006F $0070 $0071 $0072 $0073 $0074 $0075 $0076 $0077 $0078 $0079 $007A $007B $007C $007D $007E $007F $0080 $0081 $0082 $0083 $0084 $0085 $0086 $0087 $0088 $0089 $008A $008B $008C $008D $008E $008F $0090 $0091 $0092 $0093 $0094 $0095 $0096 $0097 $0098 $0099 $009A $009B $009C $009D $009E $009F $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7 $00A8 $00A9 $00AA $00AB $00AC $00AD $00AE $00AF $00B0 $00B1 $00B2 $00B3 $00B4 $00B5 $00B6 $00B7 $00B8 $00B9 $00BA $00BB $00BC $00BD $00BE $00BF $00C0 $00C1 $00C2 $00C3 $00C4 $00C5 $00C6 $00C7 $00C8 $00C9 $00CA $00CB $00CC $00CD $00CE $00CF $00D0 $00D1 $00D2 $00D3 $00D4 $00D5 $00D6 $00D7 $00D8 $00D9 $00DA $00DB $00DC $00DD $00DE $00DF $00E0 $00E1 $00E2 $00E3 $00E4 $00E5 $00E6 $00E7 $00E8 $00E9 $00EA $00EB $00EC $00ED $00EE $00EF $00F0 $00F1 $00F2 $00F3 $00F4 $00F5 $00F6 $00F7 $00F8 $00F9 $00FA $00FB $00FC $00FD $00FE $00FF
0x001470 ---- 00:D460:  STA ram_000F  ; $000F
0x001472 ---- 00:D462:  PLA  ; 
0x001473 ---- 00:D463:  TAX  ; 
0x001474 ---- 00:D464:  LDA ram_000F  ; $000F
0x001476 ---- 00:D466:  RTS  ; 001C9F 001D2A 001D5B 001D62 001DE7 001E97 002184 0028D6 0028E0 0028F9
; 12 refs via 0000A2 0000CB 0002AE 00041C 000484 0004BF 000573 000622 00064B 000F2E 00118B 0011C2
0x001477 -Z-- 00:D467:  JSR $D5F5  ; 001605
; 1 refs via 00160A
0x00147A N--- 00:D46A:  LDA #$B0  ; 
0x00147C Nz-- 00:D46C:  STA $2000  ; $2000
0x00147F Nz-- 00:D46F:  RTS  ; 0000A5 0000CE 0002B1 00041F 000487 0004C2 000576 000625 00064E 000F31 00118E 0011C5
; 11 refs via 0000C2 0002A5 0003F0 00045B 0004AC 00056A 0005E9 000642 000F22 00117A 00118F
0x001480 ---- 00:D470:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x001483 -z-- 00:D473:  LDA #$10  ; 
0x001485 nz-- 00:D475:  STA $2000  ; $2000
0x001488 nz-- 00:D478:  LDA #$06  ; 
0x00148A nz-- 00:D47A:  STA $2001  ; $2001
0x00148D nz-- 00:D47D:  RTS  ; 0000C5 0002A8 0003F3 00045E 0004AF 00056D 0005EC 000645 000F25 00117D 001192
; 9 refs via 0002A8 000468 0004B9 0005F6 000645 000F25 001185 001196 0014BC
0x00148E n--- 00:D47E:  LDA #$00  ; 
0x001490 nZ-- 00:D480:  TAX  ; 
; 1 refs via 00149E
0x001491 ---- 00:D481:  STA ram_0400,X  ; $0400 $0401 $0402 $0403 $0404 $0405 $0406 $0407 $0408 $0409 $040A $040B $040C $040D $040E $040F $0410 $0411 $0412 $0413 $0414 $0415 $0416 $0417 $0418 $0419 $041A $041B $041C $041D $041E $041F $0420 $0421 $0422 $0423 $0424 $0425 $0426 $0427 $0428 $0429 $042A $042B $042C $042D $042E $042F $0430 $0431 $0432 $0433 $0434 $0435 $0436 $0437 $0438 $0439 $043A $043B $043C $043D $043E $043F $0440 $0441 $0442 $0443 $0444 $0445 $0446 $0447 $0448 $0449 $044A $044B $044C $044D $044E $044F $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0458 $0459 $045A $045B $045C $045D $045E $045F $0460 $0461 $0462 $0463 $0464 $0465 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $046E $046F $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $047A $047B $047C $047D $047E $047F $0480 $0481 $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $049C $049D $049E $049F $04A0 $04A1 $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04BC $04BD $04BE $04BF $04C0 $04C1 $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04DC $04DD $04DE $04DF $04E0 $04E1 $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $04FC $04FD $04FE $04FF
0x001494 ---- 00:D484:  STA ram_0500,X  ; $0500 $0501 $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $051C $051D $051E $051F $0520 $0521 $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $053C $053D $053E $053F $0540 $0541 $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $055C $055D $055E $055F $0560 $0561 $0562 $0563 $0564 $0565 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $057C $057D $057E $057F $0580 $0581 $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $059C $059D $059E $059F $05A0 $05A1 $05A2 $05A3 $05A4 $05A5 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05BC $05BD $05BE $05BF $05C0 $05C1 $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05DC $05DD $05DE $05DF $05E0 $05E1 $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $05FC $05FD $05FE $05FF
0x001497 ---- 00:D487:  STA ram_0600,X  ; $0600 $0601 $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $061C $061D $061E $061F $0620 $0621 $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $0639 $063A $063B $063C $063D $063E $063F $0640 $0641 $0642 $0643 $0644 $0645 $0646 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $065C $065D $065E $065F $0660 $0661 $0662 $0663 $0664 $0665 $0666 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $067C $067D $067E $067F $0680 $0681 $0682 $0683 $0684 $0685 $0686 $0687 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0692 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $069C $069D $069E $069F $06A0 $06A1 $06A2 $06A3 $06A4 $06A5 $06A6 $06A7 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B7 $06B8 $06B9 $06BA $06BB $06BC $06BD $06BE $06BF $06C0 $06C1 $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06DC $06DD $06DE $06DF $06E0 $06E1 $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $06FA $06FB $06FC $06FD $06FE $06FF
0x00149A ---- 00:D48A:  STA ram_0700,X  ; $0700 $0701 $0702 $0703 $0704 $0705 $0706 $0707 $0708 $0709 $070A $070B $070C $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0717 $0718 $0719 $071A $071B $071C $071D $071E $071F $0720 $0721 $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072C $072D $072E $072F $0730 $0731 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $073C $073D $073E $073F $0740 $0741 $0742 $0743 $0744 $0745 $0746 $0747 $0748 $0749 $074A $074B $074C $074D $074E $074F $0750 $0751 $0752 $0753 $0754 $0755 $0756 $0757 $0758 $0759 $075A $075B $075C $075D $075E $075F $0760 $0761 $0762 $0763 $0764 $0765 $0766 $0767 $0768 $0769 $076A $076B $076C $076D $076E $076F $0770 $0771 $0772 $0773 $0774 $0775 $0776 $0777 $0778 $0779 $077A $077B $077C $077D $077E $077F $0780 $0781 $0782 $0783 $0784 $0785 $0786 $0787 $0788 $0789 $078A $078B $078C $078D $078E $078F $0790 $0791 $0792 $0793 $0794 $0795 $0796 $0797 $0798 $0799 $079A $079B $079C $079D $079E $079F $07A0 $07A1 $07A2 $07A3 $07A4 $07A5 $07A6 $07A7 $07A8 $07A9 $07AA $07AB $07AC $07AD $07AE $07AF $07B0 $07B1 $07B2 $07B3 $07B4 $07B5 $07B6 $07B7 $07B8 $07B9 $07BA $07BB $07BC $07BD $07BE $07BF $07C0 $07C1 $07C2 $07C3 $07C4 $07C5 $07C6 $07C7 $07C8 $07C9 $07CA $07CB $07CC $07CD $07CE $07CF $07D0 $07D1 $07D2 $07D3 $07D4 $07D5 $07D6 $07D7 $07D8 $07D9 $07DA $07DB $07DC $07DD $07DE $07DF $07E0 $07E1 $07E2 $07E3 $07E4 $07E5 $07E6 $07E7 $07E8 $07E9 $07EA $07EB $07EC $07ED $07EE $07EF $07F0 $07F1 $07F2 $07F3 $07F4 $07F5 $07F6 $07F7 $07F8 $07F9 $07FA $07FB $07FC $07FD $07FE $07FF
0x00149D ---- 00:D48D:  INX  ; 
0x00149E ---- 00:D48E:  BNE $D481  ; 001491
0x0014A0 -Z-- 00:D490:  RTS  ; 0002AB 00046B 0004BC 0005F9 000648 000F28 001188 001199 0014BF
; 1 refs via 000099
0x0014A1 nz-- 00:D491:  LDA #$00  ; 
0x0014A3 nZ-- 00:D493:  STA ram_0060  ; $0060
0x0014A5 nZ-- 00:D495:  STA ram_006B  ; $006B
0x0014A7 nZ-- 00:D497:  STA ram_000C  ; $000C
0x0014A9 nZ-- 00:D499:  STA ram_000D  ; $000D
0x0014AB nZ-- 00:D49B:  STA ram_006D  ; $006D
0x0014AD nZ-- 00:D49D:  LDA #$FF  ; 
0x0014AF Nz-- 00:D49F:  STA ram_004D  ; $004D
0x0014B1 Nz-- 00:D4A1:  JSR $D502  ; 001512
; 1 refs via 00151D
0x0014B4 nZ-- 00:D4A4:  LDA #$04  ; 
0x0014B6 nz-- 00:D4A6:  STA ram_000E  ; $000E
0x0014B8 nz-- 00:D4A8:  LDA #$20  ; 
0x0014BA nz-- 00:D4AA:  STA ram_006E  ; $006E
0x0014BC nz-- 00:D4AC:  JSR $D47E  ; 00148E
; 1 refs via 0014A0
0x0014BF -Z-- 00:D4AF:  JSR $DA93  ; 001AA3
; 1 refs via 001ABE
0x0014C2 -Z-- 00:D4B2:  LDX #$15  ; 
0x0014C4 nz-- 00:D4B4:  JSR $D9FE  ; 001A0E
; 1 refs via 001A22
0x0014C7 Nz-- 00:D4B7:  LDX #$1D  ; 
0x0014C9 nz-- 00:D4B9:  JSR $D9FE  ; 001A0E
; 1 refs via 001A22
0x0014CC Nz-- 00:D4BC:  JSR $D4EF  ; 0014FF
; 2 refs via 00150E 001511
0x0014CF n--- 00:D4BF:  BNE $D4CE  ; 0014DE
0x0014D1 nZ-- 00:D4C1:  LDX #$3D  ; 
0x0014D3 nz-- 00:D4C3:  JSR $D9FE  ; 001A0E
; 1 refs via 001A22
0x0014D6 Nz-- 00:D4C6:  LDA #$02  ; 
0x0014D8 nz-- 00:D4C8:  STA ram_003F  ; $003F
0x0014DA nz-- 00:D4CA:  LDA #$00  ; 
0x0014DC nZ-- 00:D4CC:  STA ram_0083  ; $0083
; 1 refs via 0014CF
0x0014DE n--- 00:D4CE:  LDA #$1C  ; 
0x0014E0 nz-- 00:D4D0:  STA ram_0005  ; $0005
0x0014E2 nz-- 00:D4D2:  JSR $D7B4  ; 0017C4
; 1 refs via 0017DB
0x0014E5 -Z-- 00:D4D5:  LDA #$24  ; 
0x0014E7 nz-- 00:D4D7:  STA ram_0005  ; $0005
0x0014E9 nz-- 00:D4D9:  JSR $D7B4  ; 0017C4
; 1 refs via 0017DB
0x0014EC -Z-- 00:D4DC:  JSR $D4E3  ; 0014F3
; 1 refs via 0014FE
0x0014EF N--- 00:D4DF:  JSR $EA51  ; 002A61
; 1 refs via 002A8D
0x0014F2 -Z-- 00:D4E2:  RTS  ; 00009C
; 1 refs via 0014EC
0x0014F3 -Z-- 00:D4E3:  LDX #$0F  ; 
; 1 refs via 0014FC
0x0014F5 n--- 00:D4E5:  LDA $C040,X  ; 000050 000051 000052 000053 000054 000055 000056 000057 000058 000059 00005A 00005B 00005C 00005D 00005E 00005F
0x0014F8 ---- 00:D4E8:  STA ram_0110,X  ; $0110 $0111 $0112 $0113 $0114 $0115 $0116 $0117 $0118 $0119 $011A $011B $011C $011D $011E $011F
0x0014FB ---- 00:D4EB:  DEX  ; 
0x0014FC ---- 00:D4EC:  BPL $D4E5  ; 0014F5
0x0014FE N--- 00:D4EE:  RTS  ; 0014EF
; 1 refs via 0014CC
0x0014FF Nz-- 00:D4EF:  LDX #$0F  ; 
; 1 refs via 00150A
0x001501 n--- 00:D4F1:  LDA ram_0110,X  ; $0110 $0111 $0112 $0113 $0114 $0115 $0116 $0117 $0118 $0119 $011A $011B $011C $011D $011E $011F
0x001504 ---- 00:D4F4:  CMP $C040,X  ; 000050 000051 000052 000053 000054 000055 000056 000057 000058 000059 00005A 00005B 00005C 00005D 00005E 00005F
0x001507 ---- 00:D4F7:  BNE $D4FF  ; 00150F
0x001509 -Z-- 00:D4F9:  DEX  ; 
0x00150A ---- 00:D4FA:  BPL $D4F1  ; 001501
0x00150C N--- 00:D4FC:  LDA #$01  ; 
0x00150E nz-- 00:D4FE:  RTS  ; 0014CF
; 1 refs via 001507
0x00150F -z-- 00:D4FF:  LDA #$00  ; 
0x001511 nZ-- 00:D501:  RTS  ; 0014CF
; 1 refs via 0014B1
0x001512 Nz-- 00:D502:  JSR $D5F5  ; 001605
; 1 refs via 00160A
0x001515 N--- 00:D505:  JSR $D53E  ; 00154E
; 1 refs via 001564
0x001518 -Z-- 00:D508:  LDA #$00  ; 
0x00151A nZ-- 00:D50A:  JSR $D50E  ; 00151E
; 1 refs via 00154D
0x00151D nZ-- 00:D50D:  RTS  ; 0014B4
; 2 refs via 00142A 00151A
0x00151E n--- 00:D50E:  ASL  ; 
0x00151F ---- 00:D50F:  ASL  ; 
0x001520 ---- 00:D510:  ASL  ; 
0x001521 ---- 00:D511:  ASL  ; 
0x001522 ---- 00:D512:  TAX  ; 
0x001523 ---- 00:D513:  LDY #$10  ; 
0x001525 nz-- 00:D515:  LDA #$3F  ; 
0x001527 nz-- 00:D517:  STA $2006  ; $2006
0x00152A nz-- 00:D51A:  LDA #$00  ; 
0x00152C nZ-- 00:D51C:  STA $2006  ; $2006
; 1 refs via 001537
0x00152F ---- 00:D51F:  LDA $D565,X  ; 001575 001576 001577 001578 001579 00157A 00157B 00157C 00157D 00157E 00157F 001580 001581 001582 001583 001584 001585 001586 001587 001588 001589 00158A 00158B 00158C 00158D 00158E 00158F 001590 001591 001592 001593 001594 001595 001596 001597 001598 001599 00159A 00159B 00159C 00159D 00159E 00159F 0015A0 0015A1 0015A2 0015A3 0015A4 0015A5 0015A6 0015A7 0015A8 0015A9 0015AA 0015AB 0015AC 0015AD 0015AE 0015AF 0015B0 0015B1 0015B2 0015B3 0015B4 0015B5 0015B6 0015B7 0015B8 0015B9 0015BA 0015BB 0015BC 0015BD 0015BE 0015BF 0015C0 0015C1 0015C2 0015C3 0015C4 0015C5 0015C6 0015C7 0015C8 0015C9 0015CA 0015CB 0015CC 0015CD 0015CE 0015CF 0015D0 0015D1 0015D2 0015D3 0015D4 0015D5 0015D6 0015D7 0015D8 0015D9 0015DA 0015DB 0015DC 0015DD 0015DE 0015DF 0015E0 0015E1 0015E2 0015E3 0015E4 0015E5 0015E6 0015E7 0015E8 0015E9 0015EA 0015EB 0015EC 0015ED 0015EE 0015EF 0015F0 0015F1 0015F2 0015F3 0015F4 0015F5 0015F6 0015F7 0015F8 0015F9 0015FA 0015FB 0015FC 0015FD 0015FE 0015FF 001600 001601 001602 001603 001604
0x001532 ---- 00:D522:  STA $2007  ; $2007
0x001535 ---- 00:D525:  INX  ; 
0x001536 ---- 00:D526:  DEY  ; 
0x001537 ---- 00:D527:  BNE $D51F  ; 00152F
0x001539 -Z-- 00:D529:  LDA #$FF  ; 
0x00153B Nz-- 00:D52B:  STA ram_004D  ; $004D
0x00153D Nz-- 00:D52D:  LDA #$3F  ; 
0x00153F nz-- 00:D52F:  STA $2006  ; $2006
0x001542 nz-- 00:D532:  LDA #$00  ; 
0x001544 nZ-- 00:D534:  STA $2006  ; $2006
0x001547 nZ-- 00:D537:  STA $2006  ; $2006
0x00154A nZ-- 00:D53A:  STA $2006  ; $2006
0x00154D nZ-- 00:D53D:  RTS  ; 00142D 00151D
; 1 refs via 001515
0x00154E N--- 00:D53E:  LDX #$00  ; 
0x001550 nZ-- 00:D540:  LDY #$10  ; 
0x001552 nz-- 00:D542:  LDA #$3F  ; 
0x001554 nz-- 00:D544:  STA $2006  ; $2006
0x001557 nz-- 00:D547:  STY $2006  ; $2006
; 1 refs via 001562
0x00155A -z-- 00:D54A:  LDA $D555,X  ; 001565 001566 001567 001568 001569 00156A 00156B 00156C 00156D 00156E 00156F 001570 001571 001572 001573 001574
0x00155D ---- 00:D54D:  STA $2007  ; $2007
0x001560 ---- 00:D550:  INX  ; 
0x001561 ---- 00:D551:  DEY  ; 
0x001562 ---- 00:D552:  BNE $D54A  ; 00155A
0x001564 -Z-- 00:D554:  RTS  ; 001518
0x001565 ---- 00:D555:  .byte $0F   ; 00155A
0x001566 ---- 00:D556:  .byte $18   ; 00155A
0x001567 ---- 00:D557:  .byte $27   ; 00155A
0x001568 ---- 00:D558:  .byte $38   ; 00155A
0x001569 ---- 00:D559:  .byte $0F   ; 00155A
0x00156A ---- 00:D55A:  .byte $0A   ; 00155A
0x00156B ---- 00:D55B:  .byte $1B   ; 00155A
0x00156C ---- 00:D55C:  .byte $3B   ; 00155A
0x00156D ---- 00:D55D:  .byte $0F   ; 00155A
0x00156E ---- 00:D55E:  .byte $0C   ; 00155A
0x00156F ---- 00:D55F:  .byte $10   ; 00155A
0x001570 ---- 00:D560:  .byte $20   ; 00155A
0x001571 ---- 00:D561:  .byte $0F   ; 00155A
0x001572 ---- 00:D562:  .byte $04   ; 00155A
0x001573 ---- 00:D563:  .byte $16   ; 00155A
0x001574 ---- 00:D564:  .byte $20   ; 00155A
0x001575 ---- 00:D565:  .byte $0F   ; 00152F
0x001576 ---- 00:D566:  .byte $17   ; 00152F
0x001577 ---- 00:D567:  .byte $06   ; 00152F
0x001578 ---- 00:D568:  .byte $00   ; 00152F
0x001579 ---- 00:D569:  .byte $0F   ; 00152F
0x00157A ---- 00:D56A:  .byte $3C   ; 00152F
0x00157B ---- 00:D56B:  .byte $10   ; 00152F
0x00157C ---- 00:D56C:  .byte $12   ; 00152F
0x00157D ---- 00:D56D:  .byte $0F   ; 00152F
0x00157E ---- 00:D56E:  .byte $29   ; 00152F
0x00157F ---- 00:D56F:  .byte $09   ; 00152F
0x001580 ---- 00:D570:  .byte $0B   ; 00152F
0x001581 ---- 00:D571:  .byte $0F   ; 00152F
0x001582 ---- 00:D572:  .byte $00   ; 00152F
0x001583 ---- 00:D573:  .byte $10   ; 00152F
0x001584 ---- 00:D574:  .byte $20   ; 00152F
0x001585 ---- 00:D575:  .byte $0F   ; 00152F
0x001586 ---- 00:D576:  .byte $17   ; 00152F
0x001587 ---- 00:D577:  .byte $06   ; 00152F
0x001588 ---- 00:D578:  .byte $00   ; 00152F
0x001589 ---- 00:D579:  .byte $0F   ; 00152F
0x00158A ---- 00:D57A:  .byte $3C   ; 00152F
0x00158B ---- 00:D57B:  .byte $12   ; 00152F
0x00158C ---- 00:D57C:  .byte $12   ; 00152F
0x00158D ---- 00:D57D:  .byte $0F   ; 00152F
0x00158E ---- 00:D57E:  .byte $29   ; 00152F
0x00158F ---- 00:D57F:  .byte $09   ; 00152F
0x001590 ---- 00:D580:  .byte $0B   ; 00152F
0x001591 ---- 00:D581:  .byte $0F   ; 00152F
0x001592 ---- 00:D582:  .byte $00   ; 00152F
0x001593 ---- 00:D583:  .byte $10   ; 00152F
0x001594 ---- 00:D584:  .byte $20   ; 00152F
0x001595 ---- 00:D585:  .byte $0F   ; 00152F
0x001596 ---- 00:D586:  .byte $17   ; 00152F
0x001597 ---- 00:D587:  .byte $06   ; 00152F
0x001598 ---- 00:D588:  .byte $00   ; 00152F
0x001599 ---- 00:D589:  .byte $0F   ; 00152F
0x00159A ---- 00:D58A:  .byte $12   ; 00152F
0x00159B ---- 00:D58B:  .byte $3C   ; 00152F
0x00159C ---- 00:D58C:  .byte $12   ; 00152F
0x00159D ---- 00:D58D:  .byte $0F   ; 00152F
0x00159E ---- 00:D58E:  .byte $29   ; 00152F
0x00159F ---- 00:D58F:  .byte $09   ; 00152F
0x0015A0 ---- 00:D590:  .byte $0B   ; 00152F
0x0015A1 ---- 00:D591:  .byte $0F   ; 00152F
0x0015A2 ---- 00:D592:  .byte $00   ; 00152F
0x0015A3 ---- 00:D593:  .byte $10   ; 00152F
0x0015A4 ---- 00:D594:  .byte $20   ; 00152F
0x0015A5 ---- 00:D595:  .byte $0F   ; 00152F
0x0015A6 ---- 00:D596:  .byte $16   ; 00152F
0x0015A7 ---- 00:D597:  .byte $16   ; 00152F
0x0015A8 ---- 00:D598:  .byte $30   ; 00152F
0x0015A9 ---- 00:D599:  .byte $0F   ; 00152F
0x0015AA ---- 00:D59A:  .byte $3C   ; 00152F
0x0015AB ---- 00:D59B:  .byte $10   ; 00152F
0x0015AC ---- 00:D59C:  .byte $16   ; 00152F
0x0015AD ---- 00:D59D:  .byte $0F   ; 00152F
0x0015AE ---- 00:D59E:  .byte $29   ; 00152F
0x0015AF ---- 00:D59F:  .byte $09   ; 00152F
0x0015B0 ---- 00:D5A0:  .byte $27   ; 00152F
0x0015B1 ---- 00:D5A1:  .byte $0F   ; 00152F
0x0015B2 ---- 00:D5A2:  .byte $00   ; 00152F
0x0015B3 ---- 00:D5A3:  .byte $10   ; 00152F
0x0015B4 ---- 00:D5A4:  .byte $20   ; 00152F
0x0015B5 ---- 00:D5A5:  .byte $0F   ; 00152F
0x0015B6 ---- 00:D5A6:  .byte $17   ; 00152F
0x0015B7 ---- 00:D5A7:  .byte $06   ; 00152F
0x0015B8 ---- 00:D5A8:  .byte $00   ; 00152F
0x0015B9 ---- 00:D5A9:  .byte $0F   ; 00152F
0x0015BA ---- 00:D5AA:  .byte $3C   ; 00152F
0x0015BB ---- 00:D5AB:  .byte $10   ; 00152F
0x0015BC ---- 00:D5AC:  .byte $00   ; 00152F
0x0015BD ---- 00:D5AD:  .byte $0F   ; 00152F
0x0015BE ---- 00:D5AE:  .byte $29   ; 00152F
0x0015BF ---- 00:D5AF:  .byte $09   ; 00152F
0x0015C0 ---- 00:D5B0:  .byte $00   ; 00152F
0x0015C1 ---- 00:D5B1:  .byte $0F   ; 00152F
0x0015C2 ---- 00:D5B2:  .byte $00   ; 00152F
0x0015C3 ---- 00:D5B3:  .byte $10   ; 00152F
0x0015C4 ---- 00:D5B4:  .byte $00   ; 00152F
0x0015C5 ---- 00:D5B5:  .byte $0F   ; 00152F
0x0015C6 ---- 00:D5B6:  .byte $0F   ; 00152F
0x0015C7 ---- 00:D5B7:  .byte $06   ; 00152F
0x0015C8 ---- 00:D5B8:  .byte $00   ; 00152F
0x0015C9 ---- 00:D5B9:  .byte $0F   ; 00152F
0x0015CA ---- 00:D5BA:  .byte $3C   ; 00152F
0x0015CB ---- 00:D5BB:  .byte $10   ; 00152F
0x0015CC ---- 00:D5BC:  .byte $00   ; 00152F
0x0015CD ---- 00:D5BD:  .byte $0F   ; 00152F
0x0015CE ---- 00:D5BE:  .byte $29   ; 00152F
0x0015CF ---- 00:D5BF:  .byte $09   ; 00152F
0x0015D0 ---- 00:D5C0:  .byte $00   ; 00152F
0x0015D1 ---- 00:D5C1:  .byte $0F   ; 00152F
0x0015D2 ---- 00:D5C2:  .byte $00   ; 00152F
0x0015D3 ---- 00:D5C3:  .byte $10   ; 00152F
0x0015D4 ---- 00:D5C4:  .byte $00   ; 00152F
0x0015D5 ---- 00:D5C5:  .byte $0F   ; 00152F
0x0015D6 ---- 00:D5C6:  .byte $12   ; 00152F
0x0015D7 ---- 00:D5C7:  .byte $06   ; 00152F
0x0015D8 ---- 00:D5C8:  .byte $00   ; 00152F
0x0015D9 ---- 00:D5C9:  .byte $0F   ; 00152F
0x0015DA ---- 00:D5CA:  .byte $3C   ; 00152F
0x0015DB ---- 00:D5CB:  .byte $10   ; 00152F
0x0015DC ---- 00:D5CC:  .byte $00   ; 00152F
0x0015DD ---- 00:D5CD:  .byte $0F   ; 00152F
0x0015DE ---- 00:D5CE:  .byte $29   ; 00152F
0x0015DF ---- 00:D5CF:  .byte $09   ; 00152F
0x0015E0 ---- 00:D5D0:  .byte $00   ; 00152F
0x0015E1 ---- 00:D5D1:  .byte $0F   ; 00152F
0x0015E2 ---- 00:D5D2:  .byte $00   ; 00152F
0x0015E3 ---- 00:D5D3:  .byte $10   ; 00152F
0x0015E4 ---- 00:D5D4:  .byte $00   ; 00152F
0x0015E5 ---- 00:D5D5:  .byte $0F   ; 00152F
0x0015E6 ---- 00:D5D6:  .byte $00   ; 00152F
0x0015E7 ---- 00:D5D7:  .byte $06   ; 00152F
0x0015E8 ---- 00:D5D8:  .byte $00   ; 00152F
0x0015E9 ---- 00:D5D9:  .byte $0F   ; 00152F
0x0015EA ---- 00:D5DA:  .byte $3C   ; 00152F
0x0015EB ---- 00:D5DB:  .byte $10   ; 00152F
0x0015EC ---- 00:D5DC:  .byte $00   ; 00152F
0x0015ED ---- 00:D5DD:  .byte $0F   ; 00152F
0x0015EE ---- 00:D5DE:  .byte $29   ; 00152F
0x0015EF ---- 00:D5DF:  .byte $09   ; 00152F
0x0015F0 ---- 00:D5E0:  .byte $00   ; 00152F
0x0015F1 ---- 00:D5E1:  .byte $0F   ; 00152F
0x0015F2 ---- 00:D5E2:  .byte $00   ; 00152F
0x0015F3 ---- 00:D5E3:  .byte $10   ; 00152F
0x0015F4 ---- 00:D5E4:  .byte $00   ; 00152F
0x0015F5 ---- 00:D5E5:  .byte $0F   ; 00152F
0x0015F6 ---- 00:D5E6:  .byte $30   ; 00152F
0x0015F7 ---- 00:D5E7:  .byte $06   ; 00152F
0x0015F8 ---- 00:D5E8:  .byte $00   ; 00152F
0x0015F9 ---- 00:D5E9:  .byte $0F   ; 00152F
0x0015FA ---- 00:D5EA:  .byte $3C   ; 00152F
0x0015FB ---- 00:D5EB:  .byte $10   ; 00152F
0x0015FC ---- 00:D5EC:  .byte $00   ; 00152F
0x0015FD ---- 00:D5ED:  .byte $0F   ; 00152F
0x0015FE ---- 00:D5EE:  .byte $29   ; 00152F
0x0015FF ---- 00:D5EF:  .byte $09   ; 00152F
0x001600 ---- 00:D5F0:  .byte $00   ; 00152F
0x001601 ---- 00:D5F1:  .byte $0F   ; 00152F
0x001602 ---- 00:D5F2:  .byte $00   ; 00152F
0x001603 ---- 00:D5F3:  .byte $10   ; 00152F
0x001604 ---- 00:D5F4:  .byte $00   ; 00152F
; 3 refs via 001477 001512 001608
0x001605 ---- 00:D5F5:  LDA $2002  ; $2002
0x001608 ---- 00:D5F8:  BPL $D5F5  ; 001605
0x00160A N--- 00:D5FA:  RTS  ; 00147A 001515
; 6 refs via 000AA8 000C6E 0016C3 0016ED 001719 0017FD
0x00160B ---- 00:D5FB:  LDA #$00  ; 
0x00160D nZ-- 00:D5FD:  STA ram_0000  ; $0000
0x00160F ---- 00:D5FF:  TYA  ; 
0x001610 ---- 00:D600:  LSR  ; 
0x001611 ---- 00:D601:  ROR ram_0000  ; $0000
0x001613 ---- 00:D603:  LSR  ; 
0x001614 ---- 00:D604:  ROR ram_0000  ; $0000
0x001616 ---- 00:D606:  LSR  ; 
0x001617 ---- 00:D607:  ROR ram_0000  ; $0000
0x001619 ---- 00:D609:  PHA  ; 
0x00161A ---- 00:D60A:  TXA  ; 
0x00161B ---- 00:D60B:  ORA ram_0000  ; $0000
0x00161D ---- 00:D60D:  TAY  ; 
0x00161E ---- 00:D60E:  PLA  ; 
0x00161F ---- 00:D60F:  ORA #$04  ; 
0x001621 -z-- 00:D611:  RTS  ; 000AAB 000C71 0016C6 0016F0 00171C 001800
; 1 refs via 00182E
0x001622 ---- 00:D612:  JSR $D635  ; 001645
; 1 refs via 001693
0x001625 ---- 00:D615:  LDX ram_000C  ; $000C
0x001627 ---- 00:D617:  LDA #$23  ; 
0x001629 nz-- 00:D619:  STA ram_0180,X  ; $0180 $0194 $01A9
0x00162C nz-- 00:D61C:  INX  ; 
0x00162D ---- 00:D61D:  TYA  ; 
0x00162E ---- 00:D61E:  CLC  ; 
0x00162F --c- 00:D61F:  ADC #$C0  ; 
0x001631 ---- 00:D621:  STA ram_0180,X  ; $0181 $0195 $01AA
0x001634 ---- 00:D624:  INX  ; 
0x001635 ---- 00:D625:  LDA ram_07C0,Y  ; $07C0 $07C1 $07C2 $07C3 $07C4 $07C5 $07C6 $07C8 $07C9 $07CA $07CB $07CC $07CD $07CE $07D0 $07D1 $07D2 $07D3 $07D4 $07D5 $07D6 $07D8 $07D9 $07DA $07DB $07DC $07DD $07DE $07E0 $07E1 $07E2 $07E3 $07E4 $07E5 $07E6 $07E8 $07E9 $07EA $07EB $07EC $07ED $07EE $07F0 $07F1 $07F2 $07F3 $07F4 $07F5 $07F6
0x001638 ---- 00:D628:  STA ram_0180,X  ; $0182 $0196 $01AB
0x00163B ---- 00:D62B:  INX  ; 
0x00163C ---- 00:D62C:  LDA #$FF  ; 
0x00163E Nz-- 00:D62E:  STA ram_0180,X  ; $0183 $0197 $01AC
0x001641 Nz-- 00:D631:  INX  ; 
0x001642 ---- 00:D632:  STX ram_000C  ; $000C
0x001644 ---- 00:D634:  RTS  ; 001831
; 1 refs via 001622
0x001645 ---- 00:D635:  LDA ram_0004  ; $0004
0x001647 ---- 00:D637:  JSR $D684  ; 001694
; 1 refs via 001698
0x00164A ---- 00:D63A:  JSR $D684  ; 001694
; 1 refs via 001698
0x00164D ---- 00:D63D:  JSR $D684  ; 001694
; 1 refs via 001698
0x001650 ---- 00:D640:  STA ram_0002  ; $0002
0x001652 ---- 00:D642:  TYA  ; 
0x001653 ---- 00:D643:  AND #$02  ; 
0x001655 ---- 00:D645:  BNE $D656  ; 001666
0x001657 -Z-- 00:D647:  TXA  ; 
0x001658 ---- 00:D648:  AND #$02  ; 
0x00165A ---- 00:D64A:  BEQ $D651  ; 001661
0x00165C -z-- 00:D64C:  LDA #$F3  ; 
0x00165E Nz-- 00:D64E:  JMP $D662  ; 001672
; 1 refs via 00165A
0x001661 -Z-- 00:D651:  LDA #$FC  ; 
0x001663 Nz-- 00:D653:  JMP $D662  ; 001672
; 1 refs via 001655
0x001666 -z-- 00:D656:  TXA  ; 
0x001667 ---- 00:D657:  AND #$02  ; 
0x001669 ---- 00:D659:  BEQ $D660  ; 001670
0x00166B -z-- 00:D65B:  LDA #$3F  ; 
0x00166D nz-- 00:D65D:  JMP $D662  ; 001672
; 1 refs via 001669
0x001670 -Z-- 00:D660:  LDA #$CF  ; 
; 3 refs via 00165E 001663 00166D
0x001672 -z-- 00:D662:  STA ram_0001  ; $0001
0x001674 -z-- 00:D664:  TYA  ; 
0x001675 ---- 00:D665:  ASL  ; 
0x001676 ---- 00:D666:  AND #$F8  ; 
0x001678 ---- 00:D668:  STA ram_0000  ; $0000
0x00167A ---- 00:D66A:  TXA  ; 
0x00167B ---- 00:D66B:  LSR  ; 
0x00167C ---- 00:D66C:  LSR  ; 
0x00167D ---- 00:D66D:  CLC  ; 
0x00167E --c- 00:D66E:  ADC ram_0000  ; $0000
0x001680 ---- 00:D670:  TAY  ; 
0x001681 ---- 00:D671:  LDA ram_0001  ; $0001
0x001683 ---- 00:D673:  EOR #$FF  ; 
0x001685 ---- 00:D675:  AND ram_0002  ; $0002
0x001687 ---- 00:D677:  STA ram_0002  ; $0002
0x001689 ---- 00:D679:  LDA ram_07C0,Y  ; $07C0 $07C1 $07C2 $07C3 $07C4 $07C5 $07C6 $07C8 $07C9 $07CA $07CB $07CC $07CD $07CE $07D0 $07D1 $07D2 $07D3 $07D4 $07D5 $07D6 $07D8 $07D9 $07DA $07DB $07DC $07DD $07DE $07E0 $07E1 $07E2 $07E3 $07E4 $07E5 $07E6 $07E8 $07E9 $07EA $07EB $07EC $07ED $07EE $07F0 $07F1 $07F2 $07F3 $07F4 $07F5 $07F6
0x00168C ---- 00:D67C:  AND ram_0001  ; $0001
0x00168E ---- 00:D67E:  ORA ram_0002  ; $0002
0x001690 ---- 00:D680:  STA ram_07C0,Y  ; $07C0 $07C1 $07C2 $07C3 $07C4 $07C5 $07C6 $07C8 $07C9 $07CA $07CB $07CC $07CD $07CE $07D0 $07D1 $07D2 $07D3 $07D4 $07D5 $07D6 $07D8 $07D9 $07DA $07DB $07DC $07DD $07DE $07E0 $07E1 $07E2 $07E3 $07E4 $07E5 $07E6 $07E8 $07E9 $07EA $07EB $07EC $07ED $07EE $07F0 $07F1 $07F2 $07F3 $07F4 $07F5 $07F6
0x001693 ---- 00:D683:  RTS  ; 001625
; 3 refs via 001647 00164A 00164D
0x001694 ---- 00:D684:  ASL  ; 
0x001695 ---- 00:D685:  ASL  ; 
0x001696 ---- 00:D686:  ORA ram_0004  ; $0004
0x001698 ---- 00:D688:  RTS  ; 00164A 00164D 001650
; 1 refs via 001443
0x001699 nz-- 00:D689:  LDX #$01  ; 
0x00169B nz-- 00:D68B:  STX $4016  ; $4016
0x00169E nz-- 00:D68E:  LDY #$00  ; 
0x0016A0 nZ-- 00:D690:  STY $4016  ; $4016
; 1 refs via 0016C0
0x0016A3 n--- 00:D693:  STY ram_0000  ; $0000
0x0016A5 n--- 00:D695:  LDY #$08  ; 
; 1 refs via 0016B1
0x0016A7 -z-- 00:D697:  LDA $4016,X  ; $4016 $4017
0x0016AA ---- 00:D69A:  AND #$03  ; 
0x0016AC ---- 00:D69C:  CMP #$01  ; 
0x0016AE ---- 00:D69E:  ROR ram_0000  ; $0000
0x0016B0 ---- 00:D6A0:  DEY  ; 
0x0016B1 ---- 00:D6A1:  BNE $D697  ; 0016A7
0x0016B3 -Z-- 00:D6A3:  LDA ram_0006,X  ; $0006 $0007
0x0016B5 ---- 00:D6A5:  EOR #$FF  ; 
0x0016B7 ---- 00:D6A7:  AND ram_0000  ; $0000
0x0016B9 ---- 00:D6A9:  STA ram_0008,X  ; $0008 $0009
0x0016BB ---- 00:D6AB:  LDA ram_0000  ; $0000
0x0016BD ---- 00:D6AD:  STA ram_0006,X  ; $0006 $0007
0x0016BF ---- 00:D6AF:  DEX  ; 
0x0016C0 ---- 00:D6B0:  BPL $D693  ; 0016A3
0x0016C2 N--- 00:D6B2:  RTS  ; 001446
; 64 refs via 0004D4 0004E6 0004F8 00050A 00051C 00052E 000540 000552 000564 0007EE 00080E 00084C 000865 000878 000887 0008BD 0008CC 000B11 000B20 000B2F 000B3E 000B79 000B88 000BBA 000BC9 000BD8 000BE7 000C24 000C33 000E7A 000E89 000ED5 000EE4 000F3D 000F58 000F7B 000F96 000FA5 000FB4 000FC3 000FD9 000FF4 001003 001012 001021 001033 001042 001051 001060 001076 001085 001094 0010A3 0010B5 0010C4 0011D5 0011F0 00120F 001231 001240 00124F 001261 001270 001282
0x0016C3 nz-- 00:D6B3:  JSR $D5FB  ; 00160B
; 1 refs via 001621
0x0016C6 -z-- 00:D6B6:  STA ram_0014  ; $0014
0x0016C8 -z-- 00:D6B8:  CLC  ; 
0x0016C9 -zc- 00:D6B9:  ADC ram_0005  ; $0005
0x0016CB ---- 00:D6BB:  LDX ram_000C  ; $000C
0x0016CD ---- 00:D6BD:  STA ram_0180,X  ; $0180 $0184 $0185 $0186 $0188 $0189 $018A $018B $018C $018D $018E $018F $0190 $0191 $0192 $0193 $0194 $0195 $0196 $0197 $0198 $0199 $019A $019B $019C $019D $019E $019F $01A0 $01A1 $01A3 $01A4 $01A8 $01A9 $01AA $01AC $01AD $01B1 $01B2 $01B7 $01B9 $01BC $01BD $01C1 $01C6 $01CB $01D0 $01D5
0x0016D0 ---- 00:D6C0:  INX  ; 
0x0016D1 ---- 00:D6C1:  TYA  ; 
0x0016D2 ---- 00:D6C2:  STA ram_0180,X  ; $0181 $0185 $0186 $0187 $0189 $018A $018B $018C $018D $018E $018F $0190 $0191 $0192 $0193 $0194 $0195 $0196 $0197 $0198 $0199 $019A $019B $019C $019D $019E $019F $01A0 $01A1 $01A2 $01A4 $01A5 $01A9 $01AA $01AB $01AD $01AE $01B2 $01B3 $01B8 $01BA $01BD $01BE $01C2 $01C7 $01CC $01D1 $01D6
0x0016D5 ---- 00:D6C5:  INX  ; 
0x0016D6 ---- 00:D6C6:  STA ram_0013  ; $0013
0x0016D8 ---- 00:D6C8:  LDY #$00  ; 
; 1 refs via 0016E7
0x0016DA ---- 00:D6CA:  LDA (ram_0011),Y  ; 001294 001295 001296 001297 001298 001299 00129A 00129B 00129C 00129D 00129E 00129F 0012A0 0012A1 0012A2 0012A3 0012A4 0012A5 0012A6 0012A7 0012A8 0012B5 0012B6 0012B7 0012B8 0012B9 0012BA 0012BB 0012BC 0012BD 0012BE 0012BF 0012C0 0012C1 0012C2 0012C3 0012C4 0012CD 0012CE 0012CF 0012D0 0012D1 0012D2 0012D3 0012D4 0012D5 0012D6 0012D7 0012D8 0012D9 0012DA 0012DB 0012DC 0012DD 0012DE 0012DF 0012E0 0012E1 0012E2 0012E3 0012E4 0012E5 0012E6 0012E7 0012E8 0012E9 0012EA 0012EB 0012EC 0012ED 0012EE 0012EF 0012F0 0012F1 0012F2 0012F3 0012F4 0012F5 0012F6 0012F7 0012F8 0012F9 0012FA 0012FB 0012FC 0012FD 0012FE 0012FF 001300 001301 001302 001303 001304 001305 001306 001307 001308 001309 00130A 00130B 00130C 00130D 00130E 00130F 001310 001311 001312 001313 001314 001315 001316 001317 001318 001319 00131A 00131B 00131C 00131D 00131E 00131F 001320 001321 001322 001323 001324 001325 001326 001327 001328 001329 00132A 00132B 00132C 00132D 00132E 00132F 001330 001331 001332 001333 001334 001335 001336 001337 001338 001339 00133A 00133B 00133C 00133D 00133E 00133F 001340 001341 001342 001343 001344 001345 001346 001347 001348 001349 00134A 00134B 00134C 00134D 00134E 00134F 001350 001351 001352 00135D 00135E 00135F 001360 001361 001362 001363 001364 001365 001366 001367 001368 001369 00136A 00136B 00136C 00136D 00136E 00136F 001370 001371 001372 001373 001374 001375 001376 001377 001378 001379 00137A 00137B 00137C 00137D 00137E 00137F 001380 001381 001382 001383 001384 001385 001386 001387 001388 001389 00138A 00138B 00138C 00138D 00138E 00138F 001390 001391 001392 001393 001394 001395 001396 001397 001398 001399 00139A 00139B 00139C 00139D 00139E 00139F 0013A0 0013A1 0013A2 0013A3 0013A4 0013A5 0013A6 0013A7 0013A8 0013A9 0013AA 0013AB 0013AC 0013AD 0013AE 0013AF 0013B0 0013B1 0013B2 0013B3 0013B4 0013B5 0013B6 0013B7 0013B8 0013B9 0013BA 0013BB 0013BC 0013BD 0013BE 0013BF 0013C0 0013C1 0013C2 0013C3 0013C4 0013C5 0013C6 0013C7 0013C8 0013C9 0013CA 0013CB 0013CC 0013CD 0013CE 0013CF 0013D0 0013D1 0013D2 0013D3 0013D4 0013D5 0013D6 0013D7 0013D8 0013D9 0013DA 0013DB 0013DC 0013DD 0013DE 0013DF 0013E0
0x0016DC ---- 00:D6CC:  STA ram_0180,X  ; $0182 $0183 $0184 $0185 $0186 $0187 $0188 $0189 $018A $018B $018C $018D $018E $018F $0190 $0191 $0192 $0193 $0194 $0195 $0196 $0197 $0198 $0199 $019A $019B $019C $019D $019E $019F $01A0 $01A1 $01A2 $01A3 $01A4 $01A5 $01A6 $01A7 $01A8 $01A9 $01AA $01AB $01AC $01AD $01AE $01AF $01B0 $01B1 $01B2 $01B3 $01B4 $01B5 $01B6 $01B9 $01BA $01BB $01BC $01BE $01BF $01C0 $01C3 $01C4 $01C5 $01C8 $01C9 $01CA $01CD $01CE $01CF $01D2 $01D3 $01D4 $01D7 $01D8 $01D9
0x0016DF ---- 00:D6CF:  INX  ; 
0x0016E0 ---- 00:D6D0:  CMP #$FF  ; 
0x0016E2 ---- 00:D6D2:  BEQ $D6DA  ; 0016EA
0x0016E4 -z-- 00:D6D4:  STA (ram_0013),Y  ; $0462 $0463 $0468 $0469 $046A $046B $046C $046D $046E $046F $0475 $0476 $047D $047E $049D $049E $04AC $04AD $04AE $04AF $04B0 $04BD $04BE $04DD $04DE $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $04FC $04FD $04FE $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $051D $051E $053D $053E $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $055D $055E $057D $057E $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $059A $059B $059C $059D $059E $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05E8 $05E9 $05EA $05EE $05F1 $05FA $05FB $05FC $0608 $0609 $060A $060B $060C $062B $062C $062D $062E $062F $0630 $0631 $0632 $063D $063E $0648 $0649 $064A $064E $0651 $065A $065B $065C $065D $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $069D $069E $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06BA $06BB $06BC $06BD $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06FD $06FE $070C $070D $070E $070F $0710 $0711 $071D $071E $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072C $072D $072E $072F $0730 $0731 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $0748 $0749 $074A $074C $074D $074E $074F $0750 $0751 $075B $075C $075D $0766 $0767 $0768 $0769 $076A $076B $076C $076D $076E $076F $0770 $0771 $0772 $0773 $0774 $0775 $0776 $0777 $0778
0x0016E6 -z-- 00:D6D6:  INY  ; 
0x0016E7 ---- 00:D6D7:  JMP $D6CA  ; 0016DA
; 1 refs via 0016E2
0x0016EA -Z-- 00:D6DA:  STX ram_000C  ; $000C
0x0016EC -Z-- 00:D6DC:  RTS  ; 0004D7 0004E9 0004FB 00050D 00051F 000531 000543 000555 000567 0007F1 000811 00084F 000868 00087B 00088A 0008C0 0008CF 000B14 000B23 000B32 000B41 000B7C 000B8B 000BBD 000BCC 000BDB 000BEA 000C27 000C36 000E7D 000E8C 000ED8 000EE7 000F40 000F5B 000F7E 000F99 000FA8 000FB7 000FC6 000FDC 000FF7 001006 001015 001024 001036 001045 001054 001063 001079 001088 001097 0010A6 0010B8 0010C7 0011D8 0011F3 001212 001234 001243 001252 001264 001273 001285
; 24 refs via 00077B 000792 000832 00089C 000AFD 000D77 000D8B 000DA6 000DB6 000DCA 000DE5 000E17 000E2C 000E5F 000E6B 000EBA 000EC6 000F49 000F69 000F87 000FE5 0011E1 0011FC 00121B
0x0016ED ---- 00:D6DD:  JSR $D5FB  ; 00160B
; 1 refs via 001621
0x0016F0 -z-- 00:D6E0:  CLC  ; 
0x0016F1 -zc- 00:D6E1:  ADC ram_0005  ; $0005
0x0016F3 ---- 00:D6E3:  LDX ram_000C  ; $000C
0x0016F5 ---- 00:D6E5:  STA ram_0180,X  ; $0180 $0184 $0185 $0186 $0187 $0188 $0189 $018A $018B $018C $018D $018E $018F $0190 $0191 $0192 $0193 $0194 $0196 $0198 $0199 $019A $019B $019C $019D $019E $01A0 $01A4 $01A6 $01A8 $01AC $01AD $01B0 $01B1 $01B4 $01B5 $01BD $01C5
0x0016F8 ---- 00:D6E8:  INX  ; 
0x0016F9 ---- 00:D6E9:  TYA  ; 
0x0016FA ---- 00:D6EA:  STA ram_0180,X  ; $0181 $0185 $0186 $0187 $0188 $0189 $018A $018B $018C $018D $018E $018F $0190 $0191 $0192 $0193 $0194 $0195 $0197 $0199 $019A $019B $019C $019D $019E $019F $01A1 $01A5 $01A7 $01A9 $01AD $01AE $01B1 $01B2 $01B5 $01B6 $01BE $01C6
0x0016FD ---- 00:D6ED:  INX  ; 
0x0016FE ---- 00:D6EE:  LDY #$00  ; 
; 1 refs via 001710
0x001700 ---- 00:D6F0:  LDA (ram_0011),Y  ; $0016 $0017 $0018 $0019 $001A $001B $001C $001F $0020 $0021 $0022 $0023 $0024 $0028 $0029 $002A $002B $002C $0030 $0031 $0032 $0033 $0034 $0038 $0039 $003A $003B $003C $003E $003F $0040 $0041 $0042 $0043 $0044
0x001702 ---- 00:D6F2:  BMI $D6F7  ; 001707
0x001704 n--- 00:D6F4:  CLC  ; 
0x001705 n-c- 00:D6F5:  ADC ram_0060  ; $0060
; 1 refs via 001702
0x001707 ---- 00:D6F7:  STA ram_0180,X  ; $0182 $0183 $0184 $0185 $0186 $0187 $0188 $0189 $018A $018B $018C $018D $018E $018F $0190 $0191 $0192 $0193 $0194 $0195 $0196 $0197 $0198 $0199 $019A $019B $019C $019D $019E $019F $01A0 $01A1 $01A2 $01A3 $01A4 $01A5 $01A6 $01A7 $01A8 $01A9 $01AA $01AB $01AE $01AF $01B0 $01B2 $01B3 $01B4 $01B6 $01B7 $01B8 $01BF $01C0 $01C7 $01C8
0x00170A ---- 00:D6FA:  INX  ; 
0x00170B ---- 00:D6FB:  CMP #$FF  ; 
0x00170D ---- 00:D6FD:  BEQ $D703  ; 001713
0x00170F -z-- 00:D6FF:  INY  ; 
0x001710 ---- 00:D700:  JMP $D6F0  ; 001700
; 1 refs via 00170D
0x001713 -Z-- 00:D703:  STX ram_000C  ; $000C
0x001715 -Z-- 00:D705:  RTS  ; 00077E 000795 000835 00089F 000B00 000D7A 000D8E 000DA9 000DB9 000DCD 000DE8 000E1A 000E2F 000E62 000E6E 000EBD 000EC9 000F4C 000F6C 000F8A 000FE8 0011E4 0011FF 00121E
; 6 refs via 001732 001A48 001CE2 001D07 0021AB 0026A7
0x001716 ---- 00:D706:  JSR $D713  ; 001723
; 2 refs via 00172D 00183B
0x001719 ---- 00:D709:  JSR $D5FB  ; 00160B
; 1 refs via 001621
0x00171C ---- 00:D70C:  STA ram_0012  ; $0012
0x00171E ---- 00:D70E:  STY ram_0011  ; $0011
0x001720 ---- 00:D710:  LDY #$00  ; 
0x001722 nZ-- 00:D712:  RTS  ; 001735 00183E 001A4B 001CE5 001D0A 0021AE 0026AA
; 2 refs via 001716 00181E
0x001723 ---- 00:D713:  TYA  ; 
0x001724 ---- 00:D714:  LSR  ; 
0x001725 ---- 00:D715:  LSR  ; 
0x001726 ---- 00:D716:  LSR  ; 
0x001727 ---- 00:D717:  TAY  ; 
0x001728 ---- 00:D718:  TXA  ; 
0x001729 ---- 00:D719:  LSR  ; 
0x00172A ---- 00:D71A:  LSR  ; 
0x00172B ---- 00:D71B:  LSR  ; 
0x00172C ---- 00:D71C:  TAX  ; 
0x00172D ---- 00:D71D:  RTS  ; 001719 001821
; 1 refs via 0018B2
0x00172E ---- 00:D71E:  STX ram_0047  ; $0047
0x001730 ---- 00:D720:  STY ram_0048  ; $0048
0x001732 ---- 00:D722:  JSR $D706  ; 001716
; 2 refs via 001722 0026AA
0x001735 ---- 00:D725:  LDA #$01  ; 
0x001737 nz-- 00:D727:  STA ram_0000  ; $0000
0x001739 nz-- 00:D729:  LDA ram_0048  ; $0048
0x00173B ---- 00:D72B:  AND #$04  ; 
0x00173D ---- 00:D72D:  BEQ $D733  ; 001743
0x00173F -z-- 00:D72F:  ASL ram_0000  ; $0000
0x001741 ---- 00:D731:  ASL ram_0000  ; $0000
; 1 refs via 00173D
0x001743 ---- 00:D733:  LDA ram_0047  ; $0047
0x001745 ---- 00:D735:  AND #$04  ; 
0x001747 ---- 00:D737:  BEQ $D73B  ; 00174B
0x001749 -z-- 00:D739:  ASL ram_0000  ; $0000
; 1 refs via 001747
0x00174B ---- 00:D73B:  RTS  ; 0018B5 0026AD
; 1 refs via 0026AD
0x00174C ---- 00:D73C:  LDA ram_0000  ; $0000
0x00174E ---- 00:D73E:  ORA #$F0  ; 
0x001750 Nz-- 00:D740:  AND (ram_0011),Y  ; $0422 $0423 $0424 $0425 $0426 $0427 $0428 $0429 $042A $042B $042C $042D $042E $042F $0430 $0431 $0432 $0433 $0434 $0435 $0436 $0437 $0438 $0439 $043A $043B $0440 $0441 $0442 $0443 $0444 $0445 $0446 $0447 $0448 $0449 $044A $044B $044C $044D $044E $044F $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0458 $0459 $045A $045B $045C $0460 $0461 $0462 $0463 $0464 $0465 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $046E $046F $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $047A $047B $047C $0481 $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $049C $04A1 $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04BC $04C1 $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04DC $04E1 $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $04FC $0501 $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $051C $0521 $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $053C $0541 $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $055C $0561 $0562 $0563 $0564 $0565 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $057C $0581 $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $059C $05A1 $05A2 $05A3 $05A4 $05A5 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05BC $05C1 $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05DC $05E1 $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $05FC $0601 $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $061C $0621 $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $0639 $063A $063B $063C $0641 $0642 $0643 $0644 $0645 $0646 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $065C $0661 $0662 $0663 $0664 $0665 $0666 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $067C $0681 $0682 $0683 $0684 $0685 $0686 $0687 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0692 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $069C $06A1 $06A2 $06A3 $06A4 $06A5 $06A6 $06A7 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B7 $06B8 $06B9 $06BA $06BB $06BC $06C1 $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06DC $06E1 $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $06FA $06FB $06FC $0702 $0703 $0704 $0705 $0706 $0707 $0708 $0709 $070A $070B $070C $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0717 $0718 $0719 $071A $071B $071C $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072C $072D $072E $072F $0730 $0731 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $073C $0741 $0742 $0743 $0744 $0745 $0746 $0747 $0748 $0749 $074A $074B $074C $074D $074E $074F $0750 $0751 $0752 $0753 $0754 $0755 $0756 $0757 $0758 $0759 $075A $075B $075C $0761 $0762 $0763 $0764 $0765 $0766 $0767 $0768 $0769 $076A $076B $076C $076D $076E $076F $0770 $0771 $0772 $0773 $0774 $0775 $0776 $0777 $0778 $0779 $077A $077B $077C $0782 $0783 $0784 $0786 $0787 $0788 $0789 $078A $078B $078C $078D $0790 $0791 $0792 $0793 $0794 $0795 $0796 $0797 $0798 $0799 $079A $079B
0x001752 ---- 00:D742:  RTS  ; 0026B0
; 1 refs via 00270A
0x001753 ---- 00:D743:  LDA ram_0000  ; $0000
0x001755 ---- 00:D745:  EOR #$FF  ; 
0x001757 ---- 00:D747:  AND (ram_0011),Y  ; $0446 $0447 $0448 $0449 $044A $044B $044C $044D $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $0502 $0503 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $0562 $0563 $0564 $0565 $0566 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $05A2 $05A3 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0619 $061A $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $063A $0642 $0643 $0644 $0645 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $0662 $0663 $0664 $0665 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $0682 $0683 $0684 $0685 $0686 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $06A2 $06A3 $06A4 $06A5 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B8 $06B9 $06BA $06BB $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $0702 $0703 $0704 $0705 $0708 $0709 $070A $070B $0712 $0713 $0714 $0715 $0716 $0718 $0719 $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072D $072E $072F $0730 $0734 $0735 $0736 $0737 $0738 $0739 $0742 $0743 $0745 $0746 $0748 $0749 $074D $0750 $0754 $0755 $0756 $0757 $0762 $0763 $0766 $0768 $0769 $076D $0770 $0775 $0776 $0777
0x001759 ---- 00:D749:  JSR $D784  ; 001794
; 1 refs via 0017B9
0x00175C ---- 00:D74C:  RTS  ; 00270D
; 1 refs via 0018C1
0x00175D -Z-- 00:D74D:  LDA (ram_0011),Y  ; $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D5 $04D6 $04D7 $04D9 $04DA $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FC $04FD $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051C $051D $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053C $053D $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $055C $055D $0563 $0564 $0565 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0579 $057A $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05BC $05BD $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05DA $05DB $05DC $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $05FC $05FD $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $061C $061D $0627 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677
0x00175F ---- 00:D74F:  AND #$F0  ; 
0x001761 ---- 00:D751:  BNE $D75B  ; 00176B
0x001763 -Z-- 00:D753:  LDA ram_0000  ; $0000
0x001765 ---- 00:D755:  EOR #$FF  ; 
0x001767 ---- 00:D757:  AND (ram_0011),Y  ; $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D5 $04D6 $04D7 $04D9 $04DA $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FC $04FD $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051C $051D $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053C $053D $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $055C $055D $0563 $0564 $0565 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0579 $057A $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05BC $05BD $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05DA $05DB $05DC $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $05FC $05FD $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $061C $061D $0627 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677
0x001769 ---- 00:D759:  STA (ram_0011),Y  ; $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D5 $04D6 $04D7 $04D9 $04DA $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FC $04FD $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051C $051D $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053C $053D $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $055C $055D $0563 $0564 $0565 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0579 $057A $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05BC $05BD $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05DA $05DB $05DC $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $05FC $05FD $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $061C $061D $0627 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677
; 1 refs via 001761
0x00176B ---- 00:D75B:  RTS  ; 0018C4
0x00176C ---- xx:D75C:  .byte $A5   ; 
0x00176D ---- xx:D75D:  .byte $00   ; 
0x00176E ---- xx:D75E:  .byte $11   ; 
0x00176F ---- xx:D75F:  .byte $11   ; 
0x001770 ---- xx:D760:  .byte $20   ; 
0x001771 ---- xx:D761:  .byte $84   ; 
0x001772 ---- xx:D762:  .byte $D7   ; 
0x001773 ---- xx:D763:  .byte $60   ; 
; 1 refs via 0018BB
0x001774 -z-- 00:D764:  LDA (ram_0011),Y  ; $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04DC $04DD $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04EA $04EB $04EC $04ED $04EE $04EF $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051B $051C $051D $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $053C $053D $0543 $0544 $0545 $0546 $0547 $0548 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0558 $0559 $055A $0563 $0564 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BB $05BC $05BD $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D9 $05DA $05DB $05DD $05E8 $05E9 $05EA $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F9 $05FA $05FB $05FD $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $061B $061C $0628 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0634 $0635 $0636 $0637 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657
0x001776 ---- 00:D766:  AND #$F0  ; 
0x001778 ---- 00:D768:  BNE $D770  ; 001780
0x00177A -Z-- 00:D76A:  LDA ram_0000  ; $0000
0x00177C ---- 00:D76C:  ORA (ram_0011),Y  ; $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04DC $04DD $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04EA $04EB $04EC $04ED $04EE $04EF $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051B $051C $051D $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $053C $053D $0543 $0544 $0545 $0546 $0547 $0548 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0558 $0559 $055A $0563 $0564 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BB $05BC $05BD $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D9 $05DA $05DB $05DD $05E8 $05E9 $05EA $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F9 $05FA $05FB $05FD $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $061B $061C $0628 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0634 $0635 $0636 $0637 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657
0x00177E ---- 00:D76E:  STA (ram_0011),Y  ; $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04DC $04DD $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04EA $04EB $04EC $04ED $04EE $04EF $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051B $051C $051D $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $053C $053D $0543 $0544 $0545 $0546 $0547 $0548 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0558 $0559 $055A $0563 $0564 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BB $05BC $05BD $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D9 $05DA $05DB $05DD $05E8 $05E9 $05EA $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F9 $05FA $05FB $05FD $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $061B $061C $0628 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0634 $0635 $0636 $0637 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657
; 1 refs via 001778
0x001780 ---- 00:D770:  RTS  ; 0018BE
; 1 refs via 0017CD
0x001781 -z-- 00:D771:  LDA ram_0012  ; $0012
0x001783 ---- 00:D773:  CLC  ; 
0x001784 --c- 00:D774:  ADC ram_0005  ; $0005
0x001786 ---- 00:D776:  STA $2006  ; $2006
0x001789 ---- 00:D779:  LDA ram_0011  ; $0011
0x00178B ---- 00:D77B:  STA $2006  ; $2006
0x00178E ---- 00:D77E:  LDA (ram_0011),Y  ; $0400 $0401 $0402 $0403 $0404 $0405 $0406 $0407 $0408 $0409 $040A $040B $040C $040D $040E $040F $0410 $0411 $0412 $0413 $0414 $0415 $0416 $0417 $0418 $0419 $041A $041B $041C $041D $041E $041F $0420 $0421 $0422 $0423 $0424 $0425 $0426 $0427 $0428 $0429 $042A $042B $042C $042D $042E $042F $0430 $0431 $0432 $0433 $0434 $0435 $0436 $0437 $0438 $0439 $043A $043B $043C $043D $043E $043F $0440 $0441 $0442 $0443 $0444 $0445 $0446 $0447 $0448 $0449 $044A $044B $044C $044D $044E $044F $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0458 $0459 $045A $045B $045C $045D $045E $045F $0460 $0461 $0462 $0463 $0464 $0465 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $046E $046F $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $047A $047B $047C $047D $047E $047F $0480 $0481 $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $049C $049D $049E $049F $04A0 $04A1 $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04BC $04BD $04BE $04BF $04C0 $04C1 $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04DC $04DD $04DE $04DF $04E0 $04E1 $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $04FC $04FD $04FE $04FF $0500 $0501 $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $051C $051D $051E $051F $0520 $0521 $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $053C $053D $053E $053F $0540 $0541 $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $055C $055D $055E $055F $0560 $0561 $0562 $0563 $0564 $0565 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $057C $057D $057E $057F $0580 $0581 $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $059C $059D $059E $059F $05A0 $05A1 $05A2 $05A3 $05A4 $05A5 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05BC $05BD $05BE $05BF $05C0 $05C1 $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05DC $05DD $05DE $05DF $05E0 $05E1 $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $05FC $05FD $05FE $05FF $0600 $0601 $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $061C $061D $061E $061F $0620 $0621 $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $0639 $063A $063B $063C $063D $063E $063F $0640 $0641 $0642 $0643 $0644 $0645 $0646 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $065C $065D $065E $065F $0660 $0661 $0662 $0663 $0664 $0665 $0666 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $067C $067D $067E $067F $0680 $0681 $0682 $0683 $0684 $0685 $0686 $0687 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0692 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $069C $069D $069E $069F $06A0 $06A1 $06A2 $06A3 $06A4 $06A5 $06A6 $06A7 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B7 $06B8 $06B9 $06BA $06BB $06BC $06BD $06BE $06BF $06C0 $06C1 $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06DC $06DD $06DE $06DF $06E0 $06E1 $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $06FA $06FB $06FC $06FD $06FE $06FF $0700 $0701 $0702 $0703 $0704 $0705 $0706 $0707 $0708 $0709 $070A $070B $070C $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0717 $0718 $0719 $071A $071B $071C $071D $071E $071F $0720 $0721 $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072C $072D $072E $072F $0730 $0731 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $073C $073D $073E $073F $0740 $0741 $0742 $0743 $0744 $0745 $0746 $0747 $0748 $0749 $074A $074B $074C $074D $074E $074F $0750 $0751 $0752 $0753 $0754 $0755 $0756 $0757 $0758 $0759 $075A $075B $075C $075D $075E $075F $0760 $0761 $0762 $0763 $0764 $0765 $0766 $0767 $0768 $0769 $076A $076B $076C $076D $076E $076F $0770 $0771 $0772 $0773 $0774 $0775 $0776 $0777 $0778 $0779 $077A $077B $077C $077D $077E $077F $0780 $0781 $0782 $0783 $0784 $0785 $0786 $0787 $0788 $0789 $078A $078B $078C $078D $078E $078F $0790 $0791 $0792 $0793 $0794 $0795 $0796 $0797 $0798 $0799 $079A $079B $079C $079D $079E $079F $07A0 $07A1 $07A2 $07A3 $07A4 $07A5 $07A6 $07A7 $07A8 $07A9 $07AA $07AB $07AC $07AD $07AE $07AF $07B0 $07B1 $07B2 $07B3 $07B4 $07B5 $07B6 $07B7 $07B8 $07B9 $07BA $07BB $07BC $07BD $07BE $07BF $07C0 $07C1 $07C2 $07C3 $07C4 $07C5 $07C6 $07C7 $07C8 $07C9 $07CA $07CB $07CC $07CD $07CE $07CF $07D0 $07D1 $07D2 $07D3 $07D4 $07D5 $07D6 $07D7 $07D8 $07D9 $07DA $07DB $07DC $07DD $07DE $07DF $07E0 $07E1 $07E2 $07E3 $07E4 $07E5 $07E6 $07E7 $07E8 $07E9 $07EA $07EB $07EC $07ED $07EE $07EF $07F0 $07F1 $07F2 $07F3 $07F4 $07F5 $07F6 $07F7 $07F8 $07F9 $07FA $07FB $07FC $07FD $07FE $07FF
0x001790 ---- 00:D780:  STA $2007  ; $2007
0x001793 ---- 00:D783:  RTS  ; 0017D0
; 6 refs via 001759 001846 001852 00185E 00186A 0026F0
0x001794 ---- 00:D784:  STA (ram_0011),Y  ; $0442 $0443 $0444 $0445 $0446 $0447 $0448 $0449 $044A $044B $044C $044D $044E $044F $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0458 $0459 $045A $045B $0462 $0463 $0464 $0465 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $046E $046F $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $047A $047B $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $0562 $0563 $0564 $0565 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $05A2 $05A3 $05A4 $05A5 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $0639 $063A $063B $0642 $0643 $0644 $0645 $0646 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $0662 $0663 $0664 $0665 $0666 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $0682 $0683 $0684 $0685 $0686 $0687 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0692 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $06A2 $06A3 $06A4 $06A5 $06A6 $06A7 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B7 $06B8 $06B9 $06BA $06BB $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $06FA $06FB $0702 $0703 $0704 $0705 $0706 $0707 $0708 $0709 $070A $070B $070C $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0717 $0718 $0719 $071A $071B $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072C $072D $072E $072F $0730 $0731 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $0742 $0743 $0744 $0745 $0746 $0747 $0748 $0749 $074A $074B $074C $074D $074E $074F $0750 $0751 $0752 $0753 $0754 $0755 $0756 $0757 $0758 $0759 $075A $075B $0762 $0763 $0764 $0765 $0766 $0767 $0768 $0769 $076A $076B $076C $076D $076E $076F $0770 $0771 $0772 $0773 $0774 $0775 $0776 $0777 $0778 $0779 $077A $077B
0x001796 ---- 00:D786:  STX ram_0047  ; $0047
0x001798 ---- 00:D788:  LDX ram_000C  ; $000C
0x00179A ---- 00:D78A:  LDA ram_0012  ; $0012
0x00179C ---- 00:D78C:  CLC  ; 
0x00179D --c- 00:D78D:  ADC #$1C  ; 
0x00179F ---- 00:D78F:  STA ram_0180,X  ; $0180 $0184 $0188 $018C $0190 $0194 $0198 $019C $01A0 $01A4 $01A9 $01AD $01B1 $01B5 $01B9
0x0017A2 ---- 00:D792:  INX  ; 
0x0017A3 ---- 00:D793:  LDA ram_0011  ; $0011
0x0017A5 ---- 00:D795:  STA ram_0180,X  ; $0181 $0185 $0189 $018D $0191 $0195 $0199 $019D $01A1 $01A5 $01AA $01AE $01B2 $01B6 $01BA
0x0017A8 ---- 00:D798:  INX  ; 
0x0017A9 ---- 00:D799:  LDA (ram_0011),Y  ; $0442 $0443 $0444 $0445 $0446 $0447 $0448 $0449 $044A $044B $044C $044D $044E $044F $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0458 $0459 $045A $045B $0462 $0463 $0464 $0465 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $046E $046F $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $047A $047B $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $0562 $0563 $0564 $0565 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $05A2 $05A3 $05A4 $05A5 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $0639 $063A $063B $0642 $0643 $0644 $0645 $0646 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $0662 $0663 $0664 $0665 $0666 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $0682 $0683 $0684 $0685 $0686 $0687 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0692 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $06A2 $06A3 $06A4 $06A5 $06A6 $06A7 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B7 $06B8 $06B9 $06BA $06BB $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $06FA $06FB $0702 $0703 $0704 $0705 $0706 $0707 $0708 $0709 $070A $070B $070C $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0717 $0718 $0719 $071A $071B $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072C $072D $072E $072F $0730 $0731 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $0742 $0743 $0744 $0745 $0746 $0747 $0748 $0749 $074A $074B $074C $074D $074E $074F $0750 $0751 $0752 $0753 $0754 $0755 $0756 $0757 $0758 $0759 $075A $075B $0762 $0763 $0764 $0765 $0766 $0767 $0768 $0769 $076A $076B $076C $076D $076E $076F $0770 $0771 $0772 $0773 $0774 $0775 $0776 $0777 $0778 $0779 $077A $077B
0x0017AB ---- 00:D79B:  STA ram_0180,X  ; $0182 $0186 $018A $018E $0192 $0196 $019A $019E $01A2 $01A6 $01AB $01AF $01B3 $01B7 $01BB
0x0017AE ---- 00:D79E:  INX  ; 
0x0017AF ---- 00:D79F:  LDA #$FF  ; 
0x0017B1 Nz-- 00:D7A1:  STA ram_0180,X  ; $0183 $0187 $018B $018F $0193 $0197 $019B $019F $01A3 $01A7 $01AC $01B0 $01B4 $01B8 $01BC
0x0017B4 Nz-- 00:D7A4:  INX  ; 
0x0017B5 ---- 00:D7A5:  STX ram_000C  ; $000C
0x0017B7 ---- 00:D7A7:  LDX ram_0047  ; $0047
0x0017B9 ---- 00:D7A9:  RTS  ; 00175C 001849 001855 001861 00186D 0026F3
; 8 refs via 000C64 0017D2 001814 00184B 001857 001863 001884 003030
0x0017BA nz-- 00:D7AA:  CLC  ; 
0x0017BB nzc- 00:D7AB:  ADC ram_0011  ; $0011
0x0017BD ---- 00:D7AD:  STA ram_0011  ; $0011
0x0017BF ---- 00:D7AF:  BCC $D7B3  ; 0017C3
0x0017C1 --C- 00:D7B1:  INC ram_0012  ; $0012
; 1 refs via 0017BF
0x0017C3 ---- 00:D7B3:  RTS  ; 000C67 0017D5 001817 00184E 00185A 001866 001887 003033
; 13 refs via 0000C8 0002AB 000419 000481 0004BC 000570 00061F 000648 000F2B 001188 0011BF 0014E2 0014E9
0x0017C4 ---- 00:D7B4:  LDA #$00  ; 
0x0017C6 nZ-- 00:D7B6:  STA ram_0011  ; $0011
0x0017C8 nZ-- 00:D7B8:  TAY  ; 
0x0017C9 ---- 00:D7B9:  LDA #$04  ; 
0x0017CB nz-- 00:D7BB:  STA ram_0012  ; $0012
; 1 refs via 0017D9
0x0017CD -z-- 00:D7BD:  JSR $D771  ; 001781
; 1 refs via 001793
0x0017D0 ---- 00:D7C0:  LDA #$01  ; 
0x0017D2 nz-- 00:D7C2:  JSR $D7AA  ; 0017BA
; 1 refs via 0017C3
0x0017D5 ---- 00:D7C5:  LDA ram_0012  ; $0012
0x0017D7 ---- 00:D7C7:  CMP #$08  ; 
0x0017D9 ---- 00:D7C9:  BNE $D7BD  ; 0017CD
0x0017DB -Z-- 00:D7CB:  RTS  ; 0000CB 0002AE 00041C 000484 0004BF 000573 000622 00064B 000F2E 00118B 0011C2 0014E5 0014EC
; 1 refs via 0009CC
0x0017DC nz-- 00:D7CC:  LDX #$00  ; 
0x0017DE nZ-- 00:D7CE:  LDA #$11  ; 
; 1 refs via 0017ED
0x0017E0 -z-- 00:D7D0:  STA ram_0400,X  ; $0400 $0401 $0402 $0403 $0404 $0405 $0406 $0407 $0408 $0409 $040A $040B $040C $040D $040E $040F $0410 $0411 $0412 $0413 $0414 $0415 $0416 $0417 $0418 $0419 $041A $041B $041C $041D $041E $041F $0420 $0421 $0422 $0423 $0424 $0425 $0426 $0427 $0428 $0429 $042A $042B $042C $042D $042E $042F $0430 $0431 $0432 $0433 $0434 $0435 $0436 $0437 $0438 $0439 $043A $043B $043C $043D $043E $043F $0440 $0441 $0442 $0443 $0444 $0445 $0446 $0447 $0448 $0449 $044A $044B $044C $044D $044E $044F $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0458 $0459 $045A $045B $045C $045D $045E $045F $0460 $0461 $0462 $0463 $0464 $0465 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $046E $046F $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $047A $047B $047C $047D $047E $047F $0480 $0481 $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $049C $049D $049E $049F $04A0 $04A1 $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04BC $04BD $04BE $04BF $04C0 $04C1 $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04DC $04DD $04DE $04DF $04E0 $04E1 $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $04FC $04FD $04FE $04FF
0x0017E3 -z-- 00:D7D3:  STA ram_0500,X  ; $0500 $0501 $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $051C $051D $051E $051F $0520 $0521 $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $053C $053D $053E $053F $0540 $0541 $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $055C $055D $055E $055F $0560 $0561 $0562 $0563 $0564 $0565 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $057C $057D $057E $057F $0580 $0581 $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $059C $059D $059E $059F $05A0 $05A1 $05A2 $05A3 $05A4 $05A5 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05BC $05BD $05BE $05BF $05C0 $05C1 $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05DC $05DD $05DE $05DF $05E0 $05E1 $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $05FC $05FD $05FE $05FF
0x0017E6 -z-- 00:D7D6:  STA ram_0600,X  ; $0600 $0601 $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $061C $061D $061E $061F $0620 $0621 $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $0639 $063A $063B $063C $063D $063E $063F $0640 $0641 $0642 $0643 $0644 $0645 $0646 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $065C $065D $065E $065F $0660 $0661 $0662 $0663 $0664 $0665 $0666 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $067C $067D $067E $067F $0680 $0681 $0682 $0683 $0684 $0685 $0686 $0687 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0692 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $069C $069D $069E $069F $06A0 $06A1 $06A2 $06A3 $06A4 $06A5 $06A6 $06A7 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B7 $06B8 $06B9 $06BA $06BB $06BC $06BD $06BE $06BF $06C0 $06C1 $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06DC $06DD $06DE $06DF $06E0 $06E1 $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $06FA $06FB $06FC $06FD $06FE $06FF
0x0017E9 -z-- 00:D7D9:  STA ram_0700,X  ; $0700 $0701 $0702 $0703 $0704 $0705 $0706 $0707 $0708 $0709 $070A $070B $070C $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0717 $0718 $0719 $071A $071B $071C $071D $071E $071F $0720 $0721 $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072C $072D $072E $072F $0730 $0731 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $073C $073D $073E $073F $0740 $0741 $0742 $0743 $0744 $0745 $0746 $0747 $0748 $0749 $074A $074B $074C $074D $074E $074F $0750 $0751 $0752 $0753 $0754 $0755 $0756 $0757 $0758 $0759 $075A $075B $075C $075D $075E $075F $0760 $0761 $0762 $0763 $0764 $0765 $0766 $0767 $0768 $0769 $076A $076B $076C $076D $076E $076F $0770 $0771 $0772 $0773 $0774 $0775 $0776 $0777 $0778 $0779 $077A $077B $077C $077D $077E $077F $0780 $0781 $0782 $0783 $0784 $0785 $0786 $0787 $0788 $0789 $078A $078B $078C $078D $078E $078F $0790 $0791 $0792 $0793 $0794 $0795 $0796 $0797 $0798 $0799 $079A $079B $079C $079D $079E $079F $07A0 $07A1 $07A2 $07A3 $07A4 $07A5 $07A6 $07A7 $07A8 $07A9 $07AA $07AB $07AC $07AD $07AE $07AF $07B0 $07B1 $07B2 $07B3 $07B4 $07B5 $07B6 $07B7 $07B8 $07B9 $07BA $07BB $07BC $07BD $07BE $07BF $07C0 $07C1 $07C2 $07C3 $07C4 $07C5 $07C6 $07C7 $07C8 $07C9 $07CA $07CB $07CC $07CD $07CE $07CF $07D0 $07D1 $07D2 $07D3 $07D4 $07D5 $07D6 $07D7 $07D8 $07D9 $07DA $07DB $07DC $07DD $07DE $07DF $07E0 $07E1 $07E2 $07E3 $07E4 $07E5 $07E6 $07E7 $07E8 $07E9 $07EA $07EB $07EC $07ED $07EE $07EF $07F0 $07F1 $07F2 $07F3 $07F4 $07F5 $07F6 $07F7 $07F8 $07F9 $07FA $07FB $07FC $07FD $07FE $07FF
0x0017EC -z-- 00:D7DC:  INX  ; 
0x0017ED ---- 00:D7DD:  BNE $D7D0  ; 0017E0
0x0017EF -Z-- 00:D7DF:  LDA #$00  ; 
0x0017F1 nZ-- 00:D7E1:  LDX #$C0  ; 
; 1 refs via 0017F7
0x0017F3 -z-- 00:D7E3:  STA ram_0700,X  ; $07C0 $07C1 $07C2 $07C3 $07C4 $07C5 $07C6 $07C7 $07C8 $07C9 $07CA $07CB $07CC $07CD $07CE $07CF $07D0 $07D1 $07D2 $07D3 $07D4 $07D5 $07D6 $07D7 $07D8 $07D9 $07DA $07DB $07DC $07DD $07DE $07DF $07E0 $07E1 $07E2 $07E3 $07E4 $07E5 $07E6 $07E7 $07E8 $07E9 $07EA $07EB $07EC $07ED $07EE $07EF $07F0 $07F1 $07F2 $07F3 $07F4 $07F5 $07F6 $07F7 $07F8 $07F9 $07FA $07FB $07FC $07FD $07FE $07FF
0x0017F6 -z-- 00:D7E6:  INX  ; 
0x0017F7 ---- 00:D7E7:  BNE $D7E3  ; 0017F3
0x0017F9 -Z-- 00:D7E9:  LDX ram_0056  ; $0056
0x0017FB ---- 00:D7EB:  LDY ram_0057  ; $0057
0x0017FD ---- 00:D7ED:  JSR $D5FB  ; 00160B
; 1 refs via 001621
0x001800 -z-- 00:D7F0:  STA ram_0012  ; $0012
0x001802 -z-- 00:D7F2:  STY ram_0011  ; $0011
; 1 refs via 001817
0x001804 ---- 00:D7F4:  LDY ram_005B  ; $005B
0x001806 ---- 00:D7F6:  DEY  ; 
; 1 refs via 00180C
0x001807 ---- 00:D7F7:  LDA #$00  ; 
0x001809 nZ-- 00:D7F9:  STA (ram_0011),Y  ; $0442 $0443 $0444 $0445 $0446 $0447 $0448 $0449 $044A $044B $044C $044D $044E $044F $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0458 $0459 $045A $045B $0462 $0463 $0464 $0465 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $046E $046F $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $047A $047B $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $0562 $0563 $0564 $0565 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $05A2 $05A3 $05A4 $05A5 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $0639 $063A $063B $0642 $0643 $0644 $0645 $0646 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $0662 $0663 $0664 $0665 $0666 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $0682 $0683 $0684 $0685 $0686 $0687 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0692 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $06A2 $06A3 $06A4 $06A5 $06A6 $06A7 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B7 $06B8 $06B9 $06BA $06BB $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $06FA $06FB $0702 $0703 $0704 $0705 $0706 $0707 $0708 $0709 $070A $070B $070C $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0717 $0718 $0719 $071A $071B $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072C $072D $072E $072F $0730 $0731 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $0742 $0743 $0744 $0745 $0746 $0747 $0748 $0749 $074A $074B $074C $074D $074E $074F $0750 $0751 $0752 $0753 $0754 $0755 $0756 $0757 $0758 $0759 $075A $075B $0762 $0763 $0764 $0765 $0766 $0767 $0768 $0769 $076A $076B $076C $076D $076E $076F $0770 $0771 $0772 $0773 $0774 $0775 $0776 $0777 $0778 $0779 $077A $077B
0x00180B nZ-- 00:D7FB:  DEY  ; 
0x00180C ---- 00:D7FC:  BPL $D7F7  ; 001807
0x00180E N--- 00:D7FE:  DEC ram_005A  ; $005A
0x001810 ---- 00:D800:  BEQ $D80A  ; 00181A
0x001812 -z-- 00:D802:  LDA #$20  ; 
0x001814 nz-- 00:D804:  JSR $D7AA  ; 0017BA
; 1 refs via 0017C3
0x001817 ---- 00:D807:  JMP $D7F4  ; 001804
; 1 refs via 001810
0x00181A -Z-- 00:D80A:  RTS  ; 0009CF
; 3 refs via 0006DE 0023C4 003068
0x00181B ---- 00:D80B:  PHA  ; 
0x00181C ---- 00:D80C:  STA ram_0000  ; $0000
0x00181E ---- 00:D80E:  JSR $D713  ; 001723
; 1 refs via 00172D
0x001821 ---- 00:D811:  STX ram_0047  ; $0047
0x001823 ---- 00:D813:  STY ram_0048  ; $0048
0x001825 ---- 00:D815:  LDY ram_0000  ; $0000
0x001827 ---- 00:D817:  LDA $DABB,Y  ; 001ACB 001ACC 001ACD 001ACE 001ACF 001AD0 001AD1 001AD2 001AD3 001AD4 001AD5 001AD6 001AD7 001AD8 001ADA
0x00182A ---- 00:D81A:  STA ram_0004  ; $0004
0x00182C ---- 00:D81C:  LDY ram_0048  ; $0048
0x00182E ---- 00:D81E:  JSR $D612  ; 001622
; 1 refs via 001644
0x001831 ---- 00:D821:  LDA ram_0048  ; $0048
0x001833 ---- 00:D823:  AND #$FE  ; 
0x001835 ---- 00:D825:  TAY  ; 
0x001836 ---- 00:D826:  LDA ram_0047  ; $0047
0x001838 ---- 00:D828:  AND #$FE  ; 
0x00183A ---- 00:D82A:  TAX  ; 
0x00183B ---- 00:D82B:  JSR $D709  ; 001719
; 1 refs via 001722
0x00183E nZ-- 00:D82E:  PLA  ; 
0x00183F ---- 00:D82F:  ASL  ; 
0x001840 ---- 00:D830:  ASL  ; 
0x001841 ---- 00:D831:  TAX  ; 
0x001842 ---- 00:D832:  LDA $DACB,X  ; 001ADB 001ADF 001AE3 001AE7 001AEB 001AEF 001AF3 001AF7 001AFB 001AFF 001B03 001B07 001B0B 001B0F 001B17
0x001845 ---- 00:D835:  INX  ; 
0x001846 ---- 00:D836:  JSR $D784  ; 001794
; 1 refs via 0017B9
0x001849 ---- 00:D839:  LDA #$01  ; 
0x00184B nz-- 00:D83B:  JSR $D7AA  ; 0017BA
; 1 refs via 0017C3
0x00184E ---- 00:D83E:  LDA $DACB,X  ; 001ADC 001AE0 001AE4 001AE8 001AEC 001AF0 001AF4 001AF8 001AFC 001B00 001B04 001B08 001B0C 001B10 001B18
0x001851 ---- 00:D841:  INX  ; 
0x001852 ---- 00:D842:  JSR $D784  ; 001794
; 1 refs via 0017B9
0x001855 ---- 00:D845:  LDA #$1F  ; 
0x001857 nz-- 00:D847:  JSR $D7AA  ; 0017BA
; 1 refs via 0017C3
0x00185A ---- 00:D84A:  LDA $DACB,X  ; 001ADD 001AE1 001AE5 001AE9 001AED 001AF1 001AF5 001AF9 001AFD 001B01 001B05 001B09 001B0D 001B11 001B19
0x00185D ---- 00:D84D:  INX  ; 
0x00185E ---- 00:D84E:  JSR $D784  ; 001794
; 1 refs via 0017B9
0x001861 ---- 00:D851:  LDA #$01  ; 
0x001863 nz-- 00:D853:  JSR $D7AA  ; 0017BA
; 1 refs via 0017C3
0x001866 ---- 00:D856:  LDA $DACB,X  ; 001ADE 001AE2 001AE6 001AEA 001AEE 001AF2 001AF6 001AFA 001AFE 001B02 001B06 001B0A 001B0E 001B12 001B1A
0x001869 ---- 00:D859:  INX  ; 
0x00186A ---- 00:D85A:  JSR $D784  ; 001794
; 1 refs via 0017B9
0x00186D ---- 00:D85D:  RTS  ; 0006E1 0023C7 00306B
; 1 refs via 0018F6
0x00186E ---- 00:D85E:  STX ram_005D  ; $005D
0x001870 ---- 00:D860:  TAX  ; 
0x001871 ---- 00:D861:  TYA  ; 
0x001872 ---- 00:D862:  CLC  ; 
0x001873 --c- 00:D863:  ADC #$20  ; 
0x001875 ---- 00:D865:  STA ram_005E  ; $005E
0x001877 ---- 00:D867:  LDA #$00  ; 
0x001879 nZ-- 00:D869:  STA ram_0011  ; $0011
0x00187B nZ-- 00:D86B:  LDA #$10  ; 
0x00187D nz-- 00:D86D:  STA ram_0012  ; $0012
; 1 refs via 001887
0x00187F ---- 00:D86F:  DEX  ; 
0x001880 ---- 00:D870:  BMI $D87A  ; 00188A
0x001882 n--- 00:D872:  LDA #$10  ; 
0x001884 nz-- 00:D874:  JSR $D7AA  ; 0017BA
; 1 refs via 0017C3
0x001887 ---- 00:D877:  JMP $D86F  ; 00187F
; 1 refs via 001880
0x00188A N--- 00:D87A:  LDA ram_0012  ; $0012
0x00188C ---- 00:D87C:  STA $2006  ; $2006
0x00188F ---- 00:D87F:  LDA ram_0011  ; $0011
0x001891 ---- 00:D881:  STA $2006  ; $2006
0x001894 ---- 00:D884:  LDA $2007  ; $2007
0x001897 ---- 00:D887:  LDA #$08  ; 
0x001899 nz-- 00:D889:  STA ram_005A  ; $005A
; 1 refs via 0018A1
0x00189B -z-- 00:D88B:  LDA $2007  ; $2007
0x00189E ---- 00:D88E:  PHA  ; 
0x00189F ---- 00:D88F:  DEC ram_005A  ; $005A
0x0018A1 ---- 00:D891:  BNE $D88B  ; 00189B
0x0018A3 -Z-- 00:D893:  LDA #$08  ; 
0x0018A5 nz-- 00:D895:  STA ram_005A  ; $005A
; 1 refs via 0018DF
0x0018A7 -z-- 00:D897:  PLA  ; 
0x0018A8 ---- 00:D898:  STA ram_0002  ; $0002
0x0018AA ---- 00:D89A:  LDA #$80  ; 
0x0018AC Nz-- 00:D89C:  STA ram_0003  ; $0003
; 1 refs via 0018CD
0x0018AE ---- 00:D89E:  LDX ram_005D  ; $005D
0x0018B0 ---- 00:D8A0:  LDY ram_005E  ; $005E
0x0018B2 ---- 00:D8A2:  JSR $D71E  ; 00172E
; 1 refs via 00174B
0x0018B5 ---- 00:D8A5:  LDA ram_0002  ; $0002
0x0018B7 ---- 00:D8A7:  AND ram_0003  ; $0003
0x0018B9 ---- 00:D8A9:  BEQ $D8B1  ; 0018C1
0x0018BB -z-- 00:D8AB:  JSR $D764  ; 001774
; 1 refs via 001780
0x0018BE ---- 00:D8AE:  JMP $D8B4  ; 0018C4
; 1 refs via 0018B9
0x0018C1 -Z-- 00:D8B1:  JSR $D74D  ; 00175D
; 2 refs via 00176B 0018BE
0x0018C4 ---- 00:D8B4:  LDA ram_005D  ; $005D
0x0018C6 ---- 00:D8B6:  CLC  ; 
0x0018C7 --c- 00:D8B7:  ADC #$04  ; 
0x0018C9 ---- 00:D8B9:  STA ram_005D  ; $005D
0x0018CB ---- 00:D8BB:  LSR ram_0003  ; $0003
0x0018CD ---- 00:D8BD:  BCC $D89E  ; 0018AE
0x0018CF --C- 00:D8BF:  LDA ram_005D  ; $005D
0x0018D1 --C- 00:D8C1:  SEC  ; 
0x0018D2 --C- 00:D8C2:  SBC #$20  ; 
0x0018D4 ---- 00:D8C4:  STA ram_005D  ; $005D
0x0018D6 ---- 00:D8C6:  LDA ram_005E  ; $005E
0x0018D8 ---- 00:D8C8:  SEC  ; 
0x0018D9 --C- 00:D8C9:  SBC #$04  ; 
0x0018DB ---- 00:D8CB:  STA ram_005E  ; $005E
0x0018DD ---- 00:D8CD:  DEC ram_005A  ; $005A
0x0018DF ---- 00:D8CF:  BNE $D897  ; 0018A7
0x0018E1 -Z-- 00:D8D1:  RTS  ; 0018F9
; 8 refs via 000403 000416 00047B 000609 00061C 0011A9 0011BC 001985
0x0018E2 ---- 00:D8D2:  LDY #$00  ; 
0x0018E4 nZ-- 00:D8D4:  STY ram_005F  ; $005F
; 1 refs via 001902
0x0018E6 ---- 00:D8D6:  LDA (ram_0013),Y  ; 0012A9 0012AA 0012AB 0012AC 0012AD 0012AE 0012AF 0012B0 0012B1 0012B2 0012B3 0012B4 0012C5 0012C6 0012C7 0012C8 0012C9 0012CA 0012CB 0012CC 001353 001354 001355 001356 001357 001358 001359 00135A 00135B 00135C $003E $003F $0040 $0041 $0042 $0043 $0044
0x0018E8 ---- 00:D8D8:  CMP #$FF  ; 
0x0018EA ---- 00:D8DA:  BEQ $D8F5  ; 001905
0x0018EC -z-- 00:D8DC:  INY  ; 
0x0018ED ---- 00:D8DD:  STY ram_005F  ; $005F
0x0018EF ---- 00:D8DF:  LDX ram_0056  ; $0056
0x0018F1 ---- 00:D8E1:  LDY ram_0057  ; $0057
0x0018F3 ---- 00:D8E3:  CLC  ; 
0x0018F4 --c- 00:D8E4:  ADC ram_0060  ; $0060
0x0018F6 ---- 00:D8E6:  JSR $D85E  ; 00186E
; 1 refs via 0018E1
0x0018F9 -Z-- 00:D8E9:  LDA ram_0056  ; $0056
0x0018FB ---- 00:D8EB:  CLC  ; 
0x0018FC --c- 00:D8EC:  ADC #$20  ; 
0x0018FE ---- 00:D8EE:  STA ram_0056  ; $0056
0x001900 ---- 00:D8F0:  LDY ram_005F  ; $005F
0x001902 ---- 00:D8F2:  JMP $D8D6  ; 0018E6
; 1 refs via 0018EA
0x001905 -Z-- 00:D8F5:  RTS  ; 000406 000419 00047E 00060C 00061F 0011AC 0011BF 001988
; 34 refs via 0000FA 000169 000203 000209 000248 00038A 000425 00042D 000496 00057B 0005A5 0005C0 000634 0007C1 000869 0009F6 000AA1 000C41 000CA8 000CCA 000D0A 000D20 000F07 000F6C 000FCA 001024 001067 0010A6 001222 001252 001273 001286 001480 003046
0x001906 ---- 00:D8F6:  LDA ram_000B  ; $000B
; 1 refs via 00190A
0x001908 ---- 00:D8F8:  CMP ram_000B  ; $000B
0x00190A ---- 00:D8FA:  BEQ $D8F8  ; 001908
0x00190C -z-- 00:D8FC:  RTS  ; 0000FD 00016C 000206 00020C 00024B 00038D 000428 000430 000499 00057E 0005A8 0005C3 000637 0007C4 00086C 0009F9 000AA4 000C44 000CAB 000CCD 000D0D 000D23 000F0A 000F6F 000FCD 001027 00106A 0010A9 001225 001255 001276 001289 001483 003049
; 1 refs via 001423
0x00190D ---- 00:D8FD:  LDX ram_000C  ; $000C
0x00190F ---- 00:D8FF:  LDA #$00  ; 
0x001911 nZ-- 00:D901:  STA ram_0180,X  ; $0180 $0184 $0185 $0188 $0189 $018A $018C $018D $018E $018F $0190 $0191 $0192 $0193 $0194 $0195 $0196 $0198 $0199 $019A $019C $019D $019E $019F $01A0 $01A1 $01A2 $01A3 $01A4 $01A5 $01A6 $01A8 $01A9 $01AC $01B0 $01B1 $01B5 $01B8 $01B9 $01C1 $01C6 $01C9 $01DA
0x001914 nZ-- 00:D904:  TAX  ; 
; 1 refs via 001934
0x001915 ---- 00:D905:  CPX ram_000C  ; $000C
0x001917 ---- 00:D907:  BEQ $D92F  ; 00193F
0x001919 -z-- 00:D909:  LDA ram_0180,X  ; $0180 $0184 $0185 $0186 $0187 $0188 $0189 $018A $018B $018C $018D $018E $018F $0190 $0191 $0192 $0193 $0194 $0195 $0196 $0197 $0198 $0199 $019A $019B $019C $019D $019E $019F $01A0 $01A1 $01A3 $01A4 $01A6 $01A8 $01A9 $01AA $01AC $01AD $01B0 $01B1 $01B2 $01B3 $01B4 $01B5 $01B7 $01B9 $01BC $01BD $01C1 $01C5 $01C6 $01CB $01D0 $01D5
0x00191C ---- 00:D90C:  INX  ; 
0x00191D ---- 00:D90D:  STA $2006  ; $2006
0x001920 ---- 00:D910:  LDA ram_0180,X  ; $0181 $0185 $0186 $0187 $0188 $0189 $018A $018B $018C $018D $018E $018F $0190 $0191 $0192 $0193 $0194 $0195 $0196 $0197 $0198 $0199 $019A $019B $019C $019D $019E $019F $01A0 $01A1 $01A2 $01A4 $01A5 $01A7 $01A9 $01AA $01AB $01AD $01AE $01B1 $01B2 $01B3 $01B4 $01B5 $01B6 $01B8 $01BA $01BD $01BE $01C2 $01C6 $01C7 $01CC $01D1 $01D6
0x001923 ---- 00:D913:  INX  ; 
0x001924 ---- 00:D914:  STA $2006  ; $2006
; 1 refs via 00193C
0x001927 ---- 00:D917:  LDA ram_0180,X  ; $0182 $0183 $0184 $0185 $0186 $0187 $0188 $0189 $018A $018B $018C $018D $018E $018F $0190 $0191 $0192 $0193 $0194 $0195 $0196 $0197 $0198 $0199 $019A $019B $019C $019D $019E $019F $01A0 $01A1 $01A2 $01A3 $01A4 $01A5 $01A6 $01A7 $01A8 $01A9 $01AA $01AB $01AC $01AD $01AE $01AF $01B0 $01B1 $01B2 $01B3 $01B4 $01B5 $01B6 $01B7 $01B8 $01B9 $01BA $01BB $01BC $01BD $01BE $01BF $01C0 $01C1 $01C2 $01C3 $01C4 $01C5 $01C7 $01C8 $01C9 $01CA $01CD $01CE $01CF $01D2 $01D3 $01D4 $01D7 $01D8 $01D9
0x00192A ---- 00:D91A:  INX  ; 
0x00192B ---- 00:D91B:  CMP #$FF  ; 
0x00192D ---- 00:D91D:  BNE $D929  ; 001939
0x00192F -Z-- 00:D91F:  LDA ram_0180,X  ; $0183 $0184 $0185 $0186 $0187 $0188 $0189 $018A $018B $018C $018D $018E $018F $0190 $0191 $0192 $0193 $0194 $0195 $0196 $0197 $0198 $0199 $019A $019B $019C $019D $019E $019F $01A0 $01A1 $01A2 $01A3 $01A4 $01A5 $01A6 $01A8 $01A9 $01AA $01AC $01AD $01B0 $01B1 $01B2 $01B3 $01B4 $01B5 $01B7 $01B8 $01B9 $01BC $01BD $01C1 $01C5 $01C6 $01C9 $01CB $01D0 $01D5 $01DA
0x001932 ---- 00:D922:  CMP #$FF  ; 
0x001934 ---- 00:D924:  BNE $D905  ; 001915
0x001936 -Z-- 00:D926:  LDA ram_017F,X  ; $0182
; 1 refs via 00192D
0x001939 ---- 00:D929:  STA $2007  ; $2007
0x00193C ---- 00:D92C:  JMP $D917  ; 001927
; 1 refs via 001917
0x00193F -Z-- 00:D92F:  LDA #$00  ; 
0x001941 nZ-- 00:D931:  STA ram_000C  ; $000C
0x001943 nZ-- 00:D933:  RTS  ; 001426
; 23 refs via 000823 000897 000AF8 000D72 000D7E 000D99 000DB1 000DBD 000DD8 000E12 000E27 000E5A 000E66 000EB5 000EC1 000F44 000F64 000F82 000FE0 0011DC 0011F7 001216 00194B
0x001944 ---- 00:D934:  LDA ram_0000,Y  ; $0016 $0017 $0018 $0019 $001A $001B $001C $001E $001F $0020 $0021 $0022 $0023 $0024 $0026 $0027 $0028 $0029 $002A $002B $002C $002E $002F $0030 $0031 $0032 $0033 $0034 $0036 $0037 $0038 $0039 $003A $003B $003C $003E $003F
0x001947 ---- 00:D937:  BNE $D93E  ; 00194E
0x001949 -Z-- 00:D939:  INY  ; 
0x00194A ---- 00:D93A:  INX  ; 
0x00194B ---- 00:D93B:  JMP $D934  ; 001944
; 1 refs via 001947
0x00194E -z-- 00:D93E:  CMP #$FF  ; 
0x001950 ---- 00:D940:  BNE $D94A  ; 00195A
0x001952 -Z-- 00:D942:  LDA ram_006B  ; $006B
0x001954 ---- 00:D944:  BNE $D948  ; 001958
0x001956 -Z-- 00:D946:  DEX  ; 
0x001957 ---- 00:D947:  DEY  ; 
; 1 refs via 001954
0x001958 ---- 00:D948:  DEX  ; 
0x001959 ---- 00:D949:  DEY  ; 
; 1 refs via 001950
0x00195A ---- 00:D94A:  LDA #$00  ; 
0x00195C nZ-- 00:D94C:  STA ram_0012  ; $0012
0x00195E nZ-- 00:D94E:  STY ram_0011  ; $0011
0x001960 nZ-- 00:D950:  RTS  ; 000826 00089A 000AFB 000D75 000D81 000D9C 000DB4 000DC0 000DDB 000E15 000E2A 000E5D 000E69 000EB8 000EC4 000F47 000F67 000F85 000FE3 0011DF 0011FA 001219
; 1 refs via 00047E
0x001961 -Z-- 00:D951:  LDA #$10  ; 
0x001963 nz-- 00:D953:  STA ram_0056  ; $0056
0x001965 nz-- 00:D955:  LDA #$64  ; 
0x001967 nz-- 00:D957:  STA ram_0057  ; $0057
0x001969 nz-- 00:D959:  LDA #$30  ; 
0x00196B nz-- 00:D95B:  STA ram_0060  ; $0060
0x00196D nz-- 00:D95D:  LDY #$3D  ; 
; 1 refs via 00197C
0x00196F ---- 00:D95F:  LDA ram_0000,Y  ; $003D $003E $003F
0x001972 ---- 00:D962:  BNE $D96F  ; 00197F
0x001974 -Z-- 00:D964:  INY  ; 
0x001975 ---- 00:D965:  LDA ram_0056  ; $0056
0x001977 ---- 00:D967:  CLC  ; 
0x001978 --c- 00:D968:  ADC #$20  ; 
0x00197A ---- 00:D96A:  STA ram_0056  ; $0056
0x00197C ---- 00:D96C:  JMP $D95F  ; 00196F
; 1 refs via 001972
0x00197F -z-- 00:D96F:  LDA #$00  ; 
0x001981 nZ-- 00:D971:  STA ram_0014  ; $0014
0x001983 nZ-- 00:D973:  STY ram_0013  ; $0013
0x001985 nZ-- 00:D975:  JSR $D8D2  ; 0018E2
; 1 refs via 001905
0x001988 -Z-- 00:D978:  LDA #$00  ; 
0x00198A nZ-- 00:D97A:  STA ram_0060  ; $0060
0x00198C nZ-- 00:D97C:  RTS  ; 000481
; 1 refs via 000296
0x00198D -Z-- 00:D97D:  LDX #$00  ; 
0x00198F nZ-- 00:D97F:  LDY #$00  ; 
; 1 refs via 00199C
0x001991 ---- 00:D981:  LDA ram_0015,X  ; $0015 $0016 $0017
0x001993 ---- 00:D983:  CMP ram_003D,X  ; $003D $003E $003F
0x001995 ---- 00:D985:  BNE $D98F  ; 00199F
0x001997 -Z-- 00:D987:  INX  ; 
0x001998 ---- 00:D988:  CPX #$07  ; 
0x00199A ---- 00:D98A:  BEQ $D99E  ; 0019AE
0x00199C -z-- 00:D98C:  JMP $D981  ; 001991
; 1 refs via 001995
0x00199F -z-- 00:D98F:  BMI $D99E  ; 0019AE
0x0019A1 nz-- 00:D991:  LDX #$00  ; 
; 1 refs via 0019AA
0x0019A3 ---- 00:D993:  LDA ram_0015,X  ; $0015 $0016 $0017 $0018 $0019 $001A $001B
0x0019A5 ---- 00:D995:  STA ram_003D,X  ; $003D $003E $003F $0040 $0041 $0042 $0043
0x0019A7 ---- 00:D997:  INX  ; 
0x0019A8 ---- 00:D998:  CPX #$07  ; 
0x0019AA ---- 00:D99A:  BNE $D993  ; 0019A3
0x0019AC -Z-- 00:D99C:  LDY #$01  ; 
; 2 refs via 00199A 00199F
0x0019AE -z-- 00:D99E:  LDX #$00  ; 
; 1 refs via 0019BB
0x0019B0 ---- 00:D9A0:  LDA ram_001D,X  ; $001D $001E $001F
0x0019B2 ---- 00:D9A2:  CMP ram_003D,X  ; $003D $003E $003F
0x0019B4 ---- 00:D9A4:  BNE $D9AE  ; 0019BE
0x0019B6 -Z-- 00:D9A6:  INX  ; 
0x0019B7 ---- 00:D9A7:  CPX #$07  ; 
0x0019B9 ---- 00:D9A9:  BEQ $D9BD  ; 0019CD
0x0019BB -z-- 00:D9AB:  JMP $D9A0  ; 0019B0
; 1 refs via 0019B4
0x0019BE -z-- 00:D9AE:  BMI $D9BD  ; 0019CD
0x0019C0 ---- xx:D9B0:  .byte $A2   ; 
0x0019C1 ---- xx:D9B1:  .byte $00   ; 
0x0019C2 ---- xx:D9B2:  .byte $B5   ; 
0x0019C3 ---- xx:D9B3:  .byte $1D   ; 
0x0019C4 ---- xx:D9B4:  .byte $95   ; 
0x0019C5 ---- xx:D9B5:  .byte $3D   ; 
0x0019C6 ---- xx:D9B6:  .byte $E8   ; 
0x0019C7 ---- xx:D9B7:  .byte $E0   ; 
0x0019C8 ---- xx:D9B8:  .byte $07   ; 
0x0019C9 ---- xx:D9B9:  .byte $D0   ; 
0x0019CA ---- xx:D9BA:  .byte $F7   ; 
0x0019CB ---- xx:D9BB:  .byte $A0   ; 
0x0019CC ---- xx:D9BC:  .byte $FF   ; 
; 2 refs via 0019B9 0019BE
0x0019CD -z-- 00:D9BD:  RTS  ; 000299
; 6 refs via 000D46 000D64 000E53 000EAE 002834 0029CD
0x0019CE ---- 00:D9BE:  TXA  ; 
0x0019CF ---- 00:D9BF:  ASL  ; 
0x0019D0 ---- 00:D9C0:  ASL  ; 
0x0019D1 ---- 00:D9C1:  ASL  ; 
0x0019D2 ---- 00:D9C2:  CLC  ; 
0x0019D3 --c- 00:D9C3:  ADC #$06  ; 
0x0019D5 ---- 00:D9C5:  TAX  ; 
0x0019D6 ---- 00:D9C6:  LDY #$06  ; 
0x0019D8 nz-- 00:D9C8:  CLC  ; 
; 1 refs via 0019EE
0x0019D9 n--- 00:D9C9:  LDA ram_0035,Y  ; $0035 $0036 $0037 $0038 $0039 $003A $003B
0x0019DC ---- 00:D9CC:  ADC ram_0015,X  ; $0015 $0016 $0017 $0018 $0019 $001A $001B $001D $001E $001F $0020 $0021 $0022 $0023 $0025 $0026 $0027 $0028 $0029 $002A $002B $002D $002E $002F $0030 $0031 $0032 $0033
0x0019DE ---- 00:D9CE:  CMP #$0A  ; 
0x0019E0 ---- 00:D9D0:  BMI $D9D9  ; 0019E9
0x0019E2 n--- 00:D9D2:  SEC  ; 
0x0019E3 n-C- 00:D9D3:  SBC #$0A  ; 
0x0019E5 ---- 00:D9D5:  SEC  ; 
0x0019E6 --C- 00:D9D6:  JMP $D9DA  ; 0019EA
; 1 refs via 0019E0
0x0019E9 N--- 00:D9D9:  CLC  ; 
; 1 refs via 0019E6
0x0019EA ---- 00:D9DA:  STA ram_0015,X  ; $0015 $0016 $0017 $0018 $0019 $001A $001B $001D $001E $001F $0020 $0021 $0022 $0023 $0025 $0026 $0027 $0028 $0029 $002A $002B $002D $002E $002F $0030 $0031 $0032 $0033
0x0019EC ---- 00:D9DC:  DEX  ; 
0x0019ED ---- 00:D9DD:  DEY  ; 
0x0019EE ---- 00:D9DE:  BPL $D9C9  ; 0019D9
0x0019F0 N--- 00:D9E0:  RTS  ; 000D49 000D67 000E56 000EB1 002837 0029D0
; 7 refs via 000768 000783 000D2F 000E4E 000EA9 00282E 0029C8
0x0019F1 ---- 00:D9E1:  STA ram_0000  ; $0000
0x0019F3 ---- 00:D9E3:  LDX #$35  ; 
0x0019F5 nz-- 00:D9E5:  JSR $D9FE  ; 001A0E
; 1 refs via 001A22
0x0019F8 Nz-- 00:D9E8:  LDA ram_0000  ; $0000
0x0019FA ---- 00:D9EA:  BEQ $D9F9  ; 001A09
0x0019FC -z-- 00:D9EC:  AND #$0F  ; 
0x0019FE ---- 00:D9EE:  STA ram_003A  ; $003A
0x001A00 ---- 00:D9F0:  LDA ram_0000  ; $0000
0x001A02 ---- 00:D9F2:  LSR  ; 
0x001A03 ---- 00:D9F3:  LSR  ; 
0x001A04 ---- 00:D9F4:  LSR  ; 
0x001A05 ---- 00:D9F5:  LSR  ; 
0x001A06 ---- 00:D9F6:  STA ram_0039  ; $0039
0x001A08 ---- 00:D9F8:  RTS  ; 00076B 000786 000D32 002831 0029CB
; 1 refs via 0019FA
0x001A09 -Z-- 00:D9F9:  LDA #$01  ; 
0x001A0B nz-- 00:D9FB:  STA ram_0038  ; $0038
0x001A0D nz-- 00:D9FD:  RTS  ; 00076B 000786 000E51 000EAC
; 9 refs via 0002C5 0002CA 000D12 000D17 0014C4 0014C9 0014D3 0019F5 001A27
0x001A0E nz-- 00:D9FE:  LDA #$00  ; 
0x001A10 nZ-- 00:DA00:  STA ram_0000,X  ; $0015 $001D $0025 $002D $0035 $003D
0x001A12 nZ-- 00:DA02:  STA ram_0001,X  ; $0016 $001E $0026 $002E $0036 $003E
0x001A14 nZ-- 00:DA04:  STA ram_0002,X  ; $0017 $001F $0027 $002F $0037 $003F
0x001A16 nZ-- 00:DA06:  STA ram_0003,X  ; $0018 $0020 $0028 $0030 $0038 $0040
0x001A18 nZ-- 00:DA08:  STA ram_0004,X  ; $0019 $0021 $0029 $0031 $0039 $0041
0x001A1A nZ-- 00:DA0A:  STA ram_0005,X  ; $001A $0022 $002A $0032 $003A $0042
0x001A1C nZ-- 00:DA0C:  STA ram_0006,X  ; $001B $0023 $002B $0033 $003B $0043
0x001A1E nZ-- 00:DA0E:  LDA #$FF  ; 
0x001A20 Nz-- 00:DA10:  STA ram_0007,X  ; $001C $0024 $002C $0034 $003C $0044
0x001A22 Nz-- 00:DA12:  RTS  ; 0002C8 0002CD 000D15 000D1A 0014C7 0014CC 0014D6 0019F8 001A2A
; 8 refs via 00081C 000890 000AF1 000D92 000DD1 000E0B 000E20 000F5D
0x001A23 ---- 00:DA13:  STA ram_0000  ; $0000
0x001A25 ---- 00:DA15:  LDX #$35  ; 
0x001A27 nz-- 00:DA17:  JSR $D9FE  ; 001A0E
; 1 refs via 001A22
0x001A2A Nz-- 00:DA1A:  LDA ram_0000  ; $0000
; 1 refs via 001A35
0x001A2C ---- 00:DA1C:  CMP #$0A  ; 
0x001A2E ---- 00:DA1E:  BCC $DA28  ; 001A38
0x001A30 --C- 00:DA20:  SEC  ; 
0x001A31 --C- 00:DA21:  SBC #$0A  ; 
0x001A33 ---- 00:DA23:  INC ram_003A  ; $003A
0x001A35 ---- 00:DA25:  JMP $DA1C  ; 001A2C
; 1 refs via 001A2E
0x001A38 --c- 00:DA28:  STA ram_003B  ; $003B
0x001A3A --c- 00:DA2A:  RTS  ; 00081F 000893 000AF4 000D95 000DD4 000E0E 000E23 000F60
; 8 refs via 000923 00092E 000939 000944 00094F 001A7F 001A94 001A9F
0x001A3B ---- 00:DA2B:  TXA  ; 
0x001A3C ---- 00:DA2C:  STA ram_0047  ; $0047
0x001A3E ---- 00:DA2E:  CLC  ; 
0x001A3F --c- 00:DA2F:  ADC #$03  ; 
0x001A41 ---- 00:DA31:  TAX  ; 
0x001A42 ---- 00:DA32:  TYA  ; 
0x001A43 ---- 00:DA33:  SEC  ; 
0x001A44 ---- 00:DA34:  SBC #$08  ; 
0x001A46 ---- 00:DA36:  STA ram_0048  ; $0048
0x001A48 ---- 00:DA38:  JSR $D706  ; 001716
; 1 refs via 001722
0x001A4B ---- 00:DA3B:  LDA (ram_0011),Y  ; $0422 $0423 $0424 $0425 $0426 $0427 $0428 $0429 $042A $042B $042C $042D $042E $042F $0430 $0431 $0432 $0433 $0434 $0435 $0436 $0437 $0438 $0439 $043A $043B $0441 $0442 $0443 $0444 $0445 $0446 $0447 $0448 $0449 $044A $044B $044C $044D $044E $044F $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0458 $0459 $045A $045B $045C $0460 $0461 $0462 $0463 $0464 $0465 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $046E $046F $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $047A $047B $047C $0480 $0481 $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $049C $04A0 $04A1 $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04BC $04C0 $04C1 $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04DC $04E0 $04E1 $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $04FC $0500 $0501 $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $051C $0520 $0521 $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $053C $0540 $0541 $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $055C $0560 $0561 $0562 $0563 $0564 $0565 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $057C $0580 $0581 $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $059C $05A0 $05A1 $05A2 $05A3 $05A4 $05A5 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05BC $05C0 $05C1 $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05DC $05E0 $05E1 $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $05FC $0600 $0601 $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $061C $0620 $0621 $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $0639 $063A $063B $063C $0640 $0641 $0642 $0643 $0644 $0645 $0646 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $065C $0660 $0661 $0662 $0663 $0664 $0665 $0666 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $067C $0681 $0682 $0683 $0684 $0685 $0686 $0687 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0692 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $069C $06A0 $06A1 $06A2 $06A3 $06A4 $06A5 $06A6 $06A7 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B7 $06B8 $06B9 $06BA $06BB $06BC $06C1 $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06DC $06E0 $06E1 $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $06FA $06FB $06FC $0701 $0702 $0703 $0704 $0705 $0706 $0707 $0708 $0709 $070A $070B $070C $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0717 $0718 $0719 $071A $071B $071C $0721 $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072C $072D $072E $072F $0730 $0731 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $073C $0742 $0743 $0744 $0745 $0746 $0747 $0748 $0749 $074A $074B $074C $074D $074E $074F $0750 $0751 $0752 $0753 $0754 $0755 $0756 $0757 $0758 $0759 $075A $075B $0760 $0761 $0762 $0763 $0764 $0765 $0766 $0767 $0768 $0769 $076A $076B $076C $076D $076E $076F $0770 $0771 $0772 $0773 $0774 $0775 $0776 $0777 $0778 $0779 $077A $077B $077C $0782 $0783 $0784 $0785 $0786 $0787 $0788 $0789 $078A $078B $078C $078D $078E $078F $0790 $0791 $0792 $0793 $0794 $0795 $0796 $0797 $0798 $0799 $079A $079B $07AD $07AE $07AF $07B0 $07C9 $07CA $07CB $07CC $07CE $07CF $07D1 $07D2 $07D3 $07D4 $07EE $07EF
0x001A4D ---- 00:DA3D:  CMP #$22  ; 
0x001A4F ---- 00:DA3F:  BNE $DA47  ; 001A57
0x001A51 -Z-- 00:DA41:  LDA ram_0004  ; $0004
0x001A53 ---- 00:DA43:  ORA ram_006E  ; $006E
0x001A55 ---- 00:DA45:  STA ram_0004  ; $0004
; 1 refs via 001A4F
0x001A57 ---- 00:DA47:  LDX ram_000D  ; $000D
0x001A59 ---- 00:DA49:  LDA ram_0048  ; $0048
0x001A5B ---- 00:DA4B:  STA ram_0200,X  ; $0200 $0204 $0208 $020C $0210 $0214 $0218 $021C $0220 $0224 $0228 $022C $0230 $0234 $0238 $023C $0240 $0244 $0248 $024C $0250 $0254 $0258 $025C $0260 $0264 $0268 $026C $0270 $0274 $0278 $027C $0280 $0284 $0288 $028C $0290 $0294 $0298 $029C $02A0 $02A4 $02A8 $02AC $02B0 $02B4 $02B8 $02BC $02C0 $02C4 $02C8 $02CC $02D0 $02D4 $02D8 $02DC $02E0 $02E4 $02E8 $02EC $02F0 $02F4 $02F8 $02FC
0x001A5E ---- 00:DA4E:  LDA ram_0053  ; $0053
0x001A60 ---- 00:DA50:  STA ram_0201,X  ; $0201 $0205 $0209 $020D $0211 $0215 $0219 $021D $0221 $0225 $0229 $022D $0231 $0235 $0239 $023D $0241 $0245 $0249 $024D $0251 $0255 $0259 $025D $0261 $0265 $0269 $026D $0271 $0275 $0279 $027D $0281 $0285 $0289 $028D $0291 $0295 $0299 $029D $02A1 $02A5 $02A9 $02AD $02B1 $02B5 $02B9 $02BD $02C1 $02C5 $02C9 $02CD $02D1 $02D5 $02D9 $02DD $02E1 $02E5 $02E9 $02ED $02F1 $02F5 $02F9 $02FD
0x001A63 ---- 00:DA53:  LDA ram_0004  ; $0004
0x001A65 ---- 00:DA55:  STA ram_0202,X  ; $0202 $0206 $020A $020E $0212 $0216 $021A $021E $0222 $0226 $022A $022E $0232 $0236 $023A $023E $0242 $0246 $024A $024E $0252 $0256 $025A $025E $0262 $0266 $026A $026E $0272 $0276 $027A $027E $0282 $0286 $028A $028E $0292 $0296 $029A $029E $02A2 $02A6 $02AA $02AE $02B2 $02B6 $02BA $02BE $02C2 $02C6 $02CA $02CE $02D2 $02D6 $02DA $02DE $02E2 $02E6 $02EA $02EE $02F2 $02F6 $02FA $02FE
0x001A68 ---- 00:DA58:  LDA ram_0047  ; $0047
0x001A6A ---- 00:DA5A:  STA ram_0203,X  ; $0203 $0207 $020B $020F $0213 $0217 $021B $021F $0223 $0227 $022B $022F $0233 $0237 $023B $023F $0243 $0247 $024B $024F $0253 $0257 $025B $025F $0263 $0267 $026B $026F $0273 $0277 $027B $027F $0283 $0287 $028B $028F $0293 $0297 $029B $029F $02A3 $02A7 $02AB $02AF $02B3 $02B7 $02BB $02BF $02C3 $02C7 $02CB $02CF $02D3 $02D7 $02DB $02DF $02E3 $02E7 $02EB $02EF $02F3 $02F7 $02FB $02FF
0x001A6D ---- 00:DA5D:  TXA  ; 
0x001A6E ---- 00:DA5E:  CLC  ; 
0x001A6F --c- 00:DA5F:  ADC ram_000E  ; $000E
0x001A71 ---- 00:DA61:  STA ram_000D  ; $000D
0x001A73 ---- 00:DA63:  RTS  ; 000926 000931 00093C 000947 000952 001A82 001A97 001AA2
; 1 refs via 00211E
0x001A74 ---- 00:DA64:  ASL  ; 
0x001A75 ---- 00:DA65:  CLC  ; 
0x001A76 --c- 00:DA66:  ADC ram_0053  ; $0053
0x001A78 ---- 00:DA68:  STA ram_0053  ; $0053
0x001A7A ---- 00:DA6A:  TXA  ; 
0x001A7B ---- 00:DA6B:  SEC  ; 
0x001A7C --C- 00:DA6C:  SBC #$05  ; 
0x001A7E ---- 00:DA6E:  TAX  ; 
0x001A7F ---- 00:DA6F:  JSR $DA2B  ; 001A3B
; 1 refs via 001A73
0x001A82 ---- 00:DA72:  RTS  ; 002121
; 1 refs via 00200F
0x001A83 ---- 00:DA73:  ASL  ; 
0x001A84 ---- 00:DA74:  ASL  ; 
0x001A85 ---- 00:DA75:  ASL  ; 
0x001A86 ---- 00:DA76:  CLC  ; 
0x001A87 --c- 00:DA77:  ADC ram_0053  ; $0053
0x001A89 ---- 00:DA79:  STA ram_0053  ; $0053
; 15 refs via 0005B6 0005E5 000969 00097A 001144 001F09 001F2D 001F6B 001F7D 001F8F 001FA1 00203A 002284 0022B1 002334
0x001A8B ---- 00:DA7B:  STX ram_0054  ; $0054
0x001A8D ---- 00:DA7D:  STY ram_0055  ; $0055
0x001A8F ---- 00:DA7F:  TXA  ; 
0x001A90 ---- 00:DA80:  SEC  ; 
0x001A91 ---- 00:DA81:  SBC #$08  ; 
0x001A93 ---- 00:DA83:  TAX  ; 
0x001A94 ---- 00:DA84:  JSR $DA2B  ; 001A3B
; 1 refs via 001A73
0x001A97 ---- 00:DA87:  INC ram_0053  ; $0053
0x001A99 ---- 00:DA89:  INC ram_0053  ; $0053
0x001A9B ---- 00:DA8B:  LDX ram_0054  ; $0054
0x001A9D ---- 00:DA8D:  LDY ram_0055  ; $0055
0x001A9F ---- 00:DA8F:  JSR $DA2B  ; 001A3B
; 1 refs via 001A73
0x001AA2 ---- 00:DA92:  RTS  ; 0005B9 0005E8 00096C 00097D 001147 001F0C 001F30 001F6E 001F80 001F92 001FA4 002012 00203D 002287 0022B4 002337
; 2 refs via 001446 0014BF
0x001AA3 ---- 00:DA93:  LDX ram_000D  ; $000D
0x001AA5 ---- 00:DA95:  LDA ram_000E  ; $000E
0x001AA7 ---- 00:DA97:  EOR #$FF  ; 
0x001AA9 ---- 00:DA99:  CLC  ; 
0x001AAA --c- 00:DA9A:  ADC #$01  ; 
0x001AAC ---- 00:DA9C:  STA ram_000E  ; $000E
; 1 refs via 001ABA
0x001AAE ---- 00:DA9E:  TXA  ; 
0x001AAF ---- 00:DA9F:  CLC  ; 
0x001AB0 --c- 00:DAA0:  ADC ram_000E  ; $000E
0x001AB2 ---- 00:DAA2:  TAX  ; 
0x001AB3 ---- 00:DAA3:  LDA #$F0  ; 
0x001AB5 Nz-- 00:DAA5:  STA ram_0200,X  ; $0200 $0204 $0208 $020C $0210 $0214 $0218 $021C $0220 $0224 $0228 $022C $0230 $0234 $0238 $023C $0240 $0244 $0248 $024C $0250 $0254 $0258 $025C $0260 $0264 $0268 $026C $0270 $0274 $0278 $027C $0280 $0284 $0288 $028C $0290 $0294 $0298 $029C $02A0 $02A4 $02A8 $02AC $02B0 $02B4 $02B8 $02BC $02C0 $02C4 $02C8 $02CC $02D0 $02D4 $02D8 $02DC $02E0 $02E4 $02E8 $02EC $02F0 $02F4 $02F8 $02FC
0x001AB8 Nz-- 00:DAA8:  CPX #$04  ; 
0x001ABA ---- 00:DAAA:  BNE $DA9E  ; 001AAE
0x001ABC -Z-- 00:DAAC:  STX ram_000D  ; $000D
0x001ABE -Z-- 00:DAAE:  RTS  ; 001449 0014C2
; 2 refs via 001DB7 001DC4
0x001ABF ---- 00:DAAF:  BEQ $DABA  ; 001ACA
0x001AC1 -z-- 00:DAB1:  BCS $DAB8  ; 001AC8
0x001AC3 -zc- 00:DAB3:  LDA #$FF  ; 
0x001AC5 Nzc- 00:DAB5:  JMP $DABA  ; 001ACA
; 1 refs via 001AC1
0x001AC8 -zC- 00:DAB8:  LDA #$01  ; 
; 2 refs via 001ABF 001AC5
0x001ACA ---- 00:DABA:  RTS  ; 001DBA 001DC7
0x001ACB ---- 00:DABB:  .byte $00   ; 001827
0x001ACC ---- 00:DABC:  .byte $00   ; 001827
0x001ACD ---- 00:DABD:  .byte $00   ; 001827
0x001ACE ---- 00:DABE:  .byte $00   ; 001827
0x001ACF ---- 00:DABF:  .byte $00   ; 001827
0x001AD0 ---- 00:DAC0:  .byte $03   ; 001827
0x001AD1 ---- 00:DAC1:  .byte $03   ; 001827
0x001AD2 ---- 00:DAC2:  .byte $03   ; 001827
0x001AD3 ---- 00:DAC3:  .byte $03   ; 001827
0x001AD4 ---- 00:DAC4:  .byte $03   ; 001827
0x001AD5 ---- 00:DAC5:  .byte $01   ; 001827
0x001AD6 ---- 00:DAC6:  .byte $02   ; 001827
0x001AD7 ---- 00:DAC7:  .byte $03   ; 001827
0x001AD8 ---- 00:DAC8:  .byte $00   ; 001827
0x001AD9 ---- xx:DAC9:  .byte $00   ; 
0x001ADA ---- 00:DACA:  .byte $00   ; 001827
0x001ADB ---- 00:DACB:  .byte $00   ; 001842
0x001ADC ---- 00:DACC:  .byte $0F   ; 00184E
0x001ADD ---- 00:DACD:  .byte $00   ; 00185A
0x001ADE ---- 00:DACE:  .byte $0F   ; 001866
0x001ADF ---- 00:DACF:  .byte $00   ; 001842
0x001AE0 ---- 00:DAD0:  .byte $00   ; 00184E
0x001AE1 ---- 00:DAD1:  .byte $0F   ; 00185A
0x001AE2 ---- 00:DAD2:  .byte $0F   ; 001866
0x001AE3 ---- 00:DAD3:  .byte $0F   ; 001842
0x001AE4 ---- 00:DAD4:  .byte $00   ; 00184E
0x001AE5 ---- 00:DAD5:  .byte $0F   ; 00185A
0x001AE6 ---- 00:DAD6:  .byte $00   ; 001866
0x001AE7 ---- 00:DAD7:  .byte $0F   ; 001842
0x001AE8 ---- 00:DAD8:  .byte $0F   ; 00184E
0x001AE9 ---- 00:DAD9:  .byte $00   ; 00185A
0x001AEA ---- 00:DADA:  .byte $00   ; 001866
0x001AEB ---- 00:DADB:  .byte $0F   ; 001842
0x001AEC ---- 00:DADC:  .byte $0F   ; 00184E
0x001AED ---- 00:DADD:  .byte $0F   ; 00185A
0x001AEE ---- 00:DADE:  .byte $0F   ; 001866
0x001AEF ---- 00:DADF:  .byte $20   ; 001842
0x001AF0 ---- 00:DAE0:  .byte $10   ; 00184E
0x001AF1 ---- 00:DAE1:  .byte $20   ; 00185A
0x001AF2 ---- 00:DAE2:  .byte $10   ; 001866
0x001AF3 ---- 00:DAE3:  .byte $20   ; 001842
0x001AF4 ---- 00:DAE4:  .byte $20   ; 00184E
0x001AF5 ---- 00:DAE5:  .byte $10   ; 00185A
0x001AF6 ---- 00:DAE6:  .byte $10   ; 001866
0x001AF7 ---- 00:DAE7:  .byte $10   ; 001842
0x001AF8 ---- 00:DAE8:  .byte $20   ; 00184E
0x001AF9 ---- 00:DAE9:  .byte $10   ; 00185A
0x001AFA ---- 00:DAEA:  .byte $20   ; 001866
0x001AFB ---- 00:DAEB:  .byte $10   ; 001842
0x001AFC ---- 00:DAEC:  .byte $10   ; 00184E
0x001AFD ---- 00:DAED:  .byte $20   ; 00185A
0x001AFE ---- 00:DAEE:  .byte $20   ; 001866
0x001AFF ---- 00:DAEF:  .byte $10   ; 001842
0x001B00 ---- 00:DAF0:  .byte $10   ; 00184E
0x001B01 ---- 00:DAF1:  .byte $10   ; 00185A
0x001B02 ---- 00:DAF2:  .byte $10   ; 001866
0x001B03 ---- 00:DAF3:  .byte $12   ; 001842
0x001B04 ---- 00:DAF4:  .byte $12   ; 00184E
0x001B05 ---- 00:DAF5:  .byte $12   ; 00185A
0x001B06 ---- 00:DAF6:  .byte $12   ; 001866
0x001B07 ---- 00:DAF7:  .byte $22   ; 001842
0x001B08 ---- 00:DAF8:  .byte $22   ; 00184E
0x001B09 ---- 00:DAF9:  .byte $22   ; 00185A
0x001B0A ---- 00:DAFA:  .byte $22   ; 001866
0x001B0B ---- 00:DAFB:  .byte $21   ; 001842
0x001B0C ---- 00:DAFC:  .byte $21   ; 00184E
0x001B0D ---- 00:DAFD:  .byte $21   ; 00185A
0x001B0E ---- 00:DAFE:  .byte $21   ; 001866
0x001B0F ---- 00:DAFF:  .byte $00   ; 001842
0x001B10 ---- 00:DB00:  .byte $00   ; 00184E
0x001B11 ---- 00:DB01:  .byte $00   ; 00185A
0x001B12 ---- 00:DB02:  .byte $00   ; 001866
0x001B13 ---- xx:DB03:  .byte $00   ; 
0x001B14 ---- xx:DB04:  .byte $00   ; 
0x001B15 ---- xx:DB05:  .byte $00   ; 
0x001B16 ---- xx:DB06:  .byte $00   ; 
0x001B17 ---- 00:DB07:  .byte $00   ; 001842
0x001B18 ---- 00:DB08:  .byte $00   ; 00184E
0x001B19 ---- 00:DB09:  .byte $00   ; 00185A
0x001B1A ---- 00:DB0A:  .byte $00   ; 001866
; 1 refs via 000323
0x001B1B ---- 00:DB0B:  LDA ram_0311  ; $0311
0x001B1E ---- 00:DB0E:  BEQ $DB24  ; 001B34
0x001B20 -z-- 00:DB10:  LDX #$00  ; 
0x001B22 nZ-- 00:DB12:  JSR $DB38  ; 001B48
; 2 refs via 001B54 001B57
0x001B25 n--- 00:DB15:  BNE $DB37  ; 001B47
0x001B27 nZ-- 00:DB17:  LDX #$01  ; 
0x001B29 nz-- 00:DB19:  JSR $DB38  ; 001B48
; 2 refs via 001B54 001B57
0x001B2C n--- 00:DB1C:  BNE $DB37  ; 001B47
0x001B2E nZ-- 00:DB1E:  LDA #$00  ; 
0x001B30 nZ-- 00:DB20:  STA ram_0311  ; $0311
0x001B33 nZ-- 00:DB23:  RTS  ; 000326
; 1 refs via 001B1E
0x001B34 -Z-- 00:DB24:  LDX #$00  ; 
0x001B36 nZ-- 00:DB26:  JSR $DB38  ; 001B48
; 2 refs via 001B54 001B57
0x001B39 n--- 00:DB29:  BNE $DB32  ; 001B42
0x001B3B nZ-- 00:DB2B:  LDX #$01  ; 
0x001B3D nz-- 00:DB2D:  JSR $DB38  ; 001B48
; 2 refs via 001B54 001B57
0x001B40 n--- 00:DB30:  BEQ $DB37  ; 001B47
; 1 refs via 001B39
0x001B42 nz-- 00:DB32:  LDA #$01  ; 
0x001B44 nz-- 00:DB34:  STA ram_0311  ; $0311
; 3 refs via 001B25 001B2C 001B40
0x001B47 n--- 00:DB37:  RTS  ; 000326
; 4 refs via 001B22 001B29 001B36 001B3D
0x001B48 n--- 00:DB38:  LDA ram_0006,X  ; $0006 $0007
0x001B4A ---- 00:DB3A:  AND #$F0  ; 
0x001B4C ---- 00:DB3C:  BEQ $DB45  ; 001B55
0x001B4E -z-- 00:DB3E:  LDA ram_00A0,X  ; $00A0 $00A1
0x001B50 ---- 00:DB40:  BEQ $DB45  ; 001B55
0x001B52 -z-- 00:DB42:  LDA #$01  ; 
0x001B54 nz-- 00:DB44:  RTS  ; 001B25 001B2C 001B39 001B40
; 2 refs via 001B4C 001B50
0x001B55 -Z-- 00:DB45:  LDA #$00  ; 
0x001B57 nZ-- 00:DB47:  RTS  ; 001B25 001B2C 001B39 001B40
; 1 refs via 000311
0x001B58 ---- 00:DB48:  LDA ram_0082  ; $0082
0x001B5A ---- 00:DB4A:  BEQ $DB4F  ; 001B5F
0x001B5C -z-- 00:DB4C:  DEC ram_0082  ; $0082
0x001B5E ---- 00:DB4E:  RTS  ; 000314
; 1 refs via 001B5A
0x001B5F -Z-- 00:DB4F:  LDA ram_007F  ; $007F
0x001B61 ---- 00:DB51:  BEQ $DB74  ; 001B84
0x001B63 -z-- 00:DB53:  LDA ram_006C  ; $006C
0x001B65 ---- 00:DB55:  STA ram_005A  ; $005A
; 1 refs via 001B82
0x001B67 ---- 00:DB57:  LDX ram_005A  ; $005A
0x001B69 ---- 00:DB59:  LDA ram_00A0,X  ; $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001B6B ---- 00:DB5B:  BNE $DB6C  ; 001B7C
0x001B6D -Z-- 00:DB5D:  LDA ram_0084  ; $0084
0x001B6F ---- 00:DB5F:  STA ram_0082  ; $0082
0x001B71 ---- 00:DB61:  JSR $E363  ; 002373
; 1 refs via 0023C7
0x001B74 ---- 00:DB64:  DEC ram_007F  ; $007F
0x001B76 ---- 00:DB66:  LDA ram_007F  ; $007F
0x001B78 ---- 00:DB68:  JSR $C8B1  ; 0008C1
; 1 refs via 0008CF
0x001B7B -Z-- 00:DB6B:  RTS  ; 000314
; 1 refs via 001B6B
0x001B7C -z-- 00:DB6C:  DEC ram_005A  ; $005A
0x001B7E ---- 00:DB6E:  LDA ram_005A  ; $005A
0x001B80 ---- 00:DB70:  CMP #$01  ; 
0x001B82 ---- 00:DB72:  BNE $DB57  ; 001B67
; 1 refs via 001B61
0x001B84 -Z-- 00:DB74:  RTS  ; 000314
; 1 refs via 0002F9
0x001B85 N--- 00:DB75:  LDA ram_000B  ; $000B
0x001B87 ---- 00:DB77:  AND #$01  ; 
0x001B89 ---- 00:DB79:  BNE $DB81  ; 001B91
0x001B8B -Z-- 00:DB7B:  LDA ram_000B  ; $000B
0x001B8D ---- 00:DB7D:  AND #$03  ; 
0x001B8F ---- 00:DB7F:  BNE $DBF0  ; 001C00
; 1 refs via 001B89
0x001B91 ---- 00:DB81:  LDX #$01  ; 
; 1 refs via 001BFE
0x001B93 n--- 00:DB83:  LDA ram_00A0,X  ; $00A0 $00A1
0x001B95 ---- 00:DB85:  BPL $DBED  ; 001BFD
0x001B97 N--- 00:DB87:  CMP #$E0  ; 
0x001B99 ---- 00:DB89:  BCS $DBED  ; 001BFD
0x001B9B --c- 00:DB8B:  LDA ram_006F,X  ; $006F $0070
0x001B9D --c- 00:DB8D:  BEQ $DB94  ; 001BA4
0x001B9F -zc- 00:DB8F:  DEC ram_006F,X  ; $006F $0070
0x001BA1 --c- 00:DB91:  JMP $DBA6  ; 001BB6
; 1 refs via 001B9D
0x001BA4 -Zc- 00:DB94:  LDA ram_0103,X  ; $0103 $0104
0x001BA7 --c- 00:DB97:  BPL $DB9D  ; 001BAD
0x001BA9 N-c- 00:DB99:  AND #$10  ; 
0x001BAB --c- 00:DB9B:  BNE $DBA6  ; 001BB6
; 1 refs via 001BA7
0x001BAD --c- 00:DB9D:  LDA ram_0006,X  ; $0006 $0007
0x001BAF --c- 00:DB9F:  JSR $E451  ; 002461
; 5 refs via 002466 00246C 002472 002478 00247B
0x001BB2 ---- 00:DBA2:  STA ram_0000  ; $0000
0x001BB4 ---- 00:DBA4:  BPL $DBB4  ; 001BC4
; 2 refs via 001BA1 001BAB
0x001BB6 ---- 00:DBA6:  LDA #$80  ; 
0x001BB8 Nz-- 00:DBA8:  JSR $E420  ; 002430
; 1 refs via 00243A
0x001BBB ---- 00:DBAB:  LDA #$08  ; 
0x001BBD nz-- 00:DBAD:  ORA ram_00A0,X  ; $00A0 $00A1
0x001BBF ---- 00:DBAF:  STA ram_00A0,X  ; $00A0 $00A1
0x001BC1 ---- 00:DBB1:  JMP $DBED  ; 001BFD
; 1 refs via 001BB4
0x001BC4 n--- 00:DBB4:  LDA ram_0103,X  ; $0103 $0104
0x001BC7 ---- 00:DBB7:  BPL $DBC7  ; 001BD7
0x001BC9 N--- 00:DBB9:  AND #$1F  ; 
0x001BCB ---- 00:DBBB:  BNE $DBC7  ; 001BD7
0x001BCD -Z-- 00:DBBD:  LDA #$9C  ; 
0x001BCF Nz-- 00:DBBF:  STA ram_0103,X  ; $0103 $0104
0x001BD2 Nz-- 00:DBC2:  LDA #$01  ; 
0x001BD4 nz-- 00:DBC4:  STA ram_0310  ; $0310
; 2 refs via 001BC7 001BCB
0x001BD7 ---- 00:DBC7:  LDA ram_00A0,X  ; $00A0 $00A1
0x001BD9 ---- 00:DBC9:  AND #$03  ; 
0x001BDB ---- 00:DBCB:  CMP ram_0000  ; $0000
0x001BDD ---- 00:DBCD:  BEQ $DBE7  ; 001BF7
0x001BDF -z-- 00:DBCF:  EOR #$02  ; 
0x001BE1 ---- 00:DBD1:  CMP ram_0000  ; $0000
0x001BE3 ---- 00:DBD3:  BEQ $DBE7  ; 001BF7
0x001BE5 -z-- 00:DBD5:  LDA ram_0090,X  ; $0090 $0091
0x001BE7 ---- 00:DBD7:  CLC  ; 
0x001BE8 --c- 00:DBD8:  ADC #$04  ; 
0x001BEA ---- 00:DBDA:  AND #$F8  ; 
0x001BEC ---- 00:DBDC:  STA ram_0090,X  ; $0090 $0091
0x001BEE ---- 00:DBDE:  LDA ram_0098,X  ; $0098 $0099
0x001BF0 ---- 00:DBE0:  CLC  ; 
0x001BF1 --c- 00:DBE1:  ADC #$04  ; 
0x001BF3 ---- 00:DBE3:  AND #$F8  ; 
0x001BF5 ---- 00:DBE5:  STA ram_0098,X  ; $0098 $0099
; 2 refs via 001BDD 001BE3
0x001BF7 ---- 00:DBE7:  LDA ram_0000  ; $0000
0x001BF9 ---- 00:DBE9:  ORA #$A0  ; 
0x001BFB Nz-- 00:DBEB:  STA ram_00A0,X  ; $00A0 $00A1
; 3 refs via 001B95 001B99 001BC1
0x001BFD ---- 00:DBED:  DEX  ; 
0x001BFE ---- 00:DBEE:  BPL $DB83  ; 001B93
; 6 refs via 001B8F 001C5F 001EDA 00205E 002108 002312
0x001C00 ---- 00:DBF0:  RTS  ; 0002FC 000308 001C48 001EBF 002047 0020F1
; 1 refs via 0002FC
0x001C01 ---- 00:DBF1:  LDA #$07  ; 
0x001C03 nz-- 00:DBF3:  STA ram_005A  ; $005A
0x001C05 nz-- 00:DBF5:  LDA ram_0100  ; $0100
0x001C08 ---- 00:DBF8:  BEQ $DC03  ; 001C13
0x001C0A -z-- 00:DBFA:  LDA ram_000B  ; $000B
0x001C0C ---- 00:DBFC:  AND #$3F  ; 
0x001C0E ---- 00:DBFE:  BNE $DC03  ; 001C13
0x001C10 -Z-- 00:DC00:  DEC ram_0100  ; $0100
; 3 refs via 001C08 001C0E 001C4A
0x001C13 ---- 00:DC03:  LDX ram_005A  ; $005A
0x001C15 ---- 00:DC05:  CPX #$02  ; 
0x001C17 ---- 00:DC07:  BCS $DC18  ; 001C28
0x001C19 --c- 00:DC09:  LDA ram_000B  ; $000B
0x001C1B --c- 00:DC0B:  AND #$01  ; 
0x001C1D --c- 00:DC0D:  BNE $DC35  ; 001C45
0x001C1F -Zc- 00:DC0F:  LDA ram_000B  ; $000B
0x001C21 --c- 00:DC11:  AND #$03  ; 
0x001C23 --c- 00:DC13:  BNE $DC38  ; 001C48
0x001C25 -Zc- 00:DC15:  JMP $DC35  ; 001C45
; 1 refs via 001C17
0x001C28 --C- 00:DC18:  LDA ram_0100  ; $0100
0x001C2B --C- 00:DC1B:  BEQ $DC25  ; 001C35
0x001C2D -zC- 00:DC1D:  LDA ram_00A0,X  ; $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001C2F --C- 00:DC1F:  BPL $DC25  ; 001C35
0x001C31 N-C- 00:DC21:  CMP #$E0  ; 
0x001C33 ---- 00:DC23:  BCC $DC38  ; 001C48
; 2 refs via 001C2B 001C2F
0x001C35 --C- 00:DC25:  LDA ram_00A8,X  ; $00AA $00AB $00AC $00AD $00AE $00AF
0x001C37 --C- 00:DC27:  AND #$F0  ; 
0x001C39 --C- 00:DC29:  CMP #$A0  ; 
0x001C3B ---- 00:DC2B:  BEQ $DC35  ; 001C45
0x001C3D -z-- 00:DC2D:  LDA ram_005A  ; $005A
0x001C3F ---- 00:DC2F:  EOR ram_000B  ; $000B
0x001C41 ---- 00:DC31:  AND #$01  ; 
0x001C43 ---- 00:DC33:  BEQ $DC38  ; 001C48
; 3 refs via 001C1D 001C25 001C3B
0x001C45 ---- 00:DC35:  JSR $DC3D  ; 001C4D
; 18 refs via 001C00 001C23 001C33 001C43 001C8B 001CA6 001D3F 001D57 001D79 001D7D 001DB1 001E16 001E24 001E27 001E43 001E55 001E73 001E81
0x001C48 ---- 00:DC38:  DEC ram_005A  ; $005A
0x001C4A ---- 00:DC3A:  BPL $DC03  ; 001C13
0x001C4C N--- 00:DC3C:  RTS  ; 0002FF
; 1 refs via 001C45
0x001C4D ---- 00:DC3D:  LDA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001C4F ---- 00:DC3F:  LSR  ; 
0x001C50 ---- 00:DC40:  LSR  ; 
0x001C51 ---- 00:DC41:  LSR  ; 
0x001C52 ---- 00:DC42:  AND #$FE  ; 
0x001C54 ---- 00:DC44:  TAY  ; 
0x001C55 ---- 00:DC45:  LDA $E498,Y  ; 0024A8 0024AA 0024AC 0024AE 0024B0 0024B2 0024B4 0024B6 0024B8 0024BA 0024BC 0024BE 0024C0 0024C2 0024C4 0024C6
0x001C58 ---- 00:DC48:  STA ram_0011  ; $0011
0x001C5A ---- 00:DC4A:  LDA $E499,Y  ; 0024A9 0024AB 0024AD 0024AF 0024B1 0024B3 0024B5 0024B7 0024B9 0024BB 0024BD 0024BF 0024C1 0024C3 0024C5 0024C7
0x001C5D ---- 00:DC4D:  STA ram_0012  ; $0012
0x001C5F ---- 00:DC4F:  JMP (ram_0011)  ; 001C00 001C62 001C8C 001D58 001D8E 001D99 001DA4 001DFA 001E65 001E74
; 1 refs via 001C5F
0x001C62 ---- 00:DC52:  CPX #$02  ; 
0x001C64 ---- 00:DC54:  BCS $DC6B  ; 001C7B
0x001C66 --c- 00:DC56:  LDA ram_0103,X  ; $0103 $0104
0x001C69 --c- 00:DC59:  BPL $DC6B  ; 001C7B
0x001C6B N-c- 00:DC5B:  AND #$7F  ; 
0x001C6D --c- 00:DC5D:  BEQ $DC6B  ; 001C7B
0x001C6F -zc- 00:DC5F:  DEC ram_0103,X  ; $0103 $0104
0x001C72 --c- 00:DC62:  LDA ram_00B0,X  ; $00B0 $00B1
0x001C74 --c- 00:DC64:  EOR #$04  ; 
0x001C76 --c- 00:DC66:  STA ram_00B0,X  ; $00B0 $00B1
0x001C78 --c- 00:DC68:  JMP $DC97  ; 001CA7
; 3 refs via 001C64 001C69 001C6D
0x001C7B ---- 00:DC6B:  LDA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001C7D ---- 00:DC6D:  SEC  ; 
0x001C7E --C- 00:DC6E:  SBC #$04  ; 
0x001C80 ---- 00:DC70:  STA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001C82 ---- 00:DC72:  AND #$0C  ; 
0x001C84 ---- 00:DC74:  BNE $DC7B  ; 001C8B
0x001C86 -Z-- 00:DC76:  LDA #$A0  ; 
0x001C88 Nz-- 00:DC78:  JSR $E420  ; 002430
; 2 refs via 001C84 00243A
0x001C8B ---- 00:DC7B:  RTS  ; 001C48
; 1 refs via 001C5F
0x001C8C ---- 00:DC7C:  CPX #$02  ; 
0x001C8E ---- 00:DC7E:  BCC $DC97  ; 001CA7
0x001C90 --C- 00:DC80:  LDA ram_0090,X  ; $0092 $0093 $0094 $0095 $0096 $0097
0x001C92 --C- 00:DC82:  AND #$07  ; 
0x001C94 --C- 00:DC84:  BNE $DC97  ; 001CA7
0x001C96 -ZC- 00:DC86:  LDA ram_0098,X  ; $009A $009B $009C $009D $009E $009F
0x001C98 --C- 00:DC88:  AND #$07  ; 
0x001C9A --C- 00:DC8A:  BNE $DC97  ; 001CA7
0x001C9C -ZC- 00:DC8C:  JSR $D44D  ; 00145D
; 1 refs via 001476
0x001C9F ---- 00:DC8F:  AND #$0F  ; 
0x001CA1 ---- 00:DC91:  BNE $DC97  ; 001CA7
0x001CA3 -Z-- 00:DC93:  JSR $DE72  ; 001E82
; 2 refs via 001E9D 001EB5
0x001CA6 ---- 00:DC96:  RTS  ; 001C48
; 5 refs via 001C78 001C8E 001C94 001C9A 001CA1
0x001CA7 ---- 00:DC97:  LDA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001CA9 ---- 00:DC99:  AND #$03  ; 
0x001CAB ---- 00:DC9B:  TAY  ; 
0x001CAC ---- 00:DC9C:  LDA $E470,Y  ; 002480 002481 002482 002483
0x001CAF ---- 00:DC9F:  ASL  ; 
0x001CB0 ---- 00:DCA0:  ASL  ; 
0x001CB1 ---- 00:DCA1:  ASL  ; 
0x001CB2 ---- 00:DCA2:  STA ram_0059  ; $0059
0x001CB4 ---- 00:DCA4:  LDA $E470,Y  ; 002480 002481 002482 002483
0x001CB7 ---- 00:DCA7:  CLC  ; 
0x001CB8 --c- 00:DCA8:  ADC ram_0098,X  ; $0098 $0099 $009A $009B $009C $009D $009E $009F
0x001CBA ---- 00:DCAA:  STA ram_0057  ; $0057
0x001CBC ---- 00:DCAC:  LDA $E46C,Y  ; 00247C 00247D 00247E 00247F
0x001CBF ---- 00:DCAF:  ASL  ; 
0x001CC0 ---- 00:DCB0:  ASL  ; 
0x001CC1 ---- 00:DCB1:  ASL  ; 
0x001CC2 ---- 00:DCB2:  STA ram_0058  ; $0058
0x001CC4 ---- 00:DCB4:  LDA $E46C,Y  ; 00247C 00247D 00247E 00247F
0x001CC7 ---- 00:DCB7:  CLC  ; 
0x001CC8 --c- 00:DCB8:  ADC ram_0090,X  ; $0090 $0091 $0092 $0093 $0094 $0095 $0096 $0097
0x001CCA ---- 00:DCBA:  STA ram_0056  ; $0056
0x001CCC ---- 00:DCBC:  CLC  ; 
0x001CCD --c- 00:DCBD:  ADC ram_0058  ; $0058
0x001CCF ---- 00:DCBF:  CLC  ; 
0x001CD0 --c- 00:DCC0:  ADC ram_0059  ; $0059
0x001CD2 ---- 00:DCC2:  JSR $DD6E  ; 001D7E
; 1 refs via 001D85
0x001CD5 ---- 00:DCC5:  TAX  ; 
0x001CD6 ---- 00:DCC6:  LDA ram_0057  ; $0057
0x001CD8 ---- 00:DCC8:  CLC  ; 
0x001CD9 --c- 00:DCC9:  ADC ram_0058  ; $0058
0x001CDB ---- 00:DCCB:  CLC  ; 
0x001CDC --c- 00:DCCC:  ADC ram_0059  ; $0059
0x001CDE ---- 00:DCCE:  JSR $DD76  ; 001D86
; 1 refs via 001D8D
0x001CE1 ---- 00:DCD1:  TAY  ; 
0x001CE2 ---- 00:DCD2:  JSR $D706  ; 001716
; 1 refs via 001722
0x001CE5 nZ-- 00:DCD5:  LDA (ram_0011),Y  ; $0422 $0424 $0426 $0427 $0428 $0429 $042A $042B $042C $042D $042E $042F $0430 $0431 $0432 $0433 $0434 $0435 $0436 $0437 $0438 $0439 $043A $0441 $0442 $0443 $0444 $0445 $0446 $0447 $0448 $0449 $044A $044B $044C $044D $044E $044F $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0458 $0459 $045A $0461 $0462 $0463 $0464 $0465 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $046E $046F $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $047A $047B $047C $0481 $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $049C $04A1 $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04BC $04C1 $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04DC $04E1 $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $04FC $0501 $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $051C $0521 $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $053C $0541 $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $055C $0561 $0562 $0563 $0564 $0565 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $057C $0581 $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $059C $05A1 $05A2 $05A3 $05A4 $05A5 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05BC $05C1 $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05DC $05E1 $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $05FC $0601 $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $061C $0621 $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $0639 $063A $063B $063C $0641 $0642 $0643 $0644 $0645 $0646 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $065C $0661 $0662 $0663 $0664 $0665 $0666 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $067C $0681 $0682 $0683 $0684 $0685 $0686 $0687 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0692 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $069C $06A2 $06A3 $06A4 $06A5 $06A6 $06A7 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B7 $06B8 $06B9 $06BA $06BB $06BC $06C1 $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06DC $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $06FA $06FB $06FC $0701 $0702 $0703 $0704 $0705 $0706 $0707 $0708 $0709 $070A $070B $070C $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0717 $0718 $0719 $071A $071B $071C $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072C $072D $072E $072F $0730 $0731 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $073C $0741 $0742 $0743 $0744 $0745 $0746 $0747 $0748 $0749 $074A $074B $074C $074D $074E $074F $0750 $0751 $0752 $0753 $0754 $0755 $0756 $0757 $0758 $0759 $075A $075B $075C $0763 $0764 $0765 $0766 $0767 $0768 $0769 $076A $076B $076C $076D $076E $0772 $0773 $0774 $0775 $0776 $0777 $0778 $0779 $077A $077B $0783 $0784 $0785 $0786 $0787 $0788 $0789 $078A $078B $078C $0792 $0793 $0794 $0795 $0796 $0797 $0798 $0799 $079A $079B
0x001CE7 ---- 00:DCD7:  BMI $DD11  ; 001D21
0x001CE9 n--- 00:DCD9:  BEQ $DCDF  ; 001CEF
0x001CEB nz-- 00:DCDB:  CMP #$20  ; 
0x001CED ---- 00:DCDD:  BCC $DD11  ; 001D21
; 1 refs via 001CE9
0x001CEF ---- 00:DCDF:  LDA ram_0056  ; $0056
0x001CF1 ---- 00:DCE1:  CLC  ; 
0x001CF2 --c- 00:DCE2:  ADC ram_0058  ; $0058
0x001CF4 ---- 00:DCE4:  SEC  ; 
0x001CF5 --C- 00:DCE5:  SBC ram_0059  ; $0059
0x001CF7 ---- 00:DCE7:  JSR $DD6E  ; 001D7E
; 1 refs via 001D85
0x001CFA ---- 00:DCEA:  TAX  ; 
0x001CFB ---- 00:DCEB:  LDA ram_0057  ; $0057
0x001CFD ---- 00:DCED:  CLC  ; 
0x001CFE --c- 00:DCEE:  ADC ram_0059  ; $0059
0x001D00 ---- 00:DCF0:  SEC  ; 
0x001D01 --C- 00:DCF1:  SBC ram_0058  ; $0058
0x001D03 ---- 00:DCF3:  JSR $DD76  ; 001D86
; 1 refs via 001D8D
0x001D06 ---- 00:DCF6:  TAY  ; 
0x001D07 ---- 00:DCF7:  JSR $D706  ; 001716
; 1 refs via 001722
0x001D0A nZ-- 00:DCFA:  LDA (ram_0011),Y  ; $0443 $0444 $0445 $0446 $0447 $0448 $0449 $044A $044B $044C $044D $044E $044F $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0458 $0459 $045A $045B $0462 $0463 $0464 $0465 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $046E $046F $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $047A $047B $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $0562 $0563 $0564 $0565 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $05A2 $05A3 $05A4 $05A5 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $0639 $063A $063B $0642 $0643 $0644 $0645 $0646 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $0662 $0663 $0664 $0665 $0666 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $0682 $0683 $0684 $0685 $0686 $0687 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0692 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $06A2 $06A3 $06A4 $06A5 $06A6 $06A7 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B7 $06B8 $06B9 $06BA $06BB $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $06FA $06FB $0702 $0703 $0704 $0705 $0706 $0707 $0708 $0709 $070A $070B $070C $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0717 $0718 $0719 $071A $071B $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072C $072D $072E $072F $0730 $0731 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $0742 $0744 $0745 $0746 $0747 $0748 $0749 $074A $074B $074C $074D $074F $0750 $0751 $0752 $0753 $0754 $0755 $0756 $0757 $0758 $0759 $075A $075B $0762 $0763 $0764 $0765 $0766 $0767 $0768 $0769 $076A $076B $076C $0770 $0771 $0772 $0773 $0774 $0775 $0776 $0777 $0778 $0779 $077A
0x001D0C ---- 00:DCFC:  BMI $DD11  ; 001D21
0x001D0E n--- 00:DCFE:  BEQ $DD04  ; 001D14
0x001D10 nz-- 00:DD00:  CMP #$20  ; 
0x001D12 ---- 00:DD02:  BCC $DD11  ; 001D21
; 1 refs via 001D0E
0x001D14 ---- 00:DD04:  LDX ram_005A  ; $005A
0x001D16 ---- 00:DD06:  LDA ram_0056  ; $0056
0x001D18 ---- 00:DD08:  STA ram_0090,X  ; $0090 $0091 $0092 $0093 $0094 $0095 $0096 $0097
0x001D1A ---- 00:DD0A:  LDA ram_0057  ; $0057
0x001D1C ---- 00:DD0C:  STA ram_0098,X  ; $0098 $0099 $009A $009B $009C $009D $009E $009F
0x001D1E ---- 00:DD0E:  JMP $DD29  ; 001D39
; 4 refs via 001CE7 001CED 001D0C 001D12
0x001D21 ---- 00:DD11:  LDX ram_005A  ; $005A
0x001D23 ---- 00:DD13:  CPX #$02  ; 
0x001D25 ---- 00:DD15:  BCC $DD29  ; 001D39
0x001D27 --C- 00:DD17:  JSR $D44D  ; 00145D
; 1 refs via 001476
0x001D2A ---- 00:DD1A:  AND #$03  ; 
0x001D2C ---- 00:DD1C:  BEQ $DD30  ; 001D40
0x001D2E -z-- 00:DD1E:  LDA #$80  ; 
0x001D30 Nz-- 00:DD20:  JSR $E420  ; 002430
; 1 refs via 00243A
0x001D33 ---- 00:DD23:  LDA #$08  ; 
0x001D35 nz-- 00:DD25:  ORA ram_00A0,X  ; $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001D37 ---- 00:DD27:  STA ram_00A0,X  ; $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
; 2 refs via 001D1E 001D25
0x001D39 ---- 00:DD29:  LDA ram_00B0,X  ; $00B0 $00B1 $00B2 $00B3 $00B4 $00B5 $00B6 $00B7
0x001D3B ---- 00:DD2B:  EOR #$04  ; 
0x001D3D ---- 00:DD2D:  STA ram_00B0,X  ; $00B0 $00B1 $00B2 $00B3 $00B4 $00B5 $00B6 $00B7
0x001D3F ---- 00:DD2F:  RTS  ; 001C48
; 1 refs via 001D2C
0x001D40 -Z-- 00:DD30:  LDA ram_0090,X  ; $0092 $0093 $0094 $0095 $0096 $0097
0x001D42 ---- 00:DD32:  AND #$07  ; 
0x001D44 ---- 00:DD34:  BNE $DD41  ; 001D51
0x001D46 -Z-- 00:DD36:  LDA ram_0098,X  ; $009A $009B $009C $009D $009E $009F
0x001D48 ---- 00:DD38:  AND #$07  ; 
0x001D4A ---- 00:DD3A:  BNE $DD41  ; 001D51
0x001D4C -Z-- 00:DD3C:  LDA #$90  ; 
0x001D4E Nz-- 00:DD3E:  JSR $E420  ; 002430
; 3 refs via 001D44 001D4A 00243A
0x001D51 ---- 00:DD41:  LDA ram_00A0,X  ; $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001D53 ---- 00:DD43:  EOR #$02  ; 
0x001D55 ---- 00:DD45:  STA ram_00A0,X  ; $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001D57 ---- 00:DD47:  RTS  ; 001C48
; 1 refs via 001C5F
0x001D58 ---- 00:DD48:  JSR $D44D  ; 00145D
; 1 refs via 001476
0x001D5B ---- 00:DD4B:  AND #$01  ; 
0x001D5D ---- 00:DD4D:  BEQ $DD6A  ; 001D7A
0x001D5F -z-- 00:DD4F:  JSR $D44D  ; 00145D
; 1 refs via 001476
0x001D62 ---- 00:DD52:  AND #$01  ; 
0x001D64 ---- 00:DD54:  BEQ $DD5E  ; 001D6E
0x001D66 -z-- 00:DD56:  LDA ram_00A0,X  ; $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001D68 ---- 00:DD58:  CLC  ; 
0x001D69 --c- 00:DD59:  ADC #$01  ; 
0x001D6B ---- 00:DD5B:  JMP $DD63  ; 001D73
; 1 refs via 001D64
0x001D6E -Z-- 00:DD5E:  LDA ram_00A0,X  ; $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001D70 ---- 00:DD60:  SEC  ; 
0x001D71 --C- 00:DD61:  SBC #$01  ; 
; 1 refs via 001D6B
0x001D73 ---- 00:DD63:  AND #$03  ; 
0x001D75 ---- 00:DD65:  ORA #$A0  ; 
0x001D77 Nz-- 00:DD67:  STA ram_00A0,X  ; $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001D79 Nz-- 00:DD69:  RTS  ; 001C48
; 1 refs via 001D5D
0x001D7A -Z-- 00:DD6A:  JSR $DE72  ; 001E82
; 2 refs via 001E9D 001EB5
0x001D7D ---- 00:DD6D:  RTS  ; 001C48
; 2 refs via 001CD2 001CF7
0x001D7E ---- 00:DD6E:  CMP ram_0056  ; $0056
0x001D80 ---- 00:DD70:  BCC $DD75  ; 001D85
0x001D82 --C- 00:DD72:  SEC  ; 
0x001D83 --C- 00:DD73:  SBC #$01  ; 
; 1 refs via 001D80
0x001D85 ---- 00:DD75:  RTS  ; 001CD5 001CFA
; 2 refs via 001CDE 001D03
0x001D86 ---- 00:DD76:  CMP ram_0057  ; $0057
0x001D88 ---- 00:DD78:  BCC $DD7D  ; 001D8D
0x001D8A --C- 00:DD7A:  SEC  ; 
0x001D8B --C- 00:DD7B:  SBC #$01  ; 
; 1 refs via 001D88
0x001D8D ---- 00:DD7D:  RTS  ; 001CE1 001D06
; 1 refs via 001C5F
0x001D8E ---- 00:DD7E:  LDA ram_0090  ; $0090
0x001D90 ---- 00:DD80:  STA ram_0071  ; $0071
0x001D92 ---- 00:DD82:  LDA ram_0098  ; $0098
0x001D94 ---- 00:DD84:  STA ram_0072  ; $0072
0x001D96 ---- 00:DD86:  JMP $DD9C  ; 001DAC
; 1 refs via 001C5F
0x001D99 ---- 00:DD89:  LDA ram_0091  ; $0091
0x001D9B ---- 00:DD8B:  STA ram_0071  ; $0071
0x001D9D ---- 00:DD8D:  LDA ram_0099  ; $0099
0x001D9F ---- 00:DD8F:  STA ram_0072  ; $0072
0x001DA1 ---- 00:DD91:  JMP $DD9C  ; 001DAC
; 1 refs via 001C5F
0x001DA4 ---- 00:DD94:  LDA #$78  ; 
0x001DA6 nz-- 00:DD96:  STA ram_0071  ; $0071
0x001DA8 nz-- 00:DD98:  LDA #$D8  ; 
0x001DAA Nz-- 00:DD9A:  STA ram_0072  ; $0072
; 2 refs via 001D96 001DA1
0x001DAC ---- 00:DD9C:  JSR $DDA2  ; 001DB2
; 1 refs via 001DF9
0x001DAF ---- 00:DD9F:  STA ram_00A0,X  ; $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001DB1 ---- 00:DDA1:  RTS  ; 001C48
; 5 refs via 000668 00067E 000694 0006AA 001DAC
0x001DB2 ---- 00:DDA2:  LDA ram_0071  ; $0071
0x001DB4 ---- 00:DDA4:  SEC  ; 
0x001DB5 --C- 00:DDA5:  SBC ram_0090,X  ; $0090 $0091 $0092 $0093 $0094 $0095 $0096 $0097
0x001DB7 ---- 00:DDA7:  JSR $DAAF  ; 001ABF
; 1 refs via 001ACA
0x001DBA ---- 00:DDAA:  CLC  ; 
0x001DBB --c- 00:DDAB:  ADC #$01  ; 
0x001DBD ---- 00:DDAD:  STA ram_0064  ; $0064
0x001DBF ---- 00:DDAF:  LDA ram_0072  ; $0072
0x001DC1 ---- 00:DDB1:  SEC  ; 
0x001DC2 --C- 00:DDB2:  SBC ram_0098,X  ; $0098 $0099 $009A $009B $009C $009D $009E $009F
0x001DC4 ---- 00:DDB4:  JSR $DAAF  ; 001ABF
; 1 refs via 001ACA
0x001DC7 ---- 00:DDB7:  CLC  ; 
0x001DC8 --c- 00:DDB8:  ADC #$01  ; 
0x001DCA ---- 00:DDBA:  STA ram_0065  ; $0065
0x001DCC ---- 00:DDBC:  ASL  ; 
0x001DCD ---- 00:DDBD:  CLC  ; 
0x001DCE --c- 00:DDBE:  ADC ram_0065  ; $0065
0x001DD0 ---- 00:DDC0:  CLC  ; 
0x001DD1 --c- 00:DDC1:  ADC ram_0064  ; $0064
0x001DD3 ---- 00:DDC3:  STA ram_0064  ; $0064
0x001DD5 ---- 00:DDC5:  CPX #$02  ; 
0x001DD7 ---- 00:DDC7:  BCS $DDD4  ; 001DE4
0x001DD9 --c- 00:DDC9:  TXA  ; 
0x001DDA --c- 00:DDCA:  ASL  ; 
0x001DDB ---- 00:DDCB:  EOR ram_000A  ; $000A
0x001DDD ---- 00:DDCD:  AND #$02  ; 
0x001DDF ---- 00:DDCF:  BEQ $DDE4  ; 001DF4
0x001DE1 -z-- 00:DDD1:  JMP $DDDB  ; 001DEB
; 1 refs via 001DD7
0x001DE4 --C- 00:DDD4:  JSR $D44D  ; 00145D
; 1 refs via 001476
0x001DE7 ---- 00:DDD7:  AND #$01  ; 
0x001DE9 ---- 00:DDD9:  BEQ $DDE4  ; 001DF4
; 1 refs via 001DE1
0x001DEB -z-- 00:DDDB:  LDA #$09  ; 
0x001DED nz-- 00:DDDD:  CLC  ; 
0x001DEE nzc- 00:DDDE:  ADC ram_0064  ; $0064
0x001DF0 ---- 00:DDE0:  TAY  ; 
0x001DF1 ---- 00:DDE1:  JMP $DDE6  ; 001DF6
; 2 refs via 001DDF 001DE9
0x001DF4 -Z-- 00:DDE4:  LDY ram_0064  ; $0064
; 1 refs via 001DF1
0x001DF6 ---- 00:DDE6:  LDA $E486,Y  ; 002496 002497 002498 002499 00249A 00249B 00249C 00249D 00249E 00249F 0024A0 0024A1 0024A2 0024A4 0024A5 0024A6 0024A7
0x001DF9 ---- 00:DDE9:  RTS  ; 00066B 000681 000697 0006AD 001DAF
; 1 refs via 001C5F
0x001DFA ---- 00:DDEA:  DEC ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001DFC ---- 00:DDEC:  LDA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001DFE ---- 00:DDEE:  AND #$0F  ; 
0x001E00 ---- 00:DDF0:  BNE $DE45  ; 001E55
0x001E02 -Z-- 00:DDF2:  LDA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001E04 ---- 00:DDF4:  SEC  ; 
0x001E05 --C- 00:DDF5:  SBC #$10  ; 
0x001E07 ---- 00:DDF7:  BEQ $DE07  ; 001E17
0x001E09 -z-- 00:DDF9:  CMP #$10  ; 
0x001E0B ---- 00:DDFB:  BNE $DE02  ; 001E12
0x001E0D -Z-- 00:DDFD:  ORA #$06  ; 
0x001E0F -z-- 00:DDFF:  JMP $DE04  ; 001E14
; 1 refs via 001E0B
0x001E12 -z-- 00:DE02:  ORA #$03  ; 
; 1 refs via 001E0F
0x001E14 -z-- 00:DE04:  STA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001E16 -z-- 00:DE06:  RTS  ; 001C48
; 1 refs via 001E07
0x001E17 -Z-- 00:DE07:  STA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001E19 -Z-- 00:DE09:  CPX #$02  ; 
0x001E1B ---- 00:DE0B:  BCS $DE15  ; 001E25
0x001E1D --c- 00:DE0D:  DEC ram_0051,X  ; $0051 $0052
0x001E1F --c- 00:DE0F:  BEQ $DE18  ; 001E28
0x001E21 -zc- 00:DE11:  JSR $E363  ; 002373
; 1 refs via 0023C7
0x001E24 ---- 00:DE14:  RTS  ; 001C48
; 1 refs via 001E1B
0x001E25 --C- 00:DE15:  DEC ram_0080  ; $0080
0x001E27 --C- 00:DE17:  RTS  ; 001C48
; 1 refs via 001E1F
0x001E28 -Zc- 00:DE18:  LDA ram_0068  ; $0068
0x001E2A --c- 00:DE1A:  CMP #$80  ; 
0x001E2C ---- 00:DE1C:  BNE $DE45  ; 001E55
0x001E2E -Z-- 00:DE1E:  CPX #$01  ; 
0x001E30 ---- 00:DE20:  BEQ $DE34  ; 001E44
0x001E32 -z-- 00:DE22:  LDA ram_0052  ; $0052
0x001E34 ---- 00:DE24:  BEQ $DE45  ; 001E55
0x001E36 -z-- 00:DE26:  LDA #$03  ; 
0x001E38 nz-- 00:DE28:  STA ram_0107  ; $0107
0x001E3B nz-- 00:DE2B:  LDA #$20  ; 
0x001E3D nz-- 00:DE2D:  STA ram_0105  ; $0105
0x001E40 nz-- 00:DE30:  JSR $DE46  ; 001E56
; 1 refs via 001E64
0x001E43 nZ-- 00:DE33:  RTS  ; 001C48
; 1 refs via 001E30
0x001E44 -Z-- 00:DE34:  LDA ram_0051  ; $0051
0x001E46 ---- 00:DE36:  BEQ $DE45  ; 001E55
0x001E48 -z-- 00:DE38:  LDA #$01  ; 
0x001E4A nz-- 00:DE3A:  STA ram_0107  ; $0107
0x001E4D nz-- 00:DE3D:  LDA #$C0  ; 
0x001E4F Nz-- 00:DE3F:  STA ram_0105  ; $0105
0x001E52 Nz-- 00:DE42:  JSR $DE46  ; 001E56
; 5 refs via 001E00 001E2C 001E34 001E46 001E64
0x001E55 ---- 00:DE45:  RTS  ; 001C48
; 2 refs via 001E40 001E52
0x001E56 -z-- 00:DE46:  LDA #$0D  ; 
0x001E58 nz-- 00:DE48:  STA ram_0108  ; $0108
0x001E5B nz-- 00:DE4B:  LDA #$D8  ; 
0x001E5D Nz-- 00:DE4D:  STA ram_0106  ; $0106
0x001E60 Nz-- 00:DE50:  LDA #$00  ; 
0x001E62 nZ-- 00:DE52:  STA ram_000B  ; $000B
0x001E64 nZ-- 00:DE54:  RTS  ; 001E43 001E55
; 1 refs via 001C5F
0x001E65 ---- 00:DE55:  INC ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001E67 ---- 00:DE57:  LDA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001E69 ---- 00:DE59:  AND #$0F  ; 
0x001E6B ---- 00:DE5B:  CMP #$0E  ; 
0x001E6D ---- 00:DE5D:  BNE $DE63  ; 001E73
0x001E6F -Z-- 00:DE5F:  LDA #$E0  ; 
0x001E71 Nz-- 00:DE61:  STA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
; 1 refs via 001E6D
0x001E73 -z-- 00:DE63:  RTS  ; 001C48
; 1 refs via 001C5F
0x001E74 ---- 00:DE64:  INC ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001E76 ---- 00:DE66:  LDA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001E78 ---- 00:DE68:  AND #$0F  ; 
0x001E7A ---- 00:DE6A:  CMP #$0E  ; 
0x001E7C ---- 00:DE6C:  BNE $DE71  ; 001E81
0x001E7E -Z-- 00:DE6E:  JSR $E3B8  ; 0023C8
; 2 refs via 001E7C 002418
0x001E81 ---- 00:DE71:  RTS  ; 001C48
; 2 refs via 001CA3 001D7A
0x001E82 -Z-- 00:DE72:  LDA ram_0084  ; $0084
0x001E84 ---- 00:DE74:  LSR  ; 
0x001E85 ---- 00:DE75:  LSR  ; 
0x001E86 ---- 00:DE76:  CMP ram_000A  ; $000A
0x001E88 ---- 00:DE78:  BCS $DE7F  ; 001E8F
0x001E8A --c- 00:DE7A:  LDA #$B0  ; 
0x001E8C Nzc- 00:DE7C:  JMP $DEA2  ; 001EB2
; 1 refs via 001E88
0x001E8F --C- 00:DE7F:  LSR  ; 
0x001E90 ---- 00:DE80:  CMP ram_000A  ; $000A
0x001E92 ---- 00:DE82:  BCC $DE8E  ; 001E9E
0x001E94 --C- 00:DE84:  JSR $D44D  ; 00145D
; 1 refs via 001476
0x001E97 ---- 00:DE87:  AND #$03  ; 
0x001E99 ---- 00:DE89:  ORA #$A0  ; 
0x001E9B Nz-- 00:DE8B:  STA ram_00A0,X  ; $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001E9D Nz-- 00:DE8D:  RTS  ; 001CA6 001D7D
; 1 refs via 001E92
0x001E9E --c- 00:DE8E:  LDA ram_00A0  ; $00A0
0x001EA0 --c- 00:DE90:  BEQ $DE9B  ; 001EAB
0x001EA2 -zc- 00:DE92:  TXA  ; 
0x001EA3 --c- 00:DE93:  AND #$01  ; 
0x001EA5 --c- 00:DE95:  BEQ $DEA0  ; 001EB0
0x001EA7 -zc- 00:DE97:  LDA ram_00A1  ; $00A1
0x001EA9 --c- 00:DE99:  BEQ $DEA0  ; 001EB0
; 1 refs via 001EA0
0x001EAB --c- 00:DE9B:  LDA #$C0  ; 
0x001EAD Nzc- 00:DE9D:  JMP $DEA2  ; 001EB2
; 2 refs via 001EA5 001EA9
0x001EB0 -Zc- 00:DEA0:  LDA #$D0  ; 
; 2 refs via 001E8C 001EAD
0x001EB2 Nzc- 00:DEA2:  JSR $E420  ; 002430
; 1 refs via 00243A
0x001EB5 ---- 00:DEA5:  RTS  ; 001CA6 001D7D
; 5 refs via 000109 000219 000254 00043F 000A05
0x001EB6 ---- 00:DEA6:  LDA #$00  ; 
0x001EB8 nZ-- 00:DEA8:  STA ram_005A  ; $005A
; 1 refs via 001EC5
0x001EBA ---- 00:DEAA:  LDX ram_005A  ; $005A
0x001EBC ---- 00:DEAC:  JSR $DEB8  ; 001EC8
; 8 refs via 001C00 001EF1 001F42 001F55 001FA8 001FF7 002012 00203D
0x001EBF ---- 00:DEAF:  INC ram_005A  ; $005A
0x001EC1 ---- 00:DEB1:  LDA ram_005A  ; $005A
0x001EC3 ---- 00:DEB3:  CMP #$08  ; 
0x001EC5 ---- 00:DEB5:  BNE $DEAA  ; 001EBA
0x001EC7 -Z-- 00:DEB7:  RTS  ; 00010C 00021C 000257 000442 000A08
; 1 refs via 001EBC
0x001EC8 ---- 00:DEB8:  LDA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001ECA ---- 00:DEBA:  LSR  ; 
0x001ECB ---- 00:DEBB:  LSR  ; 
0x001ECC ---- 00:DEBC:  LSR  ; 
0x001ECD ---- 00:DEBD:  AND #$FE  ; 
0x001ECF ---- 00:DEBF:  TAY  ; 
0x001ED0 ---- 00:DEC0:  LDA $E4B8,Y  ; 0024C8 0024CA 0024CC 0024CE 0024D0 0024D2 0024D4 0024D6 0024D8 0024DA 0024DC 0024DE 0024E0 0024E2 0024E4 0024E6
0x001ED3 ---- 00:DEC3:  STA ram_0011  ; $0011
0x001ED5 ---- 00:DEC5:  LDA $E4B9,Y  ; 0024C9 0024CB 0024CD 0024CF 0024D1 0024D3 0024D5 0024D7 0024D9 0024DB 0024DD 0024DF 0024E1 0024E3 0024E5 0024E7
0x001ED8 ---- 00:DEC8:  STA ram_0012  ; $0012
0x001EDA ---- 00:DECA:  JMP (ram_0011)  ; 001C00 001EDD 001F0D 001F43 001F56 001FC6 00201B
; 1 refs via 001EDA
0x001EDD ---- 00:DECD:  LDA #$00  ; 
0x001EDF nZ-- 00:DECF:  STA ram_006E  ; $006E
0x001EE1 nZ-- 00:DED1:  LDA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001EE3 ---- 00:DED3:  PHA  ; 
0x001EE4 ---- 00:DED4:  LDY ram_0098,X  ; $0098 $0099 $009A $009B $009C $009D $009E $009F
0x001EE6 ---- 00:DED6:  LDA ram_0090,X  ; $0090 $0091 $0092 $0093 $0094 $0095 $0096 $0097
0x001EE8 ---- 00:DED8:  TAX  ; 
0x001EE9 ---- 00:DED9:  PLA  ; 
0x001EEA ---- 00:DEDA:  JSR $DEE2  ; 001EF2
; 1 refs via 001F0C
0x001EED ---- 00:DEDD:  LDA #$20  ; 
0x001EEF nz-- 00:DEDF:  STA ram_006E  ; $006E
0x001EF1 nz-- 00:DEE1:  RTS  ; 001EBF
; 2 refs via 001EEA 00212E
0x001EF2 ---- 00:DEE2:  LSR  ; 
0x001EF3 ---- 00:DEE3:  LSR  ; 
0x001EF4 ---- 00:DEE4:  LSR  ; 
0x001EF5 ---- 00:DEE5:  LSR  ; 
0x001EF6 ---- 00:DEE6:  SEC  ; 
0x001EF7 --C- 00:DEE7:  SBC #$07  ; 
0x001EF9 ---- 00:DEE9:  EOR #$FF  ; 
0x001EFB ---- 00:DEEB:  CLC  ; 
0x001EFC --c- 00:DEEC:  ADC #$01  ; 
0x001EFE ---- 00:DEEE:  ASL  ; 
0x001EFF ---- 00:DEEF:  ASL  ; 
; 2 refs via 001F3B 001F4E
0x001F00 ---- 00:DEF0:  CLC  ; 
0x001F01 --c- 00:DEF1:  ADC #$F1  ; 
0x001F03 ---- 00:DEF3:  STA ram_0053  ; $0053
0x001F05 ---- 00:DEF5:  LDA #$03  ; 
0x001F07 nz-- 00:DEF7:  STA ram_0004  ; $0004
0x001F09 nz-- 00:DEF9:  JSR $DA7B  ; 001A8B
; 1 refs via 001AA2
0x001F0C ---- 00:DEFC:  RTS  ; 001EED 001F3E 001F51 002131
; 1 refs via 001EDA
0x001F0D ---- 00:DEFD:  LDA #$00  ; 
0x001F0F nZ-- 00:DEFF:  STA ram_006E  ; $006E
0x001F11 nZ-- 00:DF01:  LDA ram_00A8,X  ; $00A8 $00A9 $00AA $00AB $00AC $00AD $00AE $00AF
0x001F13 ---- 00:DF03:  BEQ $DF23  ; 001F33
0x001F15 -z-- 00:DF05:  LDA ram_00A8,X  ; $00AA $00AB $00AC $00AD $00AE $00AF
0x001F17 ---- 00:DF07:  LSR  ; 
0x001F18 ---- 00:DF08:  LSR  ; 
0x001F19 ---- 00:DF09:  LSR  ; 
0x001F1A ---- 00:DF0A:  AND #$FC  ; 
0x001F1C ---- 00:DF0C:  SEC  ; 
0x001F1D --C- 00:DF0D:  SBC #$10  ; 
0x001F1F ---- 00:DF0F:  CLC  ; 
0x001F20 --c- 00:DF10:  ADC #$B9  ; 
0x001F22 ---- 00:DF12:  STA ram_0053  ; $0053
0x001F24 ---- 00:DF14:  LDA #$03  ; 
0x001F26 nz-- 00:DF16:  STA ram_0004  ; $0004
0x001F28 nz-- 00:DF18:  LDY ram_0098,X  ; $009A $009B $009C $009D $009E $009F
0x001F2A ---- 00:DF1A:  LDA ram_0090,X  ; $0092 $0093 $0094 $0095 $0096 $0097
0x001F2C ---- 00:DF1C:  TAX  ; 
0x001F2D ---- 00:DF1D:  JSR $DA7B  ; 001A8B
; 1 refs via 001AA2
0x001F30 ---- 00:DF20:  JMP $DF2E  ; 001F3E
; 1 refs via 001F13
0x001F33 -Z-- 00:DF23:  LDA ram_0098,X  ; $0098 $0099 $009A $009B $009C $009D $009E $009F
0x001F35 ---- 00:DF25:  TAY  ; 
0x001F36 ---- 00:DF26:  LDA ram_0090,X  ; $0090 $0091 $0092 $0093 $0094 $0095 $0096 $0097
0x001F38 ---- 00:DF28:  TAX  ; 
0x001F39 ---- 00:DF29:  LDA #$00  ; 
0x001F3B nZ-- 00:DF2B:  JSR $DEF0  ; 001F00
; 2 refs via 001F0C 001F30
0x001F3E ---- 00:DF2E:  LDA #$20  ; 
0x001F40 nz-- 00:DF30:  STA ram_006E  ; $006E
0x001F42 nz-- 00:DF32:  RTS  ; 001EBF
; 1 refs via 001EDA
0x001F43 ---- 00:DF33:  LDA #$00  ; 
0x001F45 nZ-- 00:DF35:  STA ram_006E  ; $006E
0x001F47 nZ-- 00:DF37:  LDY ram_0098,X  ; $0098 $0099 $009A $009B $009C $009D $009E $009F
0x001F49 ---- 00:DF39:  LDA ram_0090,X  ; $0090 $0091 $0092 $0093 $0094 $0095 $0096 $0097
0x001F4B ---- 00:DF3B:  TAX  ; 
0x001F4C ---- 00:DF3C:  LDA #$08  ; 
0x001F4E nz-- 00:DF3E:  JSR $DEF0  ; 001F00
; 1 refs via 001F0C
0x001F51 ---- 00:DF41:  LDA #$20  ; 
0x001F53 nz-- 00:DF43:  STA ram_006E  ; $006E
0x001F55 nz-- 00:DF45:  RTS  ; 001EBF
; 1 refs via 001EDA
0x001F56 ---- 00:DF46:  LDA #$03  ; 
0x001F58 nz-- 00:DF48:  STA ram_0004  ; $0004
0x001F5A nz-- 00:DF4A:  LDA #$00  ; 
0x001F5C nZ-- 00:DF4C:  STA ram_006E  ; $006E
0x001F5E nZ-- 00:DF4E:  JSR $DF99  ; 001FA9
; 1 refs via 001FC5
0x001F61 ---- 00:DF51:  TXA  ; 
0x001F62 ---- 00:DF52:  SEC  ; 
0x001F63 --C- 00:DF53:  SBC #$08  ; 
0x001F65 ---- 00:DF55:  TAX  ; 
0x001F66 ---- 00:DF56:  TYA  ; 
0x001F67 ---- 00:DF57:  SEC  ; 
0x001F68 --C- 00:DF58:  SBC #$08  ; 
0x001F6A ---- 00:DF5A:  TAY  ; 
0x001F6B ---- 00:DF5B:  JSR $DA7B  ; 001A8B
; 1 refs via 001AA2
0x001F6E ---- 00:DF5E:  LDA #$01  ; 
0x001F70 nz-- 00:DF60:  JSR $DF99  ; 001FA9
; 1 refs via 001FC5
0x001F73 ---- 00:DF63:  TXA  ; 
0x001F74 ---- 00:DF64:  CLC  ; 
0x001F75 --c- 00:DF65:  ADC #$08  ; 
0x001F77 ---- 00:DF67:  TAX  ; 
0x001F78 ---- 00:DF68:  TYA  ; 
0x001F79 ---- 00:DF69:  SEC  ; 
0x001F7A --C- 00:DF6A:  SBC #$08  ; 
0x001F7C ---- 00:DF6C:  TAY  ; 
0x001F7D ---- 00:DF6D:  JSR $DA7B  ; 001A8B
; 1 refs via 001AA2
0x001F80 ---- 00:DF70:  LDA #$02  ; 
0x001F82 nz-- 00:DF72:  JSR $DF99  ; 001FA9
; 1 refs via 001FC5
0x001F85 ---- 00:DF75:  TXA  ; 
0x001F86 ---- 00:DF76:  SEC  ; 
0x001F87 --C- 00:DF77:  SBC #$08  ; 
0x001F89 ---- 00:DF79:  TAX  ; 
0x001F8A ---- 00:DF7A:  TYA  ; 
0x001F8B ---- 00:DF7B:  CLC  ; 
0x001F8C --c- 00:DF7C:  ADC #$08  ; 
0x001F8E ---- 00:DF7E:  TAY  ; 
0x001F8F ---- 00:DF7F:  JSR $DA7B  ; 001A8B
; 1 refs via 001AA2
0x001F92 ---- 00:DF82:  LDA #$03  ; 
0x001F94 nz-- 00:DF84:  JSR $DF99  ; 001FA9
; 1 refs via 001FC5
0x001F97 ---- 00:DF87:  TXA  ; 
0x001F98 ---- 00:DF88:  CLC  ; 
0x001F99 --c- 00:DF89:  ADC #$08  ; 
0x001F9B ---- 00:DF8B:  TAX  ; 
0x001F9C ---- 00:DF8C:  TYA  ; 
0x001F9D ---- 00:DF8D:  CLC  ; 
0x001F9E --c- 00:DF8E:  ADC #$08  ; 
0x001FA0 ---- 00:DF90:  TAY  ; 
0x001FA1 ---- 00:DF91:  JSR $DA7B  ; 001A8B
; 1 refs via 001AA2
0x001FA4 ---- 00:DF94:  LDA #$20  ; 
0x001FA6 nz-- 00:DF96:  STA ram_006E  ; $006E
0x001FA8 nz-- 00:DF98:  RTS  ; 001EBF
; 4 refs via 001F5E 001F70 001F82 001F94
0x001FA9 n--- 00:DF99:  LDX ram_005A  ; $005A
0x001FAB ---- 00:DF9B:  ASL  ; 
0x001FAC ---- 00:DF9C:  ASL  ; 
0x001FAD ---- 00:DF9D:  CLC  ; 
0x001FAE --c- 00:DF9E:  ADC #$D1  ; 
0x001FB0 ---- 00:DFA0:  STA ram_0000  ; $0000
0x001FB2 ---- 00:DFA2:  LDA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001FB4 ---- 00:DFA4:  AND #$F0  ; 
0x001FB6 ---- 00:DFA6:  SEC  ; 
0x001FB7 --C- 00:DFA7:  SBC #$30  ; 
0x001FB9 ---- 00:DFA9:  EOR #$10  ; 
0x001FBB ---- 00:DFAB:  CLC  ; 
0x001FBC --c- 00:DFAC:  ADC ram_0000  ; $0000
0x001FBE ---- 00:DFAE:  STA ram_0053  ; $0053
0x001FC0 ---- 00:DFB0:  LDY ram_0098,X  ; $0098 $0099 $009A $009B $009C $009D $009E $009F
0x001FC2 ---- 00:DFB2:  LDA ram_0090,X  ; $0090 $0091 $0092 $0093 $0094 $0095 $0096 $0097
0x001FC4 ---- 00:DFB4:  TAX  ; 
0x001FC5 ---- 00:DFB5:  RTS  ; 001F61 001F73 001F85 001F97
; 1 refs via 001EDA
0x001FC6 ---- 00:DFB6:  CPX #$02  ; 
0x001FC8 ---- 00:DFB8:  BCC $DFDD  ; 001FED
0x001FCA --C- 00:DFBA:  LDA ram_00A8,X  ; $00AA $00AB $00AC $00AD $00AE $00AF
0x001FCC --C- 00:DFBC:  AND #$04  ; 
0x001FCE --C- 00:DFBE:  BEQ $DFCD  ; 001FDD
0x001FD0 -zC- 00:DFC0:  LDA ram_000B  ; $000B
0x001FD2 --C- 00:DFC2:  LSR  ; 
0x001FD3 ---- 00:DFC3:  LSR  ; 
0x001FD4 ---- 00:DFC4:  LSR  ; 
0x001FD5 ---- 00:DFC5:  AND #$01  ; 
0x001FD7 ---- 00:DFC7:  CLC  ; 
0x001FD8 --c- 00:DFC8:  ADC #$02  ; 
0x001FDA ---- 00:DFCA:  JMP $DFE9  ; 001FF9
; 1 refs via 001FCE
0x001FDD -ZC- 00:DFCD:  LDA ram_000B  ; $000B
0x001FDF --C- 00:DFCF:  ASL  ; 
0x001FE0 ---- 00:DFD0:  ASL  ; 
0x001FE1 ---- 00:DFD1:  CLC  ; 
0x001FE2 --c- 00:DFD2:  ADC ram_00A8,X  ; $00AA $00AB $00AC $00AD $00AE $00AF
0x001FE4 ---- 00:DFD4:  AND #$07  ; 
0x001FE6 ---- 00:DFD6:  TAY  ; 
0x001FE7 ---- 00:DFD7:  LDA $E003,Y  ; 002013 002014 002015 002016 002017 002018 002019 00201A
0x001FEA ---- 00:DFDA:  JMP $DFE9  ; 001FF9
; 1 refs via 001FC8
0x001FED --c- 00:DFDD:  LDA ram_006F,X  ; $006F $0070
0x001FEF --c- 00:DFDF:  BEQ $DFE8  ; 001FF8
0x001FF1 -zc- 00:DFE1:  LDA ram_000B  ; $000B
0x001FF3 --c- 00:DFE3:  AND #$08  ; 
0x001FF5 --c- 00:DFE5:  BEQ $DFE8  ; 001FF8
0x001FF7 -zc- 00:DFE7:  RTS  ; 001EBF
; 2 refs via 001FEF 001FF5
0x001FF8 -Zc- 00:DFE8:  TXA  ; 
; 2 refs via 001FDA 001FEA
0x001FF9 ---- 00:DFE9:  STA ram_0004  ; $0004
0x001FFB ---- 00:DFEB:  LDA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x001FFD ---- 00:DFED:  AND #$03  ; 
0x001FFF ---- 00:DFEF:  PHA  ; 
0x002000 ---- 00:DFF0:  LDA ram_00A8,X  ; $00A8 $00A9 $00AA $00AB $00AC $00AD $00AE $00AF
0x002002 ---- 00:DFF2:  AND #$F0  ; 
0x002004 ---- 00:DFF4:  CLC  ; 
0x002005 --c- 00:DFF5:  ADC ram_00B0,X  ; $00B0 $00B1 $00B2 $00B3 $00B4 $00B5 $00B6 $00B7
0x002007 ---- 00:DFF7:  STA ram_0053  ; $0053
0x002009 ---- 00:DFF9:  LDY ram_0098,X  ; $0098 $0099 $009A $009B $009C $009D $009E $009F
0x00200B ---- 00:DFFB:  LDA ram_0090,X  ; $0090 $0091 $0092 $0093 $0094 $0095 $0096 $0097
0x00200D ---- 00:DFFD:  TAX  ; 
0x00200E ---- 00:DFFE:  PLA  ; 
0x00200F ---- 00:DFFF:  JSR $DA73  ; 001A83
; 1 refs via 001AA2
0x002012 ---- 01:E002:  RTS  ; 001EBF
0x002013 ---- 01:E003:  .byte $02   ; 001FE7
0x002014 ---- 01:E004:  .byte $00   ; 001FE7
0x002015 ---- 01:E005:  .byte $00   ; 001FE7
0x002016 ---- 01:E006:  .byte $01   ; 001FE7
0x002017 ---- 01:E007:  .byte $02   ; 001FE7
0x002018 ---- 01:E008:  .byte $01   ; 001FE7
0x002019 ---- 01:E009:  .byte $02   ; 001FE7
0x00201A ---- 01:E00A:  .byte $02   ; 001FE7
; 1 refs via 001EDA
0x00201B ---- 01:E00B:  LDA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x00201D ---- 01:E00D:  AND #$0F  ; 
0x00201F ---- 01:E00F:  SEC  ; 
0x002020 --C- 01:E010:  SBC #$07  ; 
0x002022 ---- 01:E012:  BPL $E019  ; 002029
0x002024 N--- 01:E014:  EOR #$FF  ; 
0x002026 ---- 01:E016:  CLC  ; 
0x002027 --c- 01:E017:  ADC #$01  ; 
; 1 refs via 002022
0x002029 ---- 01:E019:  ASL  ; 
0x00202A ---- 01:E01A:  AND #$FC  ; 
0x00202C ---- 01:E01C:  CLC  ; 
0x00202D --c- 01:E01D:  ADC #$A1  ; 
0x00202F ---- 01:E01F:  STA ram_0053  ; $0053
0x002031 ---- 01:E021:  LDA #$03  ; 
0x002033 nz-- 01:E023:  STA ram_0004  ; $0004
0x002035 nz-- 01:E025:  LDY ram_0098,X  ; $0098 $0099 $009A $009B $009C $009D $009E $009F
0x002037 ---- 01:E027:  LDA ram_0090,X  ; $0090 $0091 $0092 $0093 $0094 $0095 $0096 $0097
0x002039 ---- 01:E029:  TAX  ; 
0x00203A ---- 01:E02A:  JSR $DA7B  ; 001A8B
; 1 refs via 001AA2
0x00203D ---- 01:E02D:  RTS  ; 001EBF
; 1 refs via 000302
0x00203E N--- 01:E02E:  LDA #$09  ; 
0x002040 nz-- 01:E030:  STA ram_005A  ; $005A
; 1 refs via 002049
0x002042 n--- 01:E032:  LDX ram_005A  ; $005A
0x002044 ---- 01:E034:  JSR $E03C  ; 00204C
; 3 refs via 001C00 002072 00209B
0x002047 ---- 01:E037:  DEC ram_005A  ; $005A
0x002049 ---- 01:E039:  BPL $E032  ; 002042
0x00204B N--- 01:E03B:  RTS  ; 000305
; 1 refs via 002044
0x00204C ---- 01:E03C:  LDA ram_00CC,X  ; $00CC $00CD $00CE $00CF $00D0 $00D1 $00D2 $00D3 $00D4 $00D5
0x00204E ---- 01:E03E:  LSR  ; 
0x00204F ---- 01:E03F:  LSR  ; 
0x002050 ---- 01:E040:  LSR  ; 
0x002051 ---- 01:E041:  AND #$FE  ; 
0x002053 ---- 01:E043:  TAY  ; 
0x002054 ---- 01:E044:  LDA $E4D8,Y  ; 0024E8 0024EA 0024EC 0024EE 0024F0
0x002057 ---- 01:E047:  STA ram_0011  ; $0011
0x002059 ---- 01:E049:  LDA $E4D9,Y  ; 0024E9 0024EB 0024ED 0024EF 0024F1
0x00205C ---- 01:E04C:  STA ram_0012  ; $0012
0x00205E ---- 01:E04E:  JMP (ram_0011)  ; 001C00 002061 002086
; 1 refs via 00205E
0x002061 ---- 01:E051:  LDA ram_00CC,X  ; $00CC $00CD $00CE $00CF $00D0 $00D1 $00D2 $00D3 $00D4 $00D5
0x002063 ---- 01:E053:  AND #$03  ; 
0x002065 ---- 01:E055:  TAY  ; 
0x002066 ---- 01:E056:  JSR $E063  ; 002073
; 1 refs via 002085
0x002069 ---- 01:E059:  LDA ram_00D6,X  ; $00D6 $00D7 $00D8 $00D9 $00DA $00DB $00DC $00DD $00DE $00DF
0x00206B ---- 01:E05B:  AND #$01  ; 
0x00206D ---- 01:E05D:  BEQ $E062  ; 002072
0x00206F -z-- 01:E05F:  JSR $E063  ; 002073
; 2 refs via 00206D 002085
0x002072 ---- 01:E062:  RTS  ; 002047
; 2 refs via 002066 00206F
0x002073 ---- 01:E063:  LDA $E46C,Y  ; 00247C 00247D 00247E 00247F
0x002076 ---- 01:E066:  ASL  ; 
0x002077 ---- 01:E067:  CLC  ; 
0x002078 --c- 01:E068:  ADC ram_00B8,X  ; $00B8 $00B9 $00BA $00BB $00BC $00BD $00BE $00BF $00C0 $00C1
0x00207A ---- 01:E06A:  STA ram_00B8,X  ; $00B8 $00B9 $00BA $00BB $00BC $00BD $00BE $00BF $00C0 $00C1
0x00207C ---- 01:E06C:  LDA $E470,Y  ; 002480 002481 002482 002483
0x00207F ---- 01:E06F:  ASL  ; 
0x002080 ---- 01:E070:  CLC  ; 
0x002081 --c- 01:E071:  ADC ram_00C2,X  ; $00C2 $00C3 $00C4 $00C5 $00C6 $00C7 $00C8 $00C9 $00CA $00CB
0x002083 ---- 01:E073:  STA ram_00C2,X  ; $00C2 $00C3 $00C4 $00C5 $00C6 $00C7 $00C8 $00C9 $00CA $00CB
0x002085 ---- 01:E075:  RTS  ; 002069 002072
; 1 refs via 00205E
0x002086 ---- 01:E076:  DEC ram_00CC,X  ; $00CC $00CD $00CE $00CF $00D0 $00D1 $00D2 $00D3 $00D4 $00D5
0x002088 ---- 01:E078:  LDA ram_00CC,X  ; $00CC $00CD $00CE $00CF $00D0 $00D1 $00D2 $00D3 $00D4 $00D5
0x00208A ---- 01:E07A:  AND #$0F  ; 
0x00208C ---- 01:E07C:  BNE $E08B  ; 00209B
0x00208E -Z-- 01:E07E:  LDA ram_00CC,X  ; $00CC $00CD $00CE $00CF $00D0 $00D1 $00D2 $00D3 $00D4 $00D5
0x002090 ---- 01:E080:  AND #$F0  ; 
0x002092 ---- 01:E082:  SEC  ; 
0x002093 --C- 01:E083:  SBC #$10  ; 
0x002095 ---- 01:E085:  BEQ $E089  ; 002099
0x002097 -z-- 01:E087:  ORA #$03  ; 
; 1 refs via 002095
0x002099 ---- 01:E089:  STA ram_00CC,X  ; $00CC $00CD $00CE $00CF $00D0 $00D1 $00D2 $00D3 $00D4 $00D5
; 1 refs via 00208C
0x00209B ---- 01:E08B:  RTS  ; 002047
; 2 refs via 00216A 002188
0x00209C ---- 01:E08C:  LDA ram_00CC,X  ; $00CC $00CD $00CE $00CF $00D0 $00D1 $00D2 $00D3
0x00209E ---- 01:E08E:  BNE $E0D7  ; 0020E7
0x0020A0 -Z-- 01:E090:  CPX #$02  ; 
0x0020A2 ---- 01:E092:  BCS $E099  ; 0020A9
0x0020A4 --c- 01:E094:  LDA #$01  ; 
0x0020A6 nzc- 01:E096:  STA ram_030F  ; $030F
; 1 refs via 0020A2
0x0020A9 ---- 01:E099:  LDA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x0020AB ---- 01:E09B:  AND #$03  ; 
0x0020AD ---- 01:E09D:  TAY  ; 
0x0020AE ---- 01:E09E:  ORA #$40  ; 
0x0020B0 -z-- 01:E0A0:  STA ram_00CC,X  ; $00CC $00CD $00CE $00CF $00D0 $00D1 $00D2 $00D3
0x0020B2 -z-- 01:E0A2:  LDA $E46C,Y  ; 00247C 00247D 00247E 00247F
0x0020B5 ---- 01:E0A5:  ASL  ; 
0x0020B6 ---- 01:E0A6:  ASL  ; 
0x0020B7 ---- 01:E0A7:  ASL  ; 
0x0020B8 ---- 01:E0A8:  CLC  ; 
0x0020B9 --c- 01:E0A9:  ADC ram_0090,X  ; $0090 $0091 $0092 $0093 $0094 $0095 $0096 $0097
0x0020BB ---- 01:E0AB:  STA ram_00B8,X  ; $00B8 $00B9 $00BA $00BB $00BC $00BD $00BE $00BF
0x0020BD ---- 01:E0AD:  LDA $E470,Y  ; 002480 002481 002482 002483
0x0020C0 ---- 01:E0B0:  ASL  ; 
0x0020C1 ---- 01:E0B1:  ASL  ; 
0x0020C2 ---- 01:E0B2:  ASL  ; 
0x0020C3 ---- 01:E0B3:  CLC  ; 
0x0020C4 --c- 01:E0B4:  ADC ram_0098,X  ; $0098 $0099 $009A $009B $009C $009D $009E $009F
0x0020C6 ---- 01:E0B6:  STA ram_00C2,X  ; $00C2 $00C3 $00C4 $00C5 $00C6 $00C7 $00C8 $00C9
0x0020C8 ---- 01:E0B8:  LDA #$00  ; 
0x0020CA nZ-- 01:E0BA:  STA ram_00D6,X  ; $00D6 $00D7 $00D8 $00D9 $00DA $00DB $00DC $00DD
0x0020CC nZ-- 01:E0BC:  LDA ram_00A8,X  ; $00A8 $00A9 $00AA $00AB $00AC $00AD $00AE $00AF
0x0020CE ---- 01:E0BE:  AND #$F0  ; 
0x0020D0 ---- 01:E0C0:  BEQ $E0D7  ; 0020E7
0x0020D2 -z-- 01:E0C2:  CMP #$C0  ; 
0x0020D4 ---- 01:E0C4:  BEQ $E0CE  ; 0020DE
0x0020D6 -z-- 01:E0C6:  CMP #$60  ; 
0x0020D8 ---- 01:E0C8:  BEQ $E0D3  ; 0020E3
0x0020DA -z-- 01:E0CA:  AND #$80  ; 
0x0020DC ---- 01:E0CC:  BNE $E0D7  ; 0020E7
; 1 refs via 0020D4
0x0020DE -Z-- 01:E0CE:  LDA #$01  ; 
0x0020E0 nz-- 01:E0D0:  STA ram_00D6,X  ; $00D6 $00D7 $00D8 $00D9 $00DA $00DB $00DC $00DD
0x0020E2 nz-- 01:E0D2:  RTS  ; 00216D 00218B
; 1 refs via 0020D8
0x0020E3 -Z-- 01:E0D3:  LDA #$03  ; 
0x0020E5 nz-- 01:E0D5:  STA ram_00D6,X  ; $00D6 $00D7
; 3 refs via 00209E 0020D0 0020DC
0x0020E7 ---- 01:E0D7:  RTS  ; 00216D 00218B
; 3 refs via 000216 000257 000442
0x0020E8 ---- 01:E0D8:  LDA #$09  ; 
0x0020EA nz-- 01:E0DA:  STA ram_005A  ; $005A
; 1 refs via 0020F3
0x0020EC n--- 01:E0DC:  LDX ram_005A  ; $005A
0x0020EE ---- 01:E0DE:  JSR $E0E6  ; 0020F6
; 3 refs via 001C00 002121 002131
0x0020F1 ---- 01:E0E1:  DEC ram_005A  ; $005A
0x0020F3 ---- 01:E0E3:  BPL $E0DC  ; 0020EC
0x0020F5 N--- 01:E0E5:  RTS  ; 000219 00025A 000445
; 1 refs via 0020EE
0x0020F6 ---- 01:E0E6:  LDA ram_00CC,X  ; $00CC $00CD $00CE $00CF $00D0 $00D1 $00D2 $00D3 $00D4 $00D5
0x0020F8 ---- 01:E0E8:  LSR  ; 
0x0020F9 ---- 01:E0E9:  LSR  ; 
0x0020FA ---- 01:E0EA:  LSR  ; 
0x0020FB ---- 01:E0EB:  AND #$FE  ; 
0x0020FD ---- 01:E0ED:  TAY  ; 
0x0020FE ---- 01:E0EE:  LDA $E4E2,Y  ; 0024F2 0024F4 0024F6 0024F8 0024FA
0x002101 ---- 01:E0F1:  STA ram_0011  ; $0011
0x002103 ---- 01:E0F3:  LDA $E4E3,Y  ; 0024F3 0024F5 0024F7 0024F9 0024FB
0x002106 ---- 01:E0F6:  STA ram_0012  ; $0012
0x002108 ---- 01:E0F8:  JMP (ram_0011)  ; 001C00 00210B 002122
; 1 refs via 002108
0x00210B ---- 01:E0FB:  LDA ram_00CC,X  ; $00CC $00CD $00CE $00CF $00D0 $00D1 $00D2 $00D3 $00D4 $00D5
0x00210D ---- 01:E0FD:  AND #$03  ; 
0x00210F ---- 01:E0FF:  PHA  ; 
0x002110 ---- 01:E100:  LDY ram_00C2,X  ; $00C2 $00C3 $00C4 $00C5 $00C6 $00C7 $00C8 $00C9 $00CA $00CB
0x002112 ---- 01:E102:  LDA ram_00B8,X  ; $00B8 $00B9 $00BA $00BB $00BC $00BD $00BE $00BF $00C0 $00C1
0x002114 ---- 01:E104:  TAX  ; 
0x002115 ---- 01:E105:  LDA #$02  ; 
0x002117 nz-- 01:E107:  STA ram_0004  ; $0004
0x002119 nz-- 01:E109:  LDA #$B1  ; 
0x00211B Nz-- 01:E10B:  STA ram_0053  ; $0053
0x00211D Nz-- 01:E10D:  PLA  ; 
0x00211E ---- 01:E10E:  JSR $DA64  ; 001A74
; 1 refs via 001A82
0x002121 ---- 01:E111:  RTS  ; 0020F1
; 1 refs via 002108
0x002122 ---- 01:E112:  LDA ram_00CC,X  ; $00CC $00CD $00CE $00CF $00D0 $00D1 $00D2 $00D3 $00D4 $00D5
0x002124 ---- 01:E114:  PHA  ; 
0x002125 ---- 01:E115:  LDY ram_00C2,X  ; $00C2 $00C3 $00C4 $00C5 $00C6 $00C7 $00C8 $00C9 $00CA $00CB
0x002127 ---- 01:E117:  LDA ram_00B8,X  ; $00B8 $00B9 $00BA $00BB $00BC $00BD $00BE $00BF $00C0 $00C1
0x002129 ---- 01:E119:  TAX  ; 
0x00212A ---- 01:E11A:  PLA  ; 
0x00212B ---- 01:E11B:  CLC  ; 
0x00212C --c- 01:E11C:  ADC #$40  ; 
0x00212E ---- 01:E11E:  JSR $DEE2  ; 001EF2
; 1 refs via 001F0C
0x002131 ---- 01:E121:  RTS  ; 0020F1
; 1 refs via 00030B
0x002132 N--- 01:E122:  LDA #$01  ; 
0x002134 nz-- 01:E124:  STA ram_005A  ; $005A
; 1 refs via 00216F
0x002136 n--- 01:E126:  LDX ram_005A  ; $005A
0x002138 ---- 01:E128:  LDA ram_00A0,X  ; $00A0 $00A1
0x00213A ---- 01:E12A:  BPL $E15D  ; 00216D
0x00213C N--- 01:E12C:  CMP #$E0  ; 
0x00213E ---- 01:E12E:  BCS $E15D  ; 00216D
0x002140 --c- 01:E130:  LDA ram_0008,X  ; $0008 $0009
0x002142 --c- 01:E132:  AND #$03  ; 
0x002144 --c- 01:E134:  BEQ $E15D  ; 00216D
0x002146 -zc- 01:E136:  LDA ram_00A8,X  ; $00A8 $00A9
0x002148 --c- 01:E138:  AND #$C0  ; 
0x00214A --c- 01:E13A:  CMP #$40  ; 
0x00214C ---- 01:E13C:  BNE $E15A  ; 00216A
0x00214E -Z-- 01:E13E:  LDA ram_00CC,X  ; $00CC $00CD
0x002150 ---- 01:E140:  BEQ $E15A  ; 00216A
0x002152 -z-- 01:E142:  LDA ram_00D4,X  ; $00D4 $00D5
0x002154 ---- 01:E144:  BNE $E15D  ; 00216D
0x002156 -Z-- 01:E146:  LDA ram_00CC,X  ; $00CC $00CD
0x002158 ---- 01:E148:  STA ram_00D4,X  ; $00D4 $00D5
0x00215A ---- 01:E14A:  LDA ram_00B8,X  ; $00B8 $00B9
0x00215C ---- 01:E14C:  STA ram_00C0,X  ; $00C0 $00C1
0x00215E ---- 01:E14E:  LDA ram_00C2,X  ; $00C2 $00C3
0x002160 ---- 01:E150:  STA ram_00CA,X  ; $00CA $00CB
0x002162 ---- 01:E152:  LDA ram_00D6,X  ; $00D6 $00D7
0x002164 ---- 01:E154:  STA ram_00DE,X  ; $00DE $00DF
0x002166 ---- 01:E156:  LDA #$00  ; 
0x002168 nZ-- 01:E158:  STA ram_00CC,X  ; $00CC $00CD
; 2 refs via 00214C 002150
0x00216A ---- 01:E15A:  JSR $E08C  ; 00209C
; 6 refs via 0020E2 0020E7 00213A 00213E 002144 002154
0x00216D ---- 01:E15D:  DEC ram_005A  ; $005A
0x00216F ---- 01:E15F:  BPL $E126  ; 002136
0x002171 N--- 01:E161:  RTS  ; 00030E
; 1 refs via 00030E
0x002172 N--- 01:E162:  LDA ram_0100  ; $0100
0x002175 ---- 01:E165:  BNE $E180  ; 002190
0x002177 -Z-- 01:E167:  LDX #$07  ; 
; 1 refs via 00218E
0x002179 -z-- 01:E169:  LDA ram_00A0,X  ; $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x00217B ---- 01:E16B:  BPL $E17B  ; 00218B
0x00217D N--- 01:E16D:  CMP #$E0  ; 
0x00217F ---- 01:E16F:  BCS $E17B  ; 00218B
0x002181 --c- 01:E171:  JSR $D44D  ; 00145D
; 1 refs via 001476
0x002184 ---- 01:E174:  AND #$1F  ; 
0x002186 ---- 01:E176:  BNE $E17B  ; 00218B
0x002188 -Z-- 01:E178:  JSR $E08C  ; 00209C
; 5 refs via 0020E2 0020E7 00217B 00217F 002186
0x00218B ---- 01:E17B:  DEX  ; 
0x00218C ---- 01:E17C:  CPX #$01  ; 
0x00218E ---- 01:E17E:  BNE $E169  ; 002179
; 1 refs via 002175
0x002190 ---- 01:E180:  RTS  ; 000311
; 1 refs via 0002F6
0x002191 ---- 01:E181:  LDA #$07  ; 
0x002193 nz-- 01:E183:  STA ram_005A  ; $005A
; 1 refs via 002200
0x002195 n--- 01:E185:  LDX ram_005A  ; $005A
0x002197 ---- 01:E187:  LDA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x002199 ---- 01:E189:  BPL $E1EE  ; 0021FE
0x00219B N--- 01:E18B:  CMP #$E0  ; 
0x00219D ---- 01:E18D:  BCS $E1EE  ; 0021FE
0x00219F --c- 01:E18F:  LDA ram_0098,X  ; $0098 $0099 $009A $009B $009C $009D $009E $009F
0x0021A1 --c- 01:E191:  SEC  ; 
0x0021A2 --C- 01:E192:  SBC #$08  ; 
0x0021A4 ---- 01:E194:  TAY  ; 
0x0021A5 ---- 01:E195:  LDA ram_0090,X  ; $0090 $0091 $0092 $0093 $0094 $0095 $0096 $0097
0x0021A7 ---- 01:E197:  SEC  ; 
0x0021A8 --C- 01:E198:  SBC #$08  ; 
0x0021AA ---- 01:E19A:  TAX  ; 
0x0021AB ---- 01:E19B:  JSR $D706  ; 001716
; 1 refs via 001722
0x0021AE nZ-- 01:E19E:  LDX ram_005A  ; $005A
0x0021B0 ---- 01:E1A0:  LDA ram_0011  ; $0011
0x0021B2 ---- 01:E1A2:  STA ram_00E0,X  ; $00E0 $00E1 $00E2 $00E3 $00E4 $00E5 $00E6 $00E7
0x0021B4 ---- 01:E1A4:  LDA ram_0012  ; $0012
0x0021B6 ---- 01:E1A6:  AND #$03  ; 
0x0021B8 ---- 01:E1A8:  STA ram_00E8,X  ; $00E8 $00E9 $00EA $00EB $00EC $00ED $00EE $00EF
0x0021BA ---- 01:E1AA:  LDY #$21  ; 
0x0021BC nz-- 01:E1AC:  CPX #$02  ; 
0x0021BE ---- 01:E1AE:  BCS $E1C9  ; 0021D9
0x0021C0 --c- 01:E1B0:  LDA (ram_0011),Y  ; $0463 $0464 $0465 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $046E $046F $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $047A $047B $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $0563 $0564 $0565 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $05A3 $05A4 $05A5 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $0639 $063A $063B $0643 $0644 $0645 $0646 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $0663 $0664 $0665 $0666 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $0683 $0684 $0685 $0686 $0687 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0692 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $06A3 $06A4 $06A5 $06A6 $06A7 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B7 $06B8 $06B9 $06BA $06BB $06C3 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $06FA $06FB $0703 $0705 $0706 $0707 $0708 $0709 $070A $070B $070C $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0717 $0718 $0719 $071A $071B $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072C $072D $072E $072F $0730 $0731 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $0743 $0744 $0745 $0746 $0747 $0748 $0749 $074A $074B $074C $074D $0751 $0752 $0753 $0754 $0755 $0756 $0757 $0758 $0759 $075A $075B $0763 $0764 $0765 $0766 $0767 $0768 $0769 $076A $076B $076C $076D $0771 $0772 $0773 $0774 $0775 $0776 $0777 $0778 $0779 $077A $077B
0x0021C2 --c- 01:E1B2:  CMP #$21  ; 
0x0021C4 ---- 01:E1B4:  BNE $E1C1  ; 0021D1
0x0021C6 -Z-- 01:E1B6:  LDA #$80  ; 
0x0021C8 Nz-- 01:E1B8:  ORA ram_0103,X  ; $0103 $0104
0x0021CB ---- 01:E1BB:  STA ram_0103,X  ; $0103 $0104
0x0021CE ---- 01:E1BE:  JMP $E1C9  ; 0021D9
; 1 refs via 0021C4
0x0021D1 -z-- 01:E1C1:  LDA ram_0103,X  ; $0103 $0104
0x0021D4 ---- 01:E1C4:  AND #$7F  ; 
0x0021D6 ---- 01:E1C6:  STA ram_0103,X  ; $0103 $0104
; 2 refs via 0021BE 0021CE
0x0021D9 ---- 01:E1C9:  JSR $E1F3  ; 002203
; 1 refs via 002209
0x0021DC Nz-- 01:E1CC:  LDA ram_0090,X  ; $0090 $0091 $0092 $0093 $0094 $0095 $0096 $0097
0x0021DE ---- 01:E1CE:  AND #$07  ; 
0x0021E0 ---- 01:E1D0:  BNE $E1DD  ; 0021ED
0x0021E2 -Z-- 01:E1D2:  LDA ram_00E8,X  ; $00E8 $00E9 $00EA $00EB $00EC $00ED $00EE $00EF
0x0021E4 ---- 01:E1D4:  ORA #$80  ; 
0x0021E6 Nz-- 01:E1D6:  STA ram_00E8,X  ; $00E8 $00E9 $00EA $00EB $00EC $00ED $00EE $00EF
0x0021E8 Nz-- 01:E1D8:  LDY #$20  ; 
0x0021EA nz-- 01:E1DA:  JSR $E1F3  ; 002203
; 2 refs via 0021E0 002209
0x0021ED -z-- 01:E1DD:  LDA ram_0098,X  ; $0098 $0099 $009A $009B $009C $009D $009E $009F
0x0021EF ---- 01:E1DF:  AND #$07  ; 
0x0021F1 ---- 01:E1E1:  BNE $E1EE  ; 0021FE
0x0021F3 -Z-- 01:E1E3:  LDA ram_00E8,X  ; $00E8 $00E9 $00EA $00EB $00EC $00ED $00EE $00EF
0x0021F5 ---- 01:E1E5:  ORA #$40  ; 
0x0021F7 -z-- 01:E1E7:  STA ram_00E8,X  ; $00E8 $00E9 $00EA $00EB $00EC $00ED $00EE $00EF
0x0021F9 -z-- 01:E1E9:  LDY #$01  ; 
0x0021FB nz-- 01:E1EB:  JSR $E1F3  ; 002203
; 4 refs via 002199 00219D 0021F1 002209
0x0021FE ---- 01:E1EE:  DEC ram_005A  ; $005A
0x002200 ---- 01:E1F0:  BPL $E185  ; 002195
0x002202 N--- 01:E1F2:  RTS  ; 0002F9
; 3 refs via 0021D9 0021EA 0021FB
0x002203 ---- 01:E1F3:  LDA (ram_0011),Y  ; $0443 $0444 $0445 $0446 $0447 $0448 $0449 $044A $044B $044C $044D $044E $044F $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0458 $0459 $045A $045B $0462 $0463 $0464 $0465 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $046E $046F $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $047A $047B $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $0562 $0563 $0564 $0565 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $05A2 $05A3 $05A4 $05A5 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $0639 $063A $063B $0642 $0643 $0644 $0645 $0646 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $0662 $0663 $0664 $0665 $0666 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $0682 $0683 $0684 $0685 $0686 $0687 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0692 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $06A2 $06A3 $06A4 $06A5 $06A6 $06A7 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B7 $06B8 $06B9 $06BA $06BB $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $06FA $06FB $0702 $0703 $0704 $0705 $0706 $0707 $0708 $0709 $070A $070B $070C $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0717 $0718 $0719 $071A $071B $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072C $072D $072E $072F $0730 $0731 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $0742 $0743 $0744 $0745 $0746 $0747 $0748 $0749 $074A $074B $074C $074D $0750 $0751 $0752 $0753 $0754 $0755 $0756 $0757 $0758 $0759 $075A $075B $0762 $0763 $0764 $0765 $0766 $0767 $0768 $0769 $076A $076B $076C $076D $0770 $0771 $0772 $0773 $0774 $0775 $0776 $0777 $0778 $0779 $077A $077B
0x002205 ---- 01:E1F5:  ORA #$80  ; 
0x002207 Nz-- 01:E1F7:  STA (ram_0011),Y  ; $0443 $0444 $0445 $0446 $0447 $0448 $0449 $044A $044B $044C $044D $044E $044F $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0458 $0459 $045A $045B $0462 $0463 $0464 $0465 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $046E $046F $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $047A $047B $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $0562 $0563 $0564 $0565 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $05A2 $05A3 $05A4 $05A5 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $0639 $063A $063B $0642 $0643 $0644 $0645 $0646 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $0662 $0663 $0664 $0665 $0666 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $0682 $0683 $0684 $0685 $0686 $0687 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0692 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $06A2 $06A3 $06A4 $06A5 $06A6 $06A7 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B7 $06B8 $06B9 $06BA $06BB $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $06FA $06FB $0702 $0703 $0704 $0705 $0706 $0707 $0708 $0709 $070A $070B $070C $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0717 $0718 $0719 $071A $071B $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072C $072D $072E $072F $0730 $0731 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $0742 $0743 $0744 $0745 $0746 $0747 $0748 $0749 $074A $074B $074C $074D $0750 $0751 $0752 $0753 $0754 $0755 $0756 $0757 $0758 $0759 $075A $075B $0762 $0763 $0764 $0765 $0766 $0767 $0768 $0769 $076A $076B $076C $076D $0770 $0771 $0772 $0773 $0774 $0775 $0776 $0777 $0778 $0779 $077A $077B
0x002209 Nz-- 01:E1F9:  RTS  ; 0021DC 0021ED 0021FE
; 1 refs via 0002FF
0x00220A N--- 01:E1FA:  LDA #$07  ; 
0x00220C nz-- 01:E1FC:  STA ram_005A  ; $005A
; 1 refs via 002241
0x00220E n--- 01:E1FE:  LDX ram_005A  ; $005A
0x002210 ---- 01:E200:  LDA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x002212 ---- 01:E202:  BPL $E22F  ; 00223F
0x002214 N--- 01:E204:  CMP #$E0  ; 
0x002216 ---- 01:E206:  BCS $E22F  ; 00223F
0x002218 --c- 01:E208:  LDA ram_00E0,X  ; $00E0 $00E1 $00E2 $00E3 $00E4 $00E5 $00E6 $00E7
0x00221A --c- 01:E20A:  STA ram_0011  ; $0011
0x00221C --c- 01:E20C:  LDA ram_00E8,X  ; $00E8 $00E9 $00EA $00EB $00EC $00ED $00EE $00EF
0x00221E --c- 01:E20E:  AND #$03  ; 
0x002220 --c- 01:E210:  ORA #$04  ; 
0x002222 -zc- 01:E212:  STA ram_0012  ; $0012
0x002224 -zc- 01:E214:  LDY #$21  ; 
0x002226 nzc- 01:E216:  JSR $E234  ; 002244
; 1 refs via 00224A
0x002229 --c- 01:E219:  LDA ram_00E8,X  ; $00E8 $00E9 $00EA $00EB $00EC $00ED $00EE $00EF
0x00222B --c- 01:E21B:  AND #$80  ; 
0x00222D --c- 01:E21D:  BEQ $E224  ; 002234
0x00222F -zc- 01:E21F:  LDY #$20  ; 
0x002231 nzc- 01:E221:  JSR $E234  ; 002244
; 2 refs via 00222D 00224A
0x002234 --c- 01:E224:  LDA ram_00E8,X  ; $00E8 $00E9 $00EA $00EB $00EC $00ED $00EE $00EF
0x002236 --c- 01:E226:  AND #$40  ; 
0x002238 --c- 01:E228:  BEQ $E22F  ; 00223F
0x00223A -zc- 01:E22A:  LDY #$01  ; 
0x00223C nzc- 01:E22C:  JSR $E234  ; 002244
; 4 refs via 002212 002216 002238 00224A
0x00223F ---- 01:E22F:  DEC ram_005A  ; $005A
0x002241 ---- 01:E231:  BPL $E1FE  ; 00220E
0x002243 N--- 01:E233:  RTS  ; 000302
; 3 refs via 002226 002231 00223C
0x002244 nzc- 01:E234:  LDA (ram_0011),Y  ; $0421 $0443 $0444 $0445 $0446 $0447 $0448 $0449 $044A $044B $044C $044D $044E $044F $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0458 $0459 $045A $045B $0462 $0463 $0464 $0465 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $046E $046F $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $047A $047B $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $0562 $0563 $0564 $0565 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $05A2 $05A3 $05A4 $05A5 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $0639 $063A $063B $0642 $0643 $0644 $0645 $0646 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $0662 $0663 $0664 $0665 $0666 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $0682 $0683 $0684 $0685 $0686 $0687 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0692 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $06A2 $06A3 $06A4 $06A5 $06A6 $06A7 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B7 $06B8 $06B9 $06BA $06BB $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $06FA $06FB $0702 $0703 $0704 $0705 $0706 $0707 $0708 $0709 $070A $070B $070C $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0717 $0718 $0719 $071A $071B $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072C $072D $072E $072F $0730 $0731 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $0742 $0743 $0744 $0745 $0746 $0747 $0748 $0749 $074A $074B $074C $074D $0750 $0751 $0752 $0753 $0754 $0755 $0756 $0757 $0758 $0759 $075A $075B $0762 $0763 $0764 $0765 $0766 $0767 $0768 $0769 $076A $076B $076C $076D $0770 $0771 $0772 $0773 $0774 $0775 $0776 $0777 $0778 $0779 $077A $077B $0800 $081F $0820
0x002246 --c- 01:E236:  AND #$7F  ; 
0x002248 --c- 01:E238:  STA (ram_0011),Y  ; $0421 $0443 $0444 $0445 $0446 $0447 $0448 $0449 $044A $044B $044C $044D $044E $044F $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0458 $0459 $045A $045B $0462 $0463 $0464 $0465 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $046E $046F $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $047A $047B $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $0562 $0563 $0564 $0565 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $05A2 $05A3 $05A4 $05A5 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $0639 $063A $063B $0642 $0643 $0644 $0645 $0646 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $0662 $0663 $0664 $0665 $0666 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $0682 $0683 $0684 $0685 $0686 $0687 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0692 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $06A2 $06A3 $06A4 $06A5 $06A6 $06A7 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B7 $06B8 $06B9 $06BA $06BB $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $06FA $06FB $0702 $0703 $0704 $0705 $0706 $0707 $0708 $0709 $070A $070B $070C $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0717 $0718 $0719 $071A $071B $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072C $072D $072E $072F $0730 $0731 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $0742 $0743 $0744 $0745 $0746 $0747 $0748 $0749 $074A $074B $074C $074D $0750 $0751 $0752 $0753 $0754 $0755 $0756 $0757 $0758 $0759 $075A $075B $0762 $0763 $0764 $0765 $0766 $0767 $0768 $0769 $076A $076B $076C $076D $0770 $0771 $0772 $0773 $0774 $0775 $0776 $0777 $0778 $0779 $077A $077B $0800 $081F $0820
0x00224A --c- 01:E23A:  RTS  ; 002229 002234 00223F
; 3 refs via 000213 000251 00043C
0x00224B ---- 01:E23B:  LDA ram_0086  ; $0086
0x00224D ---- 01:E23D:  BEQ $E27B  ; 00228B
0x00224F -z-- 01:E23F:  LDA ram_0062  ; $0062
0x002251 ---- 01:E241:  BEQ $E259  ; 002269
0x002253 -z-- 01:E243:  DEC ram_0062  ; $0062
0x002255 ---- 01:E245:  BNE $E24E  ; 00225E
0x002257 -Z-- 01:E247:  LDA #$00  ; 
0x002259 nZ-- 01:E249:  STA ram_0086  ; $0086
0x00225B nZ-- 01:E24B:  JMP $E27B  ; 00228B
; 1 refs via 002255
0x00225E -z-- 01:E24E:  LDA #$02  ; 
0x002260 nz-- 01:E250:  STA ram_0004  ; $0004
0x002262 nz-- 01:E252:  LDA #$3B  ; 
0x002264 nz-- 01:E254:  STA ram_0053  ; $0053
0x002266 nz-- 01:E256:  JMP $E26C  ; 00227C
; 1 refs via 002251
0x002269 -Z-- 01:E259:  LDA ram_000B  ; $000B
0x00226B ---- 01:E25B:  AND #$08  ; 
0x00226D ---- 01:E25D:  BEQ $E27B  ; 00228B
0x00226F -z-- 01:E25F:  LDA #$02  ; 
0x002271 nz-- 01:E261:  STA ram_0004  ; $0004
0x002273 nz-- 01:E263:  LDA ram_0088  ; $0088
0x002275 ---- 01:E265:  ASL  ; 
0x002276 ---- 01:E266:  ASL  ; 
0x002277 ---- 01:E267:  CLC  ; 
0x002278 --c- 01:E268:  ADC #$81  ; 
0x00227A ---- 01:E26A:  STA ram_0053  ; $0053
; 1 refs via 002266
0x00227C ---- 01:E26C:  LDX ram_0086  ; $0086
0x00227E ---- 01:E26E:  LDY ram_0087  ; $0087
0x002280 ---- 01:E270:  LDA #$00  ; 
0x002282 nZ-- 01:E272:  STA ram_006E  ; $006E
0x002284 nZ-- 01:E274:  JSR $DA7B  ; 001A8B
; 1 refs via 001AA2
0x002287 ---- 01:E277:  LDA #$20  ; 
0x002289 nz-- 01:E279:  STA ram_006E  ; $006E
; 3 refs via 00224D 00225B 00226D
0x00228B ---- 01:E27B:  RTS  ; 000216 000254 00043F
; 1 refs via 000308
0x00228C ---- 01:E27C:  LDA #$01  ; 
0x00228E nz-- 01:E27E:  STA ram_005A  ; $005A
; 1 refs via 0022B6
0x002290 n--- 01:E280:  LDX ram_005A  ; $005A
0x002292 ---- 01:E282:  LDA ram_0089,X  ; $0089 $008A
0x002294 ---- 01:E284:  BEQ $E2A4  ; 0022B4
0x002296 -z-- 01:E286:  LDA ram_000B  ; $000B
0x002298 ---- 01:E288:  AND #$3F  ; 
0x00229A ---- 01:E28A:  BNE $E28E  ; 00229E
0x00229C -Z-- 01:E28C:  DEC ram_0089,X  ; $0089 $008A
; 1 refs via 00229A
0x00229E ---- 01:E28E:  LDA #$02  ; 
0x0022A0 nz-- 01:E290:  STA ram_0004  ; $0004
0x0022A2 nz-- 01:E292:  LDY ram_0098,X  ; $0098 $0099
0x0022A4 ---- 01:E294:  LDA ram_0090,X  ; $0090 $0091
0x0022A6 ---- 01:E296:  TAX  ; 
0x0022A7 ---- 01:E297:  LDA ram_000B  ; $000B
0x0022A9 ---- 01:E299:  AND #$02  ; 
0x0022AB ---- 01:E29B:  ASL  ; 
0x0022AC ---- 01:E29C:  CLC  ; 
0x0022AD --c- 01:E29D:  ADC #$29  ; 
0x0022AF ---- 01:E29F:  STA ram_0053  ; $0053
0x0022B1 ---- 01:E2A1:  JSR $DA7B  ; 001A8B
; 2 refs via 001AA2 002294
0x0022B4 ---- 01:E2A4:  DEC ram_005A  ; $005A
0x0022B6 ---- 01:E2A6:  BPL $E280  ; 002290
0x0022B8 N--- 01:E2A8:  RTS  ; 00030B
; 1 refs via 000305
0x0022B9 N--- 01:E2A9:  LDA ram_0045  ; $0045
0x0022BB ---- 01:E2AB:  BEQ $E2D2  ; 0022E2
0x0022BD -z-- 01:E2AD:  LDA ram_000B  ; $000B
0x0022BF ---- 01:E2AF:  AND #$0F  ; 
0x0022C1 ---- 01:E2B1:  BNE $E2D2  ; 0022E2
0x0022C3 -Z-- 01:E2B3:  LDA ram_000B  ; $000B
0x0022C5 ---- 01:E2B5:  AND #$3F  ; 
0x0022C7 ---- 01:E2B7:  BNE $E2BD  ; 0022CD
0x0022C9 -Z-- 01:E2B9:  DEC ram_0045  ; $0045
0x0022CB ---- 01:E2BB:  BEQ $E2CF  ; 0022DF
; 1 refs via 0022C7
0x0022CD -z-- 01:E2BD:  LDA ram_0045  ; $0045
0x0022CF ---- 01:E2BF:  CMP #$04  ; 
0x0022D1 ---- 01:E2C1:  BCS $E2D2  ; 0022E2
0x0022D3 --c- 01:E2C3:  LDA ram_000B  ; $000B
0x0022D5 --c- 01:E2C5:  AND #$10  ; 
0x0022D7 --c- 01:E2C7:  BEQ $E2CF  ; 0022DF
0x0022D9 -zc- 01:E2C9:  JSR $CB9E  ; 000BAE
; 1 refs via 000C17
0x0022DC ---- 01:E2CC:  JMP $E2D2  ; 0022E2
; 2 refs via 0022CB 0022D7
0x0022DF -Z-- 01:E2CF:  JSR $CAF5  ; 000B05
; 5 refs via 000B6C 0022BB 0022C1 0022D1 0022DC
0x0022E2 ---- 01:E2D2:  LDA ram_0068  ; $0068
0x0022E4 ---- 01:E2D4:  BEQ $E305  ; 002315
0x0022E6 -z-- 01:E2D6:  BMI $E305  ; 002315
0x0022E8 nz-- 01:E2D8:  LDA #$03  ; 
0x0022EA nz-- 01:E2DA:  STA ram_0004  ; $0004
0x0022EC nz-- 01:E2DC:  DEC ram_0068  ; $0068
0x0022EE ---- 01:E2DE:  LDA ram_0068  ; $0068
0x0022F0 ---- 01:E2E0:  LSR  ; 
0x0022F1 ---- 01:E2E1:  LSR  ; 
0x0022F2 ---- 01:E2E2:  SEC  ; 
0x0022F3 --C- 01:E2E3:  SBC #$05  ; 
0x0022F5 ---- 01:E2E5:  BPL $E2EC  ; 0022FC
0x0022F7 N--- 01:E2E7:  EOR #$FF  ; 
0x0022F9 ---- 01:E2E9:  CLC  ; 
0x0022FA --c- 01:E2EA:  ADC #$01  ; 
; 1 refs via 0022F5
0x0022FC ---- 01:E2EC:  SEC  ; 
0x0022FD --C- 01:E2ED:  SBC #$05  ; 
0x0022FF ---- 01:E2EF:  BPL $E2F6  ; 002306
0x002301 N--- 01:E2F1:  EOR #$FF  ; 
0x002303 ---- 01:E2F3:  CLC  ; 
0x002304 --c- 01:E2F4:  ADC #$01  ; 
; 1 refs via 0022FF
0x002306 ---- 01:E2F6:  ASL  ; 
0x002307 ---- 01:E2F7:  TAY  ; 
0x002308 ---- 01:E2F8:  LDA $E306,Y  ; 002316 002318 00231A 00231C 00231E 002320
0x00230B ---- 01:E2FB:  STA ram_0011  ; $0011
0x00230D ---- 01:E2FD:  LDA $E307,Y  ; 002317 002319 00231B 00231D 00231F 002321
0x002310 ---- 01:E300:  STA ram_0012  ; $0012
0x002312 ---- 01:E302:  JMP (ram_0011)  ; 001C00 002322 002327 00232C 00233E 002346
; 2 refs via 0022E4 0022E6
0x002315 ---- 01:E305:  RTS  ; 000308
0x002316 ---- 01:E306:  .byte $F0   ; 002308
0x002317 ---- 01:E307:  .byte $DB   ; 00230D
0x002318 ---- 01:E308:  .byte $12   ; 002308
0x002319 ---- 01:E309:  .byte $E3   ; 00230D
0x00231A ---- 01:E30A:  .byte $17   ; 002308
0x00231B ---- 01:E30B:  .byte $E3   ; 00230D
0x00231C ---- 01:E30C:  .byte $1C   ; 002308
0x00231D ---- 01:E30D:  .byte $E3   ; 00230D
0x00231E ---- 01:E30E:  .byte $2E   ; 002308
0x00231F ---- 01:E30F:  .byte $E3   ; 00230D
0x002320 ---- 01:E310:  .byte $36   ; 002308
0x002321 ---- 01:E311:  .byte $E3   ; 00230D
; 1 refs via 002312
0x002322 ---- 01:E312:  LDA #$F1  ; 
0x002324 Nz-- 01:E314:  JMP $E31E  ; 00232E
; 1 refs via 002312
0x002327 ---- 01:E317:  LDA #$F5  ; 
0x002329 Nz-- 01:E319:  JMP $E31E  ; 00232E
; 1 refs via 002312
0x00232C ---- 01:E31C:  LDA #$F9  ; 
; 2 refs via 002324 002329
0x00232E Nz-- 01:E31E:  LDX #$78  ; 
0x002330 nz-- 01:E320:  LDY #$D8  ; 
; 1 refs via 00233B
0x002332 ---- 01:E322:  STA ram_0053  ; $0053
0x002334 ---- 01:E324:  JSR $DA7B  ; 001A8B
; 1 refs via 001AA2
0x002337 ---- 01:E327:  RTS  ; 000308 002357 002360 002369 002372
; 4 refs via 002354 00235D 002366 00236F
0x002338 Nz-- 01:E328:  CLC  ; 
0x002339 Nzc- 01:E329:  ADC ram_0069  ; $0069
0x00233B ---- 01:E32B:  JMP $E322  ; 002332
; 1 refs via 002312
0x00233E ---- 01:E32E:  LDA #$00  ; 
0x002340 nZ-- 01:E330:  STA ram_0069  ; $0069
0x002342 nZ-- 01:E332:  JSR $E33E  ; 00234E
; 1 refs via 002372
0x002345 ---- 01:E335:  RTS  ; 000308
; 1 refs via 002312
0x002346 ---- 01:E336:  LDA #$10  ; 
0x002348 nz-- 01:E338:  STA ram_0069  ; $0069
0x00234A nz-- 01:E33A:  JSR $E33E  ; 00234E
; 1 refs via 002372
0x00234D ---- 01:E33D:  RTS  ; 000308
; 2 refs via 002342 00234A
0x00234E n--- 01:E33E:  LDX #$70  ; 
0x002350 nz-- 01:E340:  LDY #$D0  ; 
0x002352 Nz-- 01:E342:  LDA #$D1  ; 
0x002354 Nz-- 01:E344:  JSR $E328  ; 002338
; 1 refs via 002337
0x002357 ---- 01:E347:  LDX #$80  ; 
0x002359 Nz-- 01:E349:  LDY #$D0  ; 
0x00235B Nz-- 01:E34B:  LDA #$D5  ; 
0x00235D Nz-- 01:E34D:  JSR $E328  ; 002338
; 1 refs via 002337
0x002360 ---- 01:E350:  LDX #$70  ; 
0x002362 nz-- 01:E352:  LDY #$E0  ; 
0x002364 Nz-- 01:E354:  LDA #$D9  ; 
0x002366 Nz-- 01:E356:  JSR $E328  ; 002338
; 1 refs via 002337
0x002369 ---- 01:E359:  LDX #$80  ; 
0x00236B Nz-- 01:E35B:  LDY #$E0  ; 
0x00236D Nz-- 01:E35D:  LDA #$DD  ; 
0x00236F Nz-- 01:E35F:  JSR $E328  ; 002338
; 1 refs via 002337
0x002372 ---- 01:E362:  RTS  ; 002345 00234D
; 4 refs via 000357 000360 001B71 001E21
0x002373 ---- 01:E363:  LDA #$00  ; 
0x002375 nZ-- 01:E365:  STA ram_00A8,X  ; $00A8 $00A9 $00AA $00AB $00AC $00AD $00AE $00AF
0x002377 nZ-- 01:E367:  CPX #$02  ; 
0x002379 ---- 01:E369:  BCS $E37C  ; 00238C
0x00237B --c- 01:E36B:  LDA $E47A,X  ; 00248A 00248B
0x00237E --c- 01:E36E:  STA ram_0090,X  ; $0090 $0091
0x002380 --c- 01:E370:  LDA $E47C,X  ; 00248C 00248D
0x002383 --c- 01:E373:  STA ram_0098,X  ; $0098 $0099
0x002385 --c- 01:E375:  LDA #$00  ; 
0x002387 nZc- 01:E377:  STA ram_006F,X  ; $006F $0070
0x002389 nZc- 01:E379:  JMP $E3A9  ; 0023B9
; 1 refs via 002379
0x00238C --C- 01:E37C:  INC ram_006A  ; $006A
0x00238E --C- 01:E37E:  LDY ram_006A  ; $006A
0x002390 --C- 01:E380:  CPY #$03  ; 
0x002392 ---- 01:E382:  BNE $E389  ; 002399
0x002394 -Z-- 01:E384:  LDA #$00  ; 
0x002396 nZ-- 01:E386:  STA ram_006A  ; $006A
0x002398 nZ-- 01:E388:  TAY  ; 
; 1 refs via 002392
0x002399 ---- 01:E389:  LDA $E474,Y  ; 002484 002485 002486
0x00239C ---- 01:E38C:  STA ram_0090,X  ; $0092 $0093 $0094 $0095 $0096 $0097
0x00239E ---- 01:E38E:  LDA $E477,Y  ; 002487 002488 002489
0x0023A1 ---- 01:E391:  STA ram_0098,X  ; $009A $009B $009C $009D $009E $009F
0x0023A3 ---- 01:E393:  LDA ram_007F  ; $007F
0x0023A5 ---- 01:E395:  CMP #$03  ; 
0x0023A7 ---- 01:E397:  BEQ $E3A1  ; 0023B1
0x0023A9 -z-- 01:E399:  CMP #$0A  ; 
0x0023AB ---- 01:E39B:  BEQ $E3A1  ; 0023B1
0x0023AD -z-- 01:E39D:  CMP #$11  ; 
0x0023AF ---- 01:E39F:  BNE $E3A9  ; 0023B9
; 2 refs via 0023A7 0023AB
0x0023B1 -Z-- 01:E3A1:  LDA #$04  ; 
0x0023B3 nz-- 01:E3A3:  STA ram_00A8,X  ; $00AA $00AB $00AC $00AD $00AE $00AF
0x0023B5 nz-- 01:E3A5:  LDA #$00  ; 
0x0023B7 nZ-- 01:E3A7:  STA ram_0086  ; $0086
; 2 refs via 002389 0023AF
0x0023B9 ---- 01:E3A9:  LDA #$F0  ; 
0x0023BB Nz-- 01:E3AB:  STA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x0023BD Nz-- 01:E3AD:  LDY ram_0098,X  ; $0098 $0099 $009A $009B $009C $009D $009E $009F
0x0023BF ---- 01:E3AF:  LDA ram_0090,X  ; $0090 $0091 $0092 $0093 $0094 $0095 $0096 $0097
0x0023C1 ---- 01:E3B1:  TAX  ; 
0x0023C2 ---- 01:E3B2:  LDA #$0F  ; 
0x0023C4 nz-- 01:E3B4:  JSR $D80B  ; 00181B
; 1 refs via 00186D
0x0023C7 ---- 01:E3B7:  RTS  ; 00035A 000363 001B74 001E24
; 1 refs via 001E7E
0x0023C8 -Z-- 01:E3B8:  LDA $E47E,X  ; 00248E 00248F 002490 002491 002492 002493 002494 002495
0x0023CB ---- 01:E3BB:  STA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x0023CD ---- 01:E3BD:  CPX #$02  ; 
0x0023CF ---- 01:E3BF:  BCS $E3CB  ; 0023DB
0x0023D1 --c- 01:E3C1:  LDA #$03  ; 
0x0023D3 nzc- 01:E3C3:  STA ram_0089,X  ; $0089 $008A
0x0023D5 nzc- 01:E3C5:  LDA ram_0101,X  ; $0101 $0102
0x0023D8 --c- 01:E3C8:  JMP $E3FA  ; 00240A
; 2 refs via 0023CF 0023E4
0x0023DB --C- 01:E3CB:  LDY ram_008F  ; $008F
0x0023DD --C- 01:E3CD:  LDA ram_008B,Y  ; $008B $008C $008D $008E
0x0023E0 --C- 01:E3D0:  BNE $E3D7  ; 0023E7
0x0023E2 -ZC- 01:E3D2:  INC ram_008F  ; $008F
0x0023E4 --C- 01:E3D4:  JMP $E3CB  ; 0023DB
; 1 refs via 0023E0
0x0023E7 -zC- 01:E3D7:  SEC  ; 
0x0023E8 -zC- 01:E3D8:  SBC #$01  ; 
0x0023EA ---- 01:E3DA:  STA ram_008B,Y  ; $008B $008C $008D $008E
0x0023ED ---- 01:E3DD:  LDA ram_0046  ; $0046
0x0023EF ---- 01:E3DF:  BEQ $E3E6  ; 0023F6
0x0023F1 -z-- 01:E3E1:  LDA #$23  ; 
0x0023F3 nz-- 01:E3E3:  JMP $E3E8  ; 0023F8
; 1 refs via 0023EF
0x0023F6 -Z-- 01:E3E6:  LDA ram_0085  ; $0085
; 1 refs via 0023F3
0x0023F8 ---- 01:E3E8:  SEC  ; 
0x0023F9 --C- 01:E3E9:  SBC #$01  ; 
0x0023FB ---- 01:E3EB:  ASL  ; 
0x0023FC ---- 01:E3EC:  ASL  ; 
0x0023FD ---- 01:E3ED:  CLC  ; 
0x0023FE --c- 01:E3EE:  ADC ram_008F  ; $008F
0x002400 ---- 01:E3F0:  TAY  ; 
0x002401 ---- 01:E3F1:  LDA $E4EC,Y  ; 0024FC 0024FD 002500 002501 002503 002504 002505 002507 002508 002509 00250A 00250B 00250C 00250D 00250E 00250F 002510 002511 002512 002513 002514 002515 002516 002517 002518 002519 00251A 00251B 00251C 00251D 00251E 00251F 002520 002521 002522 002523 002524 002525 002526 002527 002528 002529 00252B 00252C 00252D 00252F 002530 002531 002533 002534 002536 002537 002538 00253A 00253B 00253C 00253D 00253E 00253F 002540 002541 002542 002543 002544 002545 002546 002547 002548 002549 00254A 00254B 00254C 00254D 00254E 00254F 002550 002551 002552 002553 002554 002556 002557 002558 002559 00255A 00255B 00255C 00255D 00255F 002560 002561 002562 002563 002564 002565 002566 002567 002568 002569 00256A 00256B 00256C 00256D 00256F 002570 002571 002572 002573 002574 002575 002576 002577 002578 002579 00257A 00257B 00257C 00257D 00257E 00257F 002580 002581 002583 002584 002585 002587
0x002404 ---- 01:E3F4:  CMP #$E0  ; 
0x002406 ---- 01:E3F6:  BNE $E3FA  ; 00240A
0x002408 -Z-- 01:E3F8:  ORA #$03  ; 
; 2 refs via 0023D8 002406
0x00240A ---- 01:E3FA:  ORA ram_00A8,X  ; $00A8 $00A9 $00AA $00AB $00AC $00AD $00AE $00AF
0x00240C ---- 01:E3FC:  CMP #$E7  ; 
0x00240E ---- 01:E3FE:  BNE $E402  ; 002412
0x002410 -Z-- 01:E400:  LDA #$E4  ; 
; 1 refs via 00240E
0x002412 -z-- 01:E402:  STA ram_00A8,X  ; $00A8 $00A9 $00AA $00AB $00AC $00AD $00AE $00AF
0x002414 -z-- 01:E404:  LDA #$00  ; 
0x002416 nZ-- 01:E406:  STA ram_00B0,X  ; $00B0 $00B1 $00B2 $00B3 $00B4 $00B5 $00B6 $00B7
0x002418 nZ-- 01:E408:  RTS  ; 001E81
; 1 refs via 000341
0x002419 -z-- 01:E409:  LDX #$09  ; 
0x00241B nz-- 01:E40B:  LDA #$00  ; 
; 1 refs via 002420
0x00241D n--- 01:E40D:  STA ram_00CC,X  ; $00CC $00CD $00CE $00CF $00D0 $00D1 $00D2 $00D3 $00D4 $00D5
0x00241F n--- 01:E40F:  DEX  ; 
0x002420 ---- 01:E410:  BPL $E40D  ; 00241D
0x002422 N--- 01:E412:  RTS  ; 000344
; 3 refs via 0000CE 000344 0009D4
0x002423 ---- 01:E413:  LDA #$00  ; 
0x002425 nZ-- 01:E415:  LDX #$07  ; 
; 1 refs via 00242D
0x002427 n--- 01:E417:  STA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x002429 n--- 01:E419:  STA ram_0103,X  ; $0103 $0104 $0105 $0106 $0107 $0108 $0109 $010A
0x00242C n--- 01:E41C:  DEX  ; 
0x00242D ---- 01:E41D:  BPL $E417  ; 002427
0x00242F N--- 01:E41F:  RTS  ; 0000D1 000347 0009D7
; 5 refs via 001BB8 001C88 001D30 001D4E 001EB2
0x002430 Nz-- 01:E420:  STA ram_0000  ; $0000
0x002432 Nz-- 01:E422:  LDA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x002434 ---- 01:E424:  AND #$0F  ; 
0x002436 ---- 01:E426:  ORA ram_0000  ; $0000
0x002438 ---- 01:E428:  STA ram_00A0,X  ; $00A0 $00A1 $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x00243A ---- 01:E42A:  RTS  ; 001BBB 001C8B 001D33 001D51 001EB5
; 1 refs via 000393
0x00243B nZ-- 01:E42B:  LDA ram_0046  ; $0046
0x00243D ---- 01:E42D:  BEQ $E434  ; 002444
0x00243F -z-- 01:E42F:  LDA #$23  ; 
0x002441 nz-- 01:E431:  JMP $E436  ; 002446
; 1 refs via 00243D
0x002444 -Z-- 01:E434:  LDA ram_0085  ; $0085
; 1 refs via 002441
0x002446 ---- 01:E436:  SEC  ; 
0x002447 --C- 01:E437:  SBC #$01  ; 
0x002449 ---- 01:E439:  ASL  ; 
0x00244A ---- 01:E43A:  ASL  ; 
0x00244B ---- 01:E43B:  TAY  ; 
0x00244C ---- 01:E43C:  LDA $E578,Y  ; 002588 00258C 002590 002594 002598 00259C 0025A0 0025A4 0025A8 0025AC 0025B0 0025B4 0025B8 0025BC 0025C0 0025C4 0025C8 0025CC 0025D0 0025D4 0025D8 0025DC 0025E0 0025E4 0025E8 0025EC 0025F0 0025F4 0025F8 0025FC 002600 002604 002608 00260C 002610
0x00244F ---- 01:E43F:  STA ram_008B  ; $008B
0x002451 ---- 01:E441:  LDA $E579,Y  ; 002589 00258D 002591 002595 002599 00259D 0025A1 0025A5 0025A9 0025AD 0025B1 0025B5 0025B9 0025BD 0025C1 0025C5 0025C9 0025CD 0025D1 0025D5 0025D9 0025DD 0025E1 0025E5 0025E9 0025ED 0025F1 0025F5 0025F9 0025FD 002601 002605 002609 00260D 002611
0x002454 ---- 01:E444:  STA ram_008C  ; $008C
0x002456 ---- 01:E446:  LDA $E57A,Y  ; 00258A 00258E 002592 002596 00259A 00259E 0025A2 0025A6 0025AA 0025AE 0025B2 0025B6 0025BA 0025BE 0025C2 0025C6 0025CA 0025CE 0025D2 0025D6 0025DA 0025DE 0025E2 0025E6 0025EA 0025EE 0025F2 0025F6 0025FA 0025FE 002602 002606 00260A 00260E 002612
0x002459 ---- 01:E449:  STA ram_008D  ; $008D
0x00245B ---- 01:E44B:  LDA $E57B,Y  ; 00258B 00258F 002593 002597 00259B 00259F 0025A3 0025A7 0025AB 0025AF 0025B3 0025B7 0025BB 0025BF 0025C3 0025C7 0025CB 0025CF 0025D3 0025D7 0025DB 0025DF 0025E3 0025E7 0025EB 0025EF 0025F3 0025F7 0025FB 0025FF 002603 002607 00260B 00260F 002613
0x00245E ---- 01:E44E:  STA ram_008E  ; $008E
0x002460 ---- 01:E450:  RTS  ; 000396
; 3 refs via 000703 000711 001BAF
0x002461 ---- 01:E451:  ASL  ; 
0x002462 ---- 01:E452:  BCC $E457  ; 002467
0x002464 --C- 01:E454:  LDA #$03  ; 
0x002466 nzC- 01:E456:  RTS  ; 000706 000714 001BB2
; 1 refs via 002462
0x002467 --c- 01:E457:  ASL  ; 
0x002468 ---- 01:E458:  BCC $E45D  ; 00246D
0x00246A --C- 01:E45A:  LDA #$01  ; 
0x00246C nzC- 01:E45C:  RTS  ; 000706 000714 001BB2
; 1 refs via 002468
0x00246D --c- 01:E45D:  ASL  ; 
0x00246E ---- 01:E45E:  BCC $E463  ; 002473
0x002470 --C- 01:E460:  LDA #$02  ; 
0x002472 nzC- 01:E462:  RTS  ; 000706 000714 001BB2
; 1 refs via 00246E
0x002473 --c- 01:E463:  ASL  ; 
0x002474 ---- 01:E464:  BCC $E469  ; 002479
0x002476 --C- 01:E466:  LDA #$00  ; 
0x002478 nZC- 01:E468:  RTS  ; 000706 001BB2
; 1 refs via 002474
0x002479 --c- 01:E469:  LDA #$FF  ; 
0x00247B Nzc- 01:E46B:  RTS  ; 001BB2
0x00247C ---- 01:E46C:  .byte $00   ; 001CBC 001CC4 002073 0020B2
0x00247D ---- 01:E46D:  .byte $FF   ; 001CBC 001CC4 002073 0020B2
0x00247E ---- 01:E46E:  .byte $00   ; 001CBC 001CC4 002073 0020B2
0x00247F ---- 01:E46F:  .byte $01   ; 001CBC 001CC4 002073 0020B2
0x002480 ---- 01:E470:  .byte $FF   ; 001CAC 001CB4 00207C 0020BD
0x002481 ---- 01:E471:  .byte $00   ; 001CAC 001CB4 00207C 0020BD
0x002482 ---- 01:E472:  .byte $01   ; 001CAC 001CB4 00207C 0020BD
0x002483 ---- 01:E473:  .byte $00   ; 001CAC 001CB4 00207C 0020BD
0x002484 ---- 01:E474:  .byte $18   ; 002399
0x002485 ---- 01:E475:  .byte $78   ; 002399
0x002486 ---- 01:E476:  .byte $D8   ; 002399
0x002487 ---- 01:E477:  .byte $18   ; 00239E
0x002488 ---- 01:E478:  .byte $18   ; 00239E
0x002489 ---- 01:E479:  .byte $18   ; 00239E
0x00248A ---- 01:E47A:  .byte $58   ; 00237B
0x00248B ---- 01:E47B:  .byte $98   ; 00237B
0x00248C ---- 01:E47C:  .byte $D8   ; 002380
0x00248D ---- 01:E47D:  .byte $D8   ; 002380
0x00248E ---- 01:E47E:  .byte $A0   ; 0023C8
0x00248F ---- 01:E47F:  .byte $A0   ; 0023C8
0x002490 ---- 01:E480:  .byte $A2   ; 0023C8
0x002491 ---- 01:E481:  .byte $A2   ; 0023C8
0x002492 ---- 01:E482:  .byte $A2   ; 0023C8
0x002493 ---- 01:E483:  .byte $A2   ; 0023C8
0x002494 ---- 01:E484:  .byte $A2   ; 0023C8
0x002495 ---- 01:E485:  .byte $A2   ; 0023C8
0x002496 ---- 01:E486:  .byte $A0   ; 001DF6
0x002497 ---- 01:E487:  .byte $A0   ; 001DF6
0x002498 ---- 01:E488:  .byte $A0   ; 001DF6
0x002499 ---- 01:E489:  .byte $A1   ; 001DF6
0x00249A ---- 01:E48A:  .byte $A0   ; 001DF6
0x00249B ---- 01:E48B:  .byte $A3   ; 001DF6
0x00249C ---- 01:E48C:  .byte $A2   ; 001DF6
0x00249D ---- 01:E48D:  .byte $A2   ; 001DF6
0x00249E ---- 01:E48E:  .byte $A2   ; 001DF6
0x00249F ---- 01:E48F:  .byte $A1   ; 001DF6
0x0024A0 ---- 01:E490:  .byte $A0   ; 001DF6
0x0024A1 ---- 01:E491:  .byte $A3   ; 001DF6
0x0024A2 ---- 01:E492:  .byte $A1   ; 001DF6
0x0024A3 ---- xx:E493:  .byte $A0   ; 
0x0024A4 ---- 01:E494:  .byte $A3   ; 001DF6
0x0024A5 ---- 01:E495:  .byte $A1   ; 001DF6
0x0024A6 ---- 01:E496:  .byte $A2   ; 001DF6
0x0024A7 ---- 01:E497:  .byte $A3   ; 001DF6
0x0024A8 ---- 01:E498:  .byte $F0   ; 001C55
0x0024A9 ---- 01:E499:  .byte $DB   ; 001C5A
0x0024AA ---- 01:E49A:  .byte $EA   ; 001C55
0x0024AB ---- 01:E49B:  .byte $DD   ; 001C5A
0x0024AC ---- 01:E49C:  .byte $EA   ; 001C55
0x0024AD ---- 01:E49D:  .byte $DD   ; 001C5A
0x0024AE ---- 01:E49E:  .byte $EA   ; 001C55
0x0024AF ---- 01:E49F:  .byte $DD   ; 001C5A
0x0024B0 ---- 01:E4A0:  .byte $EA   ; 001C55
0x0024B1 ---- 01:E4A1:  .byte $DD   ; 001C5A
0x0024B2 ---- 01:E4A2:  .byte $EA   ; 001C55
0x0024B3 ---- 01:E4A3:  .byte $DD   ; 001C5A
0x0024B4 ---- 01:E4A4:  .byte $EA   ; 001C55
0x0024B5 ---- 01:E4A5:  .byte $DD   ; 001C5A
0x0024B6 ---- 01:E4A6:  .byte $EA   ; 001C55
0x0024B7 ---- 01:E4A7:  .byte $DD   ; 001C5A
0x0024B8 ---- 01:E4A8:  .byte $52   ; 001C55
0x0024B9 ---- 01:E4A9:  .byte $DC   ; 001C5A
0x0024BA ---- 01:E4AA:  .byte $48   ; 001C55
0x0024BB ---- 01:E4AB:  .byte $DD   ; 001C5A
0x0024BC ---- 01:E4AC:  .byte $7C   ; 001C55
0x0024BD ---- 01:E4AD:  .byte $DC   ; 001C5A
0x0024BE ---- 01:E4AE:  .byte $94   ; 001C55
0x0024BF ---- 01:E4AF:  .byte $DD   ; 001C5A
0x0024C0 ---- 01:E4B0:  .byte $89   ; 001C55
0x0024C1 ---- 01:E4B1:  .byte $DD   ; 001C5A
0x0024C2 ---- 01:E4B2:  .byte $7E   ; 001C55
0x0024C3 ---- 01:E4B3:  .byte $DD   ; 001C5A
0x0024C4 ---- 01:E4B4:  .byte $64   ; 001C55
0x0024C5 ---- 01:E4B5:  .byte $DE   ; 001C5A
0x0024C6 ---- 01:E4B6:  .byte $55   ; 001C55
0x0024C7 ---- 01:E4B7:  .byte $DE   ; 001C5A
0x0024C8 ---- 01:E4B8:  .byte $F0   ; 001ED0
0x0024C9 ---- 01:E4B9:  .byte $DB   ; 001ED5
0x0024CA ---- 01:E4BA:  .byte $FD   ; 001ED0
0x0024CB ---- 01:E4BB:  .byte $DE   ; 001ED5
0x0024CC ---- 01:E4BC:  .byte $33   ; 001ED0
0x0024CD ---- 01:E4BD:  .byte $DF   ; 001ED5
0x0024CE ---- 01:E4BE:  .byte $46   ; 001ED0
0x0024CF ---- 01:E4BF:  .byte $DF   ; 001ED5
0x0024D0 ---- 01:E4C0:  .byte $46   ; 001ED0
0x0024D1 ---- 01:E4C1:  .byte $DF   ; 001ED5
0x0024D2 ---- 01:E4C2:  .byte $CD   ; 001ED0
0x0024D3 ---- 01:E4C3:  .byte $DE   ; 001ED5
0x0024D4 ---- 01:E4C4:  .byte $CD   ; 001ED0
0x0024D5 ---- 01:E4C5:  .byte $DE   ; 001ED5
0x0024D6 ---- 01:E4C6:  .byte $CD   ; 001ED0
0x0024D7 ---- 01:E4C7:  .byte $DE   ; 001ED5
0x0024D8 ---- 01:E4C8:  .byte $B6   ; 001ED0
0x0024D9 ---- 01:E4C9:  .byte $DF   ; 001ED5
0x0024DA ---- 01:E4CA:  .byte $B6   ; 001ED0
0x0024DB ---- 01:E4CB:  .byte $DF   ; 001ED5
0x0024DC ---- 01:E4CC:  .byte $B6   ; 001ED0
0x0024DD ---- 01:E4CD:  .byte $DF   ; 001ED5
0x0024DE ---- 01:E4CE:  .byte $B6   ; 001ED0
0x0024DF ---- 01:E4CF:  .byte $DF   ; 001ED5
0x0024E0 ---- 01:E4D0:  .byte $B6   ; 001ED0
0x0024E1 ---- 01:E4D1:  .byte $DF   ; 001ED5
0x0024E2 ---- 01:E4D2:  .byte $B6   ; 001ED0
0x0024E3 ---- 01:E4D3:  .byte $DF   ; 001ED5
0x0024E4 ---- 01:E4D4:  .byte $0B   ; 001ED0
0x0024E5 ---- 01:E4D5:  .byte $E0   ; 001ED5
0x0024E6 ---- 01:E4D6:  .byte $0B   ; 001ED0
0x0024E7 ---- 01:E4D7:  .byte $E0   ; 001ED5
0x0024E8 ---- 01:E4D8:  .byte $F0   ; 002054
0x0024E9 ---- 01:E4D9:  .byte $DB   ; 002059
0x0024EA ---- 01:E4DA:  .byte $76   ; 002054
0x0024EB ---- 01:E4DB:  .byte $E0   ; 002059
0x0024EC ---- 01:E4DC:  .byte $76   ; 002054
0x0024ED ---- 01:E4DD:  .byte $E0   ; 002059
0x0024EE ---- 01:E4DE:  .byte $76   ; 002054
0x0024EF ---- 01:E4DF:  .byte $E0   ; 002059
0x0024F0 ---- 01:E4E0:  .byte $51   ; 002054
0x0024F1 ---- 01:E4E1:  .byte $E0   ; 002059
0x0024F2 ---- 01:E4E2:  .byte $F0   ; 0020FE
0x0024F3 ---- 01:E4E3:  .byte $DB   ; 002103
0x0024F4 ---- 01:E4E4:  .byte $12   ; 0020FE
0x0024F5 ---- 01:E4E5:  .byte $E1   ; 002103
0x0024F6 ---- 01:E4E6:  .byte $12   ; 0020FE
0x0024F7 ---- 01:E4E7:  .byte $E1   ; 002103
0x0024F8 ---- 01:E4E8:  .byte $12   ; 0020FE
0x0024F9 ---- 01:E4E9:  .byte $E1   ; 002103
0x0024FA ---- 01:E4EA:  .byte $FB   ; 0020FE
0x0024FB ---- 01:E4EB:  .byte $E0   ; 002103
0x0024FC ---- 01:E4EC:  .byte $80   ; 002401
0x0024FD ---- 01:E4ED:  .byte $A0   ; 002401
0x0024FE ---- xx:E4EE:  .byte $C0   ; 
0x0024FF ---- xx:E4EF:  .byte $E0   ; 
0x002500 ---- 01:E4F0:  .byte $E0   ; 002401
0x002501 ---- 01:E4F1:  .byte $A0   ; 002401
0x002502 ---- xx:E4F2:  .byte $C0   ; 
0x002503 ---- 01:E4F3:  .byte $80   ; 002401
0x002504 ---- 01:E4F4:  .byte $80   ; 002401
0x002505 ---- 01:E4F5:  .byte $A0   ; 002401
0x002506 ---- xx:E4F6:  .byte $C0   ; 
0x002507 ---- 01:E4F7:  .byte $E0   ; 002401
0x002508 ---- 01:E4F8:  .byte $C0   ; 002401
0x002509 ---- 01:E4F9:  .byte $A0   ; 002401
0x00250A ---- 01:E4FA:  .byte $80   ; 002401
0x00250B ---- 01:E4FB:  .byte $E0   ; 002401
0x00250C ---- 01:E4FC:  .byte $C0   ; 002401
0x00250D ---- 01:E4FD:  .byte $E0   ; 002401
0x00250E ---- 01:E4FE:  .byte $80   ; 002401
0x00250F ---- 01:E4FF:  .byte $A0   ; 002401
0x002510 ---- 01:E500:  .byte $C0   ; 002401
0x002511 ---- 01:E501:  .byte $A0   ; 002401
0x002512 ---- 01:E502:  .byte $80   ; 002401
0x002513 ---- 01:E503:  .byte $E0   ; 002401
0x002514 ---- 01:E504:  .byte $80   ; 002401
0x002515 ---- 01:E505:  .byte $A0   ; 002401
0x002516 ---- 01:E506:  .byte $C0   ; 002401
0x002517 ---- 01:E507:  .byte $80   ; 002401
0x002518 ---- 01:E508:  .byte $C0   ; 002401
0x002519 ---- 01:E509:  .byte $E0   ; 002401
0x00251A ---- 01:E50A:  .byte $A0   ; 002401
0x00251B ---- 01:E50B:  .byte $80   ; 002401
0x00251C ---- 01:E50C:  .byte $80   ; 002401
0x00251D ---- 01:E50D:  .byte $A0   ; 002401
0x00251E ---- 01:E50E:  .byte $C0   ; 002401
0x00251F ---- 01:E50F:  .byte $E0   ; 002401
0x002520 ---- 01:E510:  .byte $80   ; 002401
0x002521 ---- 01:E511:  .byte $A0   ; 002401
0x002522 ---- 01:E512:  .byte $C0   ; 002401
0x002523 ---- 01:E513:  .byte $E0   ; 002401
0x002524 ---- 01:E514:  .byte $A0   ; 002401
0x002525 ---- 01:E515:  .byte $E0   ; 002401
0x002526 ---- 01:E516:  .byte $C0   ; 002401
0x002527 ---- 01:E517:  .byte $A0   ; 002401
0x002528 ---- 01:E518:  .byte $C0   ; 002401
0x002529 ---- 01:E519:  .byte $A0   ; 002401
0x00252A ---- xx:E51A:  .byte $80   ; 
0x00252B ---- 01:E51B:  .byte $E0   ; 002401
0x00252C ---- 01:E51C:  .byte $C0   ; 002401
0x00252D ---- 01:E51D:  .byte $A0   ; 002401
0x00252E ---- xx:E51E:  .byte $80   ; 
0x00252F ---- 01:E51F:  .byte $E0   ; 002401
0x002530 ---- 01:E520:  .byte $C0   ; 002401
0x002531 ---- 01:E521:  .byte $A0   ; 002401
0x002532 ---- xx:E522:  .byte $80   ; 
0x002533 ---- 01:E523:  .byte $E0   ; 002401
0x002534 ---- 01:E524:  .byte $80   ; 002401
0x002535 ---- xx:E525:  .byte $C0   ; 
0x002536 ---- 01:E526:  .byte $A0   ; 002401
0x002537 ---- 01:E527:  .byte $E0   ; 002401
0x002538 ---- 01:E528:  .byte $80   ; 002401
0x002539 ---- xx:E529:  .byte $C0   ; 
0x00253A ---- 01:E52A:  .byte $A0   ; 002401
0x00253B ---- 01:E52B:  .byte $E0   ; 002401
0x00253C ---- 01:E52C:  .byte $E0   ; 002401
0x00253D ---- 01:E52D:  .byte $A0   ; 002401
0x00253E ---- 01:E52E:  .byte $C0   ; 002401
0x00253F ---- 01:E52F:  .byte $80   ; 002401
0x002540 ---- 01:E530:  .byte $E0   ; 002401
0x002541 ---- 01:E531:  .byte $80   ; 002401
0x002542 ---- 01:E532:  .byte $C0   ; 002401
0x002543 ---- 01:E533:  .byte $A0   ; 002401
0x002544 ---- 01:E534:  .byte $A0   ; 002401
0x002545 ---- 01:E535:  .byte $E0   ; 002401
0x002546 ---- 01:E536:  .byte $80   ; 002401
0x002547 ---- 01:E537:  .byte $C0   ; 002401
0x002548 ---- 01:E538:  .byte $A0   ; 002401
0x002549 ---- 01:E539:  .byte $80   ; 002401
0x00254A ---- 01:E53A:  .byte $C0   ; 002401
0x00254B ---- 01:E53B:  .byte $E0   ; 002401
0x00254C ---- 01:E53C:  .byte $C0   ; 002401
0x00254D ---- 01:E53D:  .byte $A0   ; 002401
0x00254E ---- 01:E53E:  .byte $80   ; 002401
0x00254F ---- 01:E53F:  .byte $E0   ; 002401
0x002550 ---- 01:E540:  .byte $A0   ; 002401
0x002551 ---- 01:E541:  .byte $80   ; 002401
0x002552 ---- 01:E542:  .byte $C0   ; 002401
0x002553 ---- 01:E543:  .byte $E0   ; 002401
0x002554 ---- 01:E544:  .byte $E0   ; 002401
0x002555 ---- xx:E545:  .byte $80   ; 
0x002556 ---- 01:E546:  .byte $C0   ; 002401
0x002557 ---- 01:E547:  .byte $A0   ; 002401
0x002558 ---- 01:E548:  .byte $C0   ; 002401
0x002559 ---- 01:E549:  .byte $E0   ; 002401
0x00255A ---- 01:E54A:  .byte $A0   ; 002401
0x00255B ---- 01:E54B:  .byte $80   ; 002401
0x00255C ---- 01:E54C:  .byte $C0   ; 002401
0x00255D ---- 01:E54D:  .byte $A0   ; 002401
0x00255E ---- xx:E54E:  .byte $80   ; 
0x00255F ---- 01:E54F:  .byte $E0   ; 002401
0x002560 ---- 01:E550:  .byte $A0   ; 002401
0x002561 ---- 01:E551:  .byte $E0   ; 002401
0x002562 ---- 01:E552:  .byte $80   ; 002401
0x002563 ---- 01:E553:  .byte $C0   ; 002401
0x002564 ---- 01:E554:  .byte $C0   ; 002401
0x002565 ---- 01:E555:  .byte $E0   ; 002401
0x002566 ---- 01:E556:  .byte $A0   ; 002401
0x002567 ---- 01:E557:  .byte $80   ; 002401
0x002568 ---- 01:E558:  .byte $A0   ; 002401
0x002569 ---- 01:E559:  .byte $E0   ; 002401
0x00256A ---- 01:E55A:  .byte $80   ; 002401
0x00256B ---- 01:E55B:  .byte $C0   ; 002401
0x00256C ---- 01:E55C:  .byte $C0   ; 002401
0x00256D ---- 01:E55D:  .byte $A0   ; 002401
0x00256E ---- xx:E55E:  .byte $80   ; 
0x00256F ---- 01:E55F:  .byte $E0   ; 002401
0x002570 ---- 01:E560:  .byte $80   ; 002401
0x002571 ---- 01:E561:  .byte $A0   ; 002401
0x002572 ---- 01:E562:  .byte $C0   ; 002401
0x002573 ---- 01:E563:  .byte $E0   ; 002401
0x002574 ---- 01:E564:  .byte $C0   ; 002401
0x002575 ---- 01:E565:  .byte $A0   ; 002401
0x002576 ---- 01:E566:  .byte $E0   ; 002401
0x002577 ---- 01:E567:  .byte $C0   ; 002401
0x002578 ---- 01:E568:  .byte $E0   ; 002401
0x002579 ---- 01:E569:  .byte $80   ; 002401
0x00257A ---- 01:E56A:  .byte $C0   ; 002401
0x00257B ---- 01:E56B:  .byte $A0   ; 002401
0x00257C ---- 01:E56C:  .byte $A0   ; 002401
0x00257D ---- 01:E56D:  .byte $E0   ; 002401
0x00257E ---- 01:E56E:  .byte $C0   ; 002401
0x00257F ---- 01:E56F:  .byte $A0   ; 002401
0x002580 ---- 01:E570:  .byte $C0   ; 002401
0x002581 ---- 01:E571:  .byte $A0   ; 002401
0x002582 ---- xx:E572:  .byte $80   ; 
0x002583 ---- 01:E573:  .byte $E0   ; 002401
0x002584 ---- 01:E574:  .byte $C0   ; 002401
0x002585 ---- 01:E575:  .byte $A0   ; 002401
0x002586 ---- xx:E576:  .byte $80   ; 
0x002587 ---- 01:E577:  .byte $E0   ; 002401
0x002588 ---- 01:E578:  .byte $12   ; 00244C
0x002589 ---- 01:E579:  .byte $02   ; 002451
0x00258A ---- 01:E57A:  .byte $00   ; 002456
0x00258B ---- 01:E57B:  .byte $00   ; 00245B
0x00258C ---- 01:E57C:  .byte $02   ; 00244C
0x00258D ---- 01:E57D:  .byte $04   ; 002451
0x00258E ---- 01:E57E:  .byte $00   ; 002456
0x00258F ---- 01:E57F:  .byte $0E   ; 00245B
0x002590 ---- 01:E580:  .byte $0E   ; 00244C
0x002591 ---- 01:E581:  .byte $04   ; 002451
0x002592 ---- 01:E582:  .byte $00   ; 002456
0x002593 ---- 01:E583:  .byte $02   ; 00245B
0x002594 ---- 01:E584:  .byte $0A   ; 00244C
0x002595 ---- 01:E585:  .byte $05   ; 002451
0x002596 ---- 01:E586:  .byte $02   ; 002456
0x002597 ---- 01:E587:  .byte $03   ; 00245B
0x002598 ---- 01:E588:  .byte $05   ; 00244C
0x002599 ---- 01:E589:  .byte $02   ; 002451
0x00259A ---- 01:E58A:  .byte $08   ; 002456
0x00259B ---- 01:E58B:  .byte $05   ; 00245B
0x00259C ---- 01:E58C:  .byte $07   ; 00244C
0x00259D ---- 01:E58D:  .byte $02   ; 002451
0x00259E ---- 01:E58E:  .byte $09   ; 002456
0x00259F ---- 01:E58F:  .byte $02   ; 00245B
0x0025A0 ---- 01:E590:  .byte $03   ; 00244C
0x0025A1 ---- 01:E591:  .byte $04   ; 002451
0x0025A2 ---- 01:E592:  .byte $06   ; 002456
0x0025A3 ---- 01:E593:  .byte $07   ; 00245B
0x0025A4 ---- 01:E594:  .byte $07   ; 00244C
0x0025A5 ---- 01:E595:  .byte $02   ; 002451
0x0025A6 ---- 01:E596:  .byte $04   ; 002456
0x0025A7 ---- 01:E597:  .byte $07   ; 00245B
0x0025A8 ---- 01:E598:  .byte $06   ; 00244C
0x0025A9 ---- 01:E599:  .byte $04   ; 002451
0x0025AA ---- 01:E59A:  .byte $07   ; 002456
0x0025AB ---- 01:E59B:  .byte $03   ; 00245B
0x0025AC ---- 01:E59C:  .byte $0C   ; 00244C
0x0025AD ---- 01:E59D:  .byte $02   ; 002451
0x0025AE ---- 01:E59E:  .byte $04   ; 002456
0x0025AF ---- 01:E59F:  .byte $02   ; 00245B
0x0025B0 ---- 01:E5A0:  .byte $05   ; 00244C
0x0025B1 ---- 01:E5A1:  .byte $06   ; 002451
0x0025B2 ---- 01:E5A2:  .byte $04   ; 002456
0x0025B3 ---- 01:E5A3:  .byte $05   ; 00245B
0x0025B4 ---- 01:E5A4:  .byte $08   ; 00244C
0x0025B5 ---- 01:E5A5:  .byte $06   ; 002451
0x0025B6 ---- 01:E5A6:  .byte $00   ; 002456
0x0025B7 ---- 01:E5A7:  .byte $06   ; 00245B
0x0025B8 ---- 01:E5A8:  .byte $08   ; 00244C
0x0025B9 ---- 01:E5A9:  .byte $08   ; 002451
0x0025BA ---- 01:E5AA:  .byte $00   ; 002456
0x0025BB ---- 01:E5AB:  .byte $04   ; 00245B
0x0025BC ---- 01:E5AC:  .byte $0A   ; 00244C
0x0025BD ---- 01:E5AD:  .byte $04   ; 002451
0x0025BE ---- 01:E5AE:  .byte $00   ; 002456
0x0025BF ---- 01:E5AF:  .byte $06   ; 00245B
0x0025C0 ---- 01:E5B0:  .byte $02   ; 00244C
0x0025C1 ---- 01:E5B1:  .byte $00   ; 002451
0x0025C2 ---- 01:E5B2:  .byte $0A   ; 002456
0x0025C3 ---- 01:E5B3:  .byte $08   ; 00245B
0x0025C4 ---- 01:E5B4:  .byte $10   ; 00244C
0x0025C5 ---- 01:E5B5:  .byte $00   ; 002451
0x0025C6 ---- 01:E5B6:  .byte $02   ; 002456
0x0025C7 ---- 01:E5B7:  .byte $02   ; 00245B
0x0025C8 ---- 01:E5B8:  .byte $02   ; 00244C
0x0025C9 ---- 01:E5B9:  .byte $02   ; 002451
0x0025CA ---- 01:E5BA:  .byte $08   ; 002456
0x0025CB ---- 01:E5BB:  .byte $08   ; 00245B
0x0025CC ---- 01:E5BC:  .byte $04   ; 00244C
0x0025CD ---- 01:E5BD:  .byte $02   ; 002451
0x0025CE ---- 01:E5BE:  .byte $06   ; 002456
0x0025CF ---- 01:E5BF:  .byte $08   ; 00245B
0x0025D0 ---- 01:E5C0:  .byte $04   ; 00244C
0x0025D1 ---- 01:E5C1:  .byte $08   ; 002451
0x0025D2 ---- 01:E5C2:  .byte $04   ; 002456
0x0025D3 ---- 01:E5C3:  .byte $04   ; 00245B
0x0025D4 ---- 01:E5C4:  .byte $08   ; 00244C
0x0025D5 ---- 01:E5C5:  .byte $02   ; 002451
0x0025D6 ---- 01:E5C6:  .byte $02   ; 002456
0x0025D7 ---- 01:E5C7:  .byte $08   ; 00245B
0x0025D8 ---- 01:E5C8:  .byte $08   ; 00244C
0x0025D9 ---- 01:E5C9:  .byte $02   ; 002451
0x0025DA ---- 01:E5CA:  .byte $06   ; 002456
0x0025DB ---- 01:E5CB:  .byte $04   ; 00245B
0x0025DC ---- 01:E5CC:  .byte $08   ; 00244C
0x0025DD ---- 01:E5CD:  .byte $06   ; 002451
0x0025DE ---- 01:E5CE:  .byte $02   ; 002456
0x0025DF ---- 01:E5CF:  .byte $04   ; 00245B
0x0025E0 ---- 01:E5D0:  .byte $06   ; 00244C
0x0025E1 ---- 01:E5D1:  .byte $00   ; 002451
0x0025E2 ---- 01:E5D2:  .byte $04   ; 002456
0x0025E3 ---- 01:E5D3:  .byte $0A   ; 00245B
0x0025E4 ---- 01:E5D4:  .byte $04   ; 00244C
0x0025E5 ---- 01:E5D5:  .byte $02   ; 002451
0x0025E6 ---- 01:E5D6:  .byte $04   ; 002456
0x0025E7 ---- 01:E5D7:  .byte $0A   ; 00245B
0x0025E8 ---- 01:E5D8:  .byte $02   ; 00244C
0x0025E9 ---- 01:E5D9:  .byte $08   ; 002451
0x0025EA ---- 01:E5DA:  .byte $00   ; 002456
0x0025EB ---- 01:E5DB:  .byte $0A   ; 00245B
0x0025EC ---- 01:E5DC:  .byte $06   ; 00244C
0x0025ED ---- 01:E5DD:  .byte $06   ; 002451
0x0025EE ---- 01:E5DE:  .byte $04   ; 002456
0x0025EF ---- 01:E5DF:  .byte $04   ; 00245B
0x0025F0 ---- 01:E5E0:  .byte $02   ; 00244C
0x0025F1 ---- 01:E5E1:  .byte $08   ; 002451
0x0025F2 ---- 01:E5E2:  .byte $08   ; 002456
0x0025F3 ---- 01:E5E3:  .byte $02   ; 00245B
0x0025F4 ---- 01:E5E4:  .byte $02   ; 00244C
0x0025F5 ---- 01:E5E5:  .byte $01   ; 002451
0x0025F6 ---- 01:E5E6:  .byte $0F   ; 002456
0x0025F7 ---- 01:E5E7:  .byte $02   ; 00245B
0x0025F8 ---- 01:E5E8:  .byte $0A   ; 00244C
0x0025F9 ---- 01:E5E9:  .byte $04   ; 002451
0x0025FA ---- 01:E5EA:  .byte $00   ; 002456
0x0025FB ---- 01:E5EB:  .byte $06   ; 00245B
0x0025FC ---- 01:E5EC:  .byte $04   ; 00244C
0x0025FD ---- 01:E5ED:  .byte $08   ; 002451
0x0025FE ---- 01:E5EE:  .byte $04   ; 002456
0x0025FF ---- 01:E5EF:  .byte $04   ; 00245B
0x002600 ---- 01:E5F0:  .byte $03   ; 00244C
0x002601 ---- 01:E5F1:  .byte $08   ; 002451
0x002602 ---- 01:E5F2:  .byte $06   ; 002456
0x002603 ---- 01:E5F3:  .byte $03   ; 00245B
0x002604 ---- 01:E5F4:  .byte $08   ; 00244C
0x002605 ---- 01:E5F5:  .byte $06   ; 002451
0x002606 ---- 01:E5F6:  .byte $02   ; 002456
0x002607 ---- 01:E5F7:  .byte $04   ; 00245B
0x002608 ---- 01:E5F8:  .byte $04   ; 00244C
0x002609 ---- 01:E5F9:  .byte $08   ; 002451
0x00260A ---- 01:E5FA:  .byte $04   ; 002456
0x00260B ---- 01:E5FB:  .byte $04   ; 00245B
0x00260C ---- 01:E5FC:  .byte $04   ; 00244C
0x00260D ---- 01:E5FD:  .byte $0A   ; 002451
0x00260E ---- 01:E5FE:  .byte $00   ; 002456
0x00260F ---- 01:E5FF:  .byte $06   ; 00245B
0x002610 ---- 01:E600:  .byte $04   ; 00244C
0x002611 ---- 01:E601:  .byte $06   ; 002451
0x002612 ---- 01:E602:  .byte $00   ; 002456
0x002613 ---- 01:E603:  .byte $0A   ; 00245B
; 1 refs via 000314
0x002614 ---- 01:E604:  LDA #$09  ; 
0x002616 nz-- 01:E606:  STA ram_005A  ; $005A
; 1 refs via 00269F
0x002618 n--- 01:E608:  LDX ram_005A  ; $005A
0x00261A ---- 01:E60A:  LDA ram_00CC,X  ; $00CC $00CD $00CE $00CF $00D0 $00D1 $00D2 $00D3 $00D4 $00D5
0x00261C ---- 01:E60C:  AND #$F0  ; 
0x00261E ---- 01:E60E:  CMP #$40  ; 
0x002620 ---- 01:E610:  BNE $E68B  ; 00269B
0x002622 -Z-- 01:E612:  LDA ram_00D6,X  ; $00D6 $00D7 $00D8 $00D9 $00DA $00DB $00DC $00DD $00DE $00DF
0x002624 ---- 01:E614:  BNE $E61D  ; 00262D
0x002626 -Z-- 01:E616:  TXA  ; 
0x002627 ---- 01:E617:  EOR ram_000B  ; $000B
0x002629 ---- 01:E619:  AND #$01  ; 
0x00262B ---- 01:E61B:  BEQ $E68B  ; 00269B
; 1 refs via 002624
0x00262D -z-- 01:E61D:  LDA ram_00CC,X  ; $00CC $00CD $00CE $00CF $00D0 $00D1 $00D2 $00D3 $00D4 $00D5
0x00262F ---- 01:E61F:  AND #$03  ; 
0x002631 ---- 01:E621:  TAY  ; 
0x002632 ---- 01:E622:  LDA $EA49,Y  ; 002A59 002A5A 002A5B 002A5C
0x002635 ---- 01:E625:  BPL $E62C  ; 00263C
0x002637 N--- 01:E627:  EOR #$FF  ; 
0x002639 ---- 01:E629:  CLC  ; 
0x00263A --c- 01:E62A:  ADC #$01  ; 
; 1 refs via 002635
0x00263C ---- 01:E62C:  STA ram_0054  ; $0054
0x00263E ---- 01:E62E:  ASL  ; 
0x00263F ---- 01:E62F:  ASL  ; 
0x002640 ---- 01:E630:  STA ram_0064  ; $0064
0x002642 ---- 01:E632:  LDA $EA4D,Y  ; 002A5D 002A5E 002A5F 002A60
0x002645 ---- 01:E635:  BPL $E63C  ; 00264C
0x002647 N--- 01:E637:  EOR #$FF  ; 
0x002649 ---- 01:E639:  CLC  ; 
0x00264A --c- 01:E63A:  ADC #$01  ; 
; 1 refs via 002645
0x00264C ---- 01:E63C:  STA ram_0055  ; $0055
0x00264E ---- 01:E63E:  ASL  ; 
0x00264F ---- 01:E63F:  ASL  ; 
0x002650 ---- 01:E640:  STA ram_0065  ; $0065
0x002652 ---- 01:E642:  LDY ram_00C2,X  ; $00C2 $00C3 $00C4 $00C5 $00C6 $00C7 $00C8 $00C9 $00CA $00CB
0x002654 ---- 01:E644:  LDA ram_00B8,X  ; $00B8 $00B9 $00BA $00BB $00BC $00BD $00BE $00BF $00C0 $00C1
0x002656 ---- 01:E646:  TAX  ; 
0x002657 ---- 01:E647:  JSR $E693  ; 0026A3
; 2 refs via 00270F 00271B
0x00265A n--- 01:E64A:  BEQ $E65F  ; 00266F
0x00265C nz-- 01:E64C:  LDX ram_005A  ; $005A
0x00265E ---- 01:E64E:  LDA ram_00C2,X  ; $00C2 $00C3 $00C4 $00C5 $00C6 $00C7 $00C8 $00C9 $00CA $00CB
0x002660 ---- 01:E650:  CLC  ; 
0x002661 --c- 01:E651:  ADC ram_0064  ; $0064
0x002663 ---- 01:E653:  STA ram_0048  ; $0048
0x002665 ---- 01:E655:  LDA ram_00B8,X  ; $00B8 $00B9 $00BA $00BB $00BC $00BD $00BE $00BF $00C0 $00C1
0x002667 ---- 01:E657:  CLC  ; 
0x002668 --c- 01:E658:  ADC ram_0065  ; $0065
0x00266A ---- 01:E65A:  STA ram_0047  ; $0047
0x00266C ---- 01:E65C:  JSR $E69A  ; 0026AA
; 3 refs via 00265A 00270F 00271B
0x00266F n--- 01:E65F:  LDX ram_005A  ; $005A
0x002671 ---- 01:E661:  LDA ram_00C2,X  ; $00C2 $00C3 $00C4 $00C5 $00C6 $00C7 $00C8 $00C9 $00CA $00CB
0x002673 ---- 01:E663:  SEC  ; 
0x002674 --C- 01:E664:  SBC ram_0054  ; $0054
0x002676 ---- 01:E666:  TAY  ; 
0x002677 ---- 01:E667:  LDA ram_00B8,X  ; $00B8 $00B9 $00BA $00BB $00BC $00BD $00BE $00BF $00C0 $00C1
0x002679 ---- 01:E669:  SEC  ; 
0x00267A --C- 01:E66A:  SBC ram_0055  ; $0055
0x00267C ---- 01:E66C:  TAX  ; 
0x00267D ---- 01:E66D:  JSR $E693  ; 0026A3
; 2 refs via 00270F 00271B
0x002680 n--- 01:E670:  BEQ $E68B  ; 00269B
0x002682 nz-- 01:E672:  LDX ram_005A  ; $005A
0x002684 ---- 01:E674:  LDA ram_00C2,X  ; $00C2 $00C3 $00C4 $00C5 $00C6 $00C7 $00C8 $00C9 $00CA $00CB
0x002686 ---- 01:E676:  SEC  ; 
0x002687 --C- 01:E677:  SBC ram_0064  ; $0064
0x002689 ---- 01:E679:  SEC  ; 
0x00268A --C- 01:E67A:  SBC ram_0054  ; $0054
0x00268C ---- 01:E67C:  STA ram_0048  ; $0048
0x00268E ---- 01:E67E:  LDA ram_00B8,X  ; $00B8 $00B9 $00BA $00BB $00BC $00BD $00BE $00BF $00C0 $00C1
0x002690 ---- 01:E680:  SEC  ; 
0x002691 --C- 01:E681:  SBC ram_0065  ; $0065
0x002693 ---- 01:E683:  SEC  ; 
0x002694 --C- 01:E684:  SBC ram_0055  ; $0055
0x002696 ---- 01:E686:  STA ram_0047  ; $0047
0x002698 ---- 01:E688:  JSR $E69A  ; 0026AA
; 5 refs via 002620 00262B 002680 00270F 00271B
0x00269B ---- 01:E68B:  DEC ram_005A  ; $005A
0x00269D ---- 01:E68D:  BMI $E692  ; 0026A2
0x00269F n--- 01:E68F:  JMP $E608  ; 002618
; 1 refs via 00269D
0x0026A2 N--- 01:E692:  RTS  ; 000317
; 2 refs via 002657 00267D
0x0026A3 ---- 01:E693:  STX ram_0047  ; $0047
0x0026A5 ---- 01:E695:  STY ram_0048  ; $0048
0x0026A7 ---- 01:E697:  JSR $D706  ; 001716
; 3 refs via 001722 00266C 002698
0x0026AA ---- 01:E69A:  JSR $D725  ; 001735
; 1 refs via 00174B
0x0026AD ---- 01:E69D:  JSR $D73C  ; 00174C
; 1 refs via 001752
0x0026B0 ---- 01:E6A0:  BEQ $E709  ; 002719
0x0026B2 -z-- 01:E6A2:  LDA (ram_0011),Y  ; $0422 $0423 $0424 $0425 $0426 $0427 $0428 $0429 $042A $042B $042C $042D $042E $042F $0430 $0431 $0432 $0433 $0434 $0435 $0436 $0437 $0438 $0439 $043A $043B $0440 $0441 $0444 $0445 $0446 $0447 $0448 $0449 $044A $044B $044C $044D $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0458 $0459 $045C $0460 $0461 $0464 $0465 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $047C $0481 $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $049C $04A1 $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04BC $04C1 $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04DC $04E1 $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $04FC $0501 $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $051C $0521 $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $053C $0541 $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $055C $0561 $0562 $0563 $0564 $0565 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $057C $0581 $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $059C $05A1 $05A2 $05A3 $05A4 $05A5 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05BC $05C1 $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05DC $05E1 $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $05FC $0601 $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $061C $0621 $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $0639 $063A $063B $063C $0641 $0642 $0643 $0644 $0645 $0646 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $065C $0661 $0662 $0663 $0664 $0665 $0666 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $067C $0681 $0682 $0683 $0684 $0685 $0686 $0687 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0692 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $069C $06A1 $06A2 $06A3 $06A4 $06A5 $06A6 $06A7 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B7 $06B8 $06B9 $06BA $06BB $06BC $06C1 $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06DC $06E1 $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $06FA $06FB $06FC $0702 $0703 $0704 $0705 $0706 $0707 $0708 $0709 $070A $070B $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0717 $0718 $0719 $071A $071B $071C $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072D $072E $072F $0730 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $073C $0741 $0742 $0743 $0744 $0745 $0746 $0747 $0748 $0749 $074C $074D $074E $074F $0750 $0754 $0755 $0756 $0757 $0758 $0759 $075A $075B $075C $0761 $0762 $0763 $0764 $0765 $0766 $0767 $0768 $0769 $076C $076D $076E $076F $0770 $0774 $0775 $0776 $0777 $0778 $0779 $077A $077B $077C $0782 $0783 $0784 $0786 $0787 $0788 $0789 $078A $078B $078C $078D $0790 $0791 $0792 $0793 $0794 $0795 $0796 $0797 $0798 $0799 $079A $079B
0x0026B4 ---- 01:E6A4:  AND #$FC  ; 
0x0026B6 ---- 01:E6A6:  CMP #$C8  ; 
0x0026B8 ---- 01:E6A8:  BNE $E6C6  ; 0026D6
0x0026BA -Z-- 01:E6AA:  LDA ram_0068  ; $0068
0x0026BC ---- 01:E6AC:  BEQ $E6C6  ; 0026D6
0x0026BE -z-- 01:E6AE:  LDA #$27  ; 
0x0026C0 nz-- 01:E6B0:  STA ram_0068  ; $0068
0x0026C2 nz-- 01:E6B2:  LDA #$01  ; 
0x0026C4 nz-- 01:E6B4:  STA ram_030B  ; $030B
0x0026C7 nz-- 01:E6B7:  STA ram_0307  ; $0307
0x0026CA nz-- 01:E6BA:  JSR $CC08  ; 000C18
; 1 refs via 000C36
0x0026CD -Z-- 01:E6BD:  LDX ram_005A  ; $005A
0x0026CF ---- 01:E6BF:  LDA #$33  ; 
0x0026D1 nz-- 01:E6C1:  STA ram_00CC,X  ; $00CC $00CD $00CE
0x0026D3 nz-- 01:E6C3:  JMP $E709  ; 002719
; 2 refs via 0026B8 0026BC
0x0026D6 -z-- 01:E6C6:  LDA (ram_0011),Y  ; $0422 $0423 $0424 $0425 $0426 $0427 $0428 $0429 $042A $042B $042C $042D $042E $042F $0430 $0431 $0432 $0433 $0434 $0435 $0436 $0437 $0438 $0439 $043A $043B $0440 $0441 $0444 $0445 $0446 $0447 $0448 $0449 $044A $044B $044C $044D $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0458 $0459 $045C $0460 $0461 $0464 $0465 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $047C $0481 $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $049C $04A1 $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04BC $04C1 $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04DC $04E1 $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $04FC $0501 $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $051C $0521 $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $053C $0541 $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $055C $0561 $0562 $0563 $0564 $0565 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $057C $0581 $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $059C $05A1 $05A2 $05A3 $05A4 $05A5 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05BC $05C1 $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05DC $05E1 $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $05FC $0601 $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $061C $0621 $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $0639 $063A $063B $063C $0641 $0642 $0643 $0644 $0645 $0646 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $065C $0661 $0662 $0663 $0664 $0665 $0666 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $067C $0681 $0682 $0683 $0684 $0685 $0686 $0687 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0692 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $069C $06A1 $06A2 $06A3 $06A4 $06A5 $06A6 $06A7 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B7 $06B8 $06B9 $06BA $06BB $06BC $06C1 $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06DC $06E1 $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $06FA $06FB $06FC $0702 $0703 $0704 $0705 $0706 $0707 $0708 $0709 $070A $070B $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0717 $0718 $0719 $071A $071B $071C $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072D $072E $072F $0730 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $073C $0741 $0742 $0743 $0744 $0745 $0746 $0747 $0748 $0749 $074C $074D $074E $074F $0750 $0754 $0755 $0756 $0757 $0758 $0759 $075A $075B $075C $0761 $0762 $0763 $0764 $0765 $0766 $0767 $0768 $0769 $076C $076D $076E $076F $0770 $0774 $0775 $0776 $0777 $0778 $0779 $077A $077B $077C $0782 $0783 $0784 $0786 $0787 $0788 $0789 $078A $078B $078C $078D $0790 $0791 $0792 $0793 $0794 $0795 $0796 $0797 $0798 $0799 $079A $079B
0x0026D8 ---- 01:E6C8:  CMP #$12  ; 
0x0026DA ---- 01:E6CA:  BCS $E709  ; 002719
0x0026DC --c- 01:E6CC:  LDX ram_005A  ; $005A
0x0026DE --c- 01:E6CE:  LDA #$33  ; 
0x0026E0 nzc- 01:E6D0:  STA ram_00CC,X  ; $00CC $00CD $00CE $00CF $00D0 $00D1 $00D2 $00D3 $00D4 $00D5
0x0026E2 nzc- 01:E6D2:  LDA (ram_0011),Y  ; $0422 $0423 $0424 $0425 $0426 $0427 $0428 $0429 $042A $042B $042C $042D $042E $042F $0430 $0431 $0432 $0433 $0434 $0435 $0436 $0437 $0438 $0439 $043A $043B $0440 $0441 $0444 $0445 $0446 $0447 $0448 $0449 $044A $044B $044C $044D $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0458 $0459 $045C $0460 $0461 $0464 $0465 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $047C $0481 $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $049C $04A1 $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04BC $04C1 $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04DC $04E1 $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $04FC $0501 $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $051C $0521 $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $053C $0541 $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $055C $0561 $0562 $0563 $0564 $0565 $0566 $0567 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $057C $0581 $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $059C $05A1 $05A2 $05A3 $05A4 $05A5 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05BC $05C1 $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05DC $05E1 $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $05FC $0601 $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $061C $0621 $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $0639 $063A $063B $063C $0641 $0642 $0643 $0644 $0645 $0646 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $065C $0661 $0662 $0663 $0664 $0665 $0666 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $067C $0681 $0682 $0683 $0684 $0685 $0686 $0687 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0692 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $069C $06A1 $06A2 $06A3 $06A4 $06A5 $06A6 $06A7 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B7 $06B8 $06B9 $06BA $06BB $06BC $06C1 $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06DC $06E1 $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $06FA $06FB $06FC $0702 $0703 $0704 $0705 $0706 $0707 $0708 $0709 $070A $070B $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0717 $0718 $0719 $071A $071B $071C $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072D $072E $072F $0730 $0732 $0733 $0734 $0735 $0736 $0737 $0738 $0739 $073A $073B $073C $0741 $0742 $0743 $0744 $0745 $0746 $0747 $0748 $0749 $074D $0750 $0754 $0755 $0756 $0757 $0758 $0759 $075A $075B $075C $0761 $0762 $0763 $0764 $0765 $0766 $0767 $0768 $0769 $076C $076D $0770 $0774 $0775 $0776 $0777 $0778 $0779 $077A $077B $077C $0782 $0783 $0784 $0786 $0787 $0788 $0789 $078A $078B $078C $078D $0790 $0791 $0792 $0793 $0794 $0795 $0796 $0797 $0798 $0799 $079A $079B
0x0026E4 --c- 01:E6D4:  CMP #$11  ; 
0x0026E6 ---- 01:E6D6:  BEQ $E700  ; 002710
0x0026E8 -z-- 01:E6D8:  LDA ram_00D6,X  ; $00D6 $00D7 $00D8 $00D9 $00DA $00DB $00DC $00DD $00DE $00DF
0x0026EA ---- 01:E6DA:  AND #$02  ; 
0x0026EC ---- 01:E6DC:  BEQ $E6EB  ; 0026FB
0x0026EE -z-- 01:E6DE:  LDA #$00  ; 
0x0026F0 nZ-- 01:E6E0:  JSR $D784  ; 001794
; 1 refs via 0017B9
0x0026F3 ---- 01:E6E3:  LDA #$01  ; 
0x0026F5 nz-- 01:E6E5:  STA ram_030C  ; $030C
0x0026F8 nz-- 01:E6E8:  JMP $E709  ; 002719
; 1 refs via 0026EC
0x0026FB -Z-- 01:E6EB:  LDA (ram_0011),Y  ; $0446 $0447 $0448 $0449 $044A $044B $044C $044D $0450 $0451 $0452 $0453 $0454 $0455 $0456 $0457 $0458 $0459 $0466 $0467 $0468 $0469 $046A $046B $046C $046D $0470 $0471 $0472 $0473 $0474 $0475 $0476 $0477 $0478 $0479 $0482 $0483 $0484 $0485 $0486 $0487 $0488 $0489 $048A $048B $048C $048D $048E $048F $0490 $0491 $0492 $0493 $0494 $0495 $0496 $0497 $0498 $0499 $049A $049B $04A2 $04A3 $04A4 $04A5 $04A6 $04A7 $04A8 $04A9 $04AA $04AB $04AC $04AD $04AE $04AF $04B0 $04B1 $04B2 $04B3 $04B4 $04B5 $04B6 $04B7 $04B8 $04B9 $04BA $04BB $04C2 $04C3 $04C4 $04C5 $04C6 $04C7 $04C8 $04C9 $04CA $04CB $04CC $04CD $04CE $04CF $04D0 $04D1 $04D2 $04D3 $04D4 $04D5 $04D6 $04D7 $04D8 $04D9 $04DA $04DB $04E2 $04E3 $04E4 $04E5 $04E6 $04E7 $04E8 $04E9 $04EA $04EB $04EC $04ED $04EE $04EF $04F0 $04F1 $04F2 $04F3 $04F4 $04F5 $04F6 $04F7 $04F8 $04F9 $04FA $04FB $0502 $0503 $0504 $0505 $0506 $0507 $0508 $0509 $050A $050B $050C $050D $050E $050F $0510 $0511 $0512 $0513 $0514 $0515 $0516 $0517 $0518 $0519 $051A $051B $0522 $0523 $0524 $0525 $0526 $0527 $0528 $0529 $052A $052B $052C $052D $052E $052F $0530 $0531 $0532 $0533 $0534 $0535 $0536 $0537 $0538 $0539 $053A $053B $0542 $0543 $0544 $0545 $0546 $0547 $0548 $0549 $054A $054B $054C $054D $054E $054F $0550 $0551 $0552 $0553 $0554 $0555 $0556 $0557 $0558 $0559 $055A $055B $0562 $0563 $0564 $0565 $0566 $0568 $0569 $056A $056B $056C $056D $056E $056F $0570 $0571 $0572 $0573 $0574 $0575 $0576 $0577 $0578 $0579 $057A $057B $0582 $0583 $0584 $0585 $0586 $0587 $0588 $0589 $058A $058B $058C $058D $058E $058F $0590 $0591 $0592 $0593 $0594 $0595 $0596 $0597 $0598 $0599 $059A $059B $05A2 $05A3 $05A4 $05A6 $05A7 $05A8 $05A9 $05AA $05AB $05AC $05AD $05AE $05AF $05B0 $05B1 $05B2 $05B3 $05B4 $05B5 $05B6 $05B7 $05B8 $05B9 $05BA $05BB $05C2 $05C3 $05C4 $05C5 $05C6 $05C7 $05C8 $05C9 $05CA $05CB $05CC $05CD $05CE $05CF $05D0 $05D1 $05D2 $05D3 $05D4 $05D5 $05D6 $05D7 $05D8 $05D9 $05DA $05DB $05E2 $05E3 $05E4 $05E5 $05E6 $05E7 $05E8 $05E9 $05EA $05EB $05EC $05ED $05EE $05EF $05F0 $05F1 $05F2 $05F3 $05F4 $05F5 $05F6 $05F7 $05F8 $05F9 $05FA $05FB $0602 $0603 $0604 $0605 $0606 $0607 $0608 $0609 $060A $060B $060C $060D $060E $060F $0610 $0611 $0612 $0613 $0614 $0615 $0616 $0617 $0618 $0619 $061A $061B $0622 $0623 $0624 $0625 $0626 $0627 $0628 $0629 $062A $062B $062C $062D $062E $062F $0630 $0631 $0632 $0633 $0634 $0635 $0636 $0637 $0638 $063A $063B $0642 $0643 $0644 $0645 $0647 $0648 $0649 $064A $064B $064C $064D $064E $064F $0650 $0651 $0652 $0653 $0654 $0655 $0656 $0657 $0658 $0659 $065A $065B $0662 $0663 $0664 $0665 $0667 $0668 $0669 $066A $066B $066C $066D $066E $066F $0670 $0671 $0672 $0673 $0674 $0675 $0676 $0677 $0678 $0679 $067A $067B $0682 $0683 $0684 $0685 $0686 $0688 $0689 $068A $068B $068C $068D $068E $068F $0690 $0691 $0693 $0694 $0695 $0696 $0697 $0698 $0699 $069A $069B $06A2 $06A3 $06A4 $06A5 $06A8 $06A9 $06AA $06AB $06AC $06AD $06AE $06AF $06B0 $06B1 $06B2 $06B3 $06B4 $06B5 $06B6 $06B8 $06B9 $06BA $06BB $06C2 $06C3 $06C4 $06C5 $06C6 $06C7 $06C8 $06C9 $06CA $06CB $06CC $06CD $06CE $06CF $06D0 $06D1 $06D2 $06D3 $06D4 $06D5 $06D6 $06D7 $06D8 $06D9 $06DA $06DB $06E2 $06E3 $06E4 $06E5 $06E6 $06E7 $06E8 $06E9 $06EA $06EB $06EC $06ED $06EE $06EF $06F0 $06F1 $06F2 $06F3 $06F4 $06F5 $06F6 $06F7 $06F8 $06F9 $0702 $0703 $0704 $0705 $0708 $0709 $070A $070B $070D $070E $070F $0710 $0711 $0712 $0713 $0714 $0715 $0716 $0718 $0719 $071A $071B $0722 $0723 $0724 $0725 $0726 $0727 $0728 $0729 $072A $072B $072D $072E $072F $0730 $0734 $0735 $0736 $0737 $0738 $0739 $0742 $0743 $0744 $0745 $0746 $0748 $0749 $074D $0750 $0754 $0755 $0756 $0757 $0762 $0763 $0766 $0768 $0769 $076C $076D $0770 $0775 $0776 $0777
0x0026FD ---- 01:E6ED:  CMP #$10  ; 
0x0026FF ---- 01:E6EF:  BEQ $E700  ; 002710
0x002701 -z-- 01:E6F1:  CPX #$02  ; 
0x002703 ---- 01:E6F3:  BCS $E6FA  ; 00270A
0x002705 --c- 01:E6F5:  LDA #$01  ; 
0x002707 nzc- 01:E6F7:  STA ram_030C  ; $030C
; 1 refs via 002703
0x00270A ---- 01:E6FA:  JSR $D743  ; 001753
; 1 refs via 00175C
0x00270D ---- 01:E6FD:  LDA #$01  ; 
0x00270F nz-- 01:E6FF:  RTS  ; 00265A 00266F 002680 00269B
; 2 refs via 0026E6 0026FF
0x002710 -Z-- 01:E700:  CPX #$02  ; 
0x002712 ---- 01:E702:  BCS $E709  ; 002719
0x002714 --c- 01:E704:  LDA #$01  ; 
0x002716 nzc- 01:E706:  STA ram_030D  ; $030D
; 5 refs via 0026B0 0026D3 0026DA 0026F8 002712
0x002719 ---- 01:E709:  LDA #$00  ; 
0x00271B nZ-- 01:E70B:  RTS  ; 00265A 00266F 002680 00269B
; 1 refs via 00031A
0x00271C N--- 01:E70C:  LDA #$01  ; 
0x00271E nz-- 01:E70E:  STA ram_005A  ; $005A
; 1 refs via 00278C
0x002720 n--- 01:E710:  LDX ram_005A  ; $005A
0x002722 ---- 01:E712:  LDA ram_00A0,X  ; $00A0 $00A1
0x002724 ---- 01:E714:  BPL $E71A  ; 00272A
0x002726 N--- 01:E716:  CMP #$E0  ; 
0x002728 ---- 01:E718:  BCC $E71D  ; 00272D
; 1 refs via 002724
0x00272A ---- 01:E71A:  JMP $E77A  ; 00278A
; 1 refs via 002728
0x00272D --c- 01:E71D:  LDA #$07  ; 
0x00272F nzc- 01:E71F:  STA ram_005B  ; $005B
; 1 refs via 002788
0x002731 -z-- 01:E721:  LDY ram_005B  ; $005B
0x002733 ---- 01:E723:  LDA ram_00CC,Y  ; $00CE $00CF $00D0 $00D1 $00D2 $00D3
0x002736 ---- 01:E726:  AND #$F0  ; 
0x002738 ---- 01:E728:  CMP #$40  ; 
0x00273A ---- 01:E72A:  BNE $E772  ; 002782
0x00273C -Z-- 01:E72C:  LDA ram_00B8,Y  ; $00BA $00BB $00BC $00BD $00BE $00BF
0x00273F ---- 01:E72F:  SEC  ; 
0x002740 --C- 01:E730:  SBC ram_0090,X  ; $0090 $0091
0x002742 ---- 01:E732:  BPL $E739  ; 002749
0x002744 N--- 01:E734:  EOR #$FF  ; 
0x002746 ---- 01:E736:  CLC  ; 
0x002747 --c- 01:E737:  ADC #$01  ; 
; 1 refs via 002742
0x002749 ---- 01:E739:  CMP #$0A  ; 
0x00274B ---- 01:E73B:  BCS $E772  ; 002782
0x00274D --c- 01:E73D:  LDA ram_00C2,Y  ; $00C4 $00C5 $00C6 $00C7 $00C8 $00C9
0x002750 --c- 01:E740:  SEC  ; 
0x002751 --C- 01:E741:  SBC ram_0098,X  ; $0098 $0099
0x002753 ---- 01:E743:  BPL $E74A  ; 00275A
0x002755 N--- 01:E745:  EOR #$FF  ; 
0x002757 ---- 01:E747:  CLC  ; 
0x002758 --c- 01:E748:  ADC #$01  ; 
; 1 refs via 002753
0x00275A ---- 01:E74A:  CMP #$0A  ; 
0x00275C ---- 01:E74C:  BCS $E772  ; 002782
0x00275E --c- 01:E74E:  LDA #$33  ; 
0x002760 nzc- 01:E750:  STA ram_00CC,Y  ; $00CE $00CF $00D0 $00D1 $00D2
0x002763 nzc- 01:E753:  LDA ram_0089,X  ; $0089 $008A
0x002765 --c- 01:E755:  BEQ $E75F  ; 00276F
0x002767 -zc- 01:E757:  LDA #$00  ; 
0x002769 nZc- 01:E759:  STA ram_00CC,Y  ; $00CE $00CF $00D0 $00D1 $00D2
0x00276C nZc- 01:E75C:  JMP $E772  ; 002782
; 1 refs via 002765
0x00276F -Zc- 01:E75F:  LDA #$73  ; 
0x002771 nzc- 01:E761:  STA ram_00A0,X  ; $00A0 $00A1
0x002773 nzc- 01:E763:  LDA #$01  ; 
0x002775 nzc- 01:E765:  STA ram_0307  ; $0307
0x002778 nzc- 01:E768:  LDA #$00  ; 
0x00277A nZc- 01:E76A:  STA ram_0101,X  ; $0101 $0102
0x00277D nZc- 01:E76D:  STA ram_00A8,X  ; $00A8 $00A9
0x00277F nZc- 01:E76F:  JMP $E77A  ; 00278A
; 4 refs via 00273A 00274B 00275C 00276C
0x002782 ---- 01:E772:  DEC ram_005B  ; $005B
0x002784 ---- 01:E774:  LDA ram_005B  ; $005B
0x002786 ---- 01:E776:  CMP #$01  ; 
0x002788 ---- 01:E778:  BNE $E721  ; 002731
; 2 refs via 00272A 00277F
0x00278A ---- 01:E77A:  DEC ram_005A  ; $005A
0x00278C ---- 01:E77C:  BPL $E710  ; 002720
0x00278E N--- 01:E77E:  LDA #$07  ; 
0x002790 nz-- 01:E780:  STA ram_005A  ; $005A
; 1 refs via 00284C
0x002792 -z-- 01:E782:  LDX ram_005A  ; $005A
0x002794 ---- 01:E784:  LDA ram_00A0,X  ; $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x002796 ---- 01:E786:  BPL $E78C  ; 00279C
0x002798 N--- 01:E788:  CMP #$E0  ; 
0x00279A ---- 01:E78A:  BCC $E78F  ; 00279F
; 1 refs via 002796
0x00279C ---- 01:E78C:  JMP $E834  ; 002844
; 1 refs via 00279A
0x00279F --c- 01:E78F:  LDA #$09  ; 
0x0027A1 nzc- 01:E791:  STA ram_005B  ; $005B
; 1 refs via 002841
0x0027A3 n--- 01:E793:  LDA ram_005B  ; $005B
0x0027A5 ---- 01:E795:  AND #$06  ; 
0x0027A7 ---- 01:E797:  BEQ $E79C  ; 0027AC
0x0027A9 -z-- 01:E799:  JMP $E82D  ; 00283D
; 1 refs via 0027A7
0x0027AC -Z-- 01:E79C:  LDY ram_005B  ; $005B
0x0027AE ---- 01:E79E:  LDA ram_00CC,Y  ; $00CC $00CD $00D4 $00D5
0x0027B1 ---- 01:E7A1:  AND #$F0  ; 
0x0027B3 ---- 01:E7A3:  CMP #$40  ; 
0x0027B5 ---- 01:E7A5:  BEQ $E7AA  ; 0027BA
0x0027B7 -z-- 01:E7A7:  JMP $E82D  ; 00283D
; 1 refs via 0027B5
0x0027BA -Z-- 01:E7AA:  LDA ram_00B8,Y  ; $00B8 $00B9 $00C0 $00C1
0x0027BD ---- 01:E7AD:  SEC  ; 
0x0027BE --C- 01:E7AE:  SBC ram_0090,X  ; $0092 $0093 $0094 $0095 $0096 $0097
0x0027C0 ---- 01:E7B0:  BPL $E7B7  ; 0027C7
0x0027C2 N--- 01:E7B2:  EOR #$FF  ; 
0x0027C4 ---- 01:E7B4:  CLC  ; 
0x0027C5 --c- 01:E7B5:  ADC #$01  ; 
; 1 refs via 0027C0
0x0027C7 ---- 01:E7B7:  CMP #$0A  ; 
0x0027C9 ---- 01:E7B9:  BCS $E82D  ; 00283D
0x0027CB --c- 01:E7BB:  LDA ram_00C2,Y  ; $00C2 $00C3 $00CA $00CB
0x0027CE --c- 01:E7BE:  SEC  ; 
0x0027CF --C- 01:E7BF:  SBC ram_0098,X  ; $009A $009B $009C $009D $009E $009F
0x0027D1 ---- 01:E7C1:  BPL $E7C8  ; 0027D8
0x0027D3 N--- 01:E7C3:  EOR #$FF  ; 
0x0027D5 ---- 01:E7C5:  CLC  ; 
0x0027D6 --c- 01:E7C6:  ADC #$01  ; 
; 1 refs via 0027D1
0x0027D8 ---- 01:E7C8:  CMP #$0A  ; 
0x0027DA ---- 01:E7CA:  BCS $E82D  ; 00283D
0x0027DC --c- 01:E7CC:  LDA #$33  ; 
0x0027DE nzc- 01:E7CE:  STA ram_00CC,Y  ; $00CC $00CD $00D4 $00D5
0x0027E1 nzc- 01:E7D1:  LDA ram_00A8,X  ; $00AA $00AB $00AC $00AD $00AE $00AF
0x0027E3 --c- 01:E7D3:  AND #$04  ; 
0x0027E5 --c- 01:E7D5:  BEQ $E7E2  ; 0027F2
0x0027E7 -zc- 01:E7D7:  JSR $E8BE  ; 0028CE
; 1 refs via 002909
0x0027EA ---- 01:E7DA:  LDA ram_00A8,X  ; $00AA $00AB $00AC $00AD $00AE $00AF
0x0027EC ---- 01:E7DC:  CMP #$E4  ; 
0x0027EE ---- 01:E7DE:  BNE $E7E2  ; 0027F2
0x0027F0 -Z-- 01:E7E0:  DEC ram_00A8,X  ; $00AA $00AB $00AC $00AD $00AE $00AF
; 2 refs via 0027E5 0027EE
0x0027F2 ---- 01:E7E2:  LDA ram_00A8,X  ; $00AA $00AB $00AC $00AD $00AE $00AF
0x0027F4 ---- 01:E7E4:  AND #$03  ; 
0x0027F6 ---- 01:E7E6:  BEQ $E7F2  ; 002802
0x0027F8 -z-- 01:E7E8:  DEC ram_00A8,X  ; $00AA $00AB $00AC $00AD $00AE $00AF
0x0027FA ---- 01:E7EA:  LDA #$01  ; 
0x0027FC nz-- 01:E7EC:  STA ram_030E  ; $030E
0x0027FF nz-- 01:E7EF:  JMP $E82D  ; 00283D
; 1 refs via 0027F6
0x002802 -Z-- 01:E7F2:  LDA #$73  ; 
0x002804 nz-- 01:E7F4:  STA ram_00A0,X  ; $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x002806 nz-- 01:E7F6:  LDA #$01  ; 
0x002808 nz-- 01:E7F8:  STA ram_030A  ; $030A
0x00280B nz-- 01:E7FB:  LDA ram_00A8,X  ; $00AA $00AB $00AC $00AD $00AE $00AF
0x00280D ---- 01:E7FD:  LSR  ; 
0x00280E ---- 01:E7FE:  LSR  ; 
0x00280F ---- 01:E7FF:  LSR  ; 
0x002810 ---- 01:E800:  LSR  ; 
0x002811 ---- 01:E801:  LSR  ; 
0x002812 ---- 01:E802:  SEC  ; 
0x002813 --C- 01:E803:  SBC #$04  ; 
0x002815 ---- 01:E805:  TAX  ; 
0x002816 ---- 01:E806:  LDA ram_005B  ; $005B
0x002818 ---- 01:E808:  AND #$01  ; 
0x00281A ---- 01:E80A:  STA ram_0047  ; $0047
0x00281C ---- 01:E80C:  BNE $E813  ; 002823
0x00281E -Z-- 01:E80E:  INC ram_0073,X  ; $0073 $0074 $0075 $0076
0x002820 ---- 01:E810:  JMP $E815  ; 002825
; 1 refs via 00281C
0x002823 -z-- 01:E813:  INC ram_0077,X  ; $0078 $0079 $007A
; 1 refs via 002820
0x002825 ---- 01:E815:  LDA ram_0046  ; $0046
0x002827 ---- 01:E817:  CMP #$02  ; 
0x002829 ---- 01:E819:  BEQ $E834  ; 002844
0x00282B -z-- 01:E81B:  LDA $E8BA,X  ; 0028CA 0028CB 0028CC 0028CD
0x00282E ---- 01:E81E:  JSR $D9E1  ; 0019F1
; 1 refs via 001A08
0x002831 ---- 01:E821:  LDA ram_0047  ; $0047
0x002833 ---- 01:E823:  TAX  ; 
0x002834 ---- 01:E824:  JSR $D9BE  ; 0019CE
; 1 refs via 0019F0
0x002837 N--- 01:E827:  JSR $D138  ; 001148
; 1 refs via 001179
0x00283A ---- 01:E82A:  JMP $E834  ; 002844
; 5 refs via 0027A9 0027B7 0027C9 0027DA 0027FF
0x00283D ---- 01:E82D:  DEC ram_005B  ; $005B
0x00283F ---- 01:E82F:  BMI $E834  ; 002844
0x002841 n--- 01:E831:  JMP $E793  ; 0027A3
; 4 refs via 00279C 002829 00283A 00283F
0x002844 ---- 01:E834:  DEC ram_005A  ; $005A
0x002846 ---- 01:E836:  LDA ram_005A  ; $005A
0x002848 ---- 01:E838:  CMP #$01  ; 
0x00284A ---- 01:E83A:  BEQ $E83F  ; 00284F
0x00284C -z-- 01:E83C:  JMP $E782  ; 002792
; 1 refs via 00284A
0x00284F -Z-- 01:E83F:  LDA #$01  ; 
0x002851 nz-- 01:E841:  STA ram_005A  ; $005A
; 1 refs via 0028C7
0x002853 n--- 01:E843:  LDX ram_005A  ; $005A
0x002855 ---- 01:E845:  LDA ram_00A0,X  ; $00A0 $00A1
0x002857 ---- 01:E847:  BPL $E84D  ; 00285D
0x002859 N--- 01:E849:  CMP #$E0  ; 
0x00285B ---- 01:E84B:  BCC $E850  ; 002860
; 1 refs via 002857
0x00285D ---- 01:E84D:  JMP $E8B5  ; 0028C5
; 1 refs via 00285B
0x002860 --c- 01:E850:  LDA #$09  ; 
0x002862 nzc- 01:E852:  STA ram_005B  ; $005B
; 1 refs via 0028C3
0x002864 n--- 01:E854:  LDA ram_005B  ; $005B
0x002866 ---- 01:E856:  AND #$06  ; 
0x002868 ---- 01:E858:  BNE $E8B1  ; 0028C1
0x00286A -Z-- 01:E85A:  LDY ram_005B  ; $005B
0x00286C ---- 01:E85C:  LDA ram_00CC,Y  ; $00CC $00CD $00D4 $00D5
0x00286F ---- 01:E85F:  AND #$F0  ; 
0x002871 ---- 01:E861:  CMP #$40  ; 
0x002873 ---- 01:E863:  BNE $E8B1  ; 0028C1
0x002875 -Z-- 01:E865:  LDA ram_005A  ; $005A
0x002877 ---- 01:E867:  EOR ram_005B  ; $005B
0x002879 ---- 01:E869:  AND #$01  ; 
0x00287B ---- 01:E86B:  BEQ $E8B1  ; 0028C1
0x00287D -z-- 01:E86D:  LDA ram_00B8,Y  ; $00B8 $00B9 $00C0 $00C1
0x002880 ---- 01:E870:  SEC  ; 
0x002881 --C- 01:E871:  SBC ram_0090,X  ; $0090 $0091
0x002883 ---- 01:E873:  BPL $E87A  ; 00288A
0x002885 N--- 01:E875:  EOR #$FF  ; 
0x002887 ---- 01:E877:  CLC  ; 
0x002888 --c- 01:E878:  ADC #$01  ; 
; 1 refs via 002883
0x00288A ---- 01:E87A:  CMP #$0A  ; 
0x00288C ---- 01:E87C:  BCS $E8B1  ; 0028C1
0x00288E --c- 01:E87E:  LDA ram_00C2,Y  ; $00C2 $00C3 $00CA $00CB
0x002891 --c- 01:E881:  SEC  ; 
0x002892 --C- 01:E882:  SBC ram_0098,X  ; $0098 $0099
0x002894 ---- 01:E884:  BPL $E88B  ; 00289B
0x002896 N--- 01:E886:  EOR #$FF  ; 
0x002898 ---- 01:E888:  CLC  ; 
0x002899 --c- 01:E889:  ADC #$01  ; 
; 1 refs via 002894
0x00289B ---- 01:E88B:  CMP #$0A  ; 
0x00289D ---- 01:E88D:  BCS $E8B1  ; 0028C1
0x00289F --c- 01:E88F:  LDA #$33  ; 
0x0028A1 nzc- 01:E891:  STA ram_00CC,Y  ; $00CC $00CD $00D5
0x0028A4 nzc- 01:E894:  LDA ram_0089,X  ; $0089 $008A
0x0028A6 --c- 01:E896:  BEQ $E8A0  ; 0028B0
0x0028A8 -zc- 01:E898:  LDA #$00  ; 
0x0028AA nZc- 01:E89A:  STA ram_00CC,Y  ; $00CC $00CD $00D5
0x0028AD nZc- 01:E89D:  JMP $E8B1  ; 0028C1
; 1 refs via 0028A6
0x0028B0 -Zc- 01:E8A0:  LDA ram_006F,X  ; $006F $0070
0x0028B2 --c- 01:E8A2:  BNE $E8B1  ; 0028C1
0x0028B4 -Zc- 01:E8A4:  LDA ram_0046  ; $0046
0x0028B6 --c- 01:E8A6:  CMP #$02  ; 
0x0028B8 ---- 01:E8A8:  BEQ $E8B1  ; 0028C1
0x0028BA -z-- 01:E8AA:  LDA #$C8  ; 
0x0028BC Nz-- 01:E8AC:  STA ram_006F,X  ; $006F $0070
0x0028BE Nz-- 01:E8AE:  JMP $E8B5  ; 0028C5
; 8 refs via 002868 002873 00287B 00288C 00289D 0028AD 0028B2 0028B8
0x0028C1 ---- 01:E8B1:  DEC ram_005B  ; $005B
0x0028C3 ---- 01:E8B3:  BPL $E854  ; 002864
; 2 refs via 00285D 0028BE
0x0028C5 ---- 01:E8B5:  DEC ram_005A  ; $005A
0x0028C7 ---- 01:E8B7:  BPL $E843  ; 002853
0x0028C9 N--- 01:E8B9:  RTS  ; 00031D
0x0028CA ---- 01:E8BA:  .byte $10   ; 00282B
0x0028CB ---- 01:E8BB:  .byte $20   ; 00282B
0x0028CC ---- 01:E8BC:  .byte $30   ; 00282B
0x0028CD ---- 01:E8BD:  .byte $40   ; 00282B
; 1 refs via 0027E7
0x0028CE -zc- 01:E8BE:  LDA #$01  ; 
0x0028D0 nzc- 01:E8C0:  STA ram_0309  ; $0309
; 1 refs via 0028F4
0x0028D3 -z-- 01:E8C3:  JSR $D44D  ; 00145D
; 1 refs via 001476
0x0028D6 ---- 01:E8C6:  AND #$03  ; 
0x0028D8 ---- 01:E8C8:  JSR $E902  ; 002912
; 1 refs via 00291F
0x0028DB ---- 01:E8CB:  STA ram_0086  ; $0086
0x0028DD ---- 01:E8CD:  JSR $D44D  ; 00145D
; 1 refs via 001476
0x0028E0 ---- 01:E8D0:  AND #$03  ; 
0x0028E2 ---- 01:E8D2:  JSR $E902  ; 002912
; 1 refs via 00291F
0x0028E5 ---- 01:E8D5:  STA ram_0087  ; $0087
0x0028E7 ---- 01:E8D7:  LDA #$FF  ; 
0x0028E9 Nz-- 01:E8D9:  STA ram_0088  ; $0088
0x0028EB Nz-- 01:E8DB:  LDA #$00  ; 
0x0028ED nZ-- 01:E8DD:  STA ram_0062  ; $0062
0x0028EF nZ-- 01:E8DF:  JSR $E972  ; 002982
; 1 refs via 0029F1
0x0028F2 ---- 01:E8E2:  LDA ram_0062  ; $0062
0x0028F4 ---- 01:E8E4:  BNE $E8C3  ; 0028D3
0x0028F6 -Z-- 01:E8E6:  JSR $D44D  ; 00145D
; 1 refs via 001476
0x0028F9 ---- 01:E8E9:  AND #$07  ; 
0x0028FB ---- 01:E8EB:  TAY  ; 
0x0028FC ---- 01:E8EC:  LDA $E8FA,Y  ; 00290A 00290B 00290C 00290D 00290E 00290F 002910 002911
0x0028FF ---- 01:E8EF:  STA ram_0088  ; $0088
0x002901 ---- 01:E8F1:  LDA #$00  ; 
0x002903 nZ-- 01:E8F3:  STA ram_0062  ; $0062
0x002905 nZ-- 01:E8F5:  LDX ram_005A  ; $005A
0x002907 ---- 01:E8F7:  LDY ram_005B  ; $005B
0x002909 ---- 01:E8F9:  RTS  ; 0027EA
0x00290A ---- 01:E8FA:  .byte $00   ; 0028FC
0x00290B ---- 01:E8FB:  .byte $01   ; 0028FC
0x00290C ---- 01:E8FC:  .byte $02   ; 0028FC
0x00290D ---- 01:E8FD:  .byte $03   ; 0028FC
0x00290E ---- 01:E8FE:  .byte $04   ; 0028FC
0x00290F ---- 01:E8FF:  .byte $05   ; 0028FC
0x002910 ---- 01:E900:  .byte $04   ; 0028FC
0x002911 ---- 01:E901:  .byte $03   ; 0028FC
; 2 refs via 0028D8 0028E2
0x002912 ---- 01:E902:  STA ram_0000  ; $0000
0x002914 ---- 01:E904:  ASL  ; 
0x002915 ---- 01:E905:  CLC  ; 
0x002916 --c- 01:E906:  ADC ram_0000  ; $0000
0x002918 ---- 01:E908:  ASL  ; 
0x002919 ---- 01:E909:  CLC  ; 
0x00291A --c- 01:E90A:  ADC #$06  ; 
0x00291C ---- 01:E90C:  ASL  ; 
0x00291D ---- 01:E90D:  ASL  ; 
0x00291E ---- 01:E90E:  ASL  ; 
0x00291F ---- 01:E90F:  RTS  ; 0028DB 0028E5
; 1 refs via 000317
0x002920 N--- 01:E910:  LDA #$09  ; 
0x002922 nz-- 01:E912:  STA ram_005A  ; $005A
; 1 refs via 00297F
0x002924 n--- 01:E914:  LDA ram_005A  ; $005A
0x002926 ---- 01:E916:  AND #$06  ; 
0x002928 ---- 01:E918:  BNE $E96D  ; 00297D
0x00292A -Z-- 01:E91A:  LDX ram_005A  ; $005A
0x00292C ---- 01:E91C:  LDA ram_00CC,X  ; $00CC $00CD $00D4 $00D5
0x00292E ---- 01:E91E:  AND #$F0  ; 
0x002930 ---- 01:E920:  CMP #$40  ; 
0x002932 ---- 01:E922:  BNE $E96D  ; 00297D
0x002934 -Z-- 01:E924:  LDA #$09  ; 
0x002936 nz-- 01:E926:  STA ram_005B  ; $005B
; 1 refs via 00297B
0x002938 n--- 01:E928:  LDA ram_005B  ; $005B
0x00293A ---- 01:E92A:  TAY  ; 
0x00293B ---- 01:E92B:  AND #$07  ; 
0x00293D ---- 01:E92D:  STA ram_0000  ; $0000
0x00293F ---- 01:E92F:  LDA ram_005A  ; $005A
0x002941 ---- 01:E931:  AND #$07  ; 
0x002943 ---- 01:E933:  CMP ram_0000  ; $0000
0x002945 ---- 01:E935:  BEQ $E969  ; 002979
0x002947 -z-- 01:E937:  LDA ram_00CC,Y  ; $00CC $00CD $00CE $00CF $00D0 $00D1 $00D2 $00D3 $00D4 $00D5
0x00294A ---- 01:E93A:  AND #$F0  ; 
0x00294C ---- 01:E93C:  CMP #$40  ; 
0x00294E ---- 01:E93E:  BNE $E969  ; 002979
0x002950 -Z-- 01:E940:  LDA ram_00B8,Y  ; $00B8 $00B9 $00BA $00BB $00BC $00BD $00BE $00BF $00C0 $00C1
0x002953 ---- 01:E943:  SEC  ; 
0x002954 --C- 01:E944:  SBC ram_00B8,X  ; $00B8 $00B9 $00C0 $00C1
0x002956 ---- 01:E946:  BPL $E94D  ; 00295D
0x002958 N--- 01:E948:  EOR #$FF  ; 
0x00295A ---- 01:E94A:  CLC  ; 
0x00295B --c- 01:E94B:  ADC #$01  ; 
; 1 refs via 002956
0x00295D ---- 01:E94D:  CMP #$06  ; 
0x00295F ---- 01:E94F:  BCS $E969  ; 002979
0x002961 --c- 01:E951:  LDA ram_00C2,Y  ; $00C2 $00C3 $00C4 $00C5 $00C6 $00C7 $00C8 $00C9 $00CA $00CB
0x002964 --c- 01:E954:  SEC  ; 
0x002965 --C- 01:E955:  SBC ram_00C2,X  ; $00C2 $00C3 $00CA $00CB
0x002967 ---- 01:E957:  BPL $E95E  ; 00296E
0x002969 N--- 01:E959:  EOR #$FF  ; 
0x00296B ---- 01:E95B:  CLC  ; 
0x00296C --c- 01:E95C:  ADC #$01  ; 
; 1 refs via 002967
0x00296E ---- 01:E95E:  CMP #$06  ; 
0x002970 ---- 01:E960:  BCS $E969  ; 002979
0x002972 --c- 01:E962:  LDA #$00  ; 
0x002974 nZc- 01:E964:  STA ram_00CC,X  ; $00CC $00CD $00D4 $00D5
0x002976 nZc- 01:E966:  STA ram_00CC,Y  ; $00CC $00CD $00CE $00CF $00D0 $00D1 $00D2 $00D3 $00D4
; 4 refs via 002945 00294E 00295F 002970
0x002979 ---- 01:E969:  DEC ram_005B  ; $005B
0x00297B ---- 01:E96B:  BPL $E928  ; 002938
; 2 refs via 002928 002932
0x00297D ---- 01:E96D:  DEC ram_005A  ; $005A
0x00297F ---- 01:E96F:  BPL $E914  ; 002924
0x002981 N--- 01:E971:  RTS  ; 00031A
; 2 refs via 00031D 0028EF
0x002982 ---- 01:E972:  LDA ram_0086  ; $0086
0x002984 ---- 01:E974:  BEQ $E9E1  ; 0029F1
0x002986 -z-- 01:E976:  LDA ram_0062  ; $0062
0x002988 ---- 01:E978:  BNE $E9E1  ; 0029F1
0x00298A -Z-- 01:E97A:  LDA #$01  ; 
0x00298C nz-- 01:E97C:  STA ram_0049  ; $0049
; 1 refs via 0029EF
0x00298E n--- 01:E97E:  LDX ram_0049  ; $0049
0x002990 ---- 01:E980:  LDA ram_00A0,X  ; $00A0 $00A1
0x002992 ---- 01:E982:  BPL $E9DD  ; 0029ED
0x002994 N--- 01:E984:  CMP #$E0  ; 
0x002996 ---- 01:E986:  BCS $E9DD  ; 0029ED
0x002998 --c- 01:E988:  LDA ram_0090,X  ; $0090 $0091
0x00299A --c- 01:E98A:  SEC  ; 
0x00299B --C- 01:E98B:  SBC ram_0086  ; $0086
0x00299D ---- 01:E98D:  BPL $E994  ; 0029A4
0x00299F N--- 01:E98F:  EOR #$FF  ; 
0x0029A1 ---- 01:E991:  CLC  ; 
0x0029A2 --c- 01:E992:  ADC #$01  ; 
; 1 refs via 00299D
0x0029A4 ---- 01:E994:  CMP #$0C  ; 
0x0029A6 ---- 01:E996:  BCS $E9DD  ; 0029ED
0x0029A8 --c- 01:E998:  LDA ram_0098,X  ; $0098 $0099
0x0029AA --c- 01:E99A:  SEC  ; 
0x0029AB --C- 01:E99B:  SBC ram_0087  ; $0087
0x0029AD ---- 01:E99D:  BPL $E9A4  ; 0029B4
0x0029AF N--- 01:E99F:  EOR #$FF  ; 
0x0029B1 ---- 01:E9A1:  CLC  ; 
0x0029B2 --c- 01:E9A2:  ADC #$01  ; 
; 1 refs via 0029AD
0x0029B4 ---- 01:E9A4:  CMP #$0C  ; 
0x0029B6 ---- 01:E9A6:  BCS $E9DD  ; 0029ED
0x0029B8 --c- 01:E9A8:  LDA #$32  ; 
0x0029BA nzc- 01:E9AA:  STA ram_0062  ; $0062
0x0029BC nzc- 01:E9AC:  LDA ram_0088  ; $0088
0x0029BE --c- 01:E9AE:  BMI $E9E1  ; 0029F1
0x0029C0 n-c- 01:E9B0:  LDA ram_0046  ; $0046
0x0029C2 --c- 01:E9B2:  CMP #$02  ; 
0x0029C4 ---- 01:E9B4:  BEQ $E9CA  ; 0029DA
0x0029C6 -z-- 01:E9B6:  LDA #$50  ; 
0x0029C8 nz-- 01:E9B8:  JSR $D9E1  ; 0019F1
; 1 refs via 001A08
0x0029CB ---- 01:E9BB:  LDX ram_0049  ; $0049
0x0029CD ---- 01:E9BD:  JSR $D9BE  ; 0019CE
; 1 refs via 0019F0
0x0029D0 N--- 01:E9C0:  JSR $D138  ; 001148
; 1 refs via 001179
0x0029D3 ---- 01:E9C3:  LDX ram_0049  ; $0049
0x0029D5 ---- 01:E9C5:  LDA #$01  ; 
0x0029D7 nz-- 01:E9C7:  STA ram_0306  ; $0306
; 1 refs via 0029C4
0x0029DA ---- 01:E9CA:  LDA ram_0088  ; $0088
0x0029DC ---- 01:E9CC:  ASL  ; 
0x0029DD ---- 01:E9CD:  TAY  ; 
0x0029DE ---- 01:E9CE:  LDA $E9E2,Y  ; 0029F2 0029F4 0029F6 0029F8 0029FA 0029FC
0x0029E1 ---- 01:E9D1:  STA ram_0011  ; $0011
0x0029E3 ---- 01:E9D3:  LDA $E9E3,Y  ; 0029F3 0029F5 0029F7 0029F9 0029FB 0029FD
0x0029E6 ---- 01:E9D6:  STA ram_0012  ; $0012
0x0029E8 ---- 01:E9D8:  PLA  ; 
0x0029E9 ---- 01:E9D9:  PLA  ; 
0x0029EA ---- 01:E9DA:  JMP (ram_0011)  ; 002A00 002A05 002A0B 002A17 002A27 002A4E
; 4 refs via 002992 002996 0029A6 0029B6
0x0029ED ---- 01:E9DD:  DEC ram_0049  ; $0049
0x0029EF ---- 01:E9DF:  BPL $E97E  ; 00298E
; 3 refs via 002984 002988 0029BE
0x0029F1 ---- 01:E9E1:  RTS  ; 000320 0028F2
0x0029F2 ---- 01:E9E2:  .byte $F0   ; 0029DE
0x0029F3 ---- 01:E9E3:  .byte $E9   ; 0029E3
0x0029F4 ---- 01:E9E4:  .byte $F5   ; 0029DE
0x0029F5 ---- 01:E9E5:  .byte $E9   ; 0029E3
0x0029F6 ---- 01:E9E6:  .byte $FB   ; 0029DE
0x0029F7 ---- 01:E9E7:  .byte $E9   ; 0029E3
0x0029F8 ---- 01:E9E8:  .byte $07   ; 0029DE
0x0029F9 ---- 01:E9E9:  .byte $EA   ; 0029E3
0x0029FA ---- 01:E9EA:  .byte $17   ; 0029DE
0x0029FB ---- 01:E9EB:  .byte $EA   ; 0029E3
0x0029FC ---- 01:E9EC:  .byte $3E   ; 0029DE
0x0029FD ---- 01:E9ED:  .byte $EA   ; 0029E3
0x0029FE ---- xx:E9EE:  .byte $48   ; 
0x0029FF ---- xx:E9EF:  .byte $EA   ; 
; 1 refs via 0029EA
0x002A00 ---- 01:E9F0:  LDA #$0A  ; 
0x002A02 nz-- 01:E9F2:  STA ram_0089,X  ; $0089
0x002A04 nz-- 01:E9F4:  RTS  ; 000213 00043C
; 1 refs via 0029EA
0x002A05 ---- 01:E9F5:  LDA #$0A  ; 
0x002A07 nz-- 01:E9F7:  STA ram_0100  ; $0100
0x002A0A nz-- 01:E9FA:  RTS  ; 000213
; 1 refs via 0029EA
0x002A0B ---- 01:E9FB:  LDA ram_0068  ; $0068
0x002A0D ---- 01:E9FD:  BPL $EA06  ; 002A16
0x002A0F N--- 01:E9FF:  JSR $CB9E  ; 000BAE
; 1 refs via 000C17
0x002A12 ---- 01:EA02:  LDA #$14  ; 
0x002A14 nz-- 01:EA04:  STA ram_0045  ; $0045
; 1 refs via 002A0D
0x002A16 n--- 01:EA06:  RTS  ; 000213
; 1 refs via 0029EA
0x002A17 ---- 01:EA07:  LDA ram_0101,X  ; $0101 $0102
0x002A1A ---- 01:EA0A:  CMP #$60  ; 
0x002A1C ---- 01:EA0C:  BEQ $EA16  ; 002A26
0x002A1E -z-- 01:EA0E:  CLC  ; 
0x002A1F -zc- 01:EA0F:  ADC #$20  ; 
0x002A21 ---- 01:EA11:  STA ram_0101,X  ; $0101 $0102
0x002A24 ---- 01:EA14:  STA ram_00A8,X  ; $00A8 $00A9
; 1 refs via 002A1C
0x002A26 ---- 01:EA16:  RTS  ; 000213 000251 00043C
; 1 refs via 0029EA
0x002A27 ---- 01:EA17:  LDA #$07  ; 
0x002A29 nz-- 01:EA19:  STA ram_005A  ; $005A
0x002A2B nz-- 01:EA1B:  LDA #$01  ; 
0x002A2D nz-- 01:EA1D:  STA ram_030A  ; $030A
; 1 refs via 002A4B
0x002A30 -z-- 01:EA20:  LDY ram_005A  ; $005A
0x002A32 ---- 01:EA22:  LDA ram_00A0,Y  ; $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x002A35 ---- 01:EA25:  BPL $EA35  ; 002A45
0x002A37 N--- 01:EA27:  CMP #$E0  ; 
0x002A39 ---- 01:EA29:  BCS $EA35  ; 002A45
0x002A3B --c- 01:EA2B:  LDA #$73  ; 
0x002A3D nzc- 01:EA2D:  STA ram_00A0,Y  ; $00A2 $00A3 $00A4 $00A5 $00A6 $00A7
0x002A40 nzc- 01:EA30:  LDA #$00  ; 
0x002A42 nZc- 01:EA32:  STA ram_00A8,Y  ; $00AA $00AB $00AC $00AD $00AE $00AF
; 2 refs via 002A35 002A39
0x002A45 ---- 01:EA35:  DEC ram_005A  ; $005A
0x002A47 ---- 01:EA37:  LDA ram_005A  ; $005A
0x002A49 ---- 01:EA39:  CMP #$01  ; 
0x002A4B ---- 01:EA3B:  BNE $EA20  ; 002A30
0x002A4D -Z-- 01:EA3D:  RTS  ; 000213 000251
; 1 refs via 0029EA
0x002A4E ---- 01:EA3E:  INC ram_0051,X  ; $0051 $0052
0x002A50 ---- 01:EA40:  LDA #$01  ; 
0x002A52 nz-- 01:EA42:  STA ram_0304  ; $0304
0x002A55 nz-- 01:EA45:  STA ram_0305  ; $0305
0x002A58 nz-- 01:EA48:  RTS  ; 000213 00043C
0x002A59 ---- 01:EA49:  .byte $00   ; 002632
0x002A5A ---- 01:EA4A:  .byte $FF   ; 002632
0x002A5B ---- 01:EA4B:  .byte $00   ; 002632
0x002A5C ---- 01:EA4C:  .byte $01   ; 002632
0x002A5D ---- 01:EA4D:  .byte $FF   ; 002642
0x002A5E ---- 01:EA4E:  .byte $00   ; 002642
0x002A5F ---- 01:EA4F:  .byte $01   ; 002642
0x002A60 ---- 01:EA50:  .byte $00   ; 002642
; 4 refs via 00016C 000263 00064E 0014EF
0x002A61 ---- 01:EA51:  LDA #$0F  ; 
0x002A63 nz-- 01:EA53:  STA $4015  ; $4015
0x002A66 nz-- 01:EA56:  LDA #$C0  ; 
0x002A68 Nz-- 01:EA58:  STA $4017  ; $4017
0x002A6B Nz-- 01:EA5B:  LDA #$1C  ; 
0x002A6D nz-- 01:EA5D:  STA ram_00F0  ; $00F0
0x002A6F nz-- 01:EA5F:  LDA #$03  ; 
0x002A71 nz-- 01:EA61:  STA ram_00F1  ; $00F1
0x002A73 nz-- 01:EA63:  LDX #$00  ; 
0x002A75 nZ-- 01:EA65:  LDY #$00  ; 
; 1 refs via 002A8B
0x002A77 ---- 01:EA67:  TYA  ; 
0x002A78 ---- 01:EA68:  STA (ram_00F0),Y  ; $031C $0324 $032C $0334 $033C $0344 $034C $0354 $035C $0364 $036C $0374 $037C $0384 $038C $0394 $039C $03A4 $03AC $03B4 $03BC $03C4 $03CC $03D4 $03DC $03E4 $03EC $03F4
0x002A7A ---- 01:EA6A:  STA ram_0300,X  ; $0300 $0301 $0302 $0303 $0304 $0305 $0306 $0307 $0308 $0309 $030A $030B $030C $030D $030E $030F $0310 $0311 $0312 $0313 $0314 $0315 $0316 $0317 $0318 $0319 $031A $031B
0x002A7D ---- 01:EA6D:  CLC  ; 
0x002A7E --c- 01:EA6E:  LDA ram_00F0  ; $00F0
0x002A80 --c- 01:EA70:  ADC #$08  ; 
0x002A82 ---- 01:EA72:  STA ram_00F0  ; $00F0
0x002A84 ---- 01:EA74:  BCC $EA78  ; 002A88
0x002A86 ---- xx:EA76:  .byte $E6   ; 
0x002A87 ---- xx:EA77:  .byte $F1   ; 
; 1 refs via 002A84
0x002A88 --c- 01:EA78:  INX  ; 
0x002A89 --c- 01:EA79:  CPX #$1C  ; 
0x002A8B ---- 01:EA7B:  BNE $EA67  ; 002A77
0x002A8D -Z-- 01:EA7D:  RTS  ; 00016F 000266 000651 0014F2
; 1 refs via 001449
0x002A8E -Z-- 01:EA7E:  LDA ram_006D  ; $006D
0x002A90 ---- 01:EA80:  BNE $EA88  ; 002A98
0x002A92 -Z-- 01:EA82:  LDA #$1C  ; 
0x002A94 nz-- 01:EA84:  STA ram_00F5  ; $00F5
0x002A96 nz-- 01:EA86:  BPL $EA8C  ; 002A9C
; 1 refs via 002A90
0x002A98 -z-- 01:EA88:  LDA #$01  ; 
0x002A9A nz-- 01:EA8A:  STA ram_00F5  ; $00F5
; 1 refs via 002A96
0x002A9C nz-- 01:EA8C:  LDA #$00  ; 
0x002A9E nZ-- 01:EA8E:  LDX #$03  ; 
; 1 refs via 002AA3
0x002AA0 n--- 01:EA90:  STA ram_00F9,X  ; $00F9 $00FA $00FB $00FC
0x002AA2 n--- 01:EA92:  DEX  ; 
0x002AA3 ---- 01:EA93:  BPL $EA90  ; 002AA0
0x002AA5 N--- 01:EA95:  LDA #$00  ; 
0x002AA7 nZ-- 01:EA97:  STA ram_00F4  ; $00F4
0x002AA9 nZ-- 01:EA99:  LDA #$1C  ; 
0x002AAB nz-- 01:EA9B:  STA ram_00F0  ; $00F0
0x002AAD nz-- 01:EA9D:  LDA #$03  ; 
0x002AAF nz-- 01:EA9F:  STA ram_00F1  ; $00F1
; 1 refs via 002B04
0x002AB1 ---- 01:EAA1:  LDX ram_00F4  ; $00F4
0x002AB3 ---- 01:EAA3:  LDA ram_0300,X  ; $0300 $0301 $0302 $0303 $0304 $0305 $0306 $0307 $0308 $0309 $030A $030B $030C $030D $030E $030F $0310 $0311 $0312 $0313 $0314 $0315 $0316 $0317 $0318 $0319 $031A $031B
0x002AB6 ---- 01:EAA6:  BEQ $EAE3  ; 002AF3
0x002AB8 -z-- 01:EAA8:  LDY #$00  ; 
0x002ABA nZ-- 01:EAAA:  LDA (ram_00F0),Y  ; $031C $0324 $032C $0334 $033C $0344 $034C $0354 $0364 $036C $0374 $037C $0384 $038C $0394 $039C $03A4 $03AC $03B4 $03BC $03C4 $03CC $03D4 $03DC $03E4 $03EC $03F4
0x002ABC ---- 01:EAAC:  BEQ $EAE3  ; 002AF3
0x002ABE -z-- 01:EAAE:  CMP #$05  ; 
0x002AC0 ---- 01:EAB0:  BCC $EABD  ; 002ACD
0x002AC2 --C- 01:EAB2:  SEC  ; 
0x002AC3 --C- 01:EAB3:  SBC #$05  ; 
0x002AC5 ---- 01:EAB5:  TAX  ; 
0x002AC6 ---- 01:EAB6:  LDA #$01  ; 
0x002AC8 nz-- 01:EAB8:  STA ram_00F9,X  ; $00F9 $00FA $00FB $00FC
0x002ACA nz-- 01:EABA:  JMP $EAE3  ; 002AF3
; 1 refs via 002AC0
0x002ACD --c- 01:EABD:  TAX  ; 
0x002ACE --c- 01:EABE:  DEX  ; 
0x002ACF --c- 01:EABF:  LDA ram_00F9,X  ; $00F9 $00FA $00FB $00FC
0x002AD1 --c- 01:EAC1:  BNE $EAE3  ; 002AF3
0x002AD3 -Zc- 01:EAC3:  LDA #$01  ; 
0x002AD5 nzc- 01:EAC5:  STA ram_00F9,X  ; $00F9 $00FA $00FB $00FC
0x002AD7 nzc- 01:EAC7:  TXA  ; 
0x002AD8 --c- 01:EAC8:  TAY  ; 
0x002AD9 --c- 01:EAC9:  CLC  ; 
0x002ADA --c- 01:EACA:  ADC #$05  ; 
0x002ADC ---- 01:EACC:  LDY #$00  ; 
0x002ADE nZ-- 01:EACE:  STA (ram_00F0),Y  ; $031C $0324 $032C $0334 $033C $0344 $034C $0354 $0364 $036C $0374 $037C $0384 $038C $0394 $039C $03A4 $03AC $03B4 $03BC $03C4 $03CC $03D4 $03DC $03E4 $03EC $03F4
0x002AE0 nZ-- 01:EAD0:  TXA  ; 
0x002AE1 ---- 01:EAD1:  ASL  ; 
0x002AE2 ---- 01:EAD2:  ASL  ; 
0x002AE3 ---- 01:EAD3:  TAX  ; 
0x002AE4 ---- 01:EAD4:  LDA #$04  ; 
0x002AE6 nz-- 01:EAD6:  STA ram_00FD  ; $00FD
; 1 refs via 002AF1
0x002AE8 -z-- 01:EAD8:  INY  ; 
0x002AE9 ---- 01:EAD9:  LDA (ram_00F0),Y  ; $031D $031E $031F $0320 $0325 $0326 $0327 $0328 $032D $032E $032F $0330 $0335 $0336 $0337 $0338 $033D $033E $033F $0340 $0345 $0346 $0347 $0348 $034D $034E $034F $0350 $0355 $0356 $0357 $0358 $0365 $0366 $0367 $0368 $036D $036E $036F $0370 $0375 $0376 $0377 $0378 $037D $037E $037F $0380 $0385 $0386 $0387 $0388 $038D $038E $038F $0390 $0395 $0396 $0397 $0398 $039D $039E $039F $03A0 $03A5 $03A6 $03A7 $03A8 $03AD $03AE $03AF $03B0 $03B5 $03B6 $03B7 $03B8 $03BD $03BE $03BF $03C0 $03C5 $03C6 $03C7 $03C8 $03CD $03CE $03CF $03D0 $03D5 $03D6 $03D7 $03D8 $03DD $03DE $03DF $03E0 $03E5 $03E6 $03E7 $03E8 $03ED $03EE $03EF $03F0 $03F5 $03F6 $03F7 $03F8
0x002AEB ---- 01:EADB:  STA $4000,X  ; $4000 $4001 $4002 $4003 $4004 $4005 $4006 $4007 $4008 $4009 $400A $400B $400C $400D $400E $400F
0x002AEE ---- 01:EADE:  INX  ; 
0x002AEF ---- 01:EADF:  DEC ram_00FD  ; $00FD
0x002AF1 ---- 01:EAE1:  BNE $EAD8  ; 002AE8
; 4 refs via 002AB6 002ABC 002ACA 002AD1
0x002AF3 ---- 01:EAE3:  CLC  ; 
0x002AF4 --c- 01:EAE4:  LDA ram_00F0  ; $00F0
0x002AF6 --c- 01:EAE6:  ADC #$08  ; 
0x002AF8 ---- 01:EAE8:  STA ram_00F0  ; $00F0
0x002AFA ---- 01:EAEA:  BCC $EAEE  ; 002AFE
0x002AFC ---- xx:EAEC:  .byte $E6   ; 
0x002AFD ---- xx:EAED:  .byte $F1   ; 
; 1 refs via 002AFA
0x002AFE --c- 01:EAEE:  INC ram_00F4  ; $00F4
0x002B00 --c- 01:EAF0:  LDA ram_00F4  ; $00F4
0x002B02 --c- 01:EAF2:  CMP ram_00F5  ; $00F5
0x002B04 ---- 01:EAF4:  BCC $EAA1  ; 002AB1
0x002B06 --C- 01:EAF6:  LDX #$00  ; 
; 1 refs via 002B1F
0x002B08 ---- 01:EAF8:  STX ram_00FD  ; $00FD
0x002B0A ---- 01:EAFA:  LDA ram_00F9,X  ; $00F9 $00FA $00FB $00FC
0x002B0C ---- 01:EAFC:  BNE $EB0A  ; 002B1A
0x002B0E -Z-- 01:EAFE:  TXA  ; 
0x002B0F ---- 01:EAFF:  ASL  ; 
0x002B10 ---- 01:EB00:  ASL  ; 
0x002B11 ---- 01:EB01:  TAX  ; 
0x002B12 ---- 01:EB02:  ASL  ; 
0x002B13 ---- 01:EB03:  AND #$10  ; 
0x002B15 ---- 01:EB05:  EOR #$10  ; 
0x002B17 ---- 01:EB07:  STA $4000,X  ; $4000 $4004 $4008 $400C
; 1 refs via 002B0C
0x002B1A ---- 01:EB0A:  LDX ram_00FD  ; $00FD
0x002B1C ---- 01:EB0C:  INX  ; 
0x002B1D ---- 01:EB0D:  CPX #$04  ; 
0x002B1F ---- 01:EB0F:  BCC $EAF8  ; 002B08
0x002B21 --C- 01:EB11:  LDY #$00  ; 
0x002B23 nZC- 01:EB13:  STY ram_00F4  ; $00F4
0x002B25 nZC- 01:EB15:  LDA #$1C  ; 
0x002B27 nzC- 01:EB17:  STA ram_00F0  ; $00F0
0x002B29 nzC- 01:EB19:  LDA #$03  ; 
0x002B2B nzC- 01:EB1B:  STA ram_00F1  ; $00F1
; 1 refs via 002B4F
0x002B2D ---- 01:EB1D:  LDX ram_00F4  ; $00F4
0x002B2F ---- 01:EB1F:  LDA ram_0300,X  ; $0300 $0301 $0302 $0303 $0304 $0305 $0306 $0307 $0308 $0309 $030A $030B $030C $030D $030E $030F $0310 $0311 $0312 $0313 $0314 $0315 $0316 $0317 $0318 $0319 $031A $031B
0x002B32 ---- 01:EB22:  BEQ $EB2E  ; 002B3E
0x002B34 -z-- 01:EB24:  CMP #$01  ; 
0x002B36 ---- 01:EB26:  BNE $EB42  ; 002B52
0x002B38 -Z-- 01:EB28:  INC ram_0300,X  ; $0300 $0301 $0302 $0303 $0304 $0305 $0306 $0307 $0309 $030A $030B $030C $030D $030E $030F $0310 $0311 $0312 $0313 $0314 $0315 $0316 $0317 $0318 $0319 $031A $031B
0x002B3B ---- 01:EB2B:  JMP $EB4F  ; 002B5F
; 4 refs via 002B32 002B5D 002BEE 002C2E
0x002B3E ---- 01:EB2E:  CLC  ; 
0x002B3F --c- 01:EB2F:  LDA ram_00F0  ; $00F0
0x002B41 --c- 01:EB31:  ADC #$08  ; 
0x002B43 ---- 01:EB33:  STA ram_00F0  ; $00F0
0x002B45 ---- 01:EB35:  BCC $EB39  ; 002B49
0x002B47 ---- xx:EB37:  .byte $E6   ; 
0x002B48 ---- xx:EB38:  .byte $F1   ; 
; 1 refs via 002B45
0x002B49 --c- 01:EB39:  INC ram_00F4  ; $00F4
0x002B4B --c- 01:EB3B:  LDA ram_00F4  ; $00F4
0x002B4D --c- 01:EB3D:  CMP ram_00F5  ; $00F5
0x002B4F ---- 01:EB3F:  BCC $EB1D  ; 002B2D
0x002B51 --C- 01:EB41:  RTS  ; 00144C
; 1 refs via 002B36
0x002B52 -z-- 01:EB42:  LDY #$07  ; 
0x002B54 nz-- 01:EB44:  LDA (ram_00F0),Y  ; $0323 $032B $0333 $033B $0343 $034B $0353 $035B $036B $0373 $037B $0383 $038B $0393 $039B $03A3 $03AB $03B3 $03BB $03C3 $03CB $03D3 $03DB $03E3 $03EB $03F3 $03FB
0x002B56 ---- 01:EB46:  SEC  ; 
0x002B57 --C- 01:EB47:  SBC #$01  ; 
0x002B59 ---- 01:EB49:  STA (ram_00F0),Y  ; $0323 $032B $0333 $033B $0343 $034B $0353 $035B $036B $0373 $037B $0383 $038B $0393 $039B $03A3 $03AB $03B3 $03BB $03C3 $03CB $03D3 $03DB $03E3 $03EB $03F3 $03FB
0x002B5B ---- 01:EB4B:  BEQ $EB85  ; 002B95
0x002B5D -z-- 01:EB4D:  BNE $EB2E  ; 002B3E
; 1 refs via 002B3B
0x002B5F ---- 01:EB4F:  LDA #$00  ; 
0x002B61 nZ-- 01:EB51:  LDY #$05  ; 
0x002B63 nz-- 01:EB53:  STA (ram_00F0),Y  ; $0321 $0329 $0331 $0339 $0341 $0349 $0351 $0359 $0369 $0371 $0379 $0381 $0389 $0391 $0399 $03A1 $03A9 $03B1 $03B9 $03C1 $03C9 $03D1 $03D9 $03E1 $03E9 $03F1 $03F9
0x002B65 nz-- 01:EB55:  JSR $ECAF  ; 002CBF
; 1 refs via 002CCD
0x002B68 ---- 01:EB58:  JSR $ECBE  ; 002CCE
; 1 refs via 002CDF
0x002B6B ---- 01:EB5B:  LDY #$00  ; 
0x002B6D nZ-- 01:EB5D:  STA (ram_00F0),Y  ; $031C $0324 $032C $0334 $033C $0344 $034C $0354 $0364 $036C $0374 $037C $0384 $038C $0394 $039C $03A4 $03AC $03B4 $03BC $03C4 $03CC $03D4 $03DC $03E4 $03EC $03F4
0x002B6F nZ-- 01:EB5F:  JSR $ECBE  ; 002CCE
; 1 refs via 002CDF
0x002B72 ---- 01:EB62:  LDY #$01  ; 
0x002B74 nz-- 01:EB64:  STA (ram_00F0),Y  ; $031D $0325 $032D $0335 $033D $0345 $034D $0355 $0365 $036D $0375 $037D $0385 $038D $0395 $039D $03A5 $03AD $03B5 $03BD $03C5 $03CD $03D5 $03DD $03E5 $03ED $03F5
0x002B76 nz-- 01:EB66:  JSR $ECBE  ; 002CCE
; 1 refs via 002CDF
0x002B79 ---- 01:EB69:  LDY #$02  ; 
0x002B7B nz-- 01:EB6B:  STA (ram_00F0),Y  ; $031E $0326 $032E $0336 $033E $0346 $034E $0356 $0366 $036E $0376 $037E $0386 $038E $0396 $039E $03A6 $03AE $03B6 $03BE $03C6 $03CE $03D6 $03DE $03E6 $03EE $03F6
0x002B7D nz-- 01:EB6D:  JSR $ECBE  ; 002CCE
; 1 refs via 002CDF
0x002B80 ---- 01:EB70:  LDY #$04  ; 
0x002B82 nz-- 01:EB72:  STA (ram_00F0),Y  ; $0320 $0328 $0330 $0338 $0340 $0348 $0350 $0358 $0368 $0370 $0378 $0380 $0388 $0390 $0398 $03A0 $03A8 $03B0 $03B8 $03C0 $03C8 $03D0 $03D8 $03E0 $03E8 $03F0 $03F8
0x002B84 nz-- 01:EB74:  LDY #$00  ; 
0x002B86 nZ-- 01:EB76:  LDA (ram_00F0),Y  ; $031C $0324 $032C $0334 $033C $0344 $034C $0354 $0364 $036C $0374 $037C $0384 $038C $0394 $039C $03A4 $03AC $03B4 $03BC $03C4 $03CC $03D4 $03DC $03E4 $03EC $03F4
0x002B88 ---- 01:EB78:  CMP #$04  ; 
0x002B8A ---- 01:EB7A:  BNE $EB88  ; 002B98
0x002B8C -Z-- 01:EB7C:  JSR $ECBE  ; 002CCE
; 1 refs via 002CDF
0x002B8F ---- 01:EB7F:  LDY #$03  ; 
0x002B91 nz-- 01:EB81:  STA (ram_00F0),Y  ; $0357 $036F $03BF
0x002B93 nz-- 01:EB83:  BPL $EB88  ; 002B98
; 1 refs via 002B5B
0x002B95 -Z-- 01:EB85:  JSR $ECAF  ; 002CBF
; 9 refs via 002B8A 002B93 002BAB 002C52 002C82 002C8E 002CB2 002CBC 002CCD
0x002B98 ---- 01:EB88:  JSR $ECBE  ; 002CCE
; 1 refs via 002CDF
0x002B9B ---- 01:EB8B:  CMP #$E8  ; 
0x002B9D ---- 01:EB8D:  BCS $EBE1  ; 002BF1
0x002B9F --c- 01:EB8F:  CMP #$60  ; 
0x002BA1 ---- 01:EB91:  BEQ $EBD7  ; 002BE7
0x002BA3 -z-- 01:EB93:  BCC $EB9E  ; 002BAE
0x002BA5 -zC- 01:EB95:  SBC #$60  ; 
0x002BA7 ---- 01:EB97:  LDY #$06  ; 
0x002BA9 nz-- 01:EB99:  STA (ram_00F0),Y  ; $0322 $032A $0332 $033A $0342 $034A $0352 $035A $036A $0372 $037A $0382 $038A $0392 $039A $03A2 $03AA $03B2 $03BA $03C2 $03CA $03D2 $03DA $03E2 $03EA $03F2 $03FA
0x002BAB nz-- 01:EB9B:  JMP $EB88  ; 002B98
; 1 refs via 002BA3
0x002BAE -zc- 01:EB9E:  PHA  ; 
0x002BAF -zc- 01:EB9F:  AND #$F8  ; 
0x002BB1 --c- 01:EBA1:  LSR  ; 
0x002BB2 ---- 01:EBA2:  LSR  ; 
0x002BB3 ---- 01:EBA3:  TAX  ; 
0x002BB4 ---- 01:EBA4:  LDA $ECE6,X  ; 002CF6 002CF8 002CFA 002CFC 002CFE 002D00 002D02 002D04 002D06 002D08 002D0A 002D0C
0x002BB7 ---- 01:EBA7:  STA ram_00FD  ; $00FD
0x002BB9 ---- 01:EBA9:  LDA $ECE7,X  ; 002CF7 002CF9 002CFB 002CFD 002CFF 002D01 002D03 002D05 002D07 002D09 002D0B 002D0D
0x002BBC ---- 01:EBAC:  STA ram_00FE  ; $00FE
0x002BBE ---- 01:EBAE:  PLA  ; 
0x002BBF ---- 01:EBAF:  AND #$07  ; 
0x002BC1 ---- 01:EBB1:  BEQ $EBBB  ; 002BCB
0x002BC3 -z-- 01:EBB3:  TAX  ; 
; 1 refs via 002BC9
0x002BC4 ---- 01:EBB4:  LSR ram_00FD  ; $00FD
0x002BC6 ---- 01:EBB6:  ROR ram_00FE  ; $00FE
0x002BC8 ---- 01:EBB8:  DEX  ; 
0x002BC9 ---- 01:EBB9:  BNE $EBB4  ; 002BC4
; 1 refs via 002BC1
0x002BCB -Z-- 01:EBBB:  LDY #$04  ; 
0x002BCD nz-- 01:EBBD:  LDA (ram_00F0),Y  ; $0320 $0328 $0330 $0338 $0340 $0348 $0350 $0358 $0368 $0370 $0378 $0380 $0388 $0390 $0398 $03A0 $03A8 $03B0 $03B8 $03C0 $03C8 $03D0 $03D8 $03E0 $03E8 $03F0 $03F8
0x002BCF ---- 01:EBBF:  AND #$F8  ; 
0x002BD1 ---- 01:EBC1:  ORA ram_00FD  ; $00FD
0x002BD3 ---- 01:EBC3:  STA (ram_00F0),Y  ; $0320 $0328 $0330 $0338 $0340 $0348 $0350 $0358 $0368 $0370 $0378 $0380 $0388 $0390 $0398 $03A0 $03A8 $03B0 $03B8 $03C0 $03C8 $03D0 $03D8 $03E0 $03E8 $03F0 $03F8
0x002BD5 ---- 01:EBC5:  LDA ram_00FE  ; $00FE
0x002BD7 ---- 01:EBC7:  DEY  ; 
0x002BD8 ---- 01:EBC8:  STA (ram_00F0),Y  ; $031F $0327 $032F $0337 $033F $0347 $034F $0357 $0367 $036F $0377 $037F $0387 $038F $0397 $039F $03A7 $03AF $03B7 $03BF $03C7 $03CF $03D7 $03DF $03E7 $03EF $03F7
0x002BDA ---- 01:EBCA:  LDY #$00  ; 
0x002BDC nZ-- 01:EBCC:  LDA (ram_00F0),Y  ; $031C $0324 $032C $0334 $033C $0344 $034C $0354 $0364 $036C $0374 $037C $0384 $038C $0394 $039C $03A4 $03AC $03B4 $03BC $03C4 $03CC $03D4 $03DC $03E4 $03EC $03F4
0x002BDE ---- 01:EBCE:  CMP #$05  ; 
0x002BE0 ---- 01:EBD0:  BCC $EBD7  ; 002BE7
0x002BE2 --C- 01:EBD2:  SEC  ; 
0x002BE3 --C- 01:EBD3:  SBC #$04  ; 
0x002BE5 ---- 01:EBD5:  STA (ram_00F0),Y  ; $031C $0324 $032C $0334 $033C $0344 $034C $0354 $0364 $036C $0374 $037C $0384 $038C $039C $03A4 $03AC $03C4 $03CC $03D4 $03DC $03E4 $03EC $03F4
; 2 refs via 002BA1 002BE0
0x002BE7 ---- 01:EBD7:  LDY #$06  ; 
0x002BE9 nz-- 01:EBD9:  LDA (ram_00F0),Y  ; $0322 $032A $0332 $033A $0342 $034A $0352 $035A $036A $0372 $037A $0382 $038A $0392 $039A $03A2 $03AA $03B2 $03BA $03C2 $03CA $03D2 $03DA $03E2 $03EA $03F2 $03FA
0x002BEB ---- 01:EBDB:  INY  ; 
0x002BEC ---- 01:EBDC:  STA (ram_00F0),Y  ; $0323 $032B $0333 $033B $0343 $034B $0353 $035B $036B $0373 $037B $0383 $038B $0393 $039B $03A3 $03AB $03B3 $03BB $03C3 $03CB $03D3 $03DB $03E3 $03EB $03F3 $03FB
0x002BEE ---- 01:EBDE:  JMP $EB2E  ; 002B3E
; 1 refs via 002B9D
0x002BF1 --C- 01:EBE1:  SBC #$E8  ; 
0x002BF3 ---- 01:EBE3:  JSR $ECD0  ; 002CE0
0x002BF6 ---- 01:EBE6:  .byte $0A   ; 002CE9
0x002BF7 ---- 01:EBE7:  .byte $EC   ; 002CED
0x002BF8 ---- xx:EBE8:  .byte $21   ; 
0x002BF9 ---- xx:EBE9:  .byte $EC   ; 
0x002BFA ---- 01:EBEA:  .byte $33   ; 002CE9
0x002BFB ---- 01:EBEB:  .byte $EC   ; 002CED
0x002BFC ---- xx:EBEC:  .byte $45   ; 
0x002BFD ---- xx:EBED:  .byte $EC   ; 
0x002BFE ---- xx:EBEE:  .byte $57   ; 
0x002BFF ---- xx:EBEF:  .byte $EC   ; 
0x002C00 ---- xx:EBF0:  .byte $61   ; 
0x002C01 ---- xx:EBF1:  .byte $EC   ; 
0x002C02 ---- 01:EBF2:  .byte $6B   ; 002CE9
0x002C03 ---- 01:EBF3:  .byte $EC   ; 002CED
0x002C04 ---- 01:EBF4:  .byte $75   ; 002CE9
0x002C05 ---- 01:EBF5:  .byte $EC   ; 002CED
0x002C06 ---- 01:EBF6:  .byte $81   ; 002CE9
0x002C07 ---- 01:EBF7:  .byte $EC   ; 002CED
0x002C08 ---- 01:EBF8:  .byte $85   ; 002CE9
0x002C09 ---- 01:EBF9:  .byte $EC   ; 002CED
0x002C0A ---- 01:EBFA:  .byte $88   ; 002CE9
0x002C0B ---- 01:EBFB:  .byte $EC   ; 002CED
0x002C0C ---- xx:EBFC:  .byte $99   ; 
0x002C0D ---- xx:EBFD:  .byte $EC   ; 
0x002C0E ---- xx:EBFE:  .byte $99   ; 
0x002C0F ---- xx:EBFF:  .byte $EC   ; 
0x002C10 ---- xx:EC00:  .byte $99   ; 
0x002C11 ---- xx:EC01:  .byte $EC   ; 
0x002C12 ---- xx:EC02:  .byte $99   ; 
0x002C13 ---- xx:EC03:  .byte $EC   ; 
0x002C14 ---- xx:EC04:  .byte $99   ; 
0x002C15 ---- xx:EC05:  .byte $EC   ; 
0x002C16 ---- xx:EC06:  .byte $99   ; 
0x002C17 ---- xx:EC07:  .byte $EC   ; 
0x002C18 ---- 01:EC08:  .byte $A5   ; 002CE9
0x002C19 ---- 01:EC09:  .byte $EC   ; 002CED
; 1 refs via 002CF3
0x002C1A ---- 01:EC0A:  LDX ram_00F4  ; $00F4
0x002C1C ---- 01:EC0C:  LDA #$00  ; 
0x002C1E nZ-- 01:EC0E:  STA ram_0300,X  ; $0300 $0301 $0302 $0303 $0304 $0305 $0306 $0307 $0309 $030A $030B $030C $030D $030E $030F $0310 $0313 $0314 $0315 $0316 $0317 $0318 $0319 $031A $031B
0x002C21 nZ-- 01:EC11:  LDY #$00  ; 
0x002C23 nZ-- 01:EC13:  STA (ram_00F0),Y  ; $031C $0324 $032C $0334 $033C $0344 $034C $0354 $0364 $036C $0374 $037C $0384 $038C $0394 $039C $03B4 $03BC $03C4 $03CC $03D4 $03DC $03E4 $03EC $03F4
0x002C25 nZ-- 01:EC15:  LDY #$05  ; 
0x002C27 nz-- 01:EC17:  LDA (ram_00F0),Y  ; $0321 $0329 $0331 $0339 $0341 $0349 $0351 $0359 $0369 $0371 $0379 $0381 $0389 $0391 $0399 $03A1 $03B9 $03C1 $03C9 $03D1 $03D9 $03E1 $03E9 $03F1 $03F9
0x002C29 ---- 01:EC19:  SEC  ; 
0x002C2A --C- 01:EC1A:  SBC #$01  ; 
0x002C2C ---- 01:EC1C:  STA (ram_00F0),Y  ; $0321 $0329 $0331 $0339 $0341 $0349 $0351 $0359 $0369 $0371 $0379 $0381 $0389 $0391 $0399 $03A1 $03B9 $03C1 $03C9 $03D1 $03D9 $03E1 $03E9 $03F1 $03F9
0x002C2E ---- 01:EC1E:  JMP $EB2E  ; 002B3E
0x002C31 ---- xx:EC21:  .byte $20   ; 
0x002C32 ---- xx:EC22:  .byte $BE   ; 
0x002C33 ---- xx:EC23:  .byte $EC   ; 
0x002C34 ---- xx:EC24:  .byte $85   ; 
0x002C35 ---- xx:EC25:  .byte $FD   ; 
0x002C36 ---- xx:EC26:  .byte $A0   ; 
0x002C37 ---- xx:EC27:  .byte $01   ; 
0x002C38 ---- xx:EC28:  .byte $B1   ; 
0x002C39 ---- xx:EC29:  .byte $F0   ; 
0x002C3A ---- xx:EC2A:  .byte $29   ; 
0x002C3B ---- xx:EC2B:  .byte $3F   ; 
0x002C3C ---- xx:EC2C:  .byte $05   ; 
0x002C3D ---- xx:EC2D:  .byte $FD   ; 
0x002C3E ---- xx:EC2E:  .byte $91   ; 
0x002C3F ---- xx:EC2F:  .byte $F0   ; 
0x002C40 ---- xx:EC30:  .byte $4C   ; 
0x002C41 ---- xx:EC31:  .byte $88   ; 
0x002C42 ---- xx:EC32:  .byte $EB   ; 
; 1 refs via 002CF3
0x002C43 ---- 01:EC33:  JSR $ECBE  ; 002CCE
; 1 refs via 002CDF
0x002C46 ---- 01:EC36:  STA ram_00FD  ; $00FD
0x002C48 ---- 01:EC38:  LDY #$01  ; 
0x002C4A nz-- 01:EC3A:  LDA (ram_00F0),Y  ; $0345 $0355 $036D $038D $03C5 $03CD
0x002C4C ---- 01:EC3C:  AND #$C0  ; 
0x002C4E ---- 01:EC3E:  ORA ram_00FD  ; $00FD
0x002C50 ---- 01:EC40:  STA (ram_00F0),Y  ; $0345 $0355 $036D $038D $03C5 $03CD
0x002C52 ---- 01:EC42:  JMP $EB88  ; 002B98
0x002C55 ---- xx:EC45:  .byte $20   ; 
0x002C56 ---- xx:EC46:  .byte $BE   ; 
0x002C57 ---- xx:EC47:  .byte $EC   ; 
0x002C58 ---- xx:EC48:  .byte $85   ; 
0x002C59 ---- xx:EC49:  .byte $FD   ; 
0x002C5A ---- xx:EC4A:  .byte $A0   ; 
0x002C5B ---- xx:EC4B:  .byte $01   ; 
0x002C5C ---- xx:EC4C:  .byte $B1   ; 
0x002C5D ---- xx:EC4D:  .byte $F0   ; 
0x002C5E ---- xx:EC4E:  .byte $29   ; 
0x002C5F ---- xx:EC4F:  .byte $F0   ; 
0x002C60 ---- xx:EC50:  .byte $05   ; 
0x002C61 ---- xx:EC51:  .byte $FD   ; 
0x002C62 ---- xx:EC52:  .byte $91   ; 
0x002C63 ---- xx:EC53:  .byte $F0   ; 
0x002C64 ---- xx:EC54:  .byte $4C   ; 
0x002C65 ---- xx:EC55:  .byte $88   ; 
0x002C66 ---- xx:EC56:  .byte $EB   ; 
0x002C67 ---- xx:EC57:  .byte $20   ; 
0x002C68 ---- xx:EC58:  .byte $BE   ; 
0x002C69 ---- xx:EC59:  .byte $EC   ; 
0x002C6A ---- xx:EC5A:  .byte $A0   ; 
0x002C6B ---- xx:EC5B:  .byte $02   ; 
0x002C6C ---- xx:EC5C:  .byte $91   ; 
0x002C6D ---- xx:EC5D:  .byte $F0   ; 
0x002C6E ---- xx:EC5E:  .byte $4C   ; 
0x002C6F ---- xx:EC5F:  .byte $88   ; 
0x002C70 ---- xx:EC60:  .byte $EB   ; 
0x002C71 ---- xx:EC61:  .byte $20   ; 
0x002C72 ---- xx:EC62:  .byte $BE   ; 
0x002C73 ---- xx:EC63:  .byte $EC   ; 
0x002C74 ---- xx:EC64:  .byte $A0   ; 
0x002C75 ---- xx:EC65:  .byte $04   ; 
0x002C76 ---- xx:EC66:  .byte $91   ; 
0x002C77 ---- xx:EC67:  .byte $F0   ; 
0x002C78 ---- xx:EC68:  .byte $4C   ; 
0x002C79 ---- xx:EC69:  .byte $88   ; 
0x002C7A ---- xx:EC6A:  .byte $EB   ; 
; 1 refs via 002CF3
0x002C7B ---- 01:EC6B:  JSR $ECBE  ; 002CCE
; 1 refs via 002CDF
0x002C7E ---- 01:EC6E:  LDY #$01  ; 
0x002C80 nz-- 01:EC70:  STA (ram_00F0),Y  ; $03D5
0x002C82 nz-- 01:EC72:  JMP $EB88  ; 002B98
; 1 refs via 002CF3
0x002C85 ---- 01:EC75:  LDA #$00  ; 
0x002C87 nZ-- 01:EC77:  LDX #$02  ; 
; 1 refs via 002C8C
0x002C89 n--- 01:EC79:  STA ram_00F6,X  ; $00F6 $00F7 $00F8
0x002C8B n--- 01:EC7B:  DEX  ; 
0x002C8C ---- 01:EC7C:  BPL $EC79  ; 002C89
0x002C8E N--- 01:EC7E:  JMP $EB88  ; 002B98
; 1 refs via 002CF3
0x002C91 ---- 01:EC81:  LDX #$00  ; 
0x002C93 nZ-- 01:EC83:  BEQ $EC8A  ; 002C9A
; 1 refs via 002CF3
0x002C95 ---- 01:EC85:  LDX #$01  ; 
0x002C97 nz-- 01:EC87:  .byte $44   ; BIT opcode
; 1 refs via 002CF3
0x002C98 ---- 01:EC88:  LDX #$02  ; 
; 1 refs via 002C93
0x002C9A ---- 01:EC8A:  JSR $ECBE  ; 002CCE
; 1 refs via 002CDF
0x002C9D ---- 01:EC8D:  INC ram_00F6,X  ; $00F6 $00F7 $00F8
0x002C9F ---- 01:EC8F:  CMP ram_00F6,X  ; $00F6 $00F7 $00F8
0x002CA1 ---- 01:EC91:  BNE $ECA5  ; 002CB5
0x002CA3 -Z-- 01:EC93:  LDA #$00  ; 
0x002CA5 nZ-- 01:EC95:  STA ram_00F6,X  ; $00F6 $00F7 $00F8
0x002CA7 nZ-- 01:EC97:  BEQ $EC99  ; 002CA9
; 1 refs via 002CA7
0x002CA9 nZ-- 01:EC99:  LDY #$05  ; 
0x002CAB nz-- 01:EC9B:  LDA (ram_00F0),Y  ; $0329 $0331 $0339 $03C9 $03D1
0x002CAD ---- 01:EC9D:  CLC  ; 
0x002CAE --c- 01:EC9E:  ADC #$01  ; 
0x002CB0 ---- 01:ECA0:  STA (ram_00F0),Y  ; $0329 $0331 $0339 $03C9 $03D1
0x002CB2 ---- 01:ECA2:  JMP $EB88  ; 002B98
; 2 refs via 002CA1 002CF3
0x002CB5 ---- 01:ECA5:  JSR $ECBE  ; 002CCE
; 1 refs via 002CDF
0x002CB8 ---- 01:ECA8:  LDY #$05  ; 
0x002CBA nz-- 01:ECAA:  STA (ram_00F0),Y  ; $0329 $0331 $0339 $03A9 $03B1 $03C9 $03D1
0x002CBC nz-- 01:ECAC:  JMP $EB88  ; 002B98
; 2 refs via 002B65 002B95
0x002CBF ---- 01:ECAF:  LDA ram_00F4  ; $00F4
0x002CC1 ---- 01:ECB1:  ASL  ; 
0x002CC2 ---- 01:ECB2:  TAX  ; 
0x002CC3 ---- 01:ECB3:  LDA $ECFE,X  ; 002D0E 002D10 002D12 002D14 002D16 002D18 002D1A 002D1C 002D20 002D22 002D24 002D26 002D28 002D2A 002D2C 002D2E 002D30 002D32 002D34 002D36 002D38 002D3A 002D3C 002D3E 002D40 002D42 002D44
0x002CC6 ---- 01:ECB6:  STA ram_00F2  ; $00F2
0x002CC8 ---- 01:ECB8:  LDA $ECFF,X  ; 002D0F 002D11 002D13 002D15 002D17 002D19 002D1B 002D1D 002D21 002D23 002D25 002D27 002D29 002D2B 002D2D 002D2F 002D31 002D33 002D35 002D37 002D39 002D3B 002D3D 002D3F 002D41 002D43 002D45
0x002CCB ---- 01:ECBB:  STA ram_00F3  ; $00F3
0x002CCD ---- 01:ECBD:  RTS  ; 002B68 002B98
; 10 refs via 002B68 002B6F 002B76 002B7D 002B8C 002B98 002C43 002C7B 002C9A 002CB5
0x002CCE ---- 01:ECBE:  LDA ram_00F4  ; $00F4
0x002CD0 ---- 01:ECC0:  LDY #$05  ; 
0x002CD2 nz-- 01:ECC2:  LDA (ram_00F0),Y  ; $0321 $0329 $0331 $0339 $0341 $0349 $0351 $0359 $0369 $0371 $0379 $0381 $0389 $0391 $0399 $03A1 $03A9 $03B1 $03B9 $03C1 $03C9 $03D1 $03D9 $03E1 $03E9 $03F1 $03F9
0x002CD4 ---- 01:ECC4:  TAY  ; 
0x002CD5 ---- 01:ECC5:  LDA (ram_00F2),Y  ; 002D46 002D47 002D48 002D49 002D4A 002D4B 002D4C 002D4D 002D4E 002D4F 002D50 002D51 002D52 002D53 002D54 002D55 002D56 002D57 002D58 002D59 002D5A 002D5B 002D5C 002D5D 002D5E 002D5F 002D60 002D61 002D62 002D63 002D64 002D65 002D66 002D67 002D68 002D69 002D6A 002D6B 002D6C 002D6D 002D6E 002D6F 002D70 002D71 002D72 002D73 002D74 002D75 002D76 002D77 002D78 002D79 002D7A 002D7B 002D7C 002D7D 002D7E 002D7F 002D80 002D81 002D82 002D83 002D84 002D85 002D86 002D87 002D88 002D89 002D8A 002D8B 002D8C 002D8D 002D8E 002D8F 002D90 002D91 002D92 002D93 002D94 002D95 002D96 002D97 002D98 002D99 002D9A 002D9B 002D9C 002D9D 002D9E 002D9F 002DA0 002DA1 002DA2 002DA3 002DA4 002DA5 002DA6 002DA7 002DA8 002DA9 002DAA 002DAB 002DAC 002DAD 002DAE 002DAF 002DB0 002DB1 002DB2 002DB3 002DB4 002DB5 002DB6 002DB7 002DB8 002DB9 002DBA 002DBB 002DBC 002DBD 002DBE 002DBF 002DC0 002DC1 002DC2 002DC3 002DC4 002DC5 002DC6 002DC7 002DC8 002DC9 002DCA 002DCB 002DCC 002DCD 002DCE 002DCF 002DD0 002DD1 002DD2 002DD3 002DD4 002DD5 002DD6 002DD7 002DD8 002DD9 002DDA 002DDB 002DDC 002DDD 002DDE 002DDF 002DE0 002DE1 002DE2 002DE3 002DE4 002E04 002E05 002E06 002E07 002E08 002E09 002E0A 002E0B 002E0C 002E0D 002E0E 002E0F 002E10 002E11 002E12 002E13 002E14 002E15 002E16 002E17 002E18 002E19 002E1A 002E1B 002E1C 002E1D 002E1E 002E1F 002E20 002E21 002E22 002E23 002E24 002E25 002E26 002E27 002E28 002E29 002E2A 002E2B 002E2C 002E2D 002E2E 002E2F 002E30 002E31 002E32 002E33 002E34 002E35 002E36 002E37 002E38 002E39 002E3A 002E3B 002E3C 002E3D 002E3E 002E3F 002E40 002E41 002E42 002E43 002E44 002E45 002E46 002E47 002E48 002E49 002E4A 002E4B 002E4C 002E4D 002E4E 002E4F 002E50 002E51 002E52 002E53 002E54 002E55 002E56 002E57 002E58 002E59 002E5A 002E5B 002E5C 002E5D 002E5E 002E5F 002E60 002E61 002E62 002E63 002E64 002E65 002E66 002E67 002E68 002E69 002E6A 002E6B 002E6C 002E6D 002E6E 002E6F 002E70 002E71 002E72 002E73 002E74 002E75 002E76 002E77 002E78 002E79 002E7A 002E7B 002E7C 002E7D 002E7E 002E7F 002E80 002E81 002E82 002E83 002E84 002E85 002E86 002E87 002E88 002E89 002E8A 002E8B 002E8C 002E8D 002E8E 002E8F 002E90 002E91 002E92 002E93 002E94 002E95 002E96 002E97 002E98 002E99 002E9A 002E9B 002E9C 002E9D 002E9E 002E9F 002EA0 002EA1 002EA2 002EA3 002EA4 002EA5 002EA6 002EA7 002EA8 002EA9 002EAA 002EAB 002EAC 002EAD 002EAE 002EAF 002EB0 002EB1 002EB2 002EB3 002EB4 002EB5 002EB6 002EB7 002EB8 002EB9 002EBA 002EBB 002EBC 002EBD 002EBE 002EBF 002EC0 002EC1 002EC2 002EC3 002EC4 002EC5 002EC6 002EC7 002EC8 002EC9 002ECA 002ECB 002ECC 002ECD 002ECE 002ECF 002ED0 002ED1 002ED2 002ED3 002ED4 002ED5 002ED6 002ED7 002ED8 002ED9 002EDA 002EDB 002EDC 002EDD 002EDE 002EDF 002EE0 002EE1 002EE2 002EE3 002EE4 002EE5 002EE6 002EE7 002EE8 002EE9 002EEA 002EEB 002EEC 002EED 002EEE 002EEF 002EF0 002EF1 002EF2 002EF3 002EF4 002EF5 002EF6 002EF7 002EF8 002EF9 002EFA 002EFB 002EFC 002EFD 002EFE 002EFF 002F00 002F01 002F02 002F03 002F04 002F05 002F06 002F07 002F08 002F09 002F0A 002F0B 002F0C 002F0D 002F0E 002F0F 002F10 002F11 002F12 002F13 002F14 002F15 002F16 002F17 002F18 002F19 002F1A 002F1B 002F1C 002F1D 002F1E 002F1F 002F20 002F21 002F22 002F23 002F24 002F25 002F26 002F27 002F28 002F29 002F2A 002F2B 002F2C 002F2D 002F2E 002F2F 002F30 002F31 002F32 002F33 002F34 002F35 002F36 002F37 002F38 002F39 002F3A 002F3B 002F3C 002F3D 002F3E 002F3F 002F40 002F41 002F42 002F43 002F44 002F45 002F46 002F47 002F48 002F49 002F4A 002F4B 002F4C 002F4D 002F4E 002F4F 002F50 002F51 002F52 002F53 002F54 002F55 002F56 002F57 002F58 002F59 002F5A 002F5B 002F5C 002F5D 002F5E 002F5F 002F60 002F61 002F62 002F63 002F64 002F65 002F66 002F67 002F68 002F69 002F6A 002F6B 002F6C 002F6D 002F6E 002F6F 002F70 002F71 002F72 002F73 002F74 002F75 002F76 002F77 002F78 002F79 002F7A 002F7B 002F7C 002F7D 002F7E 002F7F 002F80 002F81 002F82 002F83 002F84
0x002CD7 ---- 01:ECC7:  PHA  ; 
0x002CD8 ---- 01:ECC8:  INY  ; 
0x002CD9 ---- 01:ECC9:  TYA  ; 
0x002CDA ---- 01:ECCA:  LDY #$05  ; 
0x002CDC nz-- 01:ECCC:  STA (ram_00F0),Y  ; $0321 $0329 $0331 $0339 $0341 $0349 $0351 $0359 $0369 $0371 $0379 $0381 $0389 $0391 $0399 $03A1 $03A9 $03B1 $03B9 $03C1 $03C9 $03D1 $03D9 $03E1 $03E9 $03F1 $03F9
0x002CDE nz-- 01:ECCE:  PLA  ; 
0x002CDF ---- 01:ECCF:  RTS  ; 002B6B 002B72 002B79 002B80 002B8F 002B9B 002C46 002C7E 002C9D 002CB8
; 1 refs via 002BF3
0x002CE0 ---- 01:ECD0:  ASL  ; 
0x002CE1 ---- 01:ECD1:  TAY  ; 
0x002CE2 ---- 01:ECD2:  INY  ; 
0x002CE3 ---- 01:ECD3:  PLA  ; 
0x002CE4 ---- 01:ECD4:  STA ram_00FD  ; $00FD
0x002CE6 ---- 01:ECD6:  PLA  ; 
0x002CE7 ---- 01:ECD7:  STA ram_00FE  ; $00FE
0x002CE9 ---- 01:ECD9:  LDA (ram_00FD),Y  ; 002BF6 002BFA 002C02 002C04 002C06 002C08 002C0A 002C18
0x002CEB ---- 01:ECDB:  TAX  ; 
0x002CEC ---- 01:ECDC:  INY  ; 
0x002CED ---- 01:ECDD:  LDA (ram_00FD),Y  ; 002BF7 002BFB 002C03 002C05 002C07 002C09 002C0B 002C19
0x002CEF ---- 01:ECDF:  STA ram_00FE  ; $00FE
0x002CF1 ---- 01:ECE1:  STX ram_00FD  ; $00FD
0x002CF3 ---- 01:ECE3:  JMP (ram_00FD)  ; 002C1A 002C43 002C7B 002C85 002C91 002C95 002C98 002CB5
0x002CF6 ---- 01:ECE6:  .byte $07   ; 002BB4
0x002CF7 ---- 01:ECE7:  .byte $F2   ; 002BB9
0x002CF8 ---- 01:ECE8:  .byte $07   ; 002BB4
0x002CF9 ---- 01:ECE9:  .byte $80   ; 002BB9
0x002CFA ---- 01:ECEA:  .byte $07   ; 002BB4
0x002CFB ---- 01:ECEB:  .byte $14   ; 002BB9
0x002CFC ---- 01:ECEC:  .byte $06   ; 002BB4
0x002CFD ---- 01:ECED:  .byte $AE   ; 002BB9
0x002CFE ---- 01:ECEE:  .byte $06   ; 002BB4
0x002CFF ---- 01:ECEF:  .byte $43   ; 002BB9
0x002D00 ---- 01:ECF0:  .byte $05   ; 002BB4
0x002D01 ---- 01:ECF1:  .byte $F4   ; 002BB9
0x002D02 ---- 01:ECF2:  .byte $05   ; 002BB4
0x002D03 ---- 01:ECF3:  .byte $9E   ; 002BB9
0x002D04 ---- 01:ECF4:  .byte $05   ; 002BB4
0x002D05 ---- 01:ECF5:  .byte $4E   ; 002BB9
0x002D06 ---- 01:ECF6:  .byte $05   ; 002BB4
0x002D07 ---- 01:ECF7:  .byte $02   ; 002BB9
0x002D08 ---- 01:ECF8:  .byte $04   ; 002BB4
0x002D09 ---- 01:ECF9:  .byte $BA   ; 002BB9
0x002D0A ---- 01:ECFA:  .byte $04   ; 002BB4
0x002D0B ---- 01:ECFB:  .byte $76   ; 002BB9
0x002D0C ---- 01:ECFC:  .byte $04   ; 002BB4
0x002D0D ---- 01:ECFD:  .byte $36   ; 002BB9
0x002D0E ---- 01:ECFE:  .byte $2C   ; 002CC3
0x002D0F ---- 01:ECFF:  .byte $EE   ; 002CC8
0x002D10 ---- 01:ED00:  .byte $36   ; 002CC3
0x002D11 ---- 01:ED01:  .byte $ED   ; 002CC8
0x002D12 ---- 01:ED02:  .byte $5D   ; 002CC3
0x002D13 ---- 01:ED03:  .byte $ED   ; 002CC8
0x002D14 ---- 01:ED04:  .byte $88   ; 002CC3
0x002D15 ---- 01:ED05:  .byte $ED   ; 002CC8
0x002D16 ---- 01:ED06:  .byte $9F   ; 002CC3
0x002D17 ---- 01:ED07:  .byte $EE   ; 002CC8
0x002D18 ---- 01:ED08:  .byte $AE   ; 002CC3
0x002D19 ---- 01:ED09:  .byte $EE   ; 002CC8
0x002D1A ---- 01:ED0A:  .byte $19   ; 002CC3
0x002D1B ---- 01:ED0B:  .byte $EE   ; 002CC8
0x002D1C ---- 01:ED0C:  .byte $B3   ; 002CC3
0x002D1D ---- 01:ED0D:  .byte $ED   ; 002CC8
0x002D1E ---- xx:ED0E:  .byte $D5   ; 
0x002D1F ---- xx:ED0F:  .byte $ED   ; 
0x002D20 ---- 01:ED10:  .byte $48   ; 002CC3
0x002D21 ---- 01:ED11:  .byte $EE   ; 002CC8
0x002D22 ---- 01:ED12:  .byte $03   ; 002CC3
0x002D23 ---- 01:ED13:  .byte $EE   ; 002CC8
0x002D24 ---- 01:ED14:  .byte $F4   ; 002CC3
0x002D25 ---- 01:ED15:  .byte $ED   ; 002CC8
0x002D26 ---- 01:ED16:  .byte $5E   ; 002CC3
0x002D27 ---- 01:ED17:  .byte $EE   ; 002CC8
0x002D28 ---- 01:ED18:  .byte $56   ; 002CC3
0x002D29 ---- 01:ED19:  .byte $EE   ; 002CC8
0x002D2A ---- 01:ED1A:  .byte $67   ; 002CC3
0x002D2B ---- 01:ED1B:  .byte $EE   ; 002CC8
0x002D2C ---- 01:ED1C:  .byte $12   ; 002CC3
0x002D2D ---- 01:ED1D:  .byte $EE   ; 002CC8
0x002D2E ---- 01:ED1E:  .byte $95   ; 002CC3
0x002D2F ---- 01:ED1F:  .byte $EE   ; 002CC8
0x002D30 ---- 01:ED20:  .byte $8C   ; 002CC3
0x002D31 ---- 01:ED21:  .byte $EE   ; 002CC8
0x002D32 ---- 01:ED22:  .byte $82   ; 002CC3
0x002D33 ---- 01:ED23:  .byte $EE   ; 002CC8
0x002D34 ---- 01:ED24:  .byte $73   ; 002CC3
0x002D35 ---- 01:ED25:  .byte $EE   ; 002CC8
0x002D36 ---- 01:ED26:  .byte $7A   ; 002CC3
0x002D37 ---- 01:ED27:  .byte $EE   ; 002CC8
0x002D38 ---- 01:ED28:  .byte $C1   ; 002CC3
0x002D39 ---- 01:ED29:  .byte $EE   ; 002CC8
0x002D3A ---- 01:ED2A:  .byte $DF   ; 002CC3
0x002D3B ---- 01:ED2B:  .byte $EE   ; 002CC8
0x002D3C ---- 01:ED2C:  .byte $0A   ; 002CC3
0x002D3D ---- 01:ED2D:  .byte $EF   ; 002CC8
0x002D3E ---- 01:ED2E:  .byte $3C   ; 002CC3
0x002D3F ---- 01:ED2F:  .byte $EF   ; 002CC8
0x002D40 ---- 01:ED30:  .byte $4F   ; 002CC3
0x002D41 ---- 01:ED31:  .byte $EF   ; 002CC8
0x002D42 ---- 01:ED32:  .byte $62   ; 002CC3
0x002D43 ---- 01:ED33:  .byte $EF   ; 002CC8
0x002D44 ---- 01:ED34:  .byte $3A   ; 002CC3
0x002D45 ---- 01:ED35:  .byte $EE   ; 002CC8
0x002D46 ---- 01:ED36:  .byte $01   ; 002CD5
0x002D47 ---- 01:ED37:  .byte $81   ; 002CD5
0x002D48 ---- 01:ED38:  .byte $7F   ; 002CD5
0x002D49 ---- 01:ED39:  .byte $40   ; 002CD5
0x002D4A ---- 01:ED3A:  .byte $EF   ; 002CD5
0x002D4B ---- 01:ED3B:  .byte $68   ; 002CD5
0x002D4C ---- 01:ED3C:  .byte $1B   ; 002CD5
0x002D4D ---- 01:ED3D:  .byte $2B   ; 002CD5
0x002D4E ---- 01:ED3E:  .byte $33   ; 002CD5
0x002D4F ---- 01:ED3F:  .byte $F0   ; 002CD5
0x002D50 ---- 01:ED40:  .byte $02   ; 002CD5
0x002D51 ---- 01:ED41:  .byte $06   ; 002CD5
0x002D52 ---- 01:ED42:  .byte $33   ; 002CD5
0x002D53 ---- 01:ED43:  .byte $43   ; 002CD5
0x002D54 ---- 01:ED44:  .byte $53   ; 002CD5
0x002D55 ---- 01:ED45:  .byte $F0   ; 002CD5
0x002D56 ---- 01:ED46:  .byte $02   ; 002CD5
0x002D57 ---- 01:ED47:  .byte $0C   ; 002CD5
0x002D58 ---- 01:ED48:  .byte $43   ; 002CD5
0x002D59 ---- 01:ED49:  .byte $53   ; 002CD5
0x002D5A ---- 01:ED4A:  .byte $04   ; 002CD5
0x002D5B ---- 01:ED4B:  .byte $F0   ; 002CD5
0x002D5C ---- 01:ED4C:  .byte $02   ; 002CD5
0x002D5D ---- 01:ED4D:  .byte $12   ; 002CD5
0x002D5E ---- 01:ED4E:  .byte $5B   ; 002CD5
0x002D5F ---- 01:ED4F:  .byte $0C   ; 002CD5
0x002D60 ---- 01:ED50:  .byte $1C   ; 002CD5
0x002D61 ---- 01:ED51:  .byte $F0   ; 002CD5
0x002D62 ---- 01:ED52:  .byte $02   ; 002CD5
0x002D63 ---- 01:ED53:  .byte $18   ; 002CD5
0x002D64 ---- 01:ED54:  .byte $78   ; 002CD5
0x002D65 ---- 01:ED55:  .byte $1C   ; 002CD5
0x002D66 ---- 01:ED56:  .byte $68   ; 002CD5
0x002D67 ---- 01:ED57:  .byte $1C   ; 002CD5
0x002D68 ---- 01:ED58:  .byte $1C   ; 002CD5
0x002D69 ---- 01:ED59:  .byte $1C   ; 002CD5
0x002D6A ---- 01:ED5A:  .byte $78   ; 002CD5
0x002D6B ---- 01:ED5B:  .byte $1C   ; 002CD5
0x002D6C ---- 01:ED5C:  .byte $E8   ; 002CD5
0x002D6D ---- 01:ED5D:  .byte $03   ; 002CD5
0x002D6E ---- 01:ED5E:  .byte $10   ; 002CD5
0x002D6F ---- 01:ED5F:  .byte $7F   ; 002CD5
0x002D70 ---- 01:ED60:  .byte $08   ; 002CD5
0x002D71 ---- 01:ED61:  .byte $78   ; 002CD5
0x002D72 ---- 01:ED62:  .byte $1A   ; 002CD5
0x002D73 ---- 01:ED63:  .byte $68   ; 002CD5
0x002D74 ---- 01:ED64:  .byte $1A   ; 002CD5
0x002D75 ---- 01:ED65:  .byte $F1   ; 002CD5
0x002D76 ---- 01:ED66:  .byte $03   ; 002CD5
0x002D77 ---- 01:ED67:  .byte $07   ; 002CD5
0x002D78 ---- 01:ED68:  .byte $78   ; 002CD5
0x002D79 ---- 01:ED69:  .byte $32   ; 002CD5
0x002D7A ---- 01:ED6A:  .byte $68   ; 002CD5
0x002D7B ---- 01:ED6B:  .byte $32   ; 002CD5
0x002D7C ---- 01:ED6C:  .byte $F1   ; 002CD5
0x002D7D ---- 01:ED6D:  .byte $03   ; 002CD5
0x002D7E ---- 01:ED6E:  .byte $0E   ; 002CD5
0x002D7F ---- 01:ED6F:  .byte $78   ; 002CD5
0x002D80 ---- 01:ED70:  .byte $42   ; 002CD5
0x002D81 ---- 01:ED71:  .byte $68   ; 002CD5
0x002D82 ---- 01:ED72:  .byte $42   ; 002CD5
0x002D83 ---- 01:ED73:  .byte $F1   ; 002CD5
0x002D84 ---- 01:ED74:  .byte $03   ; 002CD5
0x002D85 ---- 01:ED75:  .byte $15   ; 002CD5
0x002D86 ---- 01:ED76:  .byte $5A   ; 002CD5
0x002D87 ---- 01:ED77:  .byte $F1   ; 002CD5
0x002D88 ---- 01:ED78:  .byte $03   ; 002CD5
0x002D89 ---- 01:ED79:  .byte $19   ; 002CD5
0x002D8A ---- 01:ED7A:  .byte $0B   ; 002CD5
0x002D8B ---- 01:ED7B:  .byte $F1   ; 002CD5
0x002D8C ---- 01:ED7C:  .byte $03   ; 002CD5
0x002D8D ---- 01:ED7D:  .byte $1D   ; 002CD5
0x002D8E ---- 01:ED7E:  .byte $78   ; 002CD5
0x002D8F ---- 01:ED7F:  .byte $52   ; 002CD5
0x002D90 ---- 01:ED80:  .byte $68   ; 002CD5
0x002D91 ---- 01:ED81:  .byte $52   ; 002CD5
0x002D92 ---- 01:ED82:  .byte $F1   ; 002CD5
0x002D93 ---- 01:ED83:  .byte $03   ; 002CD5
0x002D94 ---- 01:ED84:  .byte $24   ; 002CD5
0x002D95 ---- 01:ED85:  .byte $78   ; 002CD5
0x002D96 ---- 01:ED86:  .byte $52   ; 002CD5
0x002D97 ---- 01:ED87:  .byte $E8   ; 002CD5
0x002D98 ---- 01:ED88:  .byte $02   ; 002CD5
0x002D99 ---- 01:ED89:  .byte $81   ; 002CD5
0x002D9A ---- 01:ED8A:  .byte $7F   ; 002CD5
0x002D9B ---- 01:ED8B:  .byte $40   ; 002CD5
0x002D9C ---- 01:ED8C:  .byte $78   ; 002CD5
0x002D9D ---- 01:ED8D:  .byte $51   ; 002CD5
0x002D9E ---- 01:ED8E:  .byte $68   ; 002CD5
0x002D9F ---- 01:ED8F:  .byte $51   ; 002CD5
0x002DA0 ---- 01:ED90:  .byte $F2   ; 002CD5
0x002DA1 ---- 01:ED91:  .byte $03   ; 002CD5
0x002DA2 ---- 01:ED92:  .byte $07   ; 002CD5
0x002DA3 ---- 01:ED93:  .byte $78   ; 002CD5
0x002DA4 ---- 01:ED94:  .byte $0A   ; 002CD5
0x002DA5 ---- 01:ED95:  .byte $68   ; 002CD5
0x002DA6 ---- 01:ED96:  .byte $0A   ; 002CD5
0x002DA7 ---- 01:ED97:  .byte $F2   ; 002CD5
0x002DA8 ---- 01:ED98:  .byte $03   ; 002CD5
0x002DA9 ---- 01:ED99:  .byte $0E   ; 002CD5
0x002DAA ---- 01:ED9A:  .byte $78   ; 002CD5
0x002DAB ---- 01:ED9B:  .byte $1A   ; 002CD5
0x002DAC ---- 01:ED9C:  .byte $68   ; 002CD5
0x002DAD ---- 01:ED9D:  .byte $1A   ; 002CD5
0x002DAE ---- 01:ED9E:  .byte $F2   ; 002CD5
0x002DAF ---- 01:ED9F:  .byte $03   ; 002CD5
0x002DB0 ---- 01:EDA0:  .byte $15   ; 002CD5
0x002DB1 ---- 01:EDA1:  .byte $32   ; 002CD5
0x002DB2 ---- 01:EDA2:  .byte $F2   ; 002CD5
0x002DB3 ---- 01:EDA3:  .byte $03   ; 002CD5
0x002DB4 ---- 01:EDA4:  .byte $19   ; 002CD5
0x002DB5 ---- 01:EDA5:  .byte $42   ; 002CD5
0x002DB6 ---- 01:EDA6:  .byte $F2   ; 002CD5
0x002DB7 ---- 01:EDA7:  .byte $03   ; 002CD5
0x002DB8 ---- 01:EDA8:  .byte $1D   ; 002CD5
0x002DB9 ---- 01:EDA9:  .byte $78   ; 002CD5
0x002DBA ---- 01:EDAA:  .byte $3A   ; 002CD5
0x002DBB ---- 01:EDAB:  .byte $68   ; 002CD5
0x002DBC ---- 01:EDAC:  .byte $3A   ; 002CD5
0x002DBD ---- 01:EDAD:  .byte $F2   ; 002CD5
0x002DBE ---- 01:EDAE:  .byte $03   ; 002CD5
0x002DBF ---- 01:EDAF:  .byte $24   ; 002CD5
0x002DC0 ---- 01:EDB0:  .byte $78   ; 002CD5
0x002DC1 ---- 01:EDB1:  .byte $3A   ; 002CD5
0x002DC2 ---- 01:EDB2:  .byte $E8   ; 002CD5
0x002DC3 ---- 01:EDB3:  .byte $04   ; 002CD5
0x002DC4 ---- 01:EDB4:  .byte $1F   ; 002CD5
0x002DC5 ---- 01:EDB5:  .byte $7F   ; 002CD5
0x002DC6 ---- 01:EDB6:  .byte $30   ; 002CD5
0x002DC7 ---- 01:EDB7:  .byte $0A   ; 002CD5
0x002DC8 ---- 01:EDB8:  .byte $62   ; 002CD5
0x002DC9 ---- 01:EDB9:  .byte $49   ; 002CD5
0x002DCA ---- 01:EDBA:  .byte $49   ; 002CD5
0x002DCB ---- 01:EDBB:  .byte $EA   ; 002CD5
0x002DCC ---- 01:EDBC:  .byte $1E   ; 002CD5
0x002DCD ---- 01:EDBD:  .byte $49   ; 002CD5
0x002DCE ---- 01:EDBE:  .byte $49   ; 002CD5
0x002DCF ---- 01:EDBF:  .byte $EA   ; 002CD5
0x002DD0 ---- 01:EDC0:  .byte $1D   ; 002CD5
0x002DD1 ---- 01:EDC1:  .byte $49   ; 002CD5
0x002DD2 ---- 01:EDC2:  .byte $49   ; 002CD5
0x002DD3 ---- 01:EDC3:  .byte $EA   ; 002CD5
0x002DD4 ---- 01:EDC4:  .byte $1C   ; 002CD5
0x002DD5 ---- 01:EDC5:  .byte $49   ; 002CD5
0x002DD6 ---- 01:EDC6:  .byte $49   ; 002CD5
0x002DD7 ---- 01:EDC7:  .byte $EA   ; 002CD5
0x002DD8 ---- 01:EDC8:  .byte $1B   ; 002CD5
0x002DD9 ---- 01:EDC9:  .byte $49   ; 002CD5
0x002DDA ---- 01:EDCA:  .byte $49   ; 002CD5
0x002DDB ---- 01:EDCB:  .byte $EA   ; 002CD5
0x002DDC ---- 01:EDCC:  .byte $1A   ; 002CD5
0x002DDD ---- 01:EDCD:  .byte $49   ; 002CD5
0x002DDE ---- 01:EDCE:  .byte $EA   ; 002CD5
0x002DDF ---- 01:EDCF:  .byte $19   ; 002CD5
0x002DE0 ---- 01:EDD0:  .byte $49   ; 002CD5
0x002DE1 ---- 01:EDD1:  .byte $EA   ; 002CD5
0x002DE2 ---- 01:EDD2:  .byte $18   ; 002CD5
0x002DE3 ---- 01:EDD3:  .byte $49   ; 002CD5
0x002DE4 ---- 01:EDD4:  .byte $E8   ; 002CD5
0x002DE5 ---- xx:EDD5:  .byte $02   ; 
0x002DE6 ---- xx:EDD6:  .byte $1F   ; 
0x002DE7 ---- xx:EDD7:  .byte $7F   ; 
0x002DE8 ---- xx:EDD8:  .byte $30   ; 
0x002DE9 ---- xx:EDD9:  .byte $62   ; 
0x002DEA ---- xx:EDDA:  .byte $00   ; 
0x002DEB ---- xx:EDDB:  .byte $01   ; 
0x002DEC ---- xx:EDDC:  .byte $00   ; 
0x002DED ---- xx:EDDD:  .byte $EA   ; 
0x002DEE ---- xx:EDDE:  .byte $1E   ; 
0x002DEF ---- xx:EDDF:  .byte $01   ; 
0x002DF0 ---- xx:EDE0:  .byte $00   ; 
0x002DF1 ---- xx:EDE1:  .byte $EA   ; 
0x002DF2 ---- xx:EDE2:  .byte $1D   ; 
0x002DF3 ---- xx:EDE3:  .byte $01   ; 
0x002DF4 ---- xx:EDE4:  .byte $00   ; 
0x002DF5 ---- xx:EDE5:  .byte $01   ; 
0x002DF6 ---- xx:EDE6:  .byte $00   ; 
0x002DF7 ---- xx:EDE7:  .byte $EA   ; 
0x002DF8 ---- xx:EDE8:  .byte $1C   ; 
0x002DF9 ---- xx:EDE9:  .byte $01   ; 
0x002DFA ---- xx:EDEA:  .byte $EA   ; 
0x002DFB ---- xx:EDEB:  .byte $1B   ; 
0x002DFC ---- xx:EDEC:  .byte $00   ; 
0x002DFD ---- xx:EDED:  .byte $EA   ; 
0x002DFE ---- xx:EDEE:  .byte $1A   ; 
0x002DFF ---- xx:EDEF:  .byte $01   ; 
0x002E00 ---- xx:EDF0:  .byte $EA   ; 
0x002E01 ---- xx:EDF1:  .byte $19   ; 
0x002E02 ---- xx:EDF2:  .byte $00   ; 
0x002E03 ---- xx:EDF3:  .byte $E8   ; 
0x002E04 ---- 01:EDF4:  .byte $02   ; 002CD5
0x002E05 ---- 01:EDF5:  .byte $20   ; 002CD5
0x002E06 ---- 01:EDF6:  .byte $7F   ; 002CD5
0x002E07 ---- 01:EDF7:  .byte $30   ; 002CD5
0x002E08 ---- 01:EDF8:  .byte $63   ; 002CD5
0x002E09 ---- 01:EDF9:  .byte $1A   ; 002CD5
0x002E0A ---- 01:EDFA:  .byte $12   ; 002CD5
0x002E0B ---- 01:EDFB:  .byte $51   ; 002CD5
0x002E0C ---- 01:EDFC:  .byte $31   ; 002CD5
0x002E0D ---- 01:EDFD:  .byte $19   ; 002CD5
0x002E0E ---- 01:EDFE:  .byte $11   ; 002CD5
0x002E0F ---- 01:EDFF:  .byte $50   ; 002CD5
0x002E10 ---- 01:EE00:  .byte $30   ; 002CD5
0x002E11 ---- 01:EE01:  .byte $18   ; 002CD5
0x002E12 ---- 01:EE02:  .byte $E8   ; 002CD5
0x002E13 ---- 01:EE03:  .byte $04   ; 002CD5
0x002E14 ---- 01:EE04:  .byte $1F   ; 002CD5
0x002E15 ---- 01:EE05:  .byte $7F   ; 002CD5
0x002E16 ---- 01:EE06:  .byte $40   ; 002CD5
0x002E17 ---- 01:EE07:  .byte $0A   ; 002CD5
0x002E18 ---- 01:EE08:  .byte $62   ; 002CD5
0x002E19 ---- 01:EE09:  .byte $51   ; 002CD5
0x002E1A ---- 01:EE0A:  .byte $EA   ; 002CD5
0x002E1B ---- 01:EE0B:  .byte $1E   ; 002CD5
0x002E1C ---- 01:EE0C:  .byte $51   ; 002CD5
0x002E1D ---- 01:EE0D:  .byte $EA   ; 002CD5
0x002E1E ---- 01:EE0E:  .byte $08   ; 002CD5
0x002E1F ---- 01:EE0F:  .byte $6A   ; 002CD5
0x002E20 ---- 01:EE10:  .byte $51   ; 002CD5
0x002E21 ---- 01:EE11:  .byte $E8   ; 002CD5
0x002E22 ---- 01:EE12:  .byte $01   ; 002CD5
0x002E23 ---- 01:EE13:  .byte $8F   ; 002CD5
0x002E24 ---- 01:EE14:  .byte $82   ; 002CD5
0x002E25 ---- 01:EE15:  .byte $10   ; 002CD5
0x002E26 ---- 01:EE16:  .byte $6F   ; 002CD5
0x002E27 ---- 01:EE17:  .byte $2C   ; 002CD5
0x002E28 ---- 01:EE18:  .byte $E8   ; 002CD5
0x002E29 ---- 01:EE19:  .byte $02   ; 002CD5
0x002E2A ---- 01:EE1A:  .byte $80   ; 002CD5
0x002E2B ---- 01:EE1B:  .byte $7F   ; 002CD5
0x002E2C ---- 01:EE1C:  .byte $40   ; 002CD5
0x002E2D ---- 01:EE1D:  .byte $63   ; 002CD5
0x002E2E ---- 01:EE1E:  .byte $52   ; 002CD5
0x002E2F ---- 01:EE1F:  .byte $1B   ; 002CD5
0x002E30 ---- 01:EE20:  .byte $3B   ; 002CD5
0x002E31 ---- 01:EE21:  .byte $53   ; 002CD5
0x002E32 ---- 01:EE22:  .byte $4A   ; 002CD5
0x002E33 ---- 01:EE23:  .byte $13   ; 002CD5
0x002E34 ---- 01:EE24:  .byte $33   ; 002CD5
0x002E35 ---- 01:EE25:  .byte $4B   ; 002CD5
0x002E36 ---- 01:EE26:  .byte $1B   ; 002CD5
0x002E37 ---- 01:EE27:  .byte $3B   ; 002CD5
0x002E38 ---- 01:EE28:  .byte $53   ; 002CD5
0x002E39 ---- 01:EE29:  .byte $1C   ; 002CD5
0x002E3A ---- 01:EE2A:  .byte $3C   ; 002CD5
0x002E3B ---- 01:EE2B:  .byte $E8   ; 002CD5
0x002E3C ---- 01:EE2C:  .byte $02   ; 002CD5
0x002E3D ---- 01:EE2D:  .byte $82   ; 002CD5
0x002E3E ---- 01:EE2E:  .byte $7F   ; 002CD5
0x002E3F ---- 01:EE2F:  .byte $40   ; 002CD5
0x002E40 ---- 01:EE30:  .byte $64   ; 002CD5
0x002E41 ---- 01:EE31:  .byte $1B   ; 002CD5
0x002E42 ---- 01:EE32:  .byte $2B   ; 002CD5
0x002E43 ---- 01:EE33:  .byte $3B   ; 002CD5
0x002E44 ---- 01:EE34:  .byte $1C   ; 002CD5
0x002E45 ---- 01:EE35:  .byte $2C   ; 002CD5
0x002E46 ---- 01:EE36:  .byte $3C   ; 002CD5
0x002E47 ---- 01:EE37:  .byte $6C   ; 002CD5
0x002E48 ---- 01:EE38:  .byte $53   ; 002CD5
0x002E49 ---- 01:EE39:  .byte $E8   ; 002CD5
0x002E4A ---- 01:EE3A:  .byte $02   ; 002CD5
0x002E4B ---- 01:EE3B:  .byte $82   ; 002CD5
0x002E4C ---- 01:EE3C:  .byte $7F   ; 002CD5
0x002E4D ---- 01:EE3D:  .byte $40   ; 002CD5
0x002E4E ---- 01:EE3E:  .byte $63   ; 002CD5
0x002E4F ---- 01:EE3F:  .byte $53   ; 002CD5
0x002E50 ---- 01:EE40:  .byte $1B   ; 002CD5
0x002E51 ---- 01:EE41:  .byte $1C   ; 002CD5
0x002E52 ---- 01:EE42:  .byte $3B   ; 002CD5
0x002E53 ---- 01:EE43:  .byte $3C   ; 002CD5
0x002E54 ---- 01:EE44:  .byte $53   ; 002CD5
0x002E55 ---- 01:EE45:  .byte $6A   ; 002CD5
0x002E56 ---- 01:EE46:  .byte $54   ; 002CD5
0x002E57 ---- 01:EE47:  .byte $E8   ; 002CD5
0x002E58 ---- 01:EE48:  .byte $02   ; 002CD5
0x002E59 ---- 01:EE49:  .byte $60   ; 002CD5
0x002E5A ---- 01:EE4A:  .byte $7F   ; 002CD5
0x002E5B ---- 01:EE4B:  .byte $40   ; 002CD5
0x002E5C ---- 01:EE4C:  .byte $64   ; 002CD5
0x002E5D ---- 01:EE4D:  .byte $52   ; 002CD5
0x002E5E ---- 01:EE4E:  .byte $3A   ; 002CD5
0x002E5F ---- 01:EE4F:  .byte $52   ; 002CD5
0x002E60 ---- 01:EE50:  .byte $03   ; 002CD5
0x002E61 ---- 01:EE51:  .byte $52   ; 002CD5
0x002E62 ---- 01:EE52:  .byte $03   ; 002CD5
0x002E63 ---- 01:EE53:  .byte $13   ; 002CD5
0x002E64 ---- 01:EE54:  .byte $1B   ; 002CD5
0x002E65 ---- 01:EE55:  .byte $E8   ; 002CD5
0x002E66 ---- 01:EE56:  .byte $02   ; 002CD5
0x002E67 ---- 01:EE57:  .byte $D5   ; 002CD5
0x002E68 ---- 01:EE58:  .byte $7F   ; 002CD5
0x002E69 ---- 01:EE59:  .byte $00   ; 002CD5
0x002E6A ---- 01:EE5A:  .byte $62   ; 002CD5
0x002E6B ---- 01:EE5B:  .byte $1C   ; 002CD5
0x002E6C ---- 01:EE5C:  .byte $1D   ; 002CD5
0x002E6D ---- 01:EE5D:  .byte $E8   ; 002CD5
0x002E6E ---- 01:EE5E:  .byte $03   ; 002CD5
0x002E6F ---- 01:EE5F:  .byte $07   ; 002CD5
0x002E70 ---- 01:EE60:  .byte $7F   ; 002CD5
0x002E71 ---- 01:EE61:  .byte $08   ; 002CD5
0x002E72 ---- 01:EE62:  .byte $61   ; 002CD5
0x002E73 ---- 01:EE63:  .byte $3A   ; 002CD5
0x002E74 ---- 01:EE64:  .byte $13   ; 002CD5
0x002E75 ---- 01:EE65:  .byte $22   ; 002CD5
0x002E76 ---- 01:EE66:  .byte $E8   ; 002CD5
0x002E77 ---- 01:EE67:  .byte $02   ; 002CD5
0x002E78 ---- 01:EE68:  .byte $40   ; 002CD5
0x002E79 ---- 01:EE69:  .byte $7F   ; 002CD5
0x002E7A ---- 01:EE6A:  .byte $00   ; 002CD5
0x002E7B ---- 01:EE6B:  .byte $61   ; 002CD5
0x002E7C ---- 01:EE6C:  .byte $3D   ; 002CD5
0x002E7D ---- 01:EE6D:  .byte $62   ; 002CD5
0x002E7E ---- 01:EE6E:  .byte $45   ; 002CD5
0x002E7F ---- 01:EE6F:  .byte $EA   ; 002CD5
0x002E80 ---- 01:EE70:  .byte $10   ; 002CD5
0x002E81 ---- 01:EE71:  .byte $28   ; 002CD5
0x002E82 ---- 01:EE72:  .byte $E8   ; 002CD5
0x002E83 ---- 01:EE73:  .byte $02   ; 002CD5
0x002E84 ---- 01:EE74:  .byte $80   ; 002CD5
0x002E85 ---- 01:EE75:  .byte $7F   ; 002CD5
0x002E86 ---- 01:EE76:  .byte $18   ; 002CD5
0x002E87 ---- 01:EE77:  .byte $61   ; 002CD5
0x002E88 ---- 01:EE78:  .byte $39   ; 002CD5
0x002E89 ---- 01:EE79:  .byte $E8   ; 002CD5
0x002E8A ---- 01:EE7A:  .byte $04   ; 002CD5
0x002E8B ---- 01:EE7B:  .byte $00   ; 002CD5
0x002E8C ---- 01:EE7C:  .byte $7F   ; 002CD5
0x002E8D ---- 01:EE7D:  .byte $28   ; 002CD5
0x002E8E ---- 01:EE7E:  .byte $0A   ; 002CD5
0x002E8F ---- 01:EE7F:  .byte $61   ; 002CD5
0x002E90 ---- 01:EE80:  .byte $28   ; 002CD5
0x002E91 ---- 01:EE81:  .byte $E8   ; 002CD5
0x002E92 ---- 01:EE82:  .byte $02   ; 002CD5
0x002E93 ---- 01:EE83:  .byte $8C   ; 002CD5
0x002E94 ---- 01:EE84:  .byte $94   ; 002CD5
0x002E95 ---- 01:EE85:  .byte $40   ; 002CD5
0x002E96 ---- 01:EE86:  .byte $61   ; 002CD5
0x002E97 ---- 01:EE87:  .byte $10   ; 002CD5
0x002E98 ---- 01:EE88:  .byte $64   ; 002CD5
0x002E99 ---- 01:EE89:  .byte $18   ; 002CD5
0x002E9A ---- 01:EE8A:  .byte $F9   ; 002CD5
0x002E9B ---- 01:EE8B:  .byte $05   ; 002CD5
0x002E9C ---- 01:EE8C:  .byte $02   ; 002CD5
0x002E9D ---- 01:EE8D:  .byte $80   ; 002CD5
0x002E9E ---- 01:EE8E:  .byte $94   ; 002CD5
0x002E9F ---- 01:EE8F:  .byte $48   ; 002CD5
0x002EA0 ---- 01:EE90:  .byte $62   ; 002CD5
0x002EA1 ---- 01:EE91:  .byte $40   ; 002CD5
0x002EA2 ---- 01:EE92:  .byte $48   ; 002CD5
0x002EA3 ---- 01:EE93:  .byte $F9   ; 002CD5
0x002EA4 ---- 01:EE94:  .byte $05   ; 002CD5
0x002EA5 ---- 01:EE95:  .byte $01   ; 002CD5
0x002EA6 ---- 01:EE96:  .byte $1F   ; 002CD5
0x002EA7 ---- 01:EE97:  .byte $7F   ; 002CD5
0x002EA8 ---- 01:EE98:  .byte $28   ; 002CD5
0x002EA9 ---- 01:EE99:  .byte $61   ; 002CD5
0x002EAA ---- 01:EE9A:  .byte $22   ; 002CD5
0x002EAB ---- 01:EE9B:  .byte $42   ; 002CD5
0x002EAC ---- 01:EE9C:  .byte $5A   ; 002CD5
0x002EAD ---- 01:EE9D:  .byte $1B   ; 002CD5
0x002EAE ---- 01:EE9E:  .byte $E8   ; 002CD5
0x002EAF ---- 01:EE9F:  .byte $01   ; 002CD5
0x002EB0 ---- 01:EEA0:  .byte $A0   ; 002CD5
0x002EB1 ---- 01:EEA1:  .byte $7F   ; 002CD5
0x002EB2 ---- 01:EEA2:  .byte $40   ; 002CD5
0x002EB3 ---- 01:EEA3:  .byte $66   ; 002CD5
0x002EB4 ---- 01:EEA4:  .byte $1C   ; 002CD5
0x002EB5 ---- 01:EEA5:  .byte $3C   ; 002CD5
0x002EB6 ---- 01:EEA6:  .byte $1C   ; 002CD5
0x002EB7 ---- 01:EEA7:  .byte $53   ; 002CD5
0x002EB8 ---- 01:EEA8:  .byte $1C   ; 002CD5
0x002EB9 ---- 01:EEA9:  .byte $3C   ; 002CD5
0x002EBA ---- 01:EEAA:  .byte $05   ; 002CD5
0x002EBB ---- 01:EEAB:  .byte $72   ; 002CD5
0x002EBC ---- 01:EEAC:  .byte $54   ; 002CD5
0x002EBD ---- 01:EEAD:  .byte $E8   ; 002CD5
0x002EBE ---- 01:EEAE:  .byte $02   ; 002CD5
0x002EBF ---- 01:EEAF:  .byte $90   ; 002CD5
0x002EC0 ---- 01:EEB0:  .byte $7F   ; 002CD5
0x002EC1 ---- 01:EEB1:  .byte $40   ; 002CD5
0x002EC2 ---- 01:EEB2:  .byte $62   ; 002CD5
0x002EC3 ---- 01:EEB3:  .byte $38   ; 002CD5
0x002EC4 ---- 01:EEB4:  .byte $66   ; 002CD5
0x002EC5 ---- 01:EEB5:  .byte $EA   ; 002CD5
0x002EC6 ---- 01:EEB6:  .byte $20   ; 002CD5
0x002EC7 ---- 01:EEB7:  .byte $3B   ; 002CD5
0x002EC8 ---- 01:EEB8:  .byte $53   ; 002CD5
0x002EC9 ---- 01:EEB9:  .byte $3B   ; 002CD5
0x002ECA ---- 01:EEBA:  .byte $1B   ; 002CD5
0x002ECB ---- 01:EEBB:  .byte $3B   ; 002CD5
0x002ECC ---- 01:EEBC:  .byte $53   ; 002CD5
0x002ECD ---- 01:EEBD:  .byte $1C   ; 002CD5
0x002ECE ---- 01:EEBE:  .byte $6A   ; 002CD5
0x002ECF ---- 01:EEBF:  .byte $14   ; 002CD5
0x002ED0 ---- 01:EEC0:  .byte $E8   ; 002CD5
0x002ED1 ---- 01:EEC1:  .byte $01   ; 002CD5
0x002ED2 ---- 01:EEC2:  .byte $B8   ; 002CD5
0x002ED3 ---- 01:EEC3:  .byte $7F   ; 002CD5
0x002ED4 ---- 01:EEC4:  .byte $40   ; 002CD5
0x002ED5 ---- 01:EEC5:  .byte $EF   ; 002CD5
0x002ED6 ---- 01:EEC6:  .byte $65   ; 002CD5
0x002ED7 ---- 01:EEC7:  .byte $0C   ; 002CD5
0x002ED8 ---- 01:EEC8:  .byte $53   ; 002CD5
0x002ED9 ---- 01:EEC9:  .byte $F0   ; 002CD5
0x002EDA ---- 01:EECA:  .byte $0C   ; 002CD5
0x002EDB ---- 01:EECB:  .byte $05   ; 002CD5
0x002EDC ---- 01:EECC:  .byte $0C   ; 002CD5
0x002EDD ---- 01:EECD:  .byte $53   ; 002CD5
0x002EDE ---- 01:EECE:  .byte $F0   ; 002CD5
0x002EDF ---- 01:EECF:  .byte $0C   ; 002CD5
0x002EE0 ---- 01:EED0:  .byte $0B   ; 002CD5
0x002EE1 ---- 01:EED1:  .byte $34   ; 002CD5
0x002EE2 ---- 01:EED2:  .byte $24   ; 002CD5
0x002EE3 ---- 01:EED3:  .byte $F0   ; 002CD5
0x002EE4 ---- 01:EED4:  .byte $08   ; 002CD5
0x002EE5 ---- 01:EED5:  .byte $10   ; 002CD5
0x002EE6 ---- 01:EED6:  .byte $EA   ; 002CD5
0x002EE7 ---- 01:EED7:  .byte $30   ; 002CD5
0x002EE8 ---- 01:EED8:  .byte $B0   ; 002CD5
0x002EE9 ---- 01:EED9:  .byte $50   ; 002CD5
0x002EEA ---- 01:EEDA:  .byte $EA   ; 002CD5
0x002EEB ---- 01:EEDB:  .byte $20   ; 002CD5
0x002EEC ---- 01:EEDC:  .byte $9C   ; 002CD5
0x002EED ---- 01:EEDD:  .byte $54   ; 002CD5
0x002EEE ---- 01:EEDE:  .byte $E8   ; 002CD5
0x002EEF ---- 01:EEDF:  .byte $02   ; 002CD5
0x002EF0 ---- 01:EEE0:  .byte $B8   ; 002CD5
0x002EF1 ---- 01:EEE1:  .byte $7F   ; 002CD5
0x002EF2 ---- 01:EEE2:  .byte $40   ; 002CD5
0x002EF3 ---- 01:EEE3:  .byte $65   ; 002CD5
0x002EF4 ---- 01:EEE4:  .byte $43   ; 002CD5
0x002EF5 ---- 01:EEE5:  .byte $33   ; 002CD5
0x002EF6 ---- 01:EEE6:  .byte $F1   ; 002CD5
0x002EF7 ---- 01:EEE7:  .byte $0C   ; 002CD5
0x002EF8 ---- 01:EEE8:  .byte $04   ; 002CD5
0x002EF9 ---- 01:EEE9:  .byte $43   ; 002CD5
0x002EFA ---- 01:EEEA:  .byte $33   ; 002CD5
0x002EFB ---- 01:EEEB:  .byte $F1   ; 002CD5
0x002EFC ---- 01:EEEC:  .byte $0C   ; 002CD5
0x002EFD ---- 01:EEED:  .byte $0A   ; 002CD5
0x002EFE ---- 01:EEEE:  .byte $14   ; 002CD5
0x002EFF ---- 01:EEEF:  .byte $4B   ; 002CD5
0x002F00 ---- 01:EEF0:  .byte $F1   ; 002CD5
0x002F01 ---- 01:EEF1:  .byte $08   ; 002CD5
0x002F02 ---- 01:EEF2:  .byte $0F   ; 002CD5
0x002F03 ---- 01:EEF3:  .byte $EA   ; 002CD5
0x002F04 ---- 01:EEF4:  .byte $3A   ; 002CD5
0x002F05 ---- 01:EEF5:  .byte $30   ; 002CD5
0x002F06 ---- 01:EEF6:  .byte $50   ; 002CD5
0x002F07 ---- 01:EEF7:  .byte $09   ; 002CD5
0x002F08 ---- 01:EEF8:  .byte $29   ; 002CD5
0x002F09 ---- 01:EEF9:  .byte $31   ; 002CD5
0x002F0A ---- 01:EEFA:  .byte $51   ; 002CD5
0x002F0B ---- 01:EEFB:  .byte $0A   ; 002CD5
0x002F0C ---- 01:EEFC:  .byte $2A   ; 002CD5
0x002F0D ---- 01:EEFD:  .byte $32   ; 002CD5
0x002F0E ---- 01:EEFE:  .byte $52   ; 002CD5
0x002F0F ---- 01:EEFF:  .byte $0B   ; 002CD5
0x002F10 ---- 01:EF00:  .byte $2B   ; 002CD5
0x002F11 ---- 01:EF01:  .byte $33   ; 002CD5
0x002F12 ---- 01:EF02:  .byte $53   ; 002CD5
0x002F13 ---- 01:EF03:  .byte $0C   ; 002CD5
0x002F14 ---- 01:EF04:  .byte $2C   ; 002CD5
0x002F15 ---- 01:EF05:  .byte $9C   ; 002CD5
0x002F16 ---- 01:EF06:  .byte $EA   ; 002CD5
0x002F17 ---- 01:EF07:  .byte $20   ; 002CD5
0x002F18 ---- 01:EF08:  .byte $2C   ; 002CD5
0x002F19 ---- 01:EF09:  .byte $E8   ; 002CD5
0x002F1A ---- 01:EF0A:  .byte $03   ; 002CD5
0x002F1B ---- 01:EF0B:  .byte $00   ; 002CD5
0x002F1C ---- 01:EF0C:  .byte $7F   ; 002CD5
0x002F1D ---- 01:EF0D:  .byte $08   ; 002CD5
0x002F1E ---- 01:EF0E:  .byte $A1   ; 002CD5
0x002F1F ---- 01:EF0F:  .byte $01   ; 002CD5
0x002F20 ---- 01:EF10:  .byte $01   ; 002CD5
0x002F21 ---- 01:EF11:  .byte $EE   ; 002CD5
0x002F22 ---- 01:EF12:  .byte $15   ; 002CD5
0x002F23 ---- 01:EF13:  .byte $6A   ; 002CD5
0x002F24 ---- 01:EF14:  .byte $0B   ; 002CD5
0x002F25 ---- 01:EF15:  .byte $0B   ; 002CD5
0x002F26 ---- 01:EF16:  .byte $0B   ; 002CD5
0x002F27 ---- 01:EF17:  .byte $EE   ; 002CD5
0x002F28 ---- 01:EF18:  .byte $22   ; 002CD5
0x002F29 ---- 01:EF19:  .byte $6F   ; 002CD5
0x002F2A ---- 01:EF1A:  .byte $33   ; 002CD5
0x002F2B ---- 01:EF1B:  .byte $65   ; 002CD5
0x002F2C ---- 01:EF1C:  .byte $43   ; 002CD5
0x002F2D ---- 01:EF1D:  .byte $7E   ; 002CD5
0x002F2E ---- 01:EF1E:  .byte $EE   ; 002CD5
0x002F2F ---- 01:EF1F:  .byte $33   ; 002CD5
0x002F30 ---- 01:EF20:  .byte $53   ; 002CD5
0x002F31 ---- 01:EF21:  .byte $6A   ; 002CD5
0x002F32 ---- 01:EF22:  .byte $EE   ; 002CD5
0x002F33 ---- 01:EF23:  .byte $15   ; 002CD5
0x002F34 ---- 01:EF24:  .byte $43   ; 002CD5
0x002F35 ---- 01:EF25:  .byte $33   ; 002CD5
0x002F36 ---- 01:EF26:  .byte $53   ; 002CD5
0x002F37 ---- 01:EF27:  .byte $6F   ; 002CD5
0x002F38 ---- 01:EF28:  .byte $EE   ; 002CD5
0x002F39 ---- 01:EF29:  .byte $22   ; 002CD5
0x002F3A ---- 01:EF2A:  .byte $13   ; 002CD5
0x002F3B ---- 01:EF2B:  .byte $65   ; 002CD5
0x002F3C ---- 01:EF2C:  .byte $23   ; 002CD5
0x002F3D ---- 01:EF2D:  .byte $7E   ; 002CD5
0x002F3E ---- 01:EF2E:  .byte $EE   ; 002CD5
0x002F3F ---- 01:EF2F:  .byte $33   ; 002CD5
0x002F40 ---- 01:EF30:  .byte $33   ; 002CD5
0x002F41 ---- 01:EF31:  .byte $6A   ; 002CD5
0x002F42 ---- 01:EF32:  .byte $EE   ; 002CD5
0x002F43 ---- 01:EF33:  .byte $15   ; 002CD5
0x002F44 ---- 01:EF34:  .byte $23   ; 002CD5
0x002F45 ---- 01:EF35:  .byte $13   ; 002CD5
0x002F46 ---- 01:EF36:  .byte $4A   ; 002CD5
0x002F47 ---- 01:EF37:  .byte $9C   ; 002CD5
0x002F48 ---- 01:EF38:  .byte $EE   ; 002CD5
0x002F49 ---- 01:EF39:  .byte $FF   ; 002CD5
0x002F4A ---- 01:EF3A:  .byte $32   ; 002CD5
0x002F4B ---- 01:EF3B:  .byte $E8   ; 002CD5
0x002F4C ---- 01:EF3C:  .byte $01   ; 002CD5
0x002F4D ---- 01:EF3D:  .byte $42   ; 002CD5
0x002F4E ---- 01:EF3E:  .byte $7F   ; 002CD5
0x002F4F ---- 01:EF3F:  .byte $40   ; 002CD5
0x002F50 ---- 01:EF40:  .byte $66   ; 002CD5
0x002F51 ---- 01:EF41:  .byte $1B   ; 002CD5
0x002F52 ---- 01:EF42:  .byte $0B   ; 002CD5
0x002F53 ---- 01:EF43:  .byte $78   ; 002CD5
0x002F54 ---- 01:EF44:  .byte $1B   ; 002CD5
0x002F55 ---- 01:EF45:  .byte $68   ; 002CD5
0x002F56 ---- 01:EF46:  .byte $52   ; 002CD5
0x002F57 ---- 01:EF47:  .byte $42   ; 002CD5
0x002F58 ---- 01:EF48:  .byte $32   ; 002CD5
0x002F59 ---- 01:EF49:  .byte $1A   ; 002CD5
0x002F5A ---- 01:EF4A:  .byte $1A   ; 002CD5
0x002F5B ---- 01:EF4B:  .byte $1A   ; 002CD5
0x002F5C ---- 01:EF4C:  .byte $78   ; 002CD5
0x002F5D ---- 01:EF4D:  .byte $1A   ; 002CD5
0x002F5E ---- 01:EF4E:  .byte $E8   ; 002CD5
0x002F5F ---- 01:EF4F:  .byte $02   ; 002CD5
0x002F60 ---- 01:EF50:  .byte $82   ; 002CD5
0x002F61 ---- 01:EF51:  .byte $7F   ; 002CD5
0x002F62 ---- 01:EF52:  .byte $40   ; 002CD5
0x002F63 ---- 01:EF53:  .byte $66   ; 002CD5
0x002F64 ---- 01:EF54:  .byte $52   ; 002CD5
0x002F65 ---- 01:EF55:  .byte $52   ; 002CD5
0x002F66 ---- 01:EF56:  .byte $78   ; 002CD5
0x002F67 ---- 01:EF57:  .byte $52   ; 002CD5
0x002F68 ---- 01:EF58:  .byte $68   ; 002CD5
0x002F69 ---- 01:EF59:  .byte $32   ; 002CD5
0x002F6A ---- 01:EF5A:  .byte $2A   ; 002CD5
0x002F6B ---- 01:EF5B:  .byte $12   ; 002CD5
0x002F6C ---- 01:EF5C:  .byte $1A   ; 002CD5
0x002F6D ---- 01:EF5D:  .byte $1A   ; 002CD5
0x002F6E ---- 01:EF5E:  .byte $1A   ; 002CD5
0x002F6F ---- 01:EF5F:  .byte $78   ; 002CD5
0x002F70 ---- 01:EF60:  .byte $1A   ; 002CD5
0x002F71 ---- 01:EF61:  .byte $E8   ; 002CD5
0x002F72 ---- 01:EF62:  .byte $03   ; 002CD5
0x002F73 ---- 01:EF63:  .byte $10   ; 002CD5
0x002F74 ---- 01:EF64:  .byte $7F   ; 002CD5
0x002F75 ---- 01:EF65:  .byte $08   ; 002CD5
0x002F76 ---- 01:EF66:  .byte $66   ; 002CD5
0x002F77 ---- 01:EF67:  .byte $3B   ; 002CD5
0x002F78 ---- 01:EF68:  .byte $33   ; 002CD5
0x002F79 ---- 01:EF69:  .byte $78   ; 002CD5
0x002F7A ---- 01:EF6A:  .byte $3B   ; 002CD5
0x002F7B ---- 01:EF6B:  .byte $68   ; 002CD5
0x002F7C ---- 01:EF6C:  .byte $1B   ; 002CD5
0x002F7D ---- 01:EF6D:  .byte $0B   ; 002CD5
0x002F7E ---- 01:EF6E:  .byte $52   ; 002CD5
0x002F7F ---- 01:EF6F:  .byte $52   ; 002CD5
0x002F80 ---- 01:EF70:  .byte $52   ; 002CD5
0x002F81 ---- 01:EF71:  .byte $52   ; 002CD5
0x002F82 ---- 01:EF72:  .byte $78   ; 002CD5
0x002F83 ---- 01:EF73:  .byte $52   ; 002CD5
0x002F84 ---- 01:EF74:  .byte $E8   ; 002CD5
0x002F85 ---- xx:EF75:  .byte $FF   ; 
0x002F86 ---- xx:EF76:  .byte $FF   ; 
0x002F87 ---- xx:EF77:  .byte $FF   ; 
0x002F88 ---- xx:EF78:  .byte $FF   ; 
0x002F89 ---- xx:EF79:  .byte $FF   ; 
0x002F8A ---- xx:EF7A:  .byte $FF   ; 
0x002F8B ---- xx:EF7B:  .byte $FF   ; 
0x002F8C ---- xx:EF7C:  .byte $FF   ; 
0x002F8D ---- xx:EF7D:  .byte $FF   ; 
0x002F8E ---- xx:EF7E:  .byte $FF   ; 
0x002F8F ---- xx:EF7F:  .byte $FF   ; 
0x002F90 ---- xx:EF80:  .byte $FF   ; 
0x002F91 ---- xx:EF81:  .byte $FF   ; 
0x002F92 ---- xx:EF82:  .byte $FF   ; 
0x002F93 ---- xx:EF83:  .byte $FF   ; 
0x002F94 ---- xx:EF84:  .byte $FF   ; 
0x002F95 ---- xx:EF85:  .byte $FF   ; 
0x002F96 ---- xx:EF86:  .byte $FF   ; 
0x002F97 ---- xx:EF87:  .byte $FF   ; 
0x002F98 ---- xx:EF88:  .byte $FF   ; 
0x002F99 ---- xx:EF89:  .byte $FF   ; 
0x002F9A ---- xx:EF8A:  .byte $FF   ; 
0x002F9B ---- xx:EF8B:  .byte $FF   ; 
0x002F9C ---- xx:EF8C:  .byte $FF   ; 
0x002F9D ---- xx:EF8D:  .byte $FF   ; 
0x002F9E ---- xx:EF8E:  .byte $FF   ; 
0x002F9F ---- xx:EF8F:  .byte $FF   ; 
0x002FA0 ---- xx:EF90:  .byte $FF   ; 
0x002FA1 ---- xx:EF91:  .byte $FF   ; 
0x002FA2 ---- xx:EF92:  .byte $FF   ; 
0x002FA3 ---- xx:EF93:  .byte $FF   ; 
0x002FA4 ---- xx:EF94:  .byte $FF   ; 
0x002FA5 ---- xx:EF95:  .byte $FF   ; 
0x002FA6 ---- xx:EF96:  .byte $FF   ; 
0x002FA7 ---- xx:EF97:  .byte $FF   ; 
0x002FA8 ---- xx:EF98:  .byte $FF   ; 
0x002FA9 ---- xx:EF99:  .byte $FF   ; 
0x002FAA ---- xx:EF9A:  .byte $FF   ; 
0x002FAB ---- xx:EF9B:  .byte $FF   ; 
0x002FAC ---- xx:EF9C:  .byte $FF   ; 
0x002FAD ---- xx:EF9D:  .byte $FF   ; 
0x002FAE ---- xx:EF9E:  .byte $FF   ; 
0x002FAF ---- xx:EF9F:  .byte $FF   ; 
0x002FB0 ---- xx:EFA0:  .byte $FF   ; 
0x002FB1 ---- xx:EFA1:  .byte $FF   ; 
0x002FB2 ---- xx:EFA2:  .byte $FF   ; 
0x002FB3 ---- xx:EFA3:  .byte $FF   ; 
0x002FB4 ---- xx:EFA4:  .byte $FF   ; 
0x002FB5 ---- xx:EFA5:  .byte $FF   ; 
0x002FB6 ---- xx:EFA6:  .byte $FF   ; 
0x002FB7 ---- xx:EFA7:  .byte $FF   ; 
0x002FB8 ---- xx:EFA8:  .byte $FF   ; 
0x002FB9 ---- xx:EFA9:  .byte $FF   ; 
0x002FBA ---- xx:EFAA:  .byte $FF   ; 
0x002FBB ---- xx:EFAB:  .byte $FF   ; 
0x002FBC ---- xx:EFAC:  .byte $FF   ; 
0x002FBD ---- xx:EFAD:  .byte $FF   ; 
0x002FBE ---- xx:EFAE:  .byte $FF   ; 
0x002FBF ---- xx:EFAF:  .byte $FF   ; 
0x002FC0 ---- xx:EFB0:  .byte $FF   ; 
0x002FC1 ---- xx:EFB1:  .byte $FF   ; 
0x002FC2 ---- xx:EFB2:  .byte $FF   ; 
0x002FC3 ---- xx:EFB3:  .byte $FF   ; 
0x002FC4 ---- xx:EFB4:  .byte $FF   ; 
0x002FC5 ---- xx:EFB5:  .byte $FF   ; 
0x002FC6 ---- xx:EFB6:  .byte $FF   ; 
0x002FC7 ---- xx:EFB7:  .byte $FF   ; 
0x002FC8 ---- xx:EFB8:  .byte $FF   ; 
0x002FC9 ---- xx:EFB9:  .byte $FF   ; 
0x002FCA ---- xx:EFBA:  .byte $FF   ; 
0x002FCB ---- xx:EFBB:  .byte $FF   ; 
0x002FCC ---- xx:EFBC:  .byte $FF   ; 
0x002FCD ---- xx:EFBD:  .byte $FF   ; 
0x002FCE ---- xx:EFBE:  .byte $FF   ; 
0x002FCF ---- xx:EFBF:  .byte $FF   ; 
0x002FD0 ---- xx:EFC0:  .byte $FF   ; 
0x002FD1 ---- xx:EFC1:  .byte $FF   ; 
0x002FD2 ---- xx:EFC2:  .byte $FF   ; 
0x002FD3 ---- xx:EFC3:  .byte $FF   ; 
0x002FD4 ---- xx:EFC4:  .byte $FF   ; 
0x002FD5 ---- xx:EFC5:  .byte $FF   ; 
0x002FD6 ---- xx:EFC6:  .byte $FF   ; 
0x002FD7 ---- xx:EFC7:  .byte $FF   ; 
0x002FD8 ---- xx:EFC8:  .byte $FF   ; 
0x002FD9 ---- xx:EFC9:  .byte $FF   ; 
0x002FDA ---- xx:EFCA:  .byte $FF   ; 
0x002FDB ---- xx:EFCB:  .byte $FF   ; 
0x002FDC ---- xx:EFCC:  .byte $FF   ; 
0x002FDD ---- xx:EFCD:  .byte $FF   ; 
0x002FDE ---- xx:EFCE:  .byte $FF   ; 
0x002FDF ---- xx:EFCF:  .byte $FF   ; 
0x002FE0 ---- xx:EFD0:  .byte $FF   ; 
0x002FE1 ---- xx:EFD1:  .byte $FF   ; 
0x002FE2 ---- xx:EFD2:  .byte $FF   ; 
0x002FE3 ---- xx:EFD3:  .byte $FF   ; 
0x002FE4 ---- xx:EFD4:  .byte $FF   ; 
0x002FE5 ---- xx:EFD5:  .byte $FF   ; 
0x002FE6 ---- xx:EFD6:  .byte $FF   ; 
0x002FE7 ---- xx:EFD7:  .byte $FF   ; 
0x002FE8 ---- xx:EFD8:  .byte $FF   ; 
0x002FE9 ---- xx:EFD9:  .byte $FF   ; 
0x002FEA ---- xx:EFDA:  .byte $FF   ; 
0x002FEB ---- xx:EFDB:  .byte $FF   ; 
0x002FEC ---- xx:EFDC:  .byte $FF   ; 
0x002FED ---- xx:EFDD:  .byte $FF   ; 
0x002FEE ---- xx:EFDE:  .byte $FF   ; 
0x002FEF ---- xx:EFDF:  .byte $FF   ; 
0x002FF0 ---- xx:EFE0:  .byte $FF   ; 
0x002FF1 ---- xx:EFE1:  .byte $FF   ; 
0x002FF2 ---- xx:EFE2:  .byte $FF   ; 
0x002FF3 ---- xx:EFE3:  .byte $FF   ; 
0x002FF4 ---- xx:EFE4:  .byte $FF   ; 
0x002FF5 ---- xx:EFE5:  .byte $FF   ; 
0x002FF6 ---- xx:EFE6:  .byte $FF   ; 
0x002FF7 ---- xx:EFE7:  .byte $FF   ; 
0x002FF8 ---- xx:EFE8:  .byte $FF   ; 
0x002FF9 ---- xx:EFE9:  .byte $FF   ; 
0x002FFA ---- xx:EFEA:  .byte $FF   ; 
0x002FFB ---- xx:EFEB:  .byte $FF   ; 
0x002FFC ---- xx:EFEC:  .byte $FF   ; 
0x002FFD ---- xx:EFED:  .byte $FF   ; 
0x002FFE ---- xx:EFEE:  .byte $FF   ; 
0x002FFF ---- xx:EFEF:  .byte $FF   ; 
0x003000 ---- xx:EFF0:  .byte $FF   ; 
0x003001 ---- xx:EFF1:  .byte $FF   ; 
0x003002 ---- xx:EFF2:  .byte $FF   ; 
0x003003 ---- xx:EFF3:  .byte $FF   ; 
0x003004 ---- xx:EFF4:  .byte $FF   ; 
0x003005 ---- xx:EFF5:  .byte $FF   ; 
0x003006 ---- xx:EFF6:  .byte $FF   ; 
0x003007 ---- xx:EFF7:  .byte $FF   ; 
0x003008 ---- xx:EFF8:  .byte $FF   ; 
0x003009 ---- xx:EFF9:  .byte $FF   ; 
0x00300A ---- xx:EFFA:  .byte $FF   ; 
0x00300B ---- xx:EFFB:  .byte $FF   ; 
0x00300C ---- xx:EFFC:  .byte $FF   ; 
0x00300D ---- xx:EFFD:  .byte $FF   ; 
0x00300E ---- xx:EFFE:  .byte $FF   ; 
0x00300F ---- xx:EFFF:  .byte $FF   ; 
; 2 refs via 0001E9 0003E5
0x003010 ---- 01:F000:  CMP #$FF  ; 
0x003012 ---- 01:F002:  BNE $F009  ; 003019
0x003014 -Z-- 01:F004:  LDA #$24  ; 
0x003016 nz-- 01:F006:  JMP $F010  ; 003020
; 1 refs via 003012
0x003019 -z-- 01:F009:  CMP #$24  ; 
0x00301B ---- 01:F00B:  BCC $F010  ; 003020
0x00301D --C- 01:F00D:  SEC  ; 
0x00301E --C- 01:F00E:  SBC #$23  ; 
; 2 refs via 003016 00301B
0x003020 ---- 01:F010:  STA ram_0000  ; $0000
0x003022 ---- 01:F012:  LDA #$F0  ; 
0x003024 Nz-- 01:F014:  STA ram_0012  ; $0012
0x003026 Nz-- 01:F016:  LDA #$7A  ; 
0x003028 nz-- 01:F018:  STA ram_0011  ; $0011
; 1 refs via 003033
0x00302A ---- 01:F01A:  DEC ram_0000  ; $0000
0x00302C ---- 01:F01C:  BEQ $F026  ; 003036
0x00302E -z-- 01:F01E:  LDA #$5B  ; 
0x003030 nz-- 01:F020:  JSR $D7AA  ; 0017BA
; 1 refs via 0017C3
0x003033 ---- 01:F023:  JMP $F01A  ; 00302A
; 1 refs via 00302C
0x003036 -Z-- 01:F026:  LDA #$00  ; 
0x003038 nZ-- 01:F028:  STA ram_005A  ; $005A
0x00303A nZ-- 01:F02A:  LDA ram_0011  ; $0011
0x00303C ---- 01:F02C:  STA ram_0013  ; $0013
0x00303E ---- 01:F02E:  LDA ram_0012  ; $0012
0x003040 ---- 01:F030:  STA ram_0014  ; $0014
0x003042 ---- 01:F032:  LDA #$10  ; 
0x003044 nz-- 01:F034:  STA ram_0057  ; $0057
; 1 refs via 003087
0x003046 -z-- 01:F036:  JSR $D8F6  ; 001906
; 1 refs via 00190C
0x003049 -z-- 01:F039:  LDA #$10  ; 
0x00304B nz-- 01:F03B:  STA ram_0056  ; $0056
; 1 refs via 00307A
0x00304D -z-- 01:F03D:  LDA ram_005A  ; $005A
0x00304F ---- 01:F03F:  LSR  ; 
0x003050 ---- 01:F040:  TAY  ; 
0x003051 ---- 01:F041:  LDA ram_005A  ; $005A
0x003053 ---- 01:F043:  AND #$01  ; 
0x003055 ---- 01:F045:  BEQ $F04E  ; 00305E
0x003057 -z-- 01:F047:  LDA (ram_0013),Y  ; 00308A 00308B 00308C 00308D 00308E 00308F 003091 003092 003093 003094 003095 003096 003098 003099 00309A 00309B 00309C 00309D 00309F 0030A0 0030A1 0030A2 0030A3 0030A4 0030A6 0030A7 0030A8 0030A9 0030AA 0030AB 0030AD 0030AE 0030AF 0030B0 0030B1 0030B2 0030B4 0030B5 0030B6 0030B7 0030B8 0030B9 0030BB 0030BC 0030BD 0030BE 0030BF 0030C0 0030C2 0030C3 0030C4 0030C5 0030C6 0030C7 0030C9 0030CA 0030CB 0030CC 0030CD 0030CE 0030D0 0030D1 0030D2 0030D3 0030D4 0030D5 0030D7 0030D8 0030D9 0030DA 0030DB 0030DC 0030DE 0030DF 0030E0 0030E1 0030E2 0030E3 0030E5 0030E6 0030E7 0030E8 0030E9 0030EA 0030EC 0030ED 0030EE 0030EF 0030F0 0030F1 0030F3 0030F4 0030F5 0030F6 0030F7 0030F8 0030FA 0030FB 0030FC 0030FD 0030FE 0030FF 003101 003102 003103 003104 003105 003106 003108 003109 00310A 00310B 00310C 00310D 00310F 003110 003111 003112 003113 003114 003116 003117 003118 003119 00311A 00311B 00311D 00311E 00311F 003120 003121 003122 003124 003125 003126 003127 003128 003129 00312B 00312C 00312D 00312E 00312F 003130 003132 003133 003134 003135 003136 003137 003139 00313A 00313B 00313C 00313D 00313E 003140 003141 003142 003143 003144 003145 003147 003148 003149 00314A 00314B 00314C 00314E 00314F 003150 003151 003152 003153 003155 003156 003157 003158 003159 00315A 00315C 00315D 00315E 00315F 003160 003161 003163 003164 003165 003166 003167 003168 00316A 00316B 00316C 00316D 00316E 00316F 003171 003172 003173 003174 003175 003176 003178 003179 00317A 00317B 00317C 00317D 00317F 003180 003181 003182 003183 003184 003186 003187 003188 003189 00318A 00318B 00318D 00318E 00318F 003190 003191 003192 003194 003195 003196 003197 003198 003199 00319B 00319C 00319D 00319E 00319F 0031A0 0031A2 0031A3 0031A4 0031A5 0031A6 0031A7 0031A9 0031AA 0031AB 0031AC 0031AD 0031AE 0031B0 0031B1 0031B2 0031B3 0031B4 0031B5 0031B7 0031B8 0031B9 0031BA 0031BB 0031BC 0031BE 0031BF 0031C0 0031C1 0031C2 0031C3 0031C5 0031C6 0031C7 0031C8 0031C9 0031CA 0031CC 0031CD 0031CE 0031CF 0031D0 0031D1 0031D3 0031D4 0031D5 0031D6 0031D7 0031D8 0031DA 0031DB 0031DC 0031DD 0031DE 0031DF 0031E1 0031E2 0031E3 0031E4 0031E5 0031E6 0031E8 0031E9 0031EA 0031EB 0031EC 0031ED 0031EF 0031F0 0031F1 0031F2 0031F3 0031F4 0031F6 0031F7 0031F8 0031F9 0031FA 0031FB 0031FD 0031FE 0031FF 003200 003201 003202 003204 003205 003206 003207 003208 003209 00320B 00320C 00320D 00320E 00320F 003210 003212 003213 003214 003215 003216 003217 003219 00321A 00321B 00321C 00321D 00321E 003220 003221 003222 003223 003224 003225 003227 003228 003229 00322A 00322B 00322C 00322E 00322F 003230 003231 003232 003233 003235 003236 003237 003238 003239 00323A 00323C 00323D 00323E 00323F 003240 003241 003243 003244 003245 003246 003247 003248 00324A 00324B 00324C 00324D 00324E 00324F 003251 003252 003253 003254 003255 003256 003258 003259 00325A 00325B 00325C 00325D 00325F 003260 003261 003262 003263 003264 003266 003267 003268 003269 00326A 00326B 00326D 00326E 00326F 003270 003271 003272 003274 003275 003276 003277 003278 003279 00327B 00327C 00327D 00327E 00327F 003280 003282 003283 003284 003285 003286 003287 003289 00328A 00328B 00328C 00328D 00328E 003290 003291 003292 003293 003294 003295 003297 003298 003299 00329A 00329B 00329C 00329E 00329F 0032A0 0032A1 0032A2 0032A3 0032A5 0032A6 0032A7 0032A8 0032A9 0032AA 0032AC 0032AD 0032AE 0032AF 0032B0 0032B1 0032B3 0032B4 0032B5 0032B6 0032B7 0032B8 0032BA 0032BB 0032BC 0032BD 0032BE 0032BF 0032C1 0032C2 0032C3 0032C4 0032C5 0032C6 0032C8 0032C9 0032CA 0032CB 0032CC 0032CD 0032CF 0032D0 0032D1 0032D2 0032D3 0032D4 0032D6 0032D7 0032D8 0032D9 0032DA 0032DB 0032DD 0032DE 0032DF 0032E0 0032E1 0032E2 0032E4 0032E5 0032E6 0032E7 0032E8 0032E9 0032EB 0032EC 0032ED 0032EE 0032EF 0032F0 0032F2 0032F3 0032F4 0032F5 0032F6 0032F7 0032F9 0032FA 0032FB 0032FC 0032FD 0032FE 003300 003301 003302 003303 003304 003305 003307 003308 003309 00330A 00330B 00330C 00330E 00330F 003310 003311 003312 003313 003315 003316 003317 003318 003319 00331A 00331C 00331D 00331E 00331F 003320 003321 003323 003324 003325 003326 003327 003328 00332A 00332B 00332C 00332D 00332E 00332F 003331 003332 003333 003334 003335 003336 003338 003339 00333A 00333B 00333C 00333D 00333F 003340 003341 003342 003343 003344 003346 003347 003348 003349 00334A 00334B 00334D 00334E 00334F 003350 003351 003352 003354 003355 003356 003357 003358 003359 00335B 00335C 00335D 00335E 00335F 003360 003362 003363 003364 003365 003366 003367 003369 00336A 00336B 00336C 00336D 00336E 003370 003371 003372 003373 003374 003375 003377 003378 003379 00337A 00337B 00337C 00337E 00337F 003380 003381 003382 003383 003385 003386 003387 003388 003389 00338A 00338C 00338D 00338E 00338F 003390 003391 003393 003394 003395 003396 003397 003398 00339A 00339B 00339C 00339D 00339E 00339F 0033A1 0033A2 0033A3 0033A4 0033A5 0033A6 0033A8 0033A9 0033AA 0033AB 0033AC 0033AD 0033AF 0033B0 0033B1 0033B2 0033B3 0033B4 0033B6 0033B7 0033B8 0033B9 0033BA 0033BB 0033BD 0033BE 0033BF 0033C0 0033C1 0033C2 0033C4 0033C5 0033C6 0033C7 0033C8 0033C9 0033CB 0033CC 0033CD 0033CE 0033CF 0033D0 0033D2 0033D3 0033D4 0033D5 0033D6 0033D7 0033D9 0033DA 0033DB 0033DC 0033DD 0033DE 0033E0 0033E1 0033E2 0033E3 0033E4 0033E5 0033E7 0033E8 0033E9 0033EA 0033EB 0033EC 0033EE 0033EF 0033F0 0033F1 0033F2 0033F3 0033F5 0033F6 0033F7 0033F8 0033F9 0033FA 0033FC 0033FD 0033FE 0033FF 003400 003401 003403 003404 003405 003406 003407 003408 00340A 00340B 00340C 00340D 00340E 00340F 003411 003412 003413 003414 003415 003416 003418 003419 00341A 00341B 00341C 00341D 00341F 003420 003421 003422 003423 003424 003426 003427 003428 003429 00342A 00342B 00342D 00342E 00342F 003430 003431 003432 003434 003435 003436 003437 003438 003439 00343B 00343C 00343D 00343E 00343F 003440 003442 003443 003444 003445 003446 003447 003449 00344A 00344B 00344C 00344D 00344E 003450 003451 003452 003453 003454 003455 003457 003458 003459 00345A 00345B 00345C 00345E 00345F 003460 003461 003462 003463 003465 003466 003467 003468 003469 00346A 00346C 00346D 00346E 00346F 003470 003471 003473 003474 003475 003476 003477 003478 00347A 00347B 00347C 00347D 00347E 00347F 003481 003482 003483 003484 003485 003486 003488 003489 00348A 00348B 00348C 00348D 00348F 003490 003491 003492 003493 003494 003496 003497 003498 003499 00349A 00349B 00349D 00349E 00349F 0034A0 0034A1 0034A2 0034A4 0034A5 0034A6 0034A7 0034A8 0034A9 0034AB 0034AC 0034AD 0034AE 0034AF 0034B0 0034B2 0034B3 0034B4 0034B5 0034B6 0034B7 0034B9 0034BA 0034BB 0034BC 0034BD 0034BE 0034C0 0034C1 0034C2 0034C3 0034C4 0034C5 0034C7 0034C8 0034C9 0034CA 0034CB 0034CC 0034CE 0034CF 0034D0 0034D1 0034D2 0034D3 0034D5 0034D6 0034D7 0034D8 0034D9 0034DA 0034DC 0034DD 0034DE 0034DF 0034E0 0034E1 0034E3 0034E4 0034E5 0034E6 0034E7 0034E8 0034EA 0034EB 0034EC 0034ED 0034EE 0034EF 0034F1 0034F2 0034F3 0034F4 0034F5 0034F6 0034F8 0034F9 0034FA 0034FB 0034FC 0034FD 0034FF 003500 003501 003502 003503 003504 003506 003507 003508 003509 00350A 00350B 00350D 00350E 00350F 003510 003511 003512 003514 003515 003516 003517 003518 003519 00351B 00351C 00351D 00351E 00351F 003520 003522 003523 003524 003525 003526 003527 003529 00352A 00352B 00352C 00352D 00352E 003530 003531 003532 003533 003534 003535 003537 003538 003539 00353A 00353B 00353C 00353E 00353F 003540 003541 003542 003543 003545 003546 003547 003548 003549 00354A 00354C 00354D 00354E 00354F 003550 003551 003553 003554 003555 003556 003557 003558 00355A 00355B 00355C 00355D 00355E 00355F 003561 003562 003563 003564 003565 003566 003568 003569 00356A 00356B 00356C 00356D 00356F 003570 003571 003572 003573 003574 003576 003577 003578 003579 00357A 00357B 00357D 00357E 00357F 003580 003581 003582 003584 003585 003586 003587 003588 003589 00358B 00358C 00358D 00358E 00358F 003590 003592 003593 003594 003595 003596 003597 003599 00359A 00359B 00359C 00359D 00359E 0035A0 0035A1 0035A2 0035A3 0035A4 0035A5 0035A7 0035A8 0035A9 0035AA 0035AB 0035AC 0035AE 0035AF 0035B0 0035B1 0035B2 0035B3 0035B5 0035B6 0035B7 0035B8 0035B9 0035BA 0035BC 0035BD 0035BE 0035BF 0035C0 0035C1 0035C3 0035C4 0035C5 0035C6 0035C7 0035C8 0035CA 0035CB 0035CC 0035CD 0035CE 0035CF 0035D1 0035D2 0035D3 0035D4 0035D5 0035D6 0035D8 0035D9 0035DA 0035DB 0035DC 0035DD 0035DF 0035E0 0035E1 0035E2 0035E3 0035E4 0035E6 0035E7 0035E8 0035E9 0035EA 0035EB 0035ED 0035EE 0035EF 0035F0 0035F1 0035F2 0035F4 0035F5 0035F6 0035F7 0035F8 0035F9 0035FB 0035FC 0035FD 0035FE 0035FF 003600 003602 003603 003604 003605 003606 003607 003609 00360A 00360B 00360C 00360D 00360E 003610 003611 003612 003613 003614 003615 003617 003618 003619 00361A 00361B 00361C 00361E 00361F 003620 003621 003622 003623 003625 003626 003627 003628 003629 00362A 00362C 00362D 00362E 00362F 003630 003631 003633 003634 003635 003636 003637 003638 00363A 00363B 00363C 00363D 00363E 00363F 003641 003642 003643 003644 003645 003646 003648 003649 00364A 00364B 00364C 00364D 00364F 003650 003651 003652 003653 003654 003656 003657 003658 003659 00365A 00365B 00365D 00365E 00365F 003660 003661 003662 003664 003665 003666 003667 003668 003669 00366B 00366C 00366D 00366E 00366F 003670 003672 003673 003674 003675 003676 003677 003679 00367A 00367B 00367C 00367D 00367E 003680 003681 003682 003683 003684 003685 003687 003688 003689 00368A 00368B 00368C 00368E 00368F 003690 003691 003692 003693 003695 003696 003697 003698 003699 00369A 00369C 00369D 00369E 00369F 0036A0 0036A1 0036A3 0036A4 0036A5 0036A6 0036A7 0036A8 0036AA 0036AB 0036AC 0036AD 0036AE 0036AF 0036B1 0036B2 0036B3 0036B4 0036B5 0036B6 0036B8 0036B9 0036BA 0036BB 0036BC 0036BD 0036BF 0036C0 0036C1 0036C2 0036C3 0036C4 0036C6 0036C7 0036C8 0036C9 0036CA 0036CB 0036CD 0036CE 0036CF 0036D0 0036D1 0036D2 0036D4 0036D5 0036D6 0036D7 0036D8 0036D9 0036DB 0036DC 0036DD 0036DE 0036DF 0036E0 0036E2 0036E3 0036E4 0036E5 0036E6 0036E7 0036E9 0036EA 0036EB 0036EC 0036ED 0036EE 0036F0 0036F1 0036F2 0036F3 0036F4 0036F5 0036F7 0036F8 0036F9 0036FA 0036FB 0036FC 0036FE 0036FF 003700 003701 003702 003703 003705 003706 003707 003708 003709 00370A 00370C 00370D 00370E 00370F 003710 003711 003713 003714 003715 003716 003717 003718 00371A 00371B 00371C 00371D 00371E 00371F 003721 003722 003723 003724 003725 003726 003728 003729 00372A 00372B 00372C 00372D 00372F 003730 003731 003732 003733 003734 003736 003737 003738 003739 00373A 00373B 00373D 00373E 00373F 003740 003741 003742 003744 003745 003746 003747 003748 003749 00374B 00374C 00374D 00374E 00374F 003750 003752 003753 003754 003755 003756 003757 003759 00375A 00375B 00375C 00375D 00375E 003760 003761 003762 003763 003764 003765 003767 003768 003769 00376A 00376B 00376C 00376E 00376F 003770 003771 003772 003773 003775 003776 003777 003778 003779 00377A 00377C 00377D 00377E 00377F 003780 003781 003783 003784 003785 003786 003787 003788 00378A 00378B 00378C 00378D 00378E 00378F 003791 003792 003793 003794 003795 003796 003798 003799 00379A 00379B 00379C 00379D 00379F 0037A0 0037A1 0037A2 0037A3 0037A4 0037A6 0037A7 0037A8 0037A9 0037AA 0037AB 0037AD 0037AE 0037AF 0037B0 0037B1 0037B2 0037B4 0037B5 0037B6 0037B7 0037B8 0037B9 0037BB 0037BC 0037BD 0037BE 0037BF 0037C0 0037C2 0037C3 0037C4 0037C5 0037C6 0037C7 0037C9 0037CA 0037CB 0037CC 0037CD 0037CE 0037D0 0037D1 0037D2 0037D3 0037D4 0037D5 0037D7 0037D8 0037D9 0037DA 0037DB 0037DC 0037DE 0037DF 0037E0 0037E1 0037E2 0037E3 0037E5 0037E6 0037E7 0037E8 0037E9 0037EA 0037EC 0037ED 0037EE 0037EF 0037F0 0037F1 0037F3 0037F4 0037F5 0037F6 0037F7 0037F8 0037FA 0037FB 0037FC 0037FD 0037FE 0037FF 003801 003802 003803 003804 003805 003806 003808 003809 00380A 00380B 00380C 00380D 00380F 003810 003811 003812 003813 003814 003816 003817 003818 003819 00381A 00381B 00381D 00381E 00381F 003820 003821 003822 003824 003825 003826 003827 003828 003829 00382B 00382C 00382D 00382E 00382F 003830 003832 003833 003834 003835 003836 003837 003839 00383A 00383B 00383C 00383D 00383E 003840 003841 003842 003843 003844 003845 003847 003848 003849 00384A 00384B 00384C 00384E 00384F 003850 003851 003852 003853 003855 003856 003857 003858 003859 00385A 00385C 00385D 00385E 00385F 003860 003861 003863 003864 003865 003866 003867 003868 00386A 00386B 00386C 00386D 00386E 00386F 003871 003872 003873 003874 003875 003876 003878 003879 00387A 00387B 00387C 00387D 00387F 003880 003881 003882 003883 003884 003886 003887 003888 003889 00388A 00388B 00388D 00388E 00388F 003890 003891 003892 003894 003895 003896 003897 003898 003899 00389B 00389C 00389D 00389E 00389F 0038A0 0038A2 0038A3 0038A4 0038A5 0038A6 0038A7 0038A9 0038AA 0038AB 0038AC 0038AD 0038AE 0038B0 0038B1 0038B2 0038B3 0038B4 0038B5 0038B7 0038B8 0038B9 0038BA 0038BB 0038BC 0038BE 0038BF 0038C0 0038C1 0038C2 0038C3 0038C5 0038C6 0038C7 0038C8 0038C9 0038CA 0038CC 0038CD 0038CE 0038CF 0038D0 0038D1 0038D3 0038D4 0038D5 0038D6 0038D7 0038D8 0038DA 0038DB 0038DC 0038DD 0038DE 0038DF 0038E1 0038E2 0038E3 0038E4 0038E5 0038E6 0038E8 0038E9 0038EA 0038EB 0038EC 0038ED 0038EF 0038F0 0038F1 0038F2 0038F3 0038F4 0038F6 0038F7 0038F8 0038F9 0038FA 0038FB 0038FD 0038FE 0038FF 003900 003901 003902 003904 003905 003906 003907 003908 003909 00390B 00390C 00390D 00390E 00390F 003910 003912 003913 003914 003915 003916 003917 003919 00391A 00391B 00391C 00391D 00391E 003920 003921 003922 003923 003924 003925 003927 003928 003929 00392A 00392B 00392C 00392E 00392F 003930 003931 003932 003933 003935 003936 003937 003938 003939 00393A 00393C 00393D 00393E 00393F 003940 003941 003943 003944 003945 003946 003947 003948 00394A 00394B 00394C 00394D 00394E 00394F 003951 003952 003953 003954 003955 003956 003958 003959 00395A 00395B 00395C 00395D 00395F 003960 003961 003962 003963 003964 003966 003967 003968 003969 00396A 00396B 00396D 00396E 00396F 003970 003971 003972 003974 003975 003976 003977 003978 003979 00397B 00397C 00397D 00397E 00397F 003980 003982 003983 003984 003985 003986 003987 003989 00398A 00398B 00398C 00398D 00398E 003990 003991 003992 003993 003994 003995 003997 003998 003999 00399A 00399B 00399C 00399E 00399F 0039A0 0039A1 0039A2 0039A3 0039A5 0039A6 0039A7 0039A8 0039A9 0039AA 0039AC 0039AD 0039AE 0039AF 0039B0 0039B1 0039B3 0039B4 0039B5 0039B6 0039B7 0039B8 0039BA 0039BB 0039BC 0039BD 0039BE 0039BF 0039C1 0039C2 0039C3 0039C4 0039C5 0039C6 0039C8 0039C9 0039CA 0039CB 0039CC 0039CD 0039CF 0039D0 0039D1 0039D2 0039D3 0039D4 0039D6 0039D7 0039D8 0039D9 0039DA 0039DB 0039DD 0039DE 0039DF 0039E0 0039E1 0039E2 0039E4 0039E5 0039E6 0039E7 0039E8 0039E9 0039EB 0039EC 0039ED 0039EE 0039EF 0039F0 0039F2 0039F3 0039F4 0039F5 0039F6 0039F7 0039F9 0039FA 0039FB 0039FC 0039FD 0039FE 003A00 003A01 003A02 003A03 003A04 003A05 003A07 003A08 003A09 003A0A 003A0B 003A0C 003A0E 003A0F 003A10 003A11 003A12 003A13 003A15 003A16 003A17 003A18 003A19 003A1A 003A1C 003A1D 003A1E 003A1F 003A20 003A21 003A23 003A24 003A25 003A26 003A27 003A28 003A2A 003A2B 003A2C 003A2D 003A2E 003A2F 003A31 003A32 003A33 003A34 003A35 003A36 003A38 003A39 003A3A 003A3B 003A3C 003A3D 003A3F 003A40 003A41 003A42 003A43 003A44 003A46 003A47 003A48 003A49 003A4A 003A4B 003A4D 003A4E 003A4F 003A50 003A51 003A52 003A54 003A55 003A56 003A57 003A58 003A59 003A5B 003A5C 003A5D 003A5E 003A5F 003A60 003A62 003A63 003A64 003A65 003A66 003A67 003A69 003A6A 003A6B 003A6C 003A6D 003A6E 003A70 003A71 003A72 003A73 003A74 003A75 003A77 003A78 003A79 003A7A 003A7B 003A7C 003A7E 003A7F 003A80 003A81 003A82 003A83 003A85 003A86 003A87 003A88 003A89 003A8A 003A8C 003A8D 003A8E 003A8F 003A90 003A91 003A93 003A94 003A95 003A96 003A97 003A98 003A9A 003A9B 003A9C 003A9D 003A9E 003A9F 003AA1 003AA2 003AA3 003AA4 003AA5 003AA6 003AA8 003AA9 003AAA 003AAB 003AAC 003AAD 003AAF 003AB0 003AB1 003AB2 003AB3 003AB4 003AB6 003AB7 003AB8 003AB9 003ABA 003ABB 003ABD 003ABE 003ABF 003AC0 003AC1 003AC2 003AC4 003AC5 003AC6 003AC7 003AC8 003AC9 003ACB 003ACC 003ACD 003ACE 003ACF 003AD0 003AD2 003AD3 003AD4 003AD5 003AD6 003AD7 003AD9 003ADA 003ADB 003ADC 003ADD 003ADE 003AE0 003AE1 003AE2 003AE3 003AE4 003AE5 003AE7 003AE8 003AE9 003AEA 003AEB 003AEC 003AEE 003AEF 003AF0 003AF1 003AF2 003AF3 003AF5 003AF6 003AF7 003AF8 003AF9 003AFA 003AFC 003AFD 003AFE 003AFF 003B00 003B01 003B03 003B04 003B05 003B06 003B07 003B08 003B0A 003B0B 003B0C 003B0D 003B0E 003B0F 003B11 003B12 003B13 003B14 003B15 003B16 003B18 003B19 003B1A 003B1B 003B1C 003B1D 003B1F 003B20 003B21 003B22 003B23 003B24 003B26 003B27 003B28 003B29 003B2A 003B2B 003B2D 003B2E 003B2F 003B30 003B31 003B32 003B34 003B35 003B36 003B37 003B38 003B39 003B3B 003B3C 003B3D 003B3E 003B3F 003B40 003B42 003B43 003B44 003B45 003B46 003B47 003B49 003B4A 003B4B 003B4C 003B4D 003B4E 003B50 003B51 003B52 003B53 003B54 003B55 003B57 003B58 003B59 003B5A 003B5B 003B5C 003B5E 003B5F 003B60 003B61 003B62 003B63 003B65 003B66 003B67 003B68 003B69 003B6A 003B6C 003B6D 003B6E 003B6F 003B70 003B71 003B73 003B74 003B75 003B76 003B77 003B78 003B7A 003B7B 003B7C 003B7D 003B7E 003B7F 003B81 003B82 003B83 003B84 003B85 003B86 003B88 003B89 003B8A 003B8B 003B8C 003B8D 003B8F 003B90 003B91 003B92 003B93 003B94 003B96 003B97 003B98 003B99 003B9A 003B9B 003B9D 003B9E 003B9F 003BA0 003BA1 003BA2 003BA4 003BA5 003BA6 003BA7 003BA8 003BA9 003BAB 003BAC 003BAD 003BAE 003BAF 003BB0 003BB2 003BB3 003BB4 003BB5 003BB6 003BB7 003BB9 003BBA 003BBB 003BBC 003BBD 003BBE 003BC0 003BC1 003BC2 003BC3 003BC4 003BC5 003BC7 003BC8 003BC9 003BCA 003BCB 003BCC 003BCE 003BCF 003BD0 003BD1 003BD2 003BD3 003BD5 003BD6 003BD7 003BD8 003BD9 003BDA 003BDC 003BDD 003BDE 003BDF 003BE0 003BE1 003BE3 003BE4 003BE5 003BE6 003BE7 003BE8 003BEA 003BEB 003BEC 003BED 003BEE 003BEF 003BF1 003BF2 003BF3 003BF4 003BF5 003BF6 003BF8 003BF9 003BFA 003BFB 003BFC 003BFD 003BFF 003C00 003C01 003C02 003C03 003C04 003C06 003C07 003C08 003C09 003C0A 003C0B 003C0D 003C0E 003C0F 003C10 003C11 003C12 003C14 003C15 003C16 003C17 003C18 003C19 003C1B 003C1C 003C1D 003C1E 003C1F 003C20 003C22 003C23 003C24 003C25 003C26 003C27 003C29 003C2A 003C2B 003C2C 003C2D 003C2E 003C30 003C31 003C32 003C33 003C34 003C35 003C37 003C38 003C39 003C3A 003C3B 003C3C 003C3E 003C3F 003C40 003C41 003C42 003C43 003C45 003C46 003C47 003C48 003C49 003C4A 003C4C 003C4D 003C4E 003C4F 003C50 003C51 003C53 003C54 003C55 003C56 003C57 003C58 003C5A 003C5B 003C5C 003C5D 003C5E 003C5F 003C61 003C62 003C63 003C64 003C65 003C66 003C68 003C69 003C6A 003C6B 003C6C 003C6D 003C6F 003C70 003C71 003C72 003C73 003C74 003C76 003C77 003C78 003C79 003C7A 003C7B 003C7D 003C7E 003C7F 003C80 003C81 003C82 003C84 003C85 003C86 003C87 003C88 003C89 003C8B 003C8C 003C8D 003C8E 003C8F 003C90 003C92 003C93 003C94 003C95 003C96 003C97 003C99 003C9A 003C9B 003C9C 003C9D 003C9E 003CA0 003CA1 003CA2 003CA3 003CA4 003CA5 003CA7 003CA8 003CA9 003CAA 003CAB 003CAC 003CAE 003CAF 003CB0 003CB1 003CB2 003CB3 003CB5 003CB6 003CB7 003CB8 003CB9 003CBA 003CBC 003CBD 003CBE 003CBF 003CC0 003CC1 003CC3 003CC4 003CC5 003CC6 003CC7 003CC8 003CCA 003CCB 003CCC 003CCD 003CCE 003CCF 003CD1 003CD2 003CD3 003CD4 003CD5 003CD6 003CD8 003CD9 003CDA 003CDB 003CDC 003CDD 003CDF 003CE0 003CE1 003CE2 003CE3 003CE4 003CE6 003CE7 003CE8 003CE9 003CEA 003CEB 003CED 003CEE 003CEF 003CF0 003CF1 003CF2 003CF4 003CF5 003CF6 003CF7 003CF8 003CF9 003CFB 003CFC 003CFD 003CFE 003CFF 003D00 003D02 003D03 003D04 003D05 003D06 003D07 003D09 003D0A 003D0B 003D0C 003D0D 003D0E 003D10 003D11 003D12 003D13 003D14 003D15 003D17 003D18 003D19 003D1A 003D1B 003D1C 003D1E 003D1F 003D20 003D21 003D22 003D23 003D25 003D26 003D27 003D28 003D29 003D2A 003D2C 003D2D 003D2E 003D2F 003D30 003D31 003D33 003D34 003D35 003D36 003D37 003D38 003D3A 003D3B 003D3C 003D3D 003D3E 003D3F 003D41 003D42 003D43 003D44 003D45 003D46 003D48 003D49 003D4A 003D4B 003D4C 003D4D 003D4F 003D50 003D51 003D52 003D53 003D54
0x003059 ---- 01:F049:  AND #$0F  ; 
0x00305B ---- 01:F04B:  JMP $F054  ; 003064
; 1 refs via 003055
0x00305E -Z-- 01:F04E:  LDA (ram_0013),Y  ; 00308A 00308B 00308C 00308D 00308E 00308F 003090 003091 003092 003093 003094 003095 003096 003097 003098 003099 00309A 00309B 00309C 00309D 00309E 00309F 0030A0 0030A1 0030A2 0030A3 0030A4 0030A5 0030A6 0030A7 0030A8 0030A9 0030AA 0030AB 0030AC 0030AD 0030AE 0030AF 0030B0 0030B1 0030B2 0030B3 0030B4 0030B5 0030B6 0030B7 0030B8 0030B9 0030BA 0030BB 0030BC 0030BD 0030BE 0030BF 0030C0 0030C1 0030C2 0030C3 0030C4 0030C5 0030C6 0030C7 0030C8 0030C9 0030CA 0030CB 0030CC 0030CD 0030CE 0030CF 0030D0 0030D1 0030D2 0030D3 0030D4 0030D5 0030D6 0030D7 0030D8 0030D9 0030DA 0030DB 0030DC 0030DD 0030DE 0030DF 0030E0 0030E1 0030E2 0030E3 0030E4 0030E5 0030E6 0030E7 0030E8 0030E9 0030EA 0030EB 0030EC 0030ED 0030EE 0030EF 0030F0 0030F1 0030F2 0030F3 0030F4 0030F5 0030F6 0030F7 0030F8 0030F9 0030FA 0030FB 0030FC 0030FD 0030FE 0030FF 003100 003101 003102 003103 003104 003105 003106 003107 003108 003109 00310A 00310B 00310C 00310D 00310E 00310F 003110 003111 003112 003113 003114 003115 003116 003117 003118 003119 00311A 00311B 00311C 00311D 00311E 00311F 003120 003121 003122 003123 003124 003125 003126 003127 003128 003129 00312A 00312B 00312C 00312D 00312E 00312F 003130 003131 003132 003133 003134 003135 003136 003137 003138 003139 00313A 00313B 00313C 00313D 00313E 00313F 003140 003141 003142 003143 003144 003145 003146 003147 003148 003149 00314A 00314B 00314C 00314D 00314E 00314F 003150 003151 003152 003153 003154 003155 003156 003157 003158 003159 00315A 00315B 00315C 00315D 00315E 00315F 003160 003161 003162 003163 003164 003165 003166 003167 003168 003169 00316A 00316B 00316C 00316D 00316E 00316F 003170 003171 003172 003173 003174 003175 003176 003177 003178 003179 00317A 00317B 00317C 00317D 00317E 00317F 003180 003181 003182 003183 003184 003185 003186 003187 003188 003189 00318A 00318B 00318C 00318D 00318E 00318F 003190 003191 003192 003193 003194 003195 003196 003197 003198 003199 00319A 00319B 00319C 00319D 00319E 00319F 0031A0 0031A1 0031A2 0031A3 0031A4 0031A5 0031A6 0031A7 0031A8 0031A9 0031AA 0031AB 0031AC 0031AD 0031AE 0031AF 0031B0 0031B1 0031B2 0031B3 0031B4 0031B5 0031B6 0031B7 0031B8 0031B9 0031BA 0031BB 0031BC 0031BD 0031BE 0031BF 0031C0 0031C1 0031C2 0031C3 0031C4 0031C5 0031C6 0031C7 0031C8 0031C9 0031CA 0031CB 0031CC 0031CD 0031CE 0031CF 0031D0 0031D1 0031D2 0031D3 0031D4 0031D5 0031D6 0031D7 0031D8 0031D9 0031DA 0031DB 0031DC 0031DD 0031DE 0031DF 0031E0 0031E1 0031E2 0031E3 0031E4 0031E5 0031E6 0031E7 0031E8 0031E9 0031EA 0031EB 0031EC 0031ED 0031EE 0031EF 0031F0 0031F1 0031F2 0031F3 0031F4 0031F5 0031F6 0031F7 0031F8 0031F9 0031FA 0031FB 0031FC 0031FD 0031FE 0031FF 003200 003201 003202 003203 003204 003205 003206 003207 003208 003209 00320A 00320B 00320C 00320D 00320E 00320F 003210 003211 003212 003213 003214 003215 003216 003217 003218 003219 00321A 00321B 00321C 00321D 00321E 00321F 003220 003221 003222 003223 003224 003225 003226 003227 003228 003229 00322A 00322B 00322C 00322D 00322E 00322F 003230 003231 003232 003233 003234 003235 003236 003237 003238 003239 00323A 00323B 00323C 00323D 00323E 00323F 003240 003241 003242 003243 003244 003245 003246 003247 003248 003249 00324A 00324B 00324C 00324D 00324E 00324F 003250 003251 003252 003253 003254 003255 003256 003257 003258 003259 00325A 00325B 00325C 00325D 00325E 00325F 003260 003261 003262 003263 003264 003265 003266 003267 003268 003269 00326A 00326B 00326C 00326D 00326E 00326F 003270 003271 003272 003273 003274 003275 003276 003277 003278 003279 00327A 00327B 00327C 00327D 00327E 00327F 003280 003281 003282 003283 003284 003285 003286 003287 003288 003289 00328A 00328B 00328C 00328D 00328E 00328F 003290 003291 003292 003293 003294 003295 003296 003297 003298 003299 00329A 00329B 00329C 00329D 00329E 00329F 0032A0 0032A1 0032A2 0032A3 0032A4 0032A5 0032A6 0032A7 0032A8 0032A9 0032AA 0032AB 0032AC 0032AD 0032AE 0032AF 0032B0 0032B1 0032B2 0032B3 0032B4 0032B5 0032B6 0032B7 0032B8 0032B9 0032BA 0032BB 0032BC 0032BD 0032BE 0032BF 0032C0 0032C1 0032C2 0032C3 0032C4 0032C5 0032C6 0032C7 0032C8 0032C9 0032CA 0032CB 0032CC 0032CD 0032CE 0032CF 0032D0 0032D1 0032D2 0032D3 0032D4 0032D5 0032D6 0032D7 0032D8 0032D9 0032DA 0032DB 0032DC 0032DD 0032DE 0032DF 0032E0 0032E1 0032E2 0032E3 0032E4 0032E5 0032E6 0032E7 0032E8 0032E9 0032EA 0032EB 0032EC 0032ED 0032EE 0032EF 0032F0 0032F1 0032F2 0032F3 0032F4 0032F5 0032F6 0032F7 0032F8 0032F9 0032FA 0032FB 0032FC 0032FD 0032FE 0032FF 003300 003301 003302 003303 003304 003305 003306 003307 003308 003309 00330A 00330B 00330C 00330D 00330E 00330F 003310 003311 003312 003313 003314 003315 003316 003317 003318 003319 00331A 00331B 00331C 00331D 00331E 00331F 003320 003321 003322 003323 003324 003325 003326 003327 003328 003329 00332A 00332B 00332C 00332D 00332E 00332F 003330 003331 003332 003333 003334 003335 003336 003337 003338 003339 00333A 00333B 00333C 00333D 00333E 00333F 003340 003341 003342 003343 003344 003345 003346 003347 003348 003349 00334A 00334B 00334C 00334D 00334E 00334F 003350 003351 003352 003353 003354 003355 003356 003357 003358 003359 00335A 00335B 00335C 00335D 00335E 00335F 003360 003361 003362 003363 003364 003365 003366 003367 003368 003369 00336A 00336B 00336C 00336D 00336E 00336F 003370 003371 003372 003373 003374 003375 003376 003377 003378 003379 00337A 00337B 00337C 00337D 00337E 00337F 003380 003381 003382 003383 003384 003385 003386 003387 003388 003389 00338A 00338B 00338C 00338D 00338E 00338F 003390 003391 003392 003393 003394 003395 003396 003397 003398 003399 00339A 00339B 00339C 00339D 00339E 00339F 0033A0 0033A1 0033A2 0033A3 0033A4 0033A5 0033A6 0033A7 0033A8 0033A9 0033AA 0033AB 0033AC 0033AD 0033AE 0033AF 0033B0 0033B1 0033B2 0033B3 0033B4 0033B5 0033B6 0033B7 0033B8 0033B9 0033BA 0033BB 0033BC 0033BD 0033BE 0033BF 0033C0 0033C1 0033C2 0033C3 0033C4 0033C5 0033C6 0033C7 0033C8 0033C9 0033CA 0033CB 0033CC 0033CD 0033CE 0033CF 0033D0 0033D1 0033D2 0033D3 0033D4 0033D5 0033D6 0033D7 0033D8 0033D9 0033DA 0033DB 0033DC 0033DD 0033DE 0033DF 0033E0 0033E1 0033E2 0033E3 0033E4 0033E5 0033E6 0033E7 0033E8 0033E9 0033EA 0033EB 0033EC 0033ED 0033EE 0033EF 0033F0 0033F1 0033F2 0033F3 0033F4 0033F5 0033F6 0033F7 0033F8 0033F9 0033FA 0033FB 0033FC 0033FD 0033FE 0033FF 003400 003401 003402 003403 003404 003405 003406 003407 003408 003409 00340A 00340B 00340C 00340D 00340E 00340F 003410 003411 003412 003413 003414 003415 003416 003417 003418 003419 00341A 00341B 00341C 00341D 00341E 00341F 003420 003421 003422 003423 003424 003425 003426 003427 003428 003429 00342A 00342B 00342C 00342D 00342E 00342F 003430 003431 003432 003433 003434 003435 003436 003437 003438 003439 00343A 00343B 00343C 00343D 00343E 00343F 003440 003441 003442 003443 003444 003445 003446 003447 003448 003449 00344A 00344B 00344C 00344D 00344E 00344F 003450 003451 003452 003453 003454 003455 003456 003457 003458 003459 00345A 00345B 00345C 00345D 00345E 00345F 003460 003461 003462 003463 003464 003465 003466 003467 003468 003469 00346A 00346B 00346C 00346D 00346E 00346F 003470 003471 003472 003473 003474 003475 003476 003477 003478 003479 00347A 00347B 00347C 00347D 00347E 00347F 003480 003481 003482 003483 003484 003485 003486 003487 003488 003489 00348A 00348B 00348C 00348D 00348E 00348F 003490 003491 003492 003493 003494 003495 003496 003497 003498 003499 00349A 00349B 00349C 00349D 00349E 00349F 0034A0 0034A1 0034A2 0034A3 0034A4 0034A5 0034A6 0034A7 0034A8 0034A9 0034AA 0034AB 0034AC 0034AD 0034AE 0034AF 0034B0 0034B1 0034B2 0034B3 0034B4 0034B5 0034B6 0034B7 0034B8 0034B9 0034BA 0034BB 0034BC 0034BD 0034BE 0034BF 0034C0 0034C1 0034C2 0034C3 0034C4 0034C5 0034C6 0034C7 0034C8 0034C9 0034CA 0034CB 0034CC 0034CD 0034CE 0034CF 0034D0 0034D1 0034D2 0034D3 0034D4 0034D5 0034D6 0034D7 0034D8 0034D9 0034DA 0034DB 0034DC 0034DD 0034DE 0034DF 0034E0 0034E1 0034E2 0034E3 0034E4 0034E5 0034E6 0034E7 0034E8 0034E9 0034EA 0034EB 0034EC 0034ED 0034EE 0034EF 0034F0 0034F1 0034F2 0034F3 0034F4 0034F5 0034F6 0034F7 0034F8 0034F9 0034FA 0034FB 0034FC 0034FD 0034FE 0034FF 003500 003501 003502 003503 003504 003505 003506 003507 003508 003509 00350A 00350B 00350C 00350D 00350E 00350F 003510 003511 003512 003513 003514 003515 003516 003517 003518 003519 00351A 00351B 00351C 00351D 00351E 00351F 003520 003521 003522 003523 003524 003525 003526 003527 003528 003529 00352A 00352B 00352C 00352D 00352E 00352F 003530 003531 003532 003533 003534 003535 003536 003537 003538 003539 00353A 00353B 00353C 00353D 00353E 00353F 003540 003541 003542 003543 003544 003545 003546 003547 003548 003549 00354A 00354B 00354C 00354D 00354E 00354F 003550 003551 003552 003553 003554 003555 003556 003557 003558 003559 00355A 00355B 00355C 00355D 00355E 00355F 003560 003561 003562 003563 003564 003565 003566 003567 003568 003569 00356A 00356B 00356C 00356D 00356E 00356F 003570 003571 003572 003573 003574 003575 003576 003577 003578 003579 00357A 00357B 00357C 00357D 00357E 00357F 003580 003581 003582 003583 003584 003585 003586 003587 003588 003589 00358A 00358B 00358C 00358D 00358E 00358F 003590 003591 003592 003593 003594 003595 003596 003597 003598 003599 00359A 00359B 00359C 00359D 00359E 00359F 0035A0 0035A1 0035A2 0035A3 0035A4 0035A5 0035A6 0035A7 0035A8 0035A9 0035AA 0035AB 0035AC 0035AD 0035AE 0035AF 0035B0 0035B1 0035B2 0035B3 0035B4 0035B5 0035B6 0035B7 0035B8 0035B9 0035BA 0035BB 0035BC 0035BD 0035BE 0035BF 0035C0 0035C1 0035C2 0035C3 0035C4 0035C5 0035C6 0035C7 0035C8 0035C9 0035CA 0035CB 0035CC 0035CD 0035CE 0035CF 0035D0 0035D1 0035D2 0035D3 0035D4 0035D5 0035D6 0035D7 0035D8 0035D9 0035DA 0035DB 0035DC 0035DD 0035DE 0035DF 0035E0 0035E1 0035E2 0035E3 0035E4 0035E5 0035E6 0035E7 0035E8 0035E9 0035EA 0035EB 0035EC 0035ED 0035EE 0035EF 0035F0 0035F1 0035F2 0035F3 0035F4 0035F5 0035F6 0035F7 0035F8 0035F9 0035FA 0035FB 0035FC 0035FD 0035FE 0035FF 003600 003601 003602 003603 003604 003605 003606 003607 003608 003609 00360A 00360B 00360C 00360D 00360E 00360F 003610 003611 003612 003613 003614 003615 003616 003617 003618 003619 00361A 00361B 00361C 00361D 00361E 00361F 003620 003621 003622 003623 003624 003625 003626 003627 003628 003629 00362A 00362B 00362C 00362D 00362E 00362F 003630 003631 003632 003633 003634 003635 003636 003637 003638 003639 00363A 00363B 00363C 00363D 00363E 00363F 003640 003641 003642 003643 003644 003645 003646 003647 003648 003649 00364A 00364B 00364C 00364D 00364E 00364F 003650 003651 003652 003653 003654 003655 003656 003657 003658 003659 00365A 00365B 00365C 00365D 00365E 00365F 003660 003661 003662 003663 003664 003665 003666 003667 003668 003669 00366A 00366B 00366C 00366D 00366E 00366F 003670 003671 003672 003673 003674 003675 003676 003677 003678 003679 00367A 00367B 00367C 00367D 00367E 00367F 003680 003681 003682 003683 003684 003685 003686 003687 003688 003689 00368A 00368B 00368C 00368D 00368E 00368F 003690 003691 003692 003693 003694 003695 003696 003697 003698 003699 00369A 00369B 00369C 00369D 00369E 00369F 0036A0 0036A1 0036A2 0036A3 0036A4 0036A5 0036A6 0036A7 0036A8 0036A9 0036AA 0036AB 0036AC 0036AD 0036AE 0036AF 0036B0 0036B1 0036B2 0036B3 0036B4 0036B5 0036B6 0036B7 0036B8 0036B9 0036BA 0036BB 0036BC 0036BD 0036BE 0036BF 0036C0 0036C1 0036C2 0036C3 0036C4 0036C5 0036C6 0036C7 0036C8 0036C9 0036CA 0036CB 0036CC 0036CD 0036CE 0036CF 0036D0 0036D1 0036D2 0036D3 0036D4 0036D5 0036D6 0036D7 0036D8 0036D9 0036DA 0036DB 0036DC 0036DD 0036DE 0036DF 0036E0 0036E1 0036E2 0036E3 0036E4 0036E5 0036E6 0036E7 0036E8 0036E9 0036EA 0036EB 0036EC 0036ED 0036EE 0036EF 0036F0 0036F1 0036F2 0036F3 0036F4 0036F5 0036F6 0036F7 0036F8 0036F9 0036FA 0036FB 0036FC 0036FD 0036FE 0036FF 003700 003701 003702 003703 003704 003705 003706 003707 003708 003709 00370A 00370B 00370C 00370D 00370E 00370F 003710 003711 003712 003713 003714 003715 003716 003717 003718 003719 00371A 00371B 00371C 00371D 00371E 00371F 003720 003721 003722 003723 003724 003725 003726 003727 003728 003729 00372A 00372B 00372C 00372D 00372E 00372F 003730 003731 003732 003733 003734 003735 003736 003737 003738 003739 00373A 00373B 00373C 00373D 00373E 00373F 003740 003741 003742 003743 003744 003745 003746 003747 003748 003749 00374A 00374B 00374C 00374D 00374E 00374F 003750 003751 003752 003753 003754 003755 003756 003757 003758 003759 00375A 00375B 00375C 00375D 00375E 00375F 003760 003761 003762 003763 003764 003765 003766 003767 003768 003769 00376A 00376B 00376C 00376D 00376E 00376F 003770 003771 003772 003773 003774 003775 003776 003777 003778 003779 00377A 00377B 00377C 00377D 00377E 00377F 003780 003781 003782 003783 003784 003785 003786 003787 003788 003789 00378A 00378B 00378C 00378D 00378E 00378F 003790 003791 003792 003793 003794 003795 003796 003797 003798 003799 00379A 00379B 00379C 00379D 00379E 00379F 0037A0 0037A1 0037A2 0037A3 0037A4 0037A5 0037A6 0037A7 0037A8 0037A9 0037AA 0037AB 0037AC 0037AD 0037AE 0037AF 0037B0 0037B1 0037B2 0037B3 0037B4 0037B5 0037B6 0037B7 0037B8 0037B9 0037BA 0037BB 0037BC 0037BD 0037BE 0037BF 0037C0 0037C1 0037C2 0037C3 0037C4 0037C5 0037C6 0037C7 0037C8 0037C9 0037CA 0037CB 0037CC 0037CD 0037CE 0037CF 0037D0 0037D1 0037D2 0037D3 0037D4 0037D5 0037D6 0037D7 0037D8 0037D9 0037DA 0037DB 0037DC 0037DD 0037DE 0037DF 0037E0 0037E1 0037E2 0037E3 0037E4 0037E5 0037E6 0037E7 0037E8 0037E9 0037EA 0037EB 0037EC 0037ED 0037EE 0037EF 0037F0 0037F1 0037F2 0037F3 0037F4 0037F5 0037F6 0037F7 0037F8 0037F9 0037FA 0037FB 0037FC 0037FD 0037FE 0037FF 003800 003801 003802 003803 003804 003805 003806 003807 003808 003809 00380A 00380B 00380C 00380D 00380E 00380F 003810 003811 003812 003813 003814 003815 003816 003817 003818 003819 00381A 00381B 00381C 00381D 00381E 00381F 003820 003821 003822 003823 003824 003825 003826 003827 003828 003829 00382A 00382B 00382C 00382D 00382E 00382F 003830 003831 003832 003833 003834 003835 003836 003837 003838 003839 00383A 00383B 00383C 00383D 00383E 00383F 003840 003841 003842 003843 003844 003845 003846 003847 003848 003849 00384A 00384B 00384C 00384D 00384E 00384F 003850 003851 003852 003853 003854 003855 003856 003857 003858 003859 00385A 00385B 00385C 00385D 00385E 00385F 003860 003861 003862 003863 003864 003865 003866 003867 003868 003869 00386A 00386B 00386C 00386D 00386E 00386F 003870 003871 003872 003873 003874 003875 003876 003877 003878 003879 00387A 00387B 00387C 00387D 00387E 00387F 003880 003881 003882 003883 003884 003885 003886 003887 003888 003889 00388A 00388B 00388C 00388D 00388E 00388F 003890 003891 003892 003893 003894 003895 003896 003897 003898 003899 00389A 00389B 00389C 00389D 00389E 00389F 0038A0 0038A1 0038A2 0038A3 0038A4 0038A5 0038A6 0038A7 0038A8 0038A9 0038AA 0038AB 0038AC 0038AD 0038AE 0038AF 0038B0 0038B1 0038B2 0038B3 0038B4 0038B5 0038B6 0038B7 0038B8 0038B9 0038BA 0038BB 0038BC 0038BD 0038BE 0038BF 0038C0 0038C1 0038C2 0038C3 0038C4 0038C5 0038C6 0038C7 0038C8 0038C9 0038CA 0038CB 0038CC 0038CD 0038CE 0038CF 0038D0 0038D1 0038D2 0038D3 0038D4 0038D5 0038D6 0038D7 0038D8 0038D9 0038DA 0038DB 0038DC 0038DD 0038DE 0038DF 0038E0 0038E1 0038E2 0038E3 0038E4 0038E5 0038E6 0038E7 0038E8 0038E9 0038EA 0038EB 0038EC 0038ED 0038EE 0038EF 0038F0 0038F1 0038F2 0038F3 0038F4 0038F5 0038F6 0038F7 0038F8 0038F9 0038FA 0038FB 0038FC 0038FD 0038FE 0038FF 003900 003901 003902 003903 003904 003905 003906 003907 003908 003909 00390A 00390B 00390C 00390D 00390E 00390F 003910 003911 003912 003913 003914 003915 003916 003917 003918 003919 00391A 00391B 00391C 00391D 00391E 00391F 003920 003921 003922 003923 003924 003925 003926 003927 003928 003929 00392A 00392B 00392C 00392D 00392E 00392F 003930 003931 003932 003933 003934 003935 003936 003937 003938 003939 00393A 00393B 00393C 00393D 00393E 00393F 003940 003941 003942 003943 003944 003945 003946 003947 003948 003949 00394A 00394B 00394C 00394D 00394E 00394F 003950 003951 003952 003953 003954 003955 003956 003957 003958 003959 00395A 00395B 00395C 00395D 00395E 00395F 003960 003961 003962 003963 003964 003965 003966 003967 003968 003969 00396A 00396B 00396C 00396D 00396E 00396F 003970 003971 003972 003973 003974 003975 003976 003977 003978 003979 00397A 00397B 00397C 00397D 00397E 00397F 003980 003981 003982 003983 003984 003985 003986 003987 003988 003989 00398A 00398B 00398C 00398D 00398E 00398F 003990 003991 003992 003993 003994 003995 003996 003997 003998 003999 00399A 00399B 00399C 00399D 00399E 00399F 0039A0 0039A1 0039A2 0039A3 0039A4 0039A5 0039A6 0039A7 0039A8 0039A9 0039AA 0039AB 0039AC 0039AD 0039AE 0039AF 0039B0 0039B1 0039B2 0039B3 0039B4 0039B5 0039B6 0039B7 0039B8 0039B9 0039BA 0039BB 0039BC 0039BD 0039BE 0039BF 0039C0 0039C1 0039C2 0039C3 0039C4 0039C5 0039C6 0039C7 0039C8 0039C9 0039CA 0039CB 0039CC 0039CD 0039CE 0039CF 0039D0 0039D1 0039D2 0039D3 0039D4 0039D5 0039D6 0039D7 0039D8 0039D9 0039DA 0039DB 0039DC 0039DD 0039DE 0039DF 0039E0 0039E1 0039E2 0039E3 0039E4 0039E5 0039E6 0039E7 0039E8 0039E9 0039EA 0039EB 0039EC 0039ED 0039EE 0039EF 0039F0 0039F1 0039F2 0039F3 0039F4 0039F5 0039F6 0039F7 0039F8 0039F9 0039FA 0039FB 0039FC 0039FD 0039FE 0039FF 003A00 003A01 003A02 003A03 003A04 003A05 003A06 003A07 003A08 003A09 003A0A 003A0B 003A0C 003A0D 003A0E 003A0F 003A10 003A11 003A12 003A13 003A14 003A15 003A16 003A17 003A18 003A19 003A1A 003A1B 003A1C 003A1D 003A1E 003A1F 003A20 003A21 003A22 003A23 003A24 003A25 003A26 003A27 003A28 003A29 003A2A 003A2B 003A2C 003A2D 003A2E 003A2F 003A30 003A31 003A32 003A33 003A34 003A35 003A36 003A37 003A38 003A39 003A3A 003A3B 003A3C 003A3D 003A3E 003A3F 003A40 003A41 003A42 003A43 003A44 003A45 003A46 003A47 003A48 003A49 003A4A 003A4B 003A4C 003A4D 003A4E 003A4F 003A50 003A51 003A52 003A53 003A54 003A55 003A56 003A57 003A58 003A59 003A5A 003A5B 003A5C 003A5D 003A5E 003A5F 003A60 003A61 003A62 003A63 003A64 003A65 003A66 003A67 003A68 003A69 003A6A 003A6B 003A6C 003A6D 003A6E 003A6F 003A70 003A71 003A72 003A73 003A74 003A75 003A76 003A77 003A78 003A79 003A7A 003A7B 003A7C 003A7D 003A7E 003A7F 003A80 003A81 003A82 003A83 003A84 003A85 003A86 003A87 003A88 003A89 003A8A 003A8B 003A8C 003A8D 003A8E 003A8F 003A90 003A91 003A92 003A93 003A94 003A95 003A96 003A97 003A98 003A99 003A9A 003A9B 003A9C 003A9D 003A9E 003A9F 003AA0 003AA1 003AA2 003AA3 003AA4 003AA5 003AA6 003AA7 003AA8 003AA9 003AAA 003AAB 003AAC 003AAD 003AAE 003AAF 003AB0 003AB1 003AB2 003AB3 003AB4 003AB5 003AB6 003AB7 003AB8 003AB9 003ABA 003ABB 003ABC 003ABD 003ABE 003ABF 003AC0 003AC1 003AC2 003AC3 003AC4 003AC5 003AC6 003AC7 003AC8 003AC9 003ACA 003ACB 003ACC 003ACD 003ACE 003ACF 003AD0 003AD1 003AD2 003AD3 003AD4 003AD5 003AD6 003AD7 003AD8 003AD9 003ADA 003ADB 003ADC 003ADD 003ADE 003ADF 003AE0 003AE1 003AE2 003AE3 003AE4 003AE5 003AE6 003AE7 003AE8 003AE9 003AEA 003AEB 003AEC 003AED 003AEE 003AEF 003AF0 003AF1 003AF2 003AF3 003AF4 003AF5 003AF6 003AF7 003AF8 003AF9 003AFA 003AFB 003AFC 003AFD 003AFE 003AFF 003B00 003B01 003B02 003B03 003B04 003B05 003B06 003B07 003B08 003B09 003B0A 003B0B 003B0C 003B0D 003B0E 003B0F 003B10 003B11 003B12 003B13 003B14 003B15 003B16 003B17 003B18 003B19 003B1A 003B1B 003B1C 003B1D 003B1E 003B1F 003B20 003B21 003B22 003B23 003B24 003B25 003B26 003B27 003B28 003B29 003B2A 003B2B 003B2C 003B2D 003B2E 003B2F 003B30 003B31 003B32 003B33 003B34 003B35 003B36 003B37 003B38 003B39 003B3A 003B3B 003B3C 003B3D 003B3E 003B3F 003B40 003B41 003B42 003B43 003B44 003B45 003B46 003B47 003B48 003B49 003B4A 003B4B 003B4C 003B4D 003B4E 003B4F 003B50 003B51 003B52 003B53 003B54 003B55 003B56 003B57 003B58 003B59 003B5A 003B5B 003B5C 003B5D 003B5E 003B5F 003B60 003B61 003B62 003B63 003B64 003B65 003B66 003B67 003B68 003B69 003B6A 003B6B 003B6C 003B6D 003B6E 003B6F 003B70 003B71 003B72 003B73 003B74 003B75 003B76 003B77 003B78 003B79 003B7A 003B7B 003B7C 003B7D 003B7E 003B7F 003B80 003B81 003B82 003B83 003B84 003B85 003B86 003B87 003B88 003B89 003B8A 003B8B 003B8C 003B8D 003B8E 003B8F 003B90 003B91 003B92 003B93 003B94 003B95 003B96 003B97 003B98 003B99 003B9A 003B9B 003B9C 003B9D 003B9E 003B9F 003BA0 003BA1 003BA2 003BA3 003BA4 003BA5 003BA6 003BA7 003BA8 003BA9 003BAA 003BAB 003BAC 003BAD 003BAE 003BAF 003BB0 003BB1 003BB2 003BB3 003BB4 003BB5 003BB6 003BB7 003BB8 003BB9 003BBA 003BBB 003BBC 003BBD 003BBE 003BBF 003BC0 003BC1 003BC2 003BC3 003BC4 003BC5 003BC6 003BC7 003BC8 003BC9 003BCA 003BCB 003BCC 003BCD 003BCE 003BCF 003BD0 003BD1 003BD2 003BD3 003BD4 003BD5 003BD6 003BD7 003BD8 003BD9 003BDA 003BDB 003BDC 003BDD 003BDE 003BDF 003BE0 003BE1 003BE2 003BE3 003BE4 003BE5 003BE6 003BE7 003BE8 003BE9 003BEA 003BEB 003BEC 003BED 003BEE 003BEF 003BF0 003BF1 003BF2 003BF3 003BF4 003BF5 003BF6 003BF7 003BF8 003BF9 003BFA 003BFB 003BFC 003BFD 003BFE 003BFF 003C00 003C01 003C02 003C03 003C04 003C05 003C06 003C07 003C08 003C09 003C0A 003C0B 003C0C 003C0D 003C0E 003C0F 003C10 003C11 003C12 003C13 003C14 003C15 003C16 003C17 003C18 003C19 003C1A 003C1B 003C1C 003C1D 003C1E 003C1F 003C20 003C21 003C22 003C23 003C24 003C25 003C26 003C27 003C28 003C29 003C2A 003C2B 003C2C 003C2D 003C2E 003C2F 003C30 003C31 003C32 003C33 003C34 003C35 003C36 003C37 003C38 003C39 003C3A 003C3B 003C3C 003C3D 003C3E 003C3F 003C40 003C41 003C42 003C43 003C44 003C45 003C46 003C47 003C48 003C49 003C4A 003C4B 003C4C 003C4D 003C4E 003C4F 003C50 003C51 003C52 003C53 003C54 003C55 003C56 003C57 003C58 003C59 003C5A 003C5B 003C5C 003C5D 003C5E 003C5F 003C60 003C61 003C62 003C63 003C64 003C65 003C66 003C67 003C68 003C69 003C6A 003C6B 003C6C 003C6D 003C6E 003C6F 003C70 003C71 003C72 003C73 003C74 003C75 003C76 003C77 003C78 003C79 003C7A 003C7B 003C7C 003C7D 003C7E 003C7F 003C80 003C81 003C82 003C83 003C84 003C85 003C86 003C87 003C88 003C89 003C8A 003C8B 003C8C 003C8D 003C8E 003C8F 003C90 003C91 003C92 003C93 003C94 003C95 003C96 003C97 003C98 003C99 003C9A 003C9B 003C9C 003C9D 003C9E 003C9F 003CA0 003CA1 003CA2 003CA3 003CA4 003CA5 003CA6 003CA7 003CA8 003CA9 003CAA 003CAB 003CAC 003CAD 003CAE 003CAF 003CB0 003CB1 003CB2 003CB3 003CB4 003CB5 003CB6 003CB7 003CB8 003CB9 003CBA 003CBB 003CBC 003CBD 003CBE 003CBF 003CC0 003CC1 003CC2 003CC3 003CC4 003CC5 003CC6 003CC7 003CC8 003CC9 003CCA 003CCB 003CCC 003CCD 003CCE 003CCF 003CD0 003CD1 003CD2 003CD3 003CD4 003CD5 003CD6 003CD7 003CD8 003CD9 003CDA 003CDB 003CDC 003CDD 003CDE 003CDF 003CE0 003CE1 003CE2 003CE3 003CE4 003CE5 003CE6 003CE7 003CE8 003CE9 003CEA 003CEB 003CEC 003CED 003CEE 003CEF 003CF0 003CF1 003CF2 003CF3 003CF4 003CF5 003CF6 003CF7 003CF8 003CF9 003CFA 003CFB 003CFC 003CFD 003CFE 003CFF 003D00 003D01 003D02 003D03 003D04 003D05 003D06 003D07 003D08 003D09 003D0A 003D0B 003D0C 003D0D 003D0E 003D0F 003D10 003D11 003D12 003D13 003D14 003D15 003D16 003D17 003D18 003D19 003D1A 003D1B 003D1C 003D1D 003D1E 003D1F 003D20 003D21 003D22 003D23 003D24 003D25 003D26 003D27 003D28 003D29 003D2A 003D2B 003D2C 003D2D 003D2E 003D2F 003D30 003D31 003D32 003D33 003D34 003D35 003D36 003D37 003D38 003D39 003D3A 003D3B 003D3C 003D3D 003D3E 003D3F 003D40 003D41 003D42 003D43 003D44 003D45 003D46 003D47 003D48 003D49 003D4A 003D4B 003D4C 003D4D 003D4E 003D4F 003D50 003D51 003D52 003D53 003D54 003D55
0x003060 ---- 01:F050:  LSR  ; 
0x003061 ---- 01:F051:  LSR  ; 
0x003062 ---- 01:F052:  LSR  ; 
0x003063 ---- 01:F053:  LSR  ; 
; 1 refs via 00305B
0x003064 ---- 01:F054:  LDX ram_0056  ; $0056
0x003066 ---- 01:F056:  LDY ram_0057  ; $0057
0x003068 ---- 01:F058:  JSR $D80B  ; 00181B
; 1 refs via 00186D
0x00306B ---- 01:F05B:  LDA #$00  ; 
0x00306D nZ-- 01:F05D:  STA ram_000C  ; $000C
0x00306F nZ-- 01:F05F:  INC ram_005A  ; $005A
0x003071 ---- 01:F061:  LDA ram_0056  ; $0056
0x003073 ---- 01:F063:  CLC  ; 
0x003074 --c- 01:F064:  ADC #$10  ; 
0x003076 ---- 01:F066:  STA ram_0056  ; $0056
0x003078 ---- 01:F068:  CMP #$E0  ; 
0x00307A ---- 01:F06A:  BNE $F03D  ; 00304D
0x00307C -Z-- 01:F06C:  INC ram_005A  ; $005A
0x00307E ---- 01:F06E:  LDA ram_0057  ; $0057
0x003080 ---- 01:F070:  CLC  ; 
0x003081 --c- 01:F071:  ADC #$10  ; 
0x003083 ---- 01:F073:  STA ram_0057  ; $0057
0x003085 ---- 01:F075:  CMP #$E0  ; 
0x003087 ---- 01:F077:  BNE $F036  ; 003046
0x003089 -Z-- 01:F079:  RTS  ; 0001EC 0003E8
0x00308A ---- 01:F07A:  .byte $DD   ; 003057 00305E
0x00308B ---- 01:F07B:  .byte $DD   ; 003057 00305E
0x00308C ---- 01:F07C:  .byte $DD   ; 003057 00305E
0x00308D ---- 01:F07D:  .byte $DD   ; 003057 00305E
0x00308E ---- 01:F07E:  .byte $DD   ; 003057 00305E
0x00308F ---- 01:F07F:  .byte $DD   ; 003057 00305E
0x003090 ---- 01:F080:  .byte $DD   ; 00305E
0x003091 ---- 01:F081:  .byte $D4   ; 003057 00305E
0x003092 ---- 01:F082:  .byte $D4   ; 003057 00305E
0x003093 ---- 01:F083:  .byte $D4   ; 003057 00305E
0x003094 ---- 01:F084:  .byte $D4   ; 003057 00305E
0x003095 ---- 01:F085:  .byte $D4   ; 003057 00305E
0x003096 ---- 01:F086:  .byte $D4   ; 003057 00305E
0x003097 ---- 01:F087:  .byte $DD   ; 00305E
0x003098 ---- 01:F088:  .byte $D4   ; 003057 00305E
0x003099 ---- 01:F089:  .byte $D4   ; 003057 00305E
0x00309A ---- 01:F08A:  .byte $D4   ; 003057 00305E
0x00309B ---- 01:F08B:  .byte $D4   ; 003057 00305E
0x00309C ---- 01:F08C:  .byte $D4   ; 003057 00305E
0x00309D ---- 01:F08D:  .byte $D4   ; 003057 00305E
0x00309E ---- 01:F08E:  .byte $DD   ; 00305E
0x00309F ---- 01:F08F:  .byte $D4   ; 003057 00305E
0x0030A0 ---- 01:F090:  .byte $D4   ; 003057 00305E
0x0030A1 ---- 01:F091:  .byte $D4   ; 003057 00305E
0x0030A2 ---- 01:F092:  .byte $94   ; 003057 00305E
0x0030A3 ---- 01:F093:  .byte $D4   ; 003057 00305E
0x0030A4 ---- 01:F094:  .byte $D4   ; 003057 00305E
0x0030A5 ---- 01:F095:  .byte $DD   ; 00305E
0x0030A6 ---- 01:F096:  .byte $D4   ; 003057 00305E
0x0030A7 ---- 01:F097:  .byte $D4   ; 003057 00305E
0x0030A8 ---- 01:F098:  .byte $D3   ; 003057 00305E
0x0030A9 ---- 01:F099:  .byte $D3   ; 003057 00305E
0x0030AA ---- 01:F09A:  .byte $D4   ; 003057 00305E
0x0030AB ---- 01:F09B:  .byte $D4   ; 003057 00305E
0x0030AC ---- 01:F09C:  .byte $DD   ; 00305E
0x0030AD ---- 01:F09D:  .byte $D3   ; 003057 00305E
0x0030AE ---- 01:F09E:  .byte $D3   ; 003057 00305E
0x0030AF ---- 01:F09F:  .byte $D1   ; 003057 00305E
0x0030B0 ---- 01:F0A0:  .byte $D1   ; 003057 00305E
0x0030B1 ---- 01:F0A1:  .byte $D3   ; 003057 00305E
0x0030B2 ---- 01:F0A2:  .byte $D3   ; 003057 00305E
0x0030B3 ---- 01:F0A3:  .byte $DD   ; 00305E
0x0030B4 ---- 01:F0A4:  .byte $1D   ; 003057 00305E
0x0030B5 ---- 01:F0A5:  .byte $11   ; 003057 00305E
0x0030B6 ---- 01:F0A6:  .byte $D3   ; 003057 00305E
0x0030B7 ---- 01:F0A7:  .byte $D3   ; 003057 00305E
0x0030B8 ---- 01:F0A8:  .byte $D1   ; 003057 00305E
0x0030B9 ---- 01:F0A9:  .byte $1D   ; 003057 00305E
0x0030BA ---- 01:F0AA:  .byte $1D   ; 00305E
0x0030BB ---- 01:F0AB:  .byte $8D   ; 003057 00305E
0x0030BC ---- 01:F0AC:  .byte $33   ; 003057 00305E
0x0030BD ---- 01:F0AD:  .byte $D1   ; 003057 00305E
0x0030BE ---- 01:F0AE:  .byte $D1   ; 003057 00305E
0x0030BF ---- 01:F0AF:  .byte $D3   ; 003057 00305E
0x0030C0 ---- 01:F0B0:  .byte $3D   ; 003057 00305E
0x0030C1 ---- 01:F0B1:  .byte $8D   ; 00305E
0x0030C2 ---- 01:F0B2:  .byte $D1   ; 003057 00305E
0x0030C3 ---- 01:F0B3:  .byte $D1   ; 003057 00305E
0x0030C4 ---- 01:F0B4:  .byte $D4   ; 003057 00305E
0x0030C5 ---- 01:F0B5:  .byte $44   ; 003057 00305E
0x0030C6 ---- 01:F0B6:  .byte $D1   ; 003057 00305E
0x0030C7 ---- 01:F0B7:  .byte $D1   ; 003057 00305E
0x0030C8 ---- 01:F0B8:  .byte $DD   ; 00305E
0x0030C9 ---- 01:F0B9:  .byte $D4   ; 003057 00305E
0x0030CA ---- 01:F0BA:  .byte $D4   ; 003057 00305E
0x0030CB ---- 01:F0BB:  .byte $D4   ; 003057 00305E
0x0030CC ---- 01:F0BC:  .byte $D4   ; 003057 00305E
0x0030CD ---- 01:F0BD:  .byte $D4   ; 003057 00305E
0x0030CE ---- 01:F0BE:  .byte $D4   ; 003057 00305E
0x0030CF ---- 01:F0BF:  .byte $DD   ; 00305E
0x0030D0 ---- 01:F0C0:  .byte $D4   ; 003057 00305E
0x0030D1 ---- 01:F0C1:  .byte $D4   ; 003057 00305E
0x0030D2 ---- 01:F0C2:  .byte $D3   ; 003057 00305E
0x0030D3 ---- 01:F0C3:  .byte $D3   ; 003057 00305E
0x0030D4 ---- 01:F0C4:  .byte $D4   ; 003057 00305E
0x0030D5 ---- 01:F0C5:  .byte $D4   ; 003057 00305E
0x0030D6 ---- 01:F0C6:  .byte $DD   ; 00305E
0x0030D7 ---- 01:F0C7:  .byte $D4   ; 003057 00305E
0x0030D8 ---- 01:F0C8:  .byte $D4   ; 003057 00305E
0x0030D9 ---- 01:F0C9:  .byte $DD   ; 003057 00305E
0x0030DA ---- 01:F0CA:  .byte $DD   ; 003057 00305E
0x0030DB ---- 01:F0CB:  .byte $D4   ; 003057 00305E
0x0030DC ---- 01:F0CC:  .byte $D4   ; 003057 00305E
0x0030DD ---- 01:F0CD:  .byte $DD   ; 00305E
0x0030DE ---- 01:F0CE:  .byte $DD   ; 003057 00305E
0x0030DF ---- 01:F0CF:  .byte $DD   ; 003057 00305E
0x0030E0 ---- 01:F0D0:  .byte $DD   ; 003057 00305E
0x0030E1 ---- 01:F0D1:  .byte $DD   ; 003057 00305E
0x0030E2 ---- 01:F0D2:  .byte $DD   ; 003057 00305E
0x0030E3 ---- 01:F0D3:  .byte $DD   ; 003057 00305E
0x0030E4 ---- 01:F0D4:  .byte $DD   ; 00305E
0x0030E5 ---- 01:F0D5:  .byte $DD   ; 003057 00305E
0x0030E6 ---- 01:F0D6:  .byte $D9   ; 003057 00305E
0x0030E7 ---- 01:F0D7:  .byte $DD   ; 003057 00305E
0x0030E8 ---- 01:F0D8:  .byte $D9   ; 003057 00305E
0x0030E9 ---- 01:F0D9:  .byte $DD   ; 003057 00305E
0x0030EA ---- 01:F0DA:  .byte $DD   ; 003057 00305E
0x0030EB ---- 01:F0DB:  .byte $DD   ; 00305E
0x0030EC ---- 01:F0DC:  .byte $D4   ; 003057 00305E
0x0030ED ---- 01:F0DD:  .byte $D9   ; 003057 00305E
0x0030EE ---- 01:F0DE:  .byte $DD   ; 003057 00305E
0x0030EF ---- 01:F0DF:  .byte $D4   ; 003057 00305E
0x0030F0 ---- 01:F0E0:  .byte $D4   ; 003057 00305E
0x0030F1 ---- 01:F0E1:  .byte $D4   ; 003057 00305E
0x0030F2 ---- 01:F0E2:  .byte $DD   ; 00305E
0x0030F3 ---- 01:F0E3:  .byte $D4   ; 003057 00305E
0x0030F4 ---- 01:F0E4:  .byte $DD   ; 003057 00305E
0x0030F5 ---- 01:F0E5:  .byte $DD   ; 003057 00305E
0x0030F6 ---- 01:F0E6:  .byte $44   ; 003057 00305E
0x0030F7 ---- 01:F0E7:  .byte $D4   ; 003057 00305E
0x0030F8 ---- 01:F0E8:  .byte $94   ; 003057 00305E
0x0030F9 ---- 01:F0E9:  .byte $DD   ; 00305E
0x0030FA ---- 01:F0EA:  .byte $DD   ; 003057 00305E
0x0030FB ---- 01:F0EB:  .byte $D4   ; 003057 00305E
0x0030FC ---- 01:F0EC:  .byte $DD   ; 003057 00305E
0x0030FD ---- 01:F0ED:  .byte $DD   ; 003057 00305E
0x0030FE ---- 01:F0EE:  .byte $D9   ; 003057 00305E
0x0030FF ---- 01:F0EF:  .byte $DD   ; 003057 00305E
0x003100 ---- 01:F0F0:  .byte $DD   ; 00305E
0x003101 ---- 01:F0F1:  .byte $BD   ; 003057 00305E
0x003102 ---- 01:F0F2:  .byte $D4   ; 003057 00305E
0x003103 ---- 01:F0F3:  .byte $DD   ; 003057 00305E
0x003104 ---- 01:F0F4:  .byte $9D   ; 003057 00305E
0x003105 ---- 01:F0F5:  .byte $D4   ; 003057 00305E
0x003106 ---- 01:F0F6:  .byte $B4   ; 003057 00305E
0x003107 ---- 01:F0F7:  .byte $9D   ; 00305E
0x003108 ---- 01:F0F8:  .byte $BB   ; 003057 00305E
0x003109 ---- 01:F0F9:  .byte $DD   ; 003057 00305E
0x00310A ---- 01:F0FA:  .byte $D4   ; 003057 00305E
0x00310B ---- 01:F0FB:  .byte $DD   ; 003057 00305E
0x00310C ---- 01:F0FC:  .byte $9D   ; 003057 00305E
0x00310D ---- 01:F0FD:  .byte $BD   ; 003057 00305E
0x00310E ---- 01:F0FE:  .byte $DD   ; 00305E
0x00310F ---- 01:F0FF:  .byte $D4   ; 003057 00305E
0x003110 ---- 01:F100:  .byte $44   ; 003057 00305E
0x003111 ---- 01:F101:  .byte $BB   ; 003057 00305E
0x003112 ---- 01:F102:  .byte $B9   ; 003057 00305E
0x003113 ---- 01:F103:  .byte $DD   ; 003057 00305E
0x003114 ---- 01:F104:  .byte $B4   ; 003057 00305E
0x003115 ---- 01:F105:  .byte $DD   ; 00305E
0x003116 ---- 01:F106:  .byte $DD   ; 003057 00305E
0x003117 ---- 01:F107:  .byte $D9   ; 003057 00305E
0x003118 ---- 01:F108:  .byte $B4   ; 003057 00305E
0x003119 ---- 01:F109:  .byte $D4   ; 003057 00305E
0x00311A ---- 01:F10A:  .byte $D4   ; 003057 00305E
0x00311B ---- 01:F10B:  .byte $D4   ; 003057 00305E
0x00311C ---- 01:F10C:  .byte $DD   ; 00305E
0x00311D ---- 01:F10D:  .byte $94   ; 003057 00305E
0x00311E ---- 01:F10E:  .byte $D9   ; 003057 00305E
0x00311F ---- 01:F10F:  .byte $D4   ; 003057 00305E
0x003120 ---- 01:F110:  .byte $D4   ; 003057 00305E
0x003121 ---- 01:F111:  .byte $DD   ; 003057 00305E
0x003122 ---- 01:F112:  .byte $D4   ; 003057 00305E
0x003123 ---- 01:F113:  .byte $DD   ; 00305E
0x003124 ---- 01:F114:  .byte $D4   ; 003057 00305E
0x003125 ---- 01:F115:  .byte $D4   ; 003057 00305E
0x003126 ---- 01:F116:  .byte $D4   ; 003057 00305E
0x003127 ---- 01:F117:  .byte $44   ; 003057 00305E
0x003128 ---- 01:F118:  .byte $D4   ; 003057 00305E
0x003129 ---- 01:F119:  .byte $94   ; 003057 00305E
0x00312A ---- 01:F11A:  .byte $DD   ; 00305E
0x00312B ---- 01:F11B:  .byte $D4   ; 003057 00305E
0x00312C ---- 01:F11C:  .byte $D4   ; 003057 00305E
0x00312D ---- 01:F11D:  .byte $D4   ; 003057 00305E
0x00312E ---- 01:F11E:  .byte $44   ; 003057 00305E
0x00312F ---- 01:F11F:  .byte $DD   ; 003057 00305E
0x003130 ---- 01:F120:  .byte $DD   ; 003057 00305E
0x003131 ---- 01:F121:  .byte $DD   ; 00305E
0x003132 ---- 01:F122:  .byte $D4   ; 003057 00305E
0x003133 ---- 01:F123:  .byte $DD   ; 003057 00305E
0x003134 ---- 01:F124:  .byte $DD   ; 003057 00305E
0x003135 ---- 01:F125:  .byte $DD   ; 003057 00305E
0x003136 ---- 01:F126:  .byte $D4   ; 003057 00305E
0x003137 ---- 01:F127:  .byte $D4   ; 003057 00305E
0x003138 ---- 01:F128:  .byte $DD   ; 00305E
0x003139 ---- 01:F129:  .byte $D4   ; 003057 00305E
0x00313A ---- 01:F12A:  .byte $D4   ; 003057 00305E
0x00313B ---- 01:F12B:  .byte $DD   ; 003057 00305E
0x00313C ---- 01:F12C:  .byte $DD   ; 003057 00305E
0x00313D ---- 01:F12D:  .byte $D4   ; 003057 00305E
0x00313E ---- 01:F12E:  .byte $44   ; 003057 00305E
0x00313F ---- 01:F12F:  .byte $DD   ; 00305E
0x003140 ---- 01:F130:  .byte $DD   ; 003057 00305E
0x003141 ---- 01:F131:  .byte $DD   ; 003057 00305E
0x003142 ---- 01:F132:  .byte $4D   ; 003057 00305E
0x003143 ---- 01:F133:  .byte $DD   ; 003057 00305E
0x003144 ---- 01:F134:  .byte $4D   ; 003057 00305E
0x003145 ---- 01:F135:  .byte $DD   ; 003057 00305E
0x003146 ---- 01:F136:  .byte $DD   ; 00305E
0x003147 ---- 01:F137:  .byte $DB   ; 003057 00305E
0x003148 ---- 01:F138:  .byte $BB   ; 003057 00305E
0x003149 ---- 01:F139:  .byte $4D   ; 003057 00305E
0x00314A ---- 01:F13A:  .byte $DD   ; 003057 00305E
0x00314B ---- 01:F13B:  .byte $DD   ; 003057 00305E
0x00314C ---- 01:F13C:  .byte $66   ; 003057 00305E
0x00314D ---- 01:F13D:  .byte $6D   ; 00305E
0x00314E ---- 01:F13E:  .byte $4B   ; 003057 00305E
0x00314F ---- 01:F13F:  .byte $BB   ; 003057 00305E
0x003150 ---- 01:F140:  .byte $DD   ; 003057 00305E
0x003151 ---- 01:F141:  .byte $DD   ; 003057 00305E
0x003152 ---- 01:F142:  .byte $DD   ; 003057 00305E
0x003153 ---- 01:F143:  .byte $DD   ; 003057 00305E
0x003154 ---- 01:F144:  .byte $DD   ; 00305E
0x003155 ---- 01:F145:  .byte $BB   ; 003057 00305E
0x003156 ---- 01:F146:  .byte $BB   ; 003057 00305E
0x003157 ---- 01:F147:  .byte $DD   ; 003057 00305E
0x003158 ---- 01:F148:  .byte $D4   ; 003057 00305E
0x003159 ---- 01:F149:  .byte $D4   ; 003057 00305E
0x00315A ---- 01:F14A:  .byte $44   ; 003057 00305E
0x00315B ---- 01:F14B:  .byte $2D   ; 00305E
0x00315C ---- 01:F14C:  .byte $BB   ; 003057 00305E
0x00315D ---- 01:F14D:  .byte $BB   ; 003057 00305E
0x00315E ---- 01:F14E:  .byte $44   ; 003057 00305E
0x00315F ---- 01:F14F:  .byte $43   ; 003057 00305E
0x003160 ---- 01:F150:  .byte $D4   ; 003057 00305E
0x003161 ---- 01:F151:  .byte $D0   ; 003057 00305E
0x003162 ---- 01:F152:  .byte $DD   ; 00305E
0x003163 ---- 01:F153:  .byte $BB   ; 003057 00305E
0x003164 ---- 01:F154:  .byte $BB   ; 003057 00305E
0x003165 ---- 01:F155:  .byte $DD   ; 003057 00305E
0x003166 ---- 01:F156:  .byte $4D   ; 003057 00305E
0x003167 ---- 01:F157:  .byte $DD   ; 003057 00305E
0x003168 ---- 01:F158:  .byte $D0   ; 003057 00305E
0x003169 ---- 01:F159:  .byte $DD   ; 00305E
0x00316A ---- 01:F15A:  .byte $DB   ; 003057 00305E
0x00316B ---- 01:F15B:  .byte $DD   ; 003057 00305E
0x00316C ---- 01:F15C:  .byte $DD   ; 003057 00305E
0x00316D ---- 01:F15D:  .byte $99   ; 003057 00305E
0x00316E ---- 01:F15E:  .byte $9D   ; 003057 00305E
0x00316F ---- 01:F15F:  .byte $DB   ; 003057 00305E
0x003170 ---- 01:F160:  .byte $DD   ; 00305E
0x003171 ---- 01:F161:  .byte $D1   ; 003057 00305E
0x003172 ---- 01:F162:  .byte $D1   ; 003057 00305E
0x003173 ---- 01:F163:  .byte $DD   ; 003057 00305E
0x003174 ---- 01:F164:  .byte $DD   ; 003057 00305E
0x003175 ---- 01:F165:  .byte $DB   ; 003057 00305E
0x003176 ---- 01:F166:  .byte $BB   ; 003057 00305E
0x003177 ---- 01:F167:  .byte $BD   ; 00305E
0x003178 ---- 01:F168:  .byte $42   ; 003057 00305E
0x003179 ---- 01:F169:  .byte $04   ; 003057 00305E
0x00317A ---- 01:F16A:  .byte $20   ; 003057 00305E
0x00317B ---- 01:F16B:  .byte $33   ; 003057 00305E
0x00317C ---- 01:F16C:  .byte $3B   ; 003057 00305E
0x00317D ---- 01:F16D:  .byte $BB   ; 003057 00305E
0x00317E ---- 01:F16E:  .byte $BD   ; 00305E
0x00317F ---- 01:F16F:  .byte $DD   ; 003057 00305E
0x003180 ---- 01:F170:  .byte $DD   ; 003057 00305E
0x003181 ---- 01:F171:  .byte $D4   ; 003057 00305E
0x003182 ---- 01:F172:  .byte $D1   ; 003057 00305E
0x003183 ---- 01:F173:  .byte $1B   ; 003057 00305E
0x003184 ---- 01:F174:  .byte $BB   ; 003057 00305E
0x003185 ---- 01:F175:  .byte $BD   ; 00305E
0x003186 ---- 01:F176:  .byte $4D   ; 003057 00305E
0x003187 ---- 01:F177:  .byte $D7   ; 003057 00305E
0x003188 ---- 01:F178:  .byte $DD   ; 003057 00305E
0x003189 ---- 01:F179:  .byte $D3   ; 003057 00305E
0x00318A ---- 01:F17A:  .byte $3B   ; 003057 00305E
0x00318B ---- 01:F17B:  .byte $BB   ; 003057 00305E
0x00318C ---- 01:F17C:  .byte $DD   ; 00305E
0x00318D ---- 01:F17D:  .byte $44   ; 003057 00305E
0x00318E ---- 01:F17E:  .byte $D7   ; 003057 00305E
0x00318F ---- 01:F17F:  .byte $DD   ; 003057 00305E
0x003190 ---- 01:F180:  .byte $DD   ; 003057 00305E
0x003191 ---- 01:F181:  .byte $DB   ; 003057 00305E
0x003192 ---- 01:F182:  .byte $BB   ; 003057 00305E
0x003193 ---- 01:F183:  .byte $DD   ; 00305E
0x003194 ---- 01:F184:  .byte $94   ; 003057 00305E
0x003195 ---- 01:F185:  .byte $4D   ; 003057 00305E
0x003196 ---- 01:F186:  .byte $DD   ; 003057 00305E
0x003197 ---- 01:F187:  .byte $DD   ; 003057 00305E
0x003198 ---- 01:F188:  .byte $D4   ; 003057 00305E
0x003199 ---- 01:F189:  .byte $DD   ; 003057 00305E
0x00319A ---- 01:F18A:  .byte $DD   ; 00305E
0x00319B ---- 01:F18B:  .byte $DB   ; 003057 00305E
0x00319C ---- 01:F18C:  .byte $BD   ; 003057 00305E
0x00319D ---- 01:F18D:  .byte $DD   ; 003057 00305E
0x00319E ---- 01:F18E:  .byte $DD   ; 003057 00305E
0x00319F ---- 01:F18F:  .byte $DD   ; 003057 00305E
0x0031A0 ---- 01:F190:  .byte $DB   ; 003057 00305E
0x0031A1 ---- 01:F191:  .byte $DD   ; 00305E
0x0031A2 ---- 01:F192:  .byte $BB   ; 003057 00305E
0x0031A3 ---- 01:F193:  .byte $DD   ; 003057 00305E
0x0031A4 ---- 01:F194:  .byte $14   ; 003057 00305E
0x0031A5 ---- 01:F195:  .byte $41   ; 003057 00305E
0x0031A6 ---- 01:F196:  .byte $1D   ; 003057 00305E
0x0031A7 ---- 01:F197:  .byte $DD   ; 003057 00305E
0x0031A8 ---- 01:F198:  .byte $BD   ; 00305E
0x0031A9 ---- 01:F199:  .byte $BD   ; 003057 00305E
0x0031AA ---- 01:F19A:  .byte $D0   ; 003057 00305E
0x0031AB ---- 01:F19B:  .byte $44   ; 003057 00305E
0x0031AC ---- 01:F19C:  .byte $44   ; 003057 00305E
0x0031AD ---- 01:F19D:  .byte $44   ; 003057 00305E
0x0031AE ---- 01:F19E:  .byte $1D   ; 003057 00305E
0x0031AF ---- 01:F19F:  .byte $8D   ; 00305E
0x0031B0 ---- 01:F1A0:  .byte $8D   ; 003057 00305E
0x0031B1 ---- 01:F1A1:  .byte $D4   ; 003057 00305E
0x0031B2 ---- 01:F1A2:  .byte $44   ; 003057 00305E
0x0031B3 ---- 01:F1A3:  .byte $44   ; 003057 00305E
0x0031B4 ---- 01:F1A4:  .byte $44   ; 003057 00305E
0x0031B5 ---- 01:F1A5:  .byte $42   ; 003057 00305E
0x0031B6 ---- 01:F1A6:  .byte $DD   ; 00305E
0x0031B7 ---- 01:F1A7:  .byte $DD   ; 003057 00305E
0x0031B8 ---- 01:F1A8:  .byte $03   ; 003057 00305E
0x0031B9 ---- 01:F1A9:  .byte $DD   ; 003057 00305E
0x0031BA ---- 01:F1AA:  .byte $D3   ; 003057 00305E
0x0031BB ---- 01:F1AB:  .byte $44   ; 003057 00305E
0x0031BC ---- 01:F1AC:  .byte $D2   ; 003057 00305E
0x0031BD ---- 01:F1AD:  .byte $DD   ; 00305E
0x0031BE ---- 01:F1AE:  .byte $AD   ; 003057 00305E
0x0031BF ---- 01:F1AF:  .byte $0D   ; 003057 00305E
0x0031C0 ---- 01:F1B0:  .byte $7D   ; 003057 00305E
0x0031C1 ---- 01:F1B1:  .byte $7D   ; 003057 00305E
0x0031C2 ---- 01:F1B2:  .byte $42   ; 003057 00305E
0x0031C3 ---- 01:F1B3:  .byte $DD   ; 003057 00305E
0x0031C4 ---- 01:F1B4:  .byte $DD   ; 00305E
0x0031C5 ---- 01:F1B5:  .byte $DD   ; 003057 00305E
0x0031C6 ---- 01:F1B6:  .byte $4D   ; 003057 00305E
0x0031C7 ---- 01:F1B7:  .byte $11   ; 003057 00305E
0x0031C8 ---- 01:F1B8:  .byte $DD   ; 003057 00305E
0x0031C9 ---- 01:F1B9:  .byte $42   ; 003057 00305E
0x0031CA ---- 01:F1BA:  .byte $DA   ; 003057 00305E
0x0031CB ---- 01:F1BB:  .byte $AD   ; 00305E
0x0031CC ---- 01:F1BC:  .byte $DD   ; 003057 00305E
0x0031CD ---- 01:F1BD:  .byte $44   ; 003057 00305E
0x0031CE ---- 01:F1BE:  .byte $44   ; 003057 00305E
0x0031CF ---- 01:F1BF:  .byte $44   ; 003057 00305E
0x0031D0 ---- 01:F1C0:  .byte $44   ; 003057 00305E
0x0031D1 ---- 01:F1C1:  .byte $DD   ; 003057 00305E
0x0031D2 ---- 01:F1C2:  .byte $DD   ; 00305E
0x0031D3 ---- 01:F1C3:  .byte $D0   ; 003057 00305E
0x0031D4 ---- 01:F1C4:  .byte $44   ; 003057 00305E
0x0031D5 ---- 01:F1C5:  .byte $44   ; 003057 00305E
0x0031D6 ---- 01:F1C6:  .byte $44   ; 003057 00305E
0x0031D7 ---- 01:F1C7:  .byte $44   ; 003057 00305E
0x0031D8 ---- 01:F1C8:  .byte $2D   ; 003057 00305E
0x0031D9 ---- 01:F1C9:  .byte $DD   ; 00305E
0x0031DA ---- 01:F1CA:  .byte $D3   ; 003057 00305E
0x0031DB ---- 01:F1CB:  .byte $34   ; 003057 00305E
0x0031DC ---- 01:F1CC:  .byte $44   ; 003057 00305E
0x0031DD ---- 01:F1CD:  .byte $44   ; 003057 00305E
0x0031DE ---- 01:F1CE:  .byte $43   ; 003057 00305E
0x0031DF ---- 01:F1CF:  .byte $3D   ; 003057 00305E
0x0031E0 ---- 01:F1D0:  .byte $DD   ; 00305E
0x0031E1 ---- 01:F1D1:  .byte $D4   ; 003057 00305E
0x0031E2 ---- 01:F1D2:  .byte $41   ; 003057 00305E
0x0031E3 ---- 01:F1D3:  .byte $34   ; 003057 00305E
0x0031E4 ---- 01:F1D4:  .byte $43   ; 003057 00305E
0x0031E5 ---- 01:F1D5:  .byte $14   ; 003057 00305E
0x0031E6 ---- 01:F1D6:  .byte $4D   ; 003057 00305E
0x0031E7 ---- 01:F1D7:  .byte $BD   ; 00305E
0x0031E8 ---- 01:F1D8:  .byte $BD   ; 003057 00305E
0x0031E9 ---- 01:F1D9:  .byte $33   ; 003057 00305E
0x0031EA ---- 01:F1DA:  .byte $DD   ; 003057 00305E
0x0031EB ---- 01:F1DB:  .byte $DD   ; 003057 00305E
0x0031EC ---- 01:F1DC:  .byte $33   ; 003057 00305E
0x0031ED ---- 01:F1DD:  .byte $DB   ; 003057 00305E
0x0031EE ---- 01:F1DE:  .byte $BD   ; 00305E
0x0031EF ---- 01:F1DF:  .byte $9B   ; 003057 00305E
0x0031F0 ---- 01:F1E0:  .byte $DD   ; 003057 00305E
0x0031F1 ---- 01:F1E1:  .byte $DD   ; 003057 00305E
0x0031F2 ---- 01:F1E2:  .byte $DD   ; 003057 00305E
0x0031F3 ---- 01:F1E3:  .byte $DD   ; 003057 00305E
0x0031F4 ---- 01:F1E4:  .byte $BB   ; 003057 00305E
0x0031F5 ---- 01:F1E5:  .byte $9D   ; 00305E
0x0031F6 ---- 01:F1E6:  .byte $DD   ; 003057 00305E
0x0031F7 ---- 01:F1E7:  .byte $DD   ; 003057 00305E
0x0031F8 ---- 01:F1E8:  .byte $44   ; 003057 00305E
0x0031F9 ---- 01:F1E9:  .byte $4D   ; 003057 00305E
0x0031FA ---- 01:F1EA:  .byte $DD   ; 003057 00305E
0x0031FB ---- 01:F1EB:  .byte $DD   ; 003057 00305E
0x0031FC ---- 01:F1EC:  .byte $DD   ; 00305E
0x0031FD ---- 01:F1ED:  .byte $6D   ; 003057 00305E
0x0031FE ---- 01:F1EE:  .byte $1D   ; 003057 00305E
0x0031FF ---- 01:F1EF:  .byte $4D   ; 003057 00305E
0x003200 ---- 01:F1F0:  .byte $DD   ; 003057 00305E
0x003201 ---- 01:F1F1:  .byte $88   ; 003057 00305E
0x003202 ---- 01:F1F2:  .byte $9D   ; 003057 00305E
0x003203 ---- 01:F1F3:  .byte $DD   ; 00305E
0x003204 ---- 01:F1F4:  .byte $9D   ; 003057 00305E
0x003205 ---- 01:F1F5:  .byte $4D   ; 003057 00305E
0x003206 ---- 01:F1F6:  .byte $DD   ; 003057 00305E
0x003207 ---- 01:F1F7:  .byte $4D   ; 003057 00305E
0x003208 ---- 01:F1F8:  .byte $DD   ; 003057 00305E
0x003209 ---- 01:F1F9:  .byte $DD   ; 003057 00305E
0x00320A ---- 01:F1FA:  .byte $DD   ; 00305E
0x00320B ---- 01:F1FB:  .byte $4D   ; 003057 00305E
0x00320C ---- 01:F1FC:  .byte $44   ; 003057 00305E
0x00320D ---- 01:F1FD:  .byte $4D   ; 003057 00305E
0x00320E ---- 01:F1FE:  .byte $44   ; 003057 00305E
0x00320F ---- 01:F1FF:  .byte $DA   ; 003057 00305E
0x003210 ---- 01:F200:  .byte $AD   ; 003057 00305E
0x003211 ---- 01:F201:  .byte $AD   ; 00305E
0x003212 ---- 01:F202:  .byte $3D   ; 003057 00305E
0x003213 ---- 01:F203:  .byte $DD   ; 003057 00305E
0x003214 ---- 01:F204:  .byte $3D   ; 003057 00305E
0x003215 ---- 01:F205:  .byte $DD   ; 003057 00305E
0x003216 ---- 01:F206:  .byte $DA   ; 003057 00305E
0x003217 ---- 01:F207:  .byte $DD   ; 003057 00305E
0x003218 ---- 01:F208:  .byte $DD   ; 00305E
0x003219 ---- 01:F209:  .byte $DD   ; 003057 00305E
0x00321A ---- 01:F20A:  .byte $1D   ; 003057 00305E
0x00321B ---- 01:F20B:  .byte $AA   ; 003057 00305E
0x00321C ---- 01:F20C:  .byte $DA   ; 003057 00305E
0x00321D ---- 01:F20D:  .byte $AA   ; 003057 00305E
0x00321E ---- 01:F20E:  .byte $D4   ; 003057 00305E
0x00321F ---- 01:F20F:  .byte $4D   ; 00305E
0x003220 ---- 01:F210:  .byte $44   ; 003057 00305E
0x003221 ---- 01:F211:  .byte $DD   ; 003057 00305E
0x003222 ---- 01:F212:  .byte $A4   ; 003057 00305E
0x003223 ---- 01:F213:  .byte $D4   ; 003057 00305E
0x003224 ---- 01:F214:  .byte $2D   ; 003057 00305E
0x003225 ---- 01:F215:  .byte $DD   ; 003057 00305E
0x003226 ---- 01:F216:  .byte $DD   ; 00305E
0x003227 ---- 01:F217:  .byte $DD   ; 003057 00305E
0x003228 ---- 01:F218:  .byte $DD   ; 003057 00305E
0x003229 ---- 01:F219:  .byte $AD   ; 003057 00305E
0x00322A ---- 01:F21A:  .byte $DD   ; 003057 00305E
0x00322B ---- 01:F21B:  .byte $DD   ; 003057 00305E
0x00322C ---- 01:F21C:  .byte $57   ; 003057 00305E
0x00322D ---- 01:F21D:  .byte $DD   ; 00305E
0x00322E ---- 01:F21E:  .byte $AA   ; 003057 00305E
0x00322F ---- 01:F21F:  .byte $AD   ; 003057 00305E
0x003230 ---- 01:F220:  .byte $AD   ; 003057 00305E
0x003231 ---- 01:F221:  .byte $9D   ; 003057 00305E
0x003232 ---- 01:F222:  .byte $4D   ; 003057 00305E
0x003233 ---- 01:F223:  .byte $5D   ; 003057 00305E
0x003234 ---- 01:F224:  .byte $DD   ; 00305E
0x003235 ---- 01:F225:  .byte $DD   ; 003057 00305E
0x003236 ---- 01:F226:  .byte $D1   ; 003057 00305E
0x003237 ---- 01:F227:  .byte $1D   ; 003057 00305E
0x003238 ---- 01:F228:  .byte $DD   ; 003057 00305E
0x003239 ---- 01:F229:  .byte $DD   ; 003057 00305E
0x00323A ---- 01:F22A:  .byte $54   ; 003057 00305E
0x00323B ---- 01:F22B:  .byte $4D   ; 00305E
0x00323C ---- 01:F22C:  .byte $DD   ; 003057 00305E
0x00323D ---- 01:F22D:  .byte $DD   ; 003057 00305E
0x00323E ---- 01:F22E:  .byte $43   ; 003057 00305E
0x00323F ---- 01:F22F:  .byte $33   ; 003057 00305E
0x003240 ---- 01:F230:  .byte $41   ; 003057 00305E
0x003241 ---- 01:F231:  .byte $DD   ; 003057 00305E
0x003242 ---- 01:F232:  .byte $DD   ; 00305E
0x003243 ---- 01:F233:  .byte $44   ; 003057 00305E
0x003244 ---- 01:F234:  .byte $3D   ; 003057 00305E
0x003245 ---- 01:F235:  .byte $DD   ; 003057 00305E
0x003246 ---- 01:F236:  .byte $DD   ; 003057 00305E
0x003247 ---- 01:F237:  .byte $D3   ; 003057 00305E
0x003248 ---- 01:F238:  .byte $4D   ; 003057 00305E
0x003249 ---- 01:F239:  .byte $DD   ; 00305E
0x00324A ---- 01:F23A:  .byte $3D   ; 003057 00305E
0x00324B ---- 01:F23B:  .byte $DD   ; 003057 00305E
0x00324C ---- 01:F23C:  .byte $DD   ; 003057 00305E
0x00324D ---- 01:F23D:  .byte $DD   ; 003057 00305E
0x00324E ---- 01:F23E:  .byte $DD   ; 003057 00305E
0x00324F ---- 01:F23F:  .byte $DD   ; 003057 00305E
0x003250 ---- 01:F240:  .byte $DD   ; 00305E
0x003251 ---- 01:F241:  .byte $DD   ; 003057 00305E
0x003252 ---- 01:F242:  .byte $DD   ; 003057 00305E
0x003253 ---- 01:F243:  .byte $D0   ; 003057 00305E
0x003254 ---- 01:F244:  .byte $D2   ; 003057 00305E
0x003255 ---- 01:F245:  .byte $BB   ; 003057 00305E
0x003256 ---- 01:F246:  .byte $DD   ; 003057 00305E
0x003257 ---- 01:F247:  .byte $DD   ; 00305E
0x003258 ---- 01:F248:  .byte $D2   ; 003057 00305E
0x003259 ---- 01:F249:  .byte $5D   ; 003057 00305E
0x00325A ---- 01:F24A:  .byte $2D   ; 003057 00305E
0x00325B ---- 01:F24B:  .byte $DD   ; 003057 00305E
0x00325C ---- 01:F24C:  .byte $0B   ; 003057 00305E
0x00325D ---- 01:F24D:  .byte $20   ; 003057 00305E
0x00325E ---- 01:F24E:  .byte $BD   ; 00305E
0x00325F ---- 01:F24F:  .byte $D2   ; 003057 00305E
0x003260 ---- 01:F250:  .byte $5D   ; 003057 00305E
0x003261 ---- 01:F251:  .byte $2D   ; 003057 00305E
0x003262 ---- 01:F252:  .byte $4D   ; 003057 00305E
0x003263 ---- 01:F253:  .byte $0B   ; 003057 00305E
0x003264 ---- 01:F254:  .byte $20   ; 003057 00305E
0x003265 ---- 01:F255:  .byte $BD   ; 00305E
0x003266 ---- 01:F256:  .byte $D4   ; 003057 00305E
0x003267 ---- 01:F257:  .byte $DD   ; 003057 00305E
0x003268 ---- 01:F258:  .byte $4D   ; 003057 00305E
0x003269 ---- 01:F259:  .byte $9D   ; 003057 00305E
0x00326A ---- 01:F25A:  .byte $4B   ; 003057 00305E
0x00326B ---- 01:F25B:  .byte $D4   ; 003057 00305E
0x00326C ---- 01:F25C:  .byte $BD   ; 00305E
0x00326D ---- 01:F25D:  .byte $DD   ; 003057 00305E
0x00326E ---- 01:F25E:  .byte $D0   ; 003057 00305E
0x00326F ---- 01:F25F:  .byte $8D   ; 003057 00305E
0x003270 ---- 01:F260:  .byte $4D   ; 003057 00305E
0x003271 ---- 01:F261:  .byte $37   ; 003057 00305E
0x003272 ---- 01:F262:  .byte $DB   ; 003057 00305E
0x003273 ---- 01:F263:  .byte $BD   ; 00305E
0x003274 ---- 01:F264:  .byte $44   ; 003057 00305E
0x003275 ---- 01:F265:  .byte $2D   ; 003057 00305E
0x003276 ---- 01:F266:  .byte $DB   ; 003057 00305E
0x003277 ---- 01:F267:  .byte $4B   ; 003057 00305E
0x003278 ---- 01:F268:  .byte $DD   ; 003057 00305E
0x003279 ---- 01:F269:  .byte $04   ; 003057 00305E
0x00327A ---- 01:F26A:  .byte $4D   ; 00305E
0x00327B ---- 01:F26B:  .byte $DD   ; 003057 00305E
0x00327C ---- 01:F26C:  .byte $DD   ; 003057 00305E
0x00327D ---- 01:F26D:  .byte $0B   ; 003057 00305E
0x00327E ---- 01:F26E:  .byte $BB   ; 003057 00305E
0x00327F ---- 01:F26F:  .byte $2D   ; 003057 00305E
0x003280 ---- 01:F270:  .byte $DD   ; 003057 00305E
0x003281 ---- 01:F271:  .byte $DD   ; 00305E
0x003282 ---- 01:F272:  .byte $94   ; 003057 00305E
0x003283 ---- 01:F273:  .byte $4D   ; 003057 00305E
0x003284 ---- 01:F274:  .byte $3B   ; 003057 00305E
0x003285 ---- 01:F275:  .byte $BB   ; 003057 00305E
0x003286 ---- 01:F276:  .byte $30   ; 003057 00305E
0x003287 ---- 01:F277:  .byte $44   ; 003057 00305E
0x003288 ---- 01:F278:  .byte $9D   ; 00305E
0x003289 ---- 01:F279:  .byte $88   ; 003057 00305E
0x00328A ---- 01:F27A:  .byte $8D   ; 003057 00305E
0x00328B ---- 01:F27B:  .byte $1D   ; 003057 00305E
0x00328C ---- 01:F27C:  .byte $BD   ; 003057 00305E
0x00328D ---- 01:F27D:  .byte $1D   ; 003057 00305E
0x00328E ---- 01:F27E:  .byte $88   ; 003057 00305E
0x00328F ---- 01:F27F:  .byte $8D   ; 00305E
0x003290 ---- 01:F280:  .byte $D4   ; 003057 00305E
0x003291 ---- 01:F281:  .byte $DD   ; 003057 00305E
0x003292 ---- 01:F282:  .byte $4D   ; 003057 00305E
0x003293 ---- 01:F283:  .byte $DD   ; 003057 00305E
0x003294 ---- 01:F284:  .byte $4D   ; 003057 00305E
0x003295 ---- 01:F285:  .byte $DD   ; 003057 00305E
0x003296 ---- 01:F286:  .byte $DD   ; 00305E
0x003297 ---- 01:F287:  .byte $D4   ; 003057 00305E
0x003298 ---- 01:F288:  .byte $2D   ; 003057 00305E
0x003299 ---- 01:F289:  .byte $D3   ; 003057 00305E
0x00329A ---- 01:F28A:  .byte $D3   ; 003057 00305E
0x00329B ---- 01:F28B:  .byte $DD   ; 003057 00305E
0x00329C ---- 01:F28C:  .byte $04   ; 003057 00305E
0x00329D ---- 01:F28D:  .byte $BD   ; 00305E
0x00329E ---- 01:F28E:  .byte $DD   ; 003057 00305E
0x00329F ---- 01:F28F:  .byte $3D   ; 003057 00305E
0x0032A0 ---- 01:F290:  .byte $DD   ; 003057 00305E
0x0032A1 ---- 01:F291:  .byte $DD   ; 003057 00305E
0x0032A2 ---- 01:F292:  .byte $DD   ; 003057 00305E
0x0032A3 ---- 01:F293:  .byte $BB   ; 003057 00305E
0x0032A4 ---- 01:F294:  .byte $BD   ; 00305E
0x0032A5 ---- 01:F295:  .byte $DD   ; 003057 00305E
0x0032A6 ---- 01:F296:  .byte $1D   ; 003057 00305E
0x0032A7 ---- 01:F297:  .byte $DD   ; 003057 00305E
0x0032A8 ---- 01:F298:  .byte $DD   ; 003057 00305E
0x0032A9 ---- 01:F299:  .byte $DD   ; 003057 00305E
0x0032AA ---- 01:F29A:  .byte $1B   ; 003057 00305E
0x0032AB ---- 01:F29B:  .byte $BD   ; 00305E
0x0032AC ---- 01:F29C:  .byte $DD   ; 003057 00305E
0x0032AD ---- 01:F29D:  .byte $DD   ; 003057 00305E
0x0032AE ---- 01:F29E:  .byte $DD   ; 003057 00305E
0x0032AF ---- 01:F29F:  .byte $D8   ; 003057 00305E
0x0032B0 ---- 01:F2A0:  .byte $8D   ; 003057 00305E
0x0032B1 ---- 01:F2A1:  .byte $DD   ; 003057 00305E
0x0032B2 ---- 01:F2A2:  .byte $DD   ; 00305E
0x0032B3 ---- 01:F2A3:  .byte $DD   ; 003057 00305E
0x0032B4 ---- 01:F2A4:  .byte $98   ; 003057 00305E
0x0032B5 ---- 01:F2A5:  .byte $88   ; 003057 00305E
0x0032B6 ---- 01:F2A6:  .byte $DD   ; 003057 00305E
0x0032B7 ---- 01:F2A7:  .byte $DD   ; 003057 00305E
0x0032B8 ---- 01:F2A8:  .byte $9D   ; 003057 00305E
0x0032B9 ---- 01:F2A9:  .byte $DD   ; 00305E
0x0032BA ---- 01:F2AA:  .byte $DD   ; 003057 00305E
0x0032BB ---- 01:F2AB:  .byte $9D   ; 003057 00305E
0x0032BC ---- 01:F2AC:  .byte $DD   ; 003057 00305E
0x0032BD ---- 01:F2AD:  .byte $BD   ; 003057 00305E
0x0032BE ---- 01:F2AE:  .byte $89   ; 003057 00305E
0x0032BF ---- 01:F2AF:  .byte $9D   ; 003057 00305E
0x0032C0 ---- 01:F2B0:  .byte $DD   ; 00305E
0x0032C1 ---- 01:F2B1:  .byte $D9   ; 003057 00305E
0x0032C2 ---- 01:F2B2:  .byte $DD   ; 003057 00305E
0x0032C3 ---- 01:F2B3:  .byte $DB   ; 003057 00305E
0x0032C4 ---- 01:F2B4:  .byte $9D   ; 003057 00305E
0x0032C5 ---- 01:F2B5:  .byte $DD   ; 003057 00305E
0x0032C6 ---- 01:F2B6:  .byte $9D   ; 003057 00305E
0x0032C7 ---- 01:F2B7:  .byte $DD   ; 00305E
0x0032C8 ---- 01:F2B8:  .byte $DD   ; 003057 00305E
0x0032C9 ---- 01:F2B9:  .byte $DD   ; 003057 00305E
0x0032CA ---- 01:F2BA:  .byte $B9   ; 003057 00305E
0x0032CB ---- 01:F2BB:  .byte $9D   ; 003057 00305E
0x0032CC ---- 01:F2BC:  .byte $DD   ; 003057 00305E
0x0032CD ---- 01:F2BD:  .byte $89   ; 003057 00305E
0x0032CE ---- 01:F2BE:  .byte $DD   ; 00305E
0x0032CF ---- 01:F2BF:  .byte $D9   ; 003057 00305E
0x0032D0 ---- 01:F2C0:  .byte $DB   ; 003057 00305E
0x0032D1 ---- 01:F2C1:  .byte $99   ; 003057 00305E
0x0032D2 ---- 01:F2C2:  .byte $9D   ; 003057 00305E
0x0032D3 ---- 01:F2C3:  .byte $9D   ; 003057 00305E
0x0032D4 ---- 01:F2C4:  .byte $DD   ; 003057 00305E
0x0032D5 ---- 01:F2C5:  .byte $DD   ; 00305E
0x0032D6 ---- 01:F2C6:  .byte $D5   ; 003057 00305E
0x0032D7 ---- 01:F2C7:  .byte $D9   ; 003057 00305E
0x0032D8 ---- 01:F2C8:  .byte $9D   ; 003057 00305E
0x0032D9 ---- 01:F2C9:  .byte $DD   ; 003057 00305E
0x0032DA ---- 01:F2CA:  .byte $99   ; 003057 00305E
0x0032DB ---- 01:F2CB:  .byte $DD   ; 003057 00305E
0x0032DC ---- 01:F2CC:  .byte $DD   ; 00305E
0x0032DD ---- 01:F2CD:  .byte $7D   ; 003057 00305E
0x0032DE ---- 01:F2CE:  .byte $DD   ; 003057 00305E
0x0032DF ---- 01:F2CF:  .byte $9D   ; 003057 00305E
0x0032E0 ---- 01:F2D0:  .byte $99   ; 003057 00305E
0x0032E1 ---- 01:F2D1:  .byte $9D   ; 003057 00305E
0x0032E2 ---- 01:F2D2:  .byte $D5   ; 003057 00305E
0x0032E3 ---- 01:F2D3:  .byte $DD   ; 00305E
0x0032E4 ---- 01:F2D4:  .byte $D5   ; 003057 00305E
0x0032E5 ---- 01:F2D5:  .byte $9D   ; 003057 00305E
0x0032E6 ---- 01:F2D6:  .byte $DD   ; 003057 00305E
0x0032E7 ---- 01:F2D7:  .byte $99   ; 003057 00305E
0x0032E8 ---- 01:F2D8:  .byte $BD   ; 003057 00305E
0x0032E9 ---- 01:F2D9:  .byte $D9   ; 003057 00305E
0x0032EA ---- 01:F2DA:  .byte $DD   ; 00305E
0x0032EB ---- 01:F2DB:  .byte $D9   ; 003057 00305E
0x0032EC ---- 01:F2DC:  .byte $DD   ; 003057 00305E
0x0032ED ---- 01:F2DD:  .byte $DD   ; 003057 00305E
0x0032EE ---- 01:F2DE:  .byte $9B   ; 003057 00305E
0x0032EF ---- 01:F2DF:  .byte $DD   ; 003057 00305E
0x0032F0 ---- 01:F2E0:  .byte $99   ; 003057 00305E
0x0032F1 ---- 01:F2E1:  .byte $DD   ; 00305E
0x0032F2 ---- 01:F2E2:  .byte $D8   ; 003057 00305E
0x0032F3 ---- 01:F2E3:  .byte $89   ; 003057 00305E
0x0032F4 ---- 01:F2E4:  .byte $DD   ; 003057 00305E
0x0032F5 ---- 01:F2E5:  .byte $BD   ; 003057 00305E
0x0032F6 ---- 01:F2E6:  .byte $D9   ; 003057 00305E
0x0032F7 ---- 01:F2E7:  .byte $DD   ; 003057 00305E
0x0032F8 ---- 01:F2E8:  .byte $DD   ; 00305E
0x0032F9 ---- 01:F2E9:  .byte $DD   ; 003057 00305E
0x0032FA ---- 01:F2EA:  .byte $DD   ; 003057 00305E
0x0032FB ---- 01:F2EB:  .byte $DD   ; 003057 00305E
0x0032FC ---- 01:F2EC:  .byte $DD   ; 003057 00305E
0x0032FD ---- 01:F2ED:  .byte $D8   ; 003057 00305E
0x0032FE ---- 01:F2EE:  .byte $D6   ; 003057 00305E
0x0032FF ---- 01:F2EF:  .byte $9D   ; 00305E
0x003300 ---- 01:F2F0:  .byte $66   ; 003057 00305E
0x003301 ---- 01:F2F1:  .byte $DD   ; 003057 00305E
0x003302 ---- 01:F2F2:  .byte $DD   ; 003057 00305E
0x003303 ---- 01:F2F3:  .byte $DD   ; 003057 00305E
0x003304 ---- 01:F2F4:  .byte $DD   ; 003057 00305E
0x003305 ---- 01:F2F5:  .byte $DD   ; 003057 00305E
0x003306 ---- 01:F2F6:  .byte $DD   ; 00305E
0x003307 ---- 01:F2F7:  .byte $DD   ; 003057 00305E
0x003308 ---- 01:F2F8:  .byte $4D   ; 003057 00305E
0x003309 ---- 01:F2F9:  .byte $D4   ; 003057 00305E
0x00330A ---- 01:F2FA:  .byte $D1   ; 003057 00305E
0x00330B ---- 01:F2FB:  .byte $D4   ; 003057 00305E
0x00330C ---- 01:F2FC:  .byte $DD   ; 003057 00305E
0x00330D ---- 01:F2FD:  .byte $DD   ; 00305E
0x00330E ---- 01:F2FE:  .byte $B4   ; 003057 00305E
0x00330F ---- 01:F2FF:  .byte $44   ; 003057 00305E
0x003310 ---- 01:F300:  .byte $D4   ; 003057 00305E
0x003311 ---- 01:F301:  .byte $D6   ; 003057 00305E
0x003312 ---- 01:F302:  .byte $D4   ; 003057 00305E
0x003313 ---- 01:F303:  .byte $2D   ; 003057 00305E
0x003314 ---- 01:F304:  .byte $DD   ; 00305E
0x003315 ---- 01:F305:  .byte $BB   ; 003057 00305E
0x003316 ---- 01:F306:  .byte $BD   ; 003057 00305E
0x003317 ---- 01:F307:  .byte $D3   ; 003057 00305E
0x003318 ---- 01:F308:  .byte $D4   ; 003057 00305E
0x003319 ---- 01:F309:  .byte $D3   ; 003057 00305E
0x00331A ---- 01:F30A:  .byte $D0   ; 003057 00305E
0x00331B ---- 01:F30B:  .byte $2D   ; 00305E
0x00331C ---- 01:F30C:  .byte $BA   ; 003057 00305E
0x00331D ---- 01:F30D:  .byte $AA   ; 003057 00305E
0x00331E ---- 01:F30E:  .byte $AA   ; 003057 00305E
0x00331F ---- 01:F30F:  .byte $AA   ; 003057 00305E
0x003320 ---- 01:F310:  .byte $AA   ; 003057 00305E
0x003321 ---- 01:F311:  .byte $AD   ; 003057 00305E
0x003322 ---- 01:F312:  .byte $AD   ; 00305E
0x003323 ---- 01:F313:  .byte $D4   ; 003057 00305E
0x003324 ---- 01:F314:  .byte $DD   ; 003057 00305E
0x003325 ---- 01:F315:  .byte $DD   ; 003057 00305E
0x003326 ---- 01:F316:  .byte $11   ; 003057 00305E
0x003327 ---- 01:F317:  .byte $DD   ; 003057 00305E
0x003328 ---- 01:F318:  .byte $DD   ; 003057 00305E
0x003329 ---- 01:F319:  .byte $DD   ; 00305E
0x00332A ---- 01:F31A:  .byte $DD   ; 003057 00305E
0x00332B ---- 01:F31B:  .byte $4D   ; 003057 00305E
0x00332C ---- 01:F31C:  .byte $D0   ; 003057 00305E
0x00332D ---- 01:F31D:  .byte $44   ; 003057 00305E
0x00332E ---- 01:F31E:  .byte $34   ; 003057 00305E
0x00332F ---- 01:F31F:  .byte $38   ; 003057 00305E
0x003330 ---- 01:F320:  .byte $8D   ; 00305E
0x003331 ---- 01:F321:  .byte $44   ; 003057 00305E
0x003332 ---- 01:F322:  .byte $D4   ; 003057 00305E
0x003333 ---- 01:F323:  .byte $D0   ; 003057 00305E
0x003334 ---- 01:F324:  .byte $44   ; 003057 00305E
0x003335 ---- 01:F325:  .byte $B4   ; 003057 00305E
0x003336 ---- 01:F326:  .byte $66   ; 003057 00305E
0x003337 ---- 01:F327:  .byte $4D   ; 00305E
0x003338 ---- 01:F328:  .byte $DD   ; 003057 00305E
0x003339 ---- 01:F329:  .byte $D9   ; 003057 00305E
0x00333A ---- 01:F32A:  .byte $D6   ; 003057 00305E
0x00333B ---- 01:F32B:  .byte $DB   ; 003057 00305E
0x00333C ---- 01:F32C:  .byte $BB   ; 003057 00305E
0x00333D ---- 01:F32D:  .byte $BD   ; 003057 00305E
0x00333E ---- 01:F32E:  .byte $DD   ; 00305E
0x00333F ---- 01:F32F:  .byte $AA   ; 003057 00305E
0x003340 ---- 01:F330:  .byte $DA   ; 003057 00305E
0x003341 ---- 01:F331:  .byte $AA   ; 003057 00305E
0x003342 ---- 01:F332:  .byte $AA   ; 003057 00305E
0x003343 ---- 01:F333:  .byte $DA   ; 003057 00305E
0x003344 ---- 01:F334:  .byte $AA   ; 003057 00305E
0x003345 ---- 01:F335:  .byte $AD   ; 00305E
0x003346 ---- 01:F336:  .byte $BB   ; 003057 00305E
0x003347 ---- 01:F337:  .byte $D0   ; 003057 00305E
0x003348 ---- 01:F338:  .byte $DD   ; 003057 00305E
0x003349 ---- 01:F339:  .byte $11   ; 003057 00305E
0x00334A ---- 01:F33A:  .byte $DD   ; 003057 00305E
0x00334B ---- 01:F33B:  .byte $DD   ; 003057 00305E
0x00334C ---- 01:F33C:  .byte $DD   ; 00305E
0x00334D ---- 01:F33D:  .byte $BB   ; 003057 00305E
0x00334E ---- 01:F33E:  .byte $4D   ; 003057 00305E
0x00334F ---- 01:F33F:  .byte $2D   ; 003057 00305E
0x003350 ---- 01:F340:  .byte $D0   ; 003057 00305E
0x003351 ---- 01:F341:  .byte $D6   ; 003057 00305E
0x003352 ---- 01:F342:  .byte $14   ; 003057 00305E
0x003353 ---- 01:F343:  .byte $DD   ; 00305E
0x003354 ---- 01:F344:  .byte $B6   ; 003057 00305E
0x003355 ---- 01:F345:  .byte $4D   ; 003057 00305E
0x003356 ---- 01:F346:  .byte $2D   ; 003057 00305E
0x003357 ---- 01:F347:  .byte $DD   ; 003057 00305E
0x003358 ---- 01:F348:  .byte $D3   ; 003057 00305E
0x003359 ---- 01:F349:  .byte $D4   ; 003057 00305E
0x00335A ---- 01:F34A:  .byte $DD   ; 00305E
0x00335B ---- 01:F34B:  .byte $DD   ; 003057 00305E
0x00335C ---- 01:F34C:  .byte $DD   ; 003057 00305E
0x00335D ---- 01:F34D:  .byte $DD   ; 003057 00305E
0x00335E ---- 01:F34E:  .byte $DD   ; 003057 00305E
0x00335F ---- 01:F34F:  .byte $D1   ; 003057 00305E
0x003360 ---- 01:F350:  .byte $D3   ; 003057 00305E
0x003361 ---- 01:F351:  .byte $DD   ; 00305E
0x003362 ---- 01:F352:  .byte $DD   ; 003057 00305E
0x003363 ---- 01:F353:  .byte $D4   ; 003057 00305E
0x003364 ---- 01:F354:  .byte $DD   ; 003057 00305E
0x003365 ---- 01:F355:  .byte $DD   ; 003057 00305E
0x003366 ---- 01:F356:  .byte $D6   ; 003057 00305E
0x003367 ---- 01:F357:  .byte $BD   ; 003057 00305E
0x003368 ---- 01:F358:  .byte $DD   ; 00305E
0x003369 ---- 01:F359:  .byte $4D   ; 003057 00305E
0x00336A ---- 01:F35A:  .byte $DD   ; 003057 00305E
0x00336B ---- 01:F35B:  .byte $DD   ; 003057 00305E
0x00336C ---- 01:F35C:  .byte $6B   ; 003057 00305E
0x00336D ---- 01:F35D:  .byte $59   ; 003057 00305E
0x00336E ---- 01:F35E:  .byte $7D   ; 003057 00305E
0x00336F ---- 01:F35F:  .byte $4D   ; 00305E
0x003370 ---- 01:F360:  .byte $DD   ; 003057 00305E
0x003371 ---- 01:F361:  .byte $D6   ; 003057 00305E
0x003372 ---- 01:F362:  .byte $B5   ; 003057 00305E
0x003373 ---- 01:F363:  .byte $97   ; 003057 00305E
0x003374 ---- 01:F364:  .byte $D8   ; 003057 00305E
0x003375 ---- 01:F365:  .byte $BD   ; 003057 00305E
0x003376 ---- 01:F366:  .byte $DD   ; 00305E
0x003377 ---- 01:F367:  .byte $DD   ; 003057 00305E
0x003378 ---- 01:F368:  .byte $59   ; 003057 00305E
0x003379 ---- 01:F369:  .byte $7D   ; 003057 00305E
0x00337A ---- 01:F36A:  .byte $8B   ; 003057 00305E
0x00337B ---- 01:F36B:  .byte $DD   ; 003057 00305E
0x00337C ---- 01:F36C:  .byte $DD   ; 003057 00305E
0x00337D ---- 01:F36D:  .byte $DD   ; 00305E
0x00337E ---- 01:F36E:  .byte $DD   ; 003057 00305E
0x00337F ---- 01:F36F:  .byte $D8   ; 003057 00305E
0x003380 ---- 01:F370:  .byte $BD   ; 003057 00305E
0x003381 ---- 01:F371:  .byte $DD   ; 003057 00305E
0x003382 ---- 01:F372:  .byte $DD   ; 003057 00305E
0x003383 ---- 01:F373:  .byte $DD   ; 003057 00305E
0x003384 ---- 01:F374:  .byte $DD   ; 00305E
0x003385 ---- 01:F375:  .byte $DD   ; 003057 00305E
0x003386 ---- 01:F376:  .byte $DB   ; 003057 00305E
0x003387 ---- 01:F377:  .byte $6B   ; 003057 00305E
0x003388 ---- 01:F378:  .byte $DB   ; 003057 00305E
0x003389 ---- 01:F379:  .byte $6B   ; 003057 00305E
0x00338A ---- 01:F37A:  .byte $DD   ; 003057 00305E
0x00338B ---- 01:F37B:  .byte $DD   ; 00305E
0x00338C ---- 01:F37C:  .byte $94   ; 003057 00305E
0x00338D ---- 01:F37D:  .byte $D5   ; 003057 00305E
0x00338E ---- 01:F37E:  .byte $97   ; 003057 00305E
0x00338F ---- 01:F37F:  .byte $D5   ; 003057 00305E
0x003390 ---- 01:F380:  .byte $97   ; 003057 00305E
0x003391 ---- 01:F381:  .byte $D4   ; 003057 00305E
0x003392 ---- 01:F382:  .byte $9D   ; 00305E
0x003393 ---- 01:F383:  .byte $DD   ; 003057 00305E
0x003394 ---- 01:F384:  .byte $DB   ; 003057 00305E
0x003395 ---- 01:F385:  .byte $8B   ; 003057 00305E
0x003396 ---- 01:F386:  .byte $DB   ; 003057 00305E
0x003397 ---- 01:F387:  .byte $8B   ; 003057 00305E
0x003398 ---- 01:F388:  .byte $DD   ; 003057 00305E
0x003399 ---- 01:F389:  .byte $DD   ; 00305E
0x00339A ---- 01:F38A:  .byte $DD   ; 003057 00305E
0x00339B ---- 01:F38B:  .byte $DD   ; 003057 00305E
0x00339C ---- 01:F38C:  .byte $6D   ; 003057 00305E
0x00339D ---- 01:F38D:  .byte $DD   ; 003057 00305E
0x00339E ---- 01:F38E:  .byte $6D   ; 003057 00305E
0x00339F ---- 01:F38F:  .byte $DD   ; 003057 00305E
0x0033A0 ---- 01:F390:  .byte $DD   ; 00305E
0x0033A1 ---- 01:F391:  .byte $4D   ; 003057 00305E
0x0033A2 ---- 01:F392:  .byte $D5   ; 003057 00305E
0x0033A3 ---- 01:F393:  .byte $97   ; 003057 00305E
0x0033A4 ---- 01:F394:  .byte $D5   ; 003057 00305E
0x0033A5 ---- 01:F395:  .byte $97   ; 003057 00305E
0x0033A6 ---- 01:F396:  .byte $DD   ; 003057 00305E
0x0033A7 ---- 01:F397:  .byte $4D   ; 00305E
0x0033A8 ---- 01:F398:  .byte $4D   ; 003057 00305E
0x0033A9 ---- 01:F399:  .byte $DB   ; 003057 00305E
0x0033AA ---- 01:F39A:  .byte $8B   ; 003057 00305E
0x0033AB ---- 01:F39B:  .byte $DB   ; 003057 00305E
0x0033AC ---- 01:F39C:  .byte $8B   ; 003057 00305E
0x0033AD ---- 01:F39D:  .byte $DD   ; 003057 00305E
0x0033AE ---- 01:F39E:  .byte $4D   ; 00305E
0x0033AF ---- 01:F39F:  .byte $DD   ; 003057 00305E
0x0033B0 ---- 01:F3A0:  .byte $1D   ; 003057 00305E
0x0033B1 ---- 01:F3A1:  .byte $DD   ; 003057 00305E
0x0033B2 ---- 01:F3A2:  .byte $DD   ; 003057 00305E
0x0033B3 ---- 01:F3A3:  .byte $DD   ; 003057 00305E
0x0033B4 ---- 01:F3A4:  .byte $1D   ; 003057 00305E
0x0033B5 ---- 01:F3A5:  .byte $DD   ; 00305E
0x0033B6 ---- 01:F3A6:  .byte $DD   ; 003057 00305E
0x0033B7 ---- 01:F3A7:  .byte $44   ; 003057 00305E
0x0033B8 ---- 01:F3A8:  .byte $DD   ; 003057 00305E
0x0033B9 ---- 01:F3A9:  .byte $DD   ; 003057 00305E
0x0033BA ---- 01:F3AA:  .byte $D4   ; 003057 00305E
0x0033BB ---- 01:F3AB:  .byte $4D   ; 003057 00305E
0x0033BC ---- 01:F3AC:  .byte $DD   ; 00305E
0x0033BD ---- 01:F3AD:  .byte $DD   ; 003057 00305E
0x0033BE ---- 01:F3AE:  .byte $DD   ; 003057 00305E
0x0033BF ---- 01:F3AF:  .byte $DD   ; 003057 00305E
0x0033C0 ---- 01:F3B0:  .byte $DD   ; 003057 00305E
0x0033C1 ---- 01:F3B1:  .byte $DD   ; 003057 00305E
0x0033C2 ---- 01:F3B2:  .byte $DD   ; 003057 00305E
0x0033C3 ---- 01:F3B3:  .byte $DD   ; 00305E
0x0033C4 ---- 01:F3B4:  .byte $D0   ; 003057 00305E
0x0033C5 ---- 01:F3B5:  .byte $34   ; 003057 00305E
0x0033C6 ---- 01:F3B6:  .byte $DD   ; 003057 00305E
0x0033C7 ---- 01:F3B7:  .byte $DD   ; 003057 00305E
0x0033C8 ---- 01:F3B8:  .byte $DD   ; 003057 00305E
0x0033C9 ---- 01:F3B9:  .byte $43   ; 003057 00305E
0x0033CA ---- 01:F3BA:  .byte $2D   ; 00305E
0x0033CB ---- 01:F3BB:  .byte $03   ; 003057 00305E
0x0033CC ---- 01:F3BC:  .byte $DD   ; 003057 00305E
0x0033CD ---- 01:F3BD:  .byte $4D   ; 003057 00305E
0x0033CE ---- 01:F3BE:  .byte $BB   ; 003057 00305E
0x0033CF ---- 01:F3BF:  .byte $D4   ; 003057 00305E
0x0033D0 ---- 01:F3C0:  .byte $DD   ; 003057 00305E
0x0033D1 ---- 01:F3C1:  .byte $0D   ; 00305E
0x0033D2 ---- 01:F3C2:  .byte $4D   ; 003057 00305E
0x0033D3 ---- 01:F3C3:  .byte $DD   ; 003057 00305E
0x0033D4 ---- 01:F3C4:  .byte $4B   ; 003057 00305E
0x0033D5 ---- 01:F3C5:  .byte $BB   ; 003057 00305E
0x0033D6 ---- 01:F3C6:  .byte $B4   ; 003057 00305E
0x0033D7 ---- 01:F3C7:  .byte $DD   ; 003057 00305E
0x0033D8 ---- 01:F3C8:  .byte $0D   ; 00305E
0x0033D9 ---- 01:F3C9:  .byte $4D   ; 003057 00305E
0x0033DA ---- 01:F3CA:  .byte $D0   ; 003057 00305E
0x0033DB ---- 01:F3CB:  .byte $4B   ; 003057 00305E
0x0033DC ---- 01:F3CC:  .byte $99   ; 003057 00305E
0x0033DD ---- 01:F3CD:  .byte $B4   ; 003057 00305E
0x0033DE ---- 01:F3CE:  .byte $2D   ; 003057 00305E
0x0033DF ---- 01:F3CF:  .byte $4D   ; 00305E
0x0033E0 ---- 01:F3D0:  .byte $01   ; 003057 00305E
0x0033E1 ---- 01:F3D1:  .byte $14   ; 003057 00305E
0x0033E2 ---- 01:F3D2:  .byte $AA   ; 003057 00305E
0x0033E3 ---- 01:F3D3:  .byte $AA   ; 003057 00305E
0x0033E4 ---- 01:F3D4:  .byte $AA   ; 003057 00305E
0x0033E5 ---- 01:F3D5:  .byte $44   ; 003057 00305E
0x0033E6 ---- 01:F3D6:  .byte $4D   ; 00305E
0x0033E7 ---- 01:F3D7:  .byte $D4   ; 003057 00305E
0x0033E8 ---- 01:F3D8:  .byte $44   ; 003057 00305E
0x0033E9 ---- 01:F3D9:  .byte $99   ; 003057 00305E
0x0033EA ---- 01:F3DA:  .byte $49   ; 003057 00305E
0x0033EB ---- 01:F3DB:  .byte $94   ; 003057 00305E
0x0033EC ---- 01:F3DC:  .byte $44   ; 003057 00305E
0x0033ED ---- 01:F3DD:  .byte $2D   ; 00305E
0x0033EE ---- 01:F3DE:  .byte $DD   ; 003057 00305E
0x0033EF ---- 01:F3DF:  .byte $44   ; 003057 00305E
0x0033F0 ---- 01:F3E0:  .byte $9D   ; 003057 00305E
0x0033F1 ---- 01:F3E1:  .byte $4D   ; 003057 00305E
0x0033F2 ---- 01:F3E2:  .byte $94   ; 003057 00305E
0x0033F3 ---- 01:F3E3:  .byte $42   ; 003057 00305E
0x0033F4 ---- 01:F3E4:  .byte $DD   ; 00305E
0x0033F5 ---- 01:F3E5:  .byte $DD   ; 003057 00305E
0x0033F6 ---- 01:F3E6:  .byte $44   ; 003057 00305E
0x0033F7 ---- 01:F3E7:  .byte $44   ; 003057 00305E
0x0033F8 ---- 01:F3E8:  .byte $44   ; 003057 00305E
0x0033F9 ---- 01:F3E9:  .byte $44   ; 003057 00305E
0x0033FA ---- 01:F3EA:  .byte $42   ; 003057 00305E
0x0033FB ---- 01:F3EB:  .byte $DD   ; 00305E
0x0033FC ---- 01:F3EC:  .byte $4B   ; 003057 00305E
0x0033FD ---- 01:F3ED:  .byte $33   ; 003057 00305E
0x0033FE ---- 01:F3EE:  .byte $39   ; 003057 00305E
0x0033FF ---- 01:F3EF:  .byte $93   ; 003057 00305E
0x003400 ---- 01:F3F0:  .byte $33   ; 003057 00305E
0x003401 ---- 01:F3F1:  .byte $3B   ; 003057 00305E
0x003402 ---- 01:F3F2:  .byte $4D   ; 00305E
0x003403 ---- 01:F3F3:  .byte $4B   ; 003057 00305E
0x003404 ---- 01:F3F4:  .byte $BB   ; 003057 00305E
0x003405 ---- 01:F3F5:  .byte $BB   ; 003057 00305E
0x003406 ---- 01:F3F6:  .byte $BB   ; 003057 00305E
0x003407 ---- 01:F3F7:  .byte $BB   ; 003057 00305E
0x003408 ---- 01:F3F8:  .byte $BB   ; 003057 00305E
0x003409 ---- 01:F3F9:  .byte $4D   ; 00305E
0x00340A ---- 01:F3FA:  .byte $DD   ; 003057 00305E
0x00340B ---- 01:F3FB:  .byte $BB   ; 003057 00305E
0x00340C ---- 01:F3FC:  .byte $B1   ; 003057 00305E
0x00340D ---- 01:F3FD:  .byte $11   ; 003057 00305E
0x00340E ---- 01:F3FE:  .byte $BB   ; 003057 00305E
0x00340F ---- 01:F3FF:  .byte $BB   ; 003057 00305E
0x003410 ---- 01:F400:  .byte $DD   ; 00305E
0x003411 ---- 01:F401:  .byte $DD   ; 003057 00305E
0x003412 ---- 01:F402:  .byte $D2   ; 003057 00305E
0x003413 ---- 01:F403:  .byte $D4   ; 003057 00305E
0x003414 ---- 01:F404:  .byte $D4   ; 003057 00305E
0x003415 ---- 01:F405:  .byte $DD   ; 003057 00305E
0x003416 ---- 01:F406:  .byte $2D   ; 003057 00305E
0x003417 ---- 01:F407:  .byte $DD   ; 00305E
0x003418 ---- 01:F408:  .byte $DD   ; 003057 00305E
0x003419 ---- 01:F409:  .byte $DD   ; 003057 00305E
0x00341A ---- 01:F40A:  .byte $D9   ; 003057 00305E
0x00341B ---- 01:F40B:  .byte $D4   ; 003057 00305E
0x00341C ---- 01:F40C:  .byte $D4   ; 003057 00305E
0x00341D ---- 01:F40D:  .byte $4D   ; 003057 00305E
0x00341E ---- 01:F40E:  .byte $DD   ; 00305E
0x00341F ---- 01:F40F:  .byte $D0   ; 003057 00305E
0x003420 ---- 01:F410:  .byte $44   ; 003057 00305E
0x003421 ---- 01:F411:  .byte $44   ; 003057 00305E
0x003422 ---- 01:F412:  .byte $D4   ; 003057 00305E
0x003423 ---- 01:F413:  .byte $DD   ; 003057 00305E
0x003424 ---- 01:F414:  .byte $DD   ; 003057 00305E
0x003425 ---- 01:F415:  .byte $DD   ; 00305E
0x003426 ---- 01:F416:  .byte $DD   ; 003057 00305E
0x003427 ---- 01:F417:  .byte $D2   ; 003057 00305E
0x003428 ---- 01:F418:  .byte $D4   ; 003057 00305E
0x003429 ---- 01:F419:  .byte $D4   ; 003057 00305E
0x00342A ---- 01:F41A:  .byte $4D   ; 003057 00305E
0x00342B ---- 01:F41B:  .byte $BB   ; 003057 00305E
0x00342C ---- 01:F41C:  .byte $BD   ; 00305E
0x00342D ---- 01:F41D:  .byte $D0   ; 003057 00305E
0x00342E ---- 01:F41E:  .byte $DD   ; 003057 00305E
0x00342F ---- 01:F41F:  .byte $DD   ; 003057 00305E
0x003430 ---- 01:F420:  .byte $D9   ; 003057 00305E
0x003431 ---- 01:F421:  .byte $DB   ; 003057 00305E
0x003432 ---- 01:F422:  .byte $BB   ; 003057 00305E
0x003433 ---- 01:F423:  .byte $BD   ; 00305E
0x003434 ---- 01:F424:  .byte $D0   ; 003057 00305E
0x003435 ---- 01:F425:  .byte $D4   ; 003057 00305E
0x003436 ---- 01:F426:  .byte $44   ; 003057 00305E
0x003437 ---- 01:F427:  .byte $94   ; 003057 00305E
0x003438 ---- 01:F428:  .byte $4B   ; 003057 00305E
0x003439 ---- 01:F429:  .byte $B3   ; 003057 00305E
0x00343A ---- 01:F42A:  .byte $9D   ; 00305E
0x00343B ---- 01:F42B:  .byte $D3   ; 003057 00305E
0x00343C ---- 01:F42C:  .byte $33   ; 003057 00305E
0x00343D ---- 01:F42D:  .byte $9D   ; 003057 00305E
0x00343E ---- 01:F42E:  .byte $D4   ; 003057 00305E
0x00343F ---- 01:F42F:  .byte $DB   ; 003057 00305E
0x003440 ---- 01:F430:  .byte $BD   ; 003057 00305E
0x003441 ---- 01:F431:  .byte $0D   ; 00305E
0x003442 ---- 01:F432:  .byte $04   ; 003057 00305E
0x003443 ---- 01:F433:  .byte $44   ; 003057 00305E
0x003444 ---- 01:F434:  .byte $D9   ; 003057 00305E
0x003445 ---- 01:F435:  .byte $BB   ; 003057 00305E
0x003446 ---- 01:F436:  .byte $BB   ; 003057 00305E
0x003447 ---- 01:F437:  .byte $BD   ; 003057 00305E
0x003448 ---- 01:F438:  .byte $DD   ; 00305E
0x003449 ---- 01:F439:  .byte $DD   ; 003057 00305E
0x00344A ---- 01:F43A:  .byte $D9   ; 003057 00305E
0x00344B ---- 01:F43B:  .byte $DD   ; 003057 00305E
0x00344C ---- 01:F43C:  .byte $BB   ; 003057 00305E
0x00344D ---- 01:F43D:  .byte $BB   ; 003057 00305E
0x00344E ---- 01:F43E:  .byte $B4   ; 003057 00305E
0x00344F ---- 01:F43F:  .byte $DD   ; 00305E
0x003450 ---- 01:F440:  .byte $94   ; 003057 00305E
0x003451 ---- 01:F441:  .byte $DB   ; 003057 00305E
0x003452 ---- 01:F442:  .byte $BB   ; 003057 00305E
0x003453 ---- 01:F443:  .byte $B9   ; 003057 00305E
0x003454 ---- 01:F444:  .byte $BB   ; 003057 00305E
0x003455 ---- 01:F445:  .byte $B4   ; 003057 00305E
0x003456 ---- 01:F446:  .byte $DD   ; 00305E
0x003457 ---- 01:F447:  .byte $04   ; 003057 00305E
0x003458 ---- 01:F448:  .byte $BB   ; 003057 00305E
0x003459 ---- 01:F449:  .byte $BB   ; 003057 00305E
0x00345A ---- 01:F44A:  .byte $BD   ; 003057 00305E
0x00345B ---- 01:F44B:  .byte $DD   ; 003057 00305E
0x00345C ---- 01:F44C:  .byte $D4   ; 003057 00305E
0x00345D ---- 01:F44D:  .byte $2D   ; 00305E
0x00345E ---- 01:F44E:  .byte $D4   ; 003057 00305E
0x00345F ---- 01:F44F:  .byte $BB   ; 003057 00305E
0x003460 ---- 01:F450:  .byte $DD   ; 003057 00305E
0x003461 ---- 01:F451:  .byte $DD   ; 003057 00305E
0x003462 ---- 01:F452:  .byte $84   ; 003057 00305E
0x003463 ---- 01:F453:  .byte $44   ; 003057 00305E
0x003464 ---- 01:F454:  .byte $DD   ; 00305E
0x003465 ---- 01:F455:  .byte $DD   ; 003057 00305E
0x003466 ---- 01:F456:  .byte $BB   ; 003057 00305E
0x003467 ---- 01:F457:  .byte $DD   ; 003057 00305E
0x003468 ---- 01:F458:  .byte $DD   ; 003057 00305E
0x003469 ---- 01:F459:  .byte $D4   ; 003057 00305E
0x00346A ---- 01:F45A:  .byte $D0   ; 003057 00305E
0x00346B ---- 01:F45B:  .byte $DD   ; 00305E
0x00346C ---- 01:F45C:  .byte $D1   ; 003057 00305E
0x00346D ---- 01:F45D:  .byte $BB   ; 003057 00305E
0x00346E ---- 01:F45E:  .byte $DD   ; 003057 00305E
0x00346F ---- 01:F45F:  .byte $DD   ; 003057 00305E
0x003470 ---- 01:F460:  .byte $DD   ; 003057 00305E
0x003471 ---- 01:F461:  .byte $DD   ; 003057 00305E
0x003472 ---- 01:F462:  .byte $DD   ; 00305E
0x003473 ---- 01:F463:  .byte $DD   ; 003057 00305E
0x003474 ---- 01:F464:  .byte $DD   ; 003057 00305E
0x003475 ---- 01:F465:  .byte $DD   ; 003057 00305E
0x003476 ---- 01:F466:  .byte $44   ; 003057 00305E
0x003477 ---- 01:F467:  .byte $44   ; 003057 00305E
0x003478 ---- 01:F468:  .byte $DD   ; 003057 00305E
0x003479 ---- 01:F469:  .byte $DD   ; 00305E
0x00347A ---- 01:F46A:  .byte $D4   ; 003057 00305E
0x00347B ---- 01:F46B:  .byte $44   ; 003057 00305E
0x00347C ---- 01:F46C:  .byte $1D   ; 003057 00305E
0x00347D ---- 01:F46D:  .byte $1D   ; 003057 00305E
0x00347E ---- 01:F46E:  .byte $D4   ; 003057 00305E
0x00347F ---- 01:F46F:  .byte $DD   ; 003057 00305E
0x003480 ---- 01:F470:  .byte $DD   ; 00305E
0x003481 ---- 01:F471:  .byte $DD   ; 003057 00305E
0x003482 ---- 01:F472:  .byte $DD   ; 003057 00305E
0x003483 ---- 01:F473:  .byte $4D   ; 003057 00305E
0x003484 ---- 01:F474:  .byte $3D   ; 003057 00305E
0x003485 ---- 01:F475:  .byte $DD   ; 003057 00305E
0x003486 ---- 01:F476:  .byte $D4   ; 003057 00305E
0x003487 ---- 01:F477:  .byte $4D   ; 00305E
0x003488 ---- 01:F478:  .byte $DA   ; 003057 00305E
0x003489 ---- 01:F479:  .byte $AA   ; 003057 00305E
0x00348A ---- 01:F47A:  .byte $AA   ; 003057 00305E
0x00348B ---- 01:F47B:  .byte $D4   ; 003057 00305E
0x00348C ---- 01:F47C:  .byte $2D   ; 003057 00305E
0x00348D ---- 01:F47D:  .byte $D4   ; 003057 00305E
0x00348E ---- 01:F47E:  .byte $8D   ; 00305E
0x00348F ---- 01:F47F:  .byte $DD   ; 003057 00305E
0x003490 ---- 01:F480:  .byte $66   ; 003057 00305E
0x003491 ---- 01:F481:  .byte $6A   ; 003057 00305E
0x003492 ---- 01:F482:  .byte $D4   ; 003057 00305E
0x003493 ---- 01:F483:  .byte $D9   ; 003057 00305E
0x003494 ---- 01:F484:  .byte $74   ; 003057 00305E
0x003495 ---- 01:F485:  .byte $DD   ; 00305E
0x003496 ---- 01:F486:  .byte $4D   ; 003057 00305E
0x003497 ---- 01:F487:  .byte $44   ; 003057 00305E
0x003498 ---- 01:F488:  .byte $4A   ; 003057 00305E
0x003499 ---- 01:F489:  .byte $AA   ; 003057 00305E
0x00349A ---- 01:F48A:  .byte $DA   ; 003057 00305E
0x00349B ---- 01:F48B:  .byte $44   ; 003057 00305E
0x00349C ---- 01:F48C:  .byte $DD   ; 00305E
0x00349D ---- 01:F48D:  .byte $DD   ; 003057 00305E
0x00349E ---- 01:F48E:  .byte $DD   ; 003057 00305E
0x00349F ---- 01:F48F:  .byte $9A   ; 003057 00305E
0x0034A0 ---- 01:F490:  .byte $DD   ; 003057 00305E
0x0034A1 ---- 01:F491:  .byte $DA   ; 003057 00305E
0x0034A2 ---- 01:F492:  .byte $8D   ; 003057 00305E
0x0034A3 ---- 01:F493:  .byte $DD   ; 00305E
0x0034A4 ---- 01:F494:  .byte $AA   ; 003057 00305E
0x0034A5 ---- 01:F495:  .byte $AD   ; 003057 00305E
0x0034A6 ---- 01:F496:  .byte $AA   ; 003057 00305E
0x0034A7 ---- 01:F497:  .byte $44   ; 003057 00305E
0x0034A8 ---- 01:F498:  .byte $DA   ; 003057 00305E
0x0034A9 ---- 01:F499:  .byte $DD   ; 003057 00305E
0x0034AA ---- 01:F49A:  .byte $DD   ; 00305E
0x0034AB ---- 01:F49B:  .byte $DD   ; 003057 00305E
0x0034AC ---- 01:F49C:  .byte $DD   ; 003057 00305E
0x0034AD ---- 01:F49D:  .byte $D4   ; 003057 00305E
0x0034AE ---- 01:F49E:  .byte $88   ; 003057 00305E
0x0034AF ---- 01:F49F:  .byte $DA   ; 003057 00305E
0x0034B0 ---- 01:F4A0:  .byte $AA   ; 003057 00305E
0x0034B1 ---- 01:F4A1:  .byte $DD   ; 00305E
0x0034B2 ---- 01:F4A2:  .byte $44   ; 003057 00305E
0x0034B3 ---- 01:F4A3:  .byte $4D   ; 003057 00305E
0x0034B4 ---- 01:F4A4:  .byte $DD   ; 003057 00305E
0x0034B5 ---- 01:F4A5:  .byte $DD   ; 003057 00305E
0x0034B6 ---- 01:F4A6:  .byte $DD   ; 003057 00305E
0x0034B7 ---- 01:F4A7:  .byte $DD   ; 003057 00305E
0x0034B8 ---- 01:F4A8:  .byte $DD   ; 00305E
0x0034B9 ---- 01:F4A9:  .byte $DD   ; 003057 00305E
0x0034BA ---- 01:F4AA:  .byte $4D   ; 003057 00305E
0x0034BB ---- 01:F4AB:  .byte $88   ; 003057 00305E
0x0034BC ---- 01:F4AC:  .byte $DD   ; 003057 00305E
0x0034BD ---- 01:F4AD:  .byte $D4   ; 003057 00305E
0x0034BE ---- 01:F4AE:  .byte $4D   ; 003057 00305E
0x0034BF ---- 01:F4AF:  .byte $0D   ; 00305E
0x0034C0 ---- 01:F4B0:  .byte $4D   ; 003057 00305E
0x0034C1 ---- 01:F4B1:  .byte $DD   ; 003057 00305E
0x0034C2 ---- 01:F4B2:  .byte $DD   ; 003057 00305E
0x0034C3 ---- 01:F4B3:  .byte $DD   ; 003057 00305E
0x0034C4 ---- 01:F4B4:  .byte $D4   ; 003057 00305E
0x0034C5 ---- 01:F4B5:  .byte $DD   ; 003057 00305E
0x0034C6 ---- 01:F4B6:  .byte $4D   ; 00305E
0x0034C7 ---- 01:F4B7:  .byte $DD   ; 003057 00305E
0x0034C8 ---- 01:F4B8:  .byte $DD   ; 003057 00305E
0x0034C9 ---- 01:F4B9:  .byte $DD   ; 003057 00305E
0x0034CA ---- 01:F4BA:  .byte $DD   ; 003057 00305E
0x0034CB ---- 01:F4BB:  .byte $DD   ; 003057 00305E
0x0034CC ---- 01:F4BC:  .byte $DD   ; 003057 00305E
0x0034CD ---- 01:F4BD:  .byte $DD   ; 00305E
0x0034CE ---- 01:F4BE:  .byte $DD   ; 003057 00305E
0x0034CF ---- 01:F4BF:  .byte $DD   ; 003057 00305E
0x0034D0 ---- 01:F4C0:  .byte $1D   ; 003057 00305E
0x0034D1 ---- 01:F4C1:  .byte $DD   ; 003057 00305E
0x0034D2 ---- 01:F4C2:  .byte $1D   ; 003057 00305E
0x0034D3 ---- 01:F4C3:  .byte $DD   ; 003057 00305E
0x0034D4 ---- 01:F4C4:  .byte $DD   ; 00305E
0x0034D5 ---- 01:F4C5:  .byte $D4   ; 003057 00305E
0x0034D6 ---- 01:F4C6:  .byte $44   ; 003057 00305E
0x0034D7 ---- 01:F4C7:  .byte $4D   ; 003057 00305E
0x0034D8 ---- 01:F4C8:  .byte $DD   ; 003057 00305E
0x0034D9 ---- 01:F4C9:  .byte $44   ; 003057 00305E
0x0034DA ---- 01:F4CA:  .byte $44   ; 003057 00305E
0x0034DB ---- 01:F4CB:  .byte $DD   ; 00305E
0x0034DC ---- 01:F4CC:  .byte $D4   ; 003057 00305E
0x0034DD ---- 01:F4CD:  .byte $DD   ; 003057 00305E
0x0034DE ---- 01:F4CE:  .byte $DD   ; 003057 00305E
0x0034DF ---- 01:F4CF:  .byte $4D   ; 003057 00305E
0x0034E0 ---- 01:F4D0:  .byte $DD   ; 003057 00305E
0x0034E1 ---- 01:F4D1:  .byte $D9   ; 003057 00305E
0x0034E2 ---- 01:F4D2:  .byte $DD   ; 00305E
0x0034E3 ---- 01:F4D3:  .byte $D9   ; 003057 00305E
0x0034E4 ---- 01:F4D4:  .byte $D4   ; 003057 00305E
0x0034E5 ---- 01:F4D5:  .byte $3D   ; 003057 00305E
0x0034E6 ---- 01:F4D6:  .byte $DD   ; 003057 00305E
0x0034E7 ---- 01:F4D7:  .byte $34   ; 003057 00305E
0x0034E8 ---- 01:F4D8:  .byte $D4   ; 003057 00305E
0x0034E9 ---- 01:F4D9:  .byte $4D   ; 00305E
0x0034EA ---- 01:F4DA:  .byte $D4   ; 003057 00305E
0x0034EB ---- 01:F4DB:  .byte $D2   ; 003057 00305E
0x0034EC ---- 01:F4DC:  .byte $B6   ; 003057 00305E
0x0034ED ---- 01:F4DD:  .byte $96   ; 003057 00305E
0x0034EE ---- 01:F4DE:  .byte $B0   ; 003057 00305E
0x0034EF ---- 01:F4DF:  .byte $D9   ; 003057 00305E
0x0034F0 ---- 01:F4E0:  .byte $4D   ; 00305E
0x0034F1 ---- 01:F4E1:  .byte $D3   ; 003057 00305E
0x0034F2 ---- 01:F4E2:  .byte $DD   ; 003057 00305E
0x0034F3 ---- 01:F4E3:  .byte $BB   ; 003057 00305E
0x0034F4 ---- 01:F4E4:  .byte $BB   ; 003057 00305E
0x0034F5 ---- 01:F4E5:  .byte $BD   ; 003057 00305E
0x0034F6 ---- 01:F4E6:  .byte $D8   ; 003057 00305E
0x0034F7 ---- 01:F4E7:  .byte $4D   ; 00305E
0x0034F8 ---- 01:F4E8:  .byte $46   ; 003057 00305E
0x0034F9 ---- 01:F4E9:  .byte $DD   ; 003057 00305E
0x0034FA ---- 01:F4EA:  .byte $BB   ; 003057 00305E
0x0034FB ---- 01:F4EB:  .byte $BB   ; 003057 00305E
0x0034FC ---- 01:F4EC:  .byte $BD   ; 003057 00305E
0x0034FD ---- 01:F4ED:  .byte $D1   ; 003057 00305E
0x0034FE ---- 01:F4EE:  .byte $4D   ; 00305E
0x0034FF ---- 01:F4EF:  .byte $49   ; 003057 00305E
0x003500 ---- 01:F4F0:  .byte $D2   ; 003057 00305E
0x003501 ---- 01:F4F1:  .byte $B8   ; 003057 00305E
0x003502 ---- 01:F4F2:  .byte $98   ; 003057 00305E
0x003503 ---- 01:F4F3:  .byte $B0   ; 003057 00305E
0x003504 ---- 01:F4F4:  .byte $D4   ; 003057 00305E
0x003505 ---- 01:F4F5:  .byte $DD   ; 00305E
0x003506 ---- 01:F4F6:  .byte $44   ; 003057 00305E
0x003507 ---- 01:F4F7:  .byte $D4   ; 003057 00305E
0x003508 ---- 01:F4F8:  .byte $1D   ; 003057 00305E
0x003509 ---- 01:F4F9:  .byte $DD   ; 003057 00305E
0x00350A ---- 01:F4FA:  .byte $14   ; 003057 00305E
0x00350B ---- 01:F4FB:  .byte $D9   ; 003057 00305E
0x00350C ---- 01:F4FC:  .byte $DD   ; 00305E
0x00350D ---- 01:F4FD:  .byte $49   ; 003057 00305E
0x00350E ---- 01:F4FE:  .byte $DD   ; 003057 00305E
0x00350F ---- 01:F4FF:  .byte $DD   ; 003057 00305E
0x003510 ---- 01:F500:  .byte $4D   ; 003057 00305E
0x003511 ---- 01:F501:  .byte $DD   ; 003057 00305E
0x003512 ---- 01:F502:  .byte $D4   ; 003057 00305E
0x003513 ---- 01:F503:  .byte $DD   ; 00305E
0x003514 ---- 01:F504:  .byte $44   ; 003057 00305E
0x003515 ---- 01:F505:  .byte $44   ; 003057 00305E
0x003516 ---- 01:F506:  .byte $4D   ; 003057 00305E
0x003517 ---- 01:F507:  .byte $DD   ; 003057 00305E
0x003518 ---- 01:F508:  .byte $44   ; 003057 00305E
0x003519 ---- 01:F509:  .byte $49   ; 003057 00305E
0x00351A ---- 01:F50A:  .byte $9D   ; 00305E
0x00351B ---- 01:F50B:  .byte $44   ; 003057 00305E
0x00351C ---- 01:F50C:  .byte $DD   ; 003057 00305E
0x00351D ---- 01:F50D:  .byte $3D   ; 003057 00305E
0x00351E ---- 01:F50E:  .byte $DD   ; 003057 00305E
0x00351F ---- 01:F50F:  .byte $3D   ; 003057 00305E
0x003520 ---- 01:F510:  .byte $D4   ; 003057 00305E
0x003521 ---- 01:F511:  .byte $DD   ; 00305E
0x003522 ---- 01:F512:  .byte $44   ; 003057 00305E
0x003523 ---- 01:F513:  .byte $DD   ; 003057 00305E
0x003524 ---- 01:F514:  .byte $DD   ; 003057 00305E
0x003525 ---- 01:F515:  .byte $DD   ; 003057 00305E
0x003526 ---- 01:F516:  .byte $DD   ; 003057 00305E
0x003527 ---- 01:F517:  .byte $DD   ; 003057 00305E
0x003528 ---- 01:F518:  .byte $DD   ; 00305E
0x003529 ---- 01:F519:  .byte $DD   ; 003057 00305E
0x00352A ---- 01:F51A:  .byte $DD   ; 003057 00305E
0x00352B ---- 01:F51B:  .byte $DD   ; 003057 00305E
0x00352C ---- 01:F51C:  .byte $DD   ; 003057 00305E
0x00352D ---- 01:F51D:  .byte $DD   ; 003057 00305E
0x00352E ---- 01:F51E:  .byte $DD   ; 003057 00305E
0x00352F ---- 01:F51F:  .byte $DD   ; 00305E
0x003530 ---- 01:F520:  .byte $BB   ; 003057 00305E
0x003531 ---- 01:F521:  .byte $DD   ; 003057 00305E
0x003532 ---- 01:F522:  .byte $14   ; 003057 00305E
0x003533 ---- 01:F523:  .byte $44   ; 003057 00305E
0x003534 ---- 01:F524:  .byte $1D   ; 003057 00305E
0x003535 ---- 01:F525:  .byte $DB   ; 003057 00305E
0x003536 ---- 01:F526:  .byte $BD   ; 00305E
0x003537 ---- 01:F527:  .byte $BD   ; 003057 00305E
0x003538 ---- 01:F528:  .byte $D0   ; 003057 00305E
0x003539 ---- 01:F529:  .byte $44   ; 003057 00305E
0x00353A ---- 01:F52A:  .byte $44   ; 003057 00305E
0x00353B ---- 01:F52B:  .byte $42   ; 003057 00305E
0x00353C ---- 01:F52C:  .byte $DD   ; 003057 00305E
0x00353D ---- 01:F52D:  .byte $BD   ; 00305E
0x00353E ---- 01:F52E:  .byte $DD   ; 003057 00305E
0x00353F ---- 01:F52F:  .byte $D4   ; 003057 00305E
0x003540 ---- 01:F530:  .byte $4B   ; 003057 00305E
0x003541 ---- 01:F531:  .byte $4B   ; 003057 00305E
0x003542 ---- 01:F532:  .byte $44   ; 003057 00305E
0x003543 ---- 01:F533:  .byte $DD   ; 003057 00305E
0x003544 ---- 01:F534:  .byte $DD   ; 00305E
0x003545 ---- 01:F535:  .byte $DD   ; 003057 00305E
0x003546 ---- 01:F536:  .byte $D4   ; 003057 00305E
0x003547 ---- 01:F537:  .byte $BB   ; 003057 00305E
0x003548 ---- 01:F538:  .byte $4B   ; 003057 00305E
0x003549 ---- 01:F539:  .byte $B4   ; 003057 00305E
0x00354A ---- 01:F53A:  .byte $DD   ; 003057 00305E
0x00354B ---- 01:F53B:  .byte $DD   ; 00305E
0x00354C ---- 01:F53C:  .byte $BD   ; 003057 00305E
0x00354D ---- 01:F53D:  .byte $D4   ; 003057 00305E
0x00354E ---- 01:F53E:  .byte $44   ; 003057 00305E
0x00354F ---- 01:F53F:  .byte $44   ; 003057 00305E
0x003550 ---- 01:F540:  .byte $44   ; 003057 00305E
0x003551 ---- 01:F541:  .byte $DD   ; 003057 00305E
0x003552 ---- 01:F542:  .byte $BD   ; 00305E
0x003553 ---- 01:F543:  .byte $BB   ; 003057 00305E
0x003554 ---- 01:F544:  .byte $DD   ; 003057 00305E
0x003555 ---- 01:F545:  .byte $4B   ; 003057 00305E
0x003556 ---- 01:F546:  .byte $4B   ; 003057 00305E
0x003557 ---- 01:F547:  .byte $4D   ; 003057 00305E
0x003558 ---- 01:F548:  .byte $DB   ; 003057 00305E
0x003559 ---- 01:F549:  .byte $BD   ; 00305E
0x00355A ---- 01:F54A:  .byte $AA   ; 003057 00305E
0x00355B ---- 01:F54B:  .byte $AD   ; 003057 00305E
0x00355C ---- 01:F54C:  .byte $44   ; 003057 00305E
0x00355D ---- 01:F54D:  .byte $44   ; 003057 00305E
0x00355E ---- 01:F54E:  .byte $4D   ; 003057 00305E
0x00355F ---- 01:F54F:  .byte $AA   ; 003057 00305E
0x003560 ---- 01:F550:  .byte $AD   ; 00305E
0x003561 ---- 01:F551:  .byte $DD   ; 003057 00305E
0x003562 ---- 01:F552:  .byte $DD   ; 003057 00305E
0x003563 ---- 01:F553:  .byte $00   ; 003057 00305E
0x003564 ---- 01:F554:  .byte $00   ; 003057 00305E
0x003565 ---- 01:F555:  .byte $0D   ; 003057 00305E
0x003566 ---- 01:F556:  .byte $DD   ; 003057 00305E
0x003567 ---- 01:F557:  .byte $DD   ; 00305E
0x003568 ---- 01:F558:  .byte $DD   ; 003057 00305E
0x003569 ---- 01:F559:  .byte $DD   ; 003057 00305E
0x00356A ---- 01:F55A:  .byte $22   ; 003057 00305E
0x00356B ---- 01:F55B:  .byte $22   ; 003057 00305E
0x00356C ---- 01:F55C:  .byte $2D   ; 003057 00305E
0x00356D ---- 01:F55D:  .byte $DD   ; 003057 00305E
0x00356E ---- 01:F55E:  .byte $DD   ; 00305E
0x00356F ---- 01:F55F:  .byte $55   ; 003057 00305E
0x003570 ---- 01:F560:  .byte $5D   ; 003057 00305E
0x003571 ---- 01:F561:  .byte $DD   ; 003057 00305E
0x003572 ---- 01:F562:  .byte $DD   ; 003057 00305E
0x003573 ---- 01:F563:  .byte $DD   ; 003057 00305E
0x003574 ---- 01:F564:  .byte $77   ; 003057 00305E
0x003575 ---- 01:F565:  .byte $7D   ; 00305E
0x003576 ---- 01:F566:  .byte $22   ; 003057 00305E
0x003577 ---- 01:F567:  .byte $2D   ; 003057 00305E
0x003578 ---- 01:F568:  .byte $DD   ; 003057 00305E
0x003579 ---- 01:F569:  .byte $DD   ; 003057 00305E
0x00357A ---- 01:F56A:  .byte $DD   ; 003057 00305E
0x00357B ---- 01:F56B:  .byte $00   ; 003057 00305E
0x00357C ---- 01:F56C:  .byte $0D   ; 00305E
0x00357D ---- 01:F56D:  .byte $77   ; 003057 00305E
0x00357E ---- 01:F56E:  .byte $75   ; 003057 00305E
0x00357F ---- 01:F56F:  .byte $DD   ; 003057 00305E
0x003580 ---- 01:F570:  .byte $DD   ; 003057 00305E
0x003581 ---- 01:F571:  .byte $D7   ; 003057 00305E
0x003582 ---- 01:F572:  .byte $55   ; 003057 00305E
0x003583 ---- 01:F573:  .byte $5D   ; 00305E
0x003584 ---- 01:F574:  .byte $DD   ; 003057 00305E
0x003585 ---- 01:F575:  .byte $DD   ; 003057 00305E
0x003586 ---- 01:F576:  .byte $44   ; 003057 00305E
0x003587 ---- 01:F577:  .byte $DD   ; 003057 00305E
0x003588 ---- 01:F578:  .byte $4D   ; 003057 00305E
0x003589 ---- 01:F579:  .byte $DD   ; 003057 00305E
0x00358A ---- 01:F57A:  .byte $DD   ; 00305E
0x00358B ---- 01:F57B:  .byte $DB   ; 003057 00305E
0x00358C ---- 01:F57C:  .byte $B4   ; 003057 00305E
0x00358D ---- 01:F57D:  .byte $4D   ; 003057 00305E
0x00358E ---- 01:F57E:  .byte $DD   ; 003057 00305E
0x00358F ---- 01:F57F:  .byte $4D   ; 003057 00305E
0x003590 ---- 01:F580:  .byte $DD   ; 003057 00305E
0x003591 ---- 01:F581:  .byte $DD   ; 00305E
0x003592 ---- 01:F582:  .byte $BB   ; 003057 00305E
0x003593 ---- 01:F583:  .byte $BB   ; 003057 00305E
0x003594 ---- 01:F584:  .byte $BB   ; 003057 00305E
0x003595 ---- 01:F585:  .byte $BB   ; 003057 00305E
0x003596 ---- 01:F586:  .byte $44   ; 003057 00305E
0x003597 ---- 01:F587:  .byte $DD   ; 003057 00305E
0x003598 ---- 01:F588:  .byte $DD   ; 00305E
0x003599 ---- 01:F589:  .byte $B8   ; 003057 00305E
0x00359A ---- 01:F58A:  .byte $4B   ; 003057 00305E
0x00359B ---- 01:F58B:  .byte $44   ; 003057 00305E
0x00359C ---- 01:F58C:  .byte $4B   ; 003057 00305E
0x00359D ---- 01:F58D:  .byte $BB   ; 003057 00305E
0x00359E ---- 01:F58E:  .byte $B4   ; 003057 00305E
0x00359F ---- 01:F58F:  .byte $9D   ; 00305E
0x0035A0 ---- 01:F590:  .byte $BB   ; 003057 00305E
0x0035A1 ---- 01:F591:  .byte $4B   ; 003057 00305E
0x0035A2 ---- 01:F592:  .byte $BB   ; 003057 00305E
0x0035A3 ---- 01:F593:  .byte $8B   ; 003057 00305E
0x0035A4 ---- 01:F594:  .byte $B4   ; 003057 00305E
0x0035A5 ---- 01:F595:  .byte $74   ; 003057 00305E
0x0035A6 ---- 01:F596:  .byte $DD   ; 00305E
0x0035A7 ---- 01:F597:  .byte $DB   ; 003057 00305E
0x0035A8 ---- 01:F598:  .byte $B4   ; 003057 00305E
0x0035A9 ---- 01:F599:  .byte $6B   ; 003057 00305E
0x0035AA ---- 01:F59A:  .byte $BB   ; 003057 00305E
0x0035AB ---- 01:F59B:  .byte $B4   ; 003057 00305E
0x0035AC ---- 01:F59C:  .byte $D4   ; 003057 00305E
0x0035AD ---- 01:F59D:  .byte $DD   ; 00305E
0x0035AE ---- 01:F59E:  .byte $D4   ; 003057 00305E
0x0035AF ---- 01:F59F:  .byte $44   ; 003057 00305E
0x0035B0 ---- 01:F5A0:  .byte $44   ; 003057 00305E
0x0035B1 ---- 01:F5A1:  .byte $BB   ; 003057 00305E
0x0035B2 ---- 01:F5A2:  .byte $44   ; 003057 00305E
0x0035B3 ---- 01:F5A3:  .byte $2B   ; 003057 00305E
0x0035B4 ---- 01:F5A4:  .byte $BD   ; 00305E
0x0035B5 ---- 01:F5A5:  .byte $58   ; 003057 00305E
0x0035B6 ---- 01:F5A6:  .byte $44   ; 003057 00305E
0x0035B7 ---- 01:F5A7:  .byte $DD   ; 003057 00305E
0x0035B8 ---- 01:F5A8:  .byte $D4   ; 003057 00305E
0x0035B9 ---- 01:F5A9:  .byte $3D   ; 003057 00305E
0x0035BA ---- 01:F5AA:  .byte $DD   ; 003057 00305E
0x0035BB ---- 01:F5AB:  .byte $BD   ; 00305E
0x0035BC ---- 01:F5AC:  .byte $D4   ; 003057 00305E
0x0035BD ---- 01:F5AD:  .byte $D4   ; 003057 00305E
0x0035BE ---- 01:F5AE:  .byte $D6   ; 003057 00305E
0x0035BF ---- 01:F5AF:  .byte $13   ; 003057 00305E
0x0035C0 ---- 01:F5B0:  .byte $BB   ; 003057 00305E
0x0035C1 ---- 01:F5B1:  .byte $42   ; 003057 00305E
0x0035C2 ---- 01:F5B2:  .byte $BD   ; 00305E
0x0035C3 ---- 01:F5B3:  .byte $D4   ; 003057 00305E
0x0035C4 ---- 01:F5B4:  .byte $DD   ; 003057 00305E
0x0035C5 ---- 01:F5B5:  .byte $04   ; 003057 00305E
0x0035C6 ---- 01:F5B6:  .byte $3B   ; 003057 00305E
0x0035C7 ---- 01:F5B7:  .byte $B4   ; 003057 00305E
0x0035C8 ---- 01:F5B8:  .byte $DD   ; 003057 00305E
0x0035C9 ---- 01:F5B9:  .byte $BD   ; 00305E
0x0035CA ---- 01:F5BA:  .byte $D4   ; 003057 00305E
0x0035CB ---- 01:F5BB:  .byte $42   ; 003057 00305E
0x0035CC ---- 01:F5BC:  .byte $03   ; 003057 00305E
0x0035CD ---- 01:F5BD:  .byte $BB   ; 003057 00305E
0x0035CE ---- 01:F5BE:  .byte $1B   ; 003057 00305E
0x0035CF ---- 01:F5BF:  .byte $4B   ; 003057 00305E
0x0035D0 ---- 01:F5C0:  .byte $BD   ; 00305E
0x0035D1 ---- 01:F5C1:  .byte $DD   ; 003057 00305E
0x0035D2 ---- 01:F5C2:  .byte $4D   ; 003057 00305E
0x0035D3 ---- 01:F5C3:  .byte $BD   ; 003057 00305E
0x0035D4 ---- 01:F5C4:  .byte $DD   ; 003057 00305E
0x0035D5 ---- 01:F5C5:  .byte $4B   ; 003057 00305E
0x0035D6 ---- 01:F5C6:  .byte $3B   ; 003057 00305E
0x0035D7 ---- 01:F5C7:  .byte $DD   ; 00305E
0x0035D8 ---- 01:F5C8:  .byte $DD   ; 003057 00305E
0x0035D9 ---- 01:F5C9:  .byte $3D   ; 003057 00305E
0x0035DA ---- 01:F5CA:  .byte $BD   ; 003057 00305E
0x0035DB ---- 01:F5CB:  .byte $DD   ; 003057 00305E
0x0035DC ---- 01:F5CC:  .byte $DB   ; 003057 00305E
0x0035DD ---- 01:F5CD:  .byte $BB   ; 003057 00305E
0x0035DE ---- 01:F5CE:  .byte $DD   ; 00305E
0x0035DF ---- 01:F5CF:  .byte $DD   ; 003057 00305E
0x0035E0 ---- 01:F5D0:  .byte $DD   ; 003057 00305E
0x0035E1 ---- 01:F5D1:  .byte $DD   ; 003057 00305E
0x0035E2 ---- 01:F5D2:  .byte $DD   ; 003057 00305E
0x0035E3 ---- 01:F5D3:  .byte $DD   ; 003057 00305E
0x0035E4 ---- 01:F5D4:  .byte $DD   ; 003057 00305E
0x0035E5 ---- 01:F5D5:  .byte $DD   ; 00305E
0x0035E6 ---- 01:F5D6:  .byte $DD   ; 003057 00305E
0x0035E7 ---- 01:F5D7:  .byte $9B   ; 003057 00305E
0x0035E8 ---- 01:F5D8:  .byte $9D   ; 003057 00305E
0x0035E9 ---- 01:F5D9:  .byte $DD   ; 003057 00305E
0x0035EA ---- 01:F5DA:  .byte $DD   ; 003057 00305E
0x0035EB ---- 01:F5DB:  .byte $DD   ; 003057 00305E
0x0035EC ---- 01:F5DC:  .byte $DD   ; 00305E
0x0035ED ---- 01:F5DD:  .byte $DD   ; 003057 00305E
0x0035EE ---- 01:F5DE:  .byte $DB   ; 003057 00305E
0x0035EF ---- 01:F5DF:  .byte $DB   ; 003057 00305E
0x0035F0 ---- 01:F5E0:  .byte $6D   ; 003057 00305E
0x0035F1 ---- 01:F5E1:  .byte $DD   ; 003057 00305E
0x0035F2 ---- 01:F5E2:  .byte $DD   ; 003057 00305E
0x0035F3 ---- 01:F5E3:  .byte $DD   ; 00305E
0x0035F4 ---- 01:F5E4:  .byte $DB   ; 003057 00305E
0x0035F5 ---- 01:F5E5:  .byte $DD   ; 003057 00305E
0x0035F6 ---- 01:F5E6:  .byte $DD   ; 003057 00305E
0x0035F7 ---- 01:F5E7:  .byte $B1   ; 003057 00305E
0x0035F8 ---- 01:F5E8:  .byte $DD   ; 003057 00305E
0x0035F9 ---- 01:F5E9:  .byte $DD   ; 003057 00305E
0x0035FA ---- 01:F5EA:  .byte $DD   ; 00305E
0x0035FB ---- 01:F5EB:  .byte $DB   ; 003057 00305E
0x0035FC ---- 01:F5EC:  .byte $BD   ; 003057 00305E
0x0035FD ---- 01:F5ED:  .byte $DB   ; 003057 00305E
0x0035FE ---- 01:F5EE:  .byte $DB   ; 003057 00305E
0x0035FF ---- 01:F5EF:  .byte $6D   ; 003057 00305E
0x003600 ---- 01:F5F0:  .byte $DD   ; 003057 00305E
0x003601 ---- 01:F5F1:  .byte $DD   ; 00305E
0x003602 ---- 01:F5F2:  .byte $DB   ; 003057 00305E
0x003603 ---- 01:F5F3:  .byte $DB   ; 003057 00305E
0x003604 ---- 01:F5F4:  .byte $DB   ; 003057 00305E
0x003605 ---- 01:F5F5:  .byte $DD   ; 003057 00305E
0x003606 ---- 01:F5F6:  .byte $B1   ; 003057 00305E
0x003607 ---- 01:F5F7:  .byte $DD   ; 003057 00305E
0x003608 ---- 01:F5F8:  .byte $DD   ; 00305E
0x003609 ---- 01:F5F9:  .byte $DB   ; 003057 00305E
0x00360A ---- 01:F5FA:  .byte $DD   ; 003057 00305E
0x00360B ---- 01:F5FB:  .byte $BD   ; 003057 00305E
0x00360C ---- 01:F5FC:  .byte $DD   ; 003057 00305E
0x00360D ---- 01:F5FD:  .byte $BB   ; 003057 00305E
0x00360E ---- 01:F5FE:  .byte $6D   ; 003057 00305E
0x00360F ---- 01:F5FF:  .byte $DD   ; 00305E
0x003610 ---- 01:F600:  .byte $DD   ; 003057 00305E
0x003611 ---- 01:F601:  .byte $BD   ; 003057 00305E
0x003612 ---- 01:F602:  .byte $DD   ; 003057 00305E
0x003613 ---- 01:F603:  .byte $DB   ; 003057 00305E
0x003614 ---- 01:F604:  .byte $BB   ; 003057 00305E
0x003615 ---- 01:F605:  .byte $B1   ; 003057 00305E
0x003616 ---- 01:F606:  .byte $DD   ; 00305E
0x003617 ---- 01:F607:  .byte $DD   ; 003057 00305E
0x003618 ---- 01:F608:  .byte $DB   ; 003057 00305E
0x003619 ---- 01:F609:  .byte $DD   ; 003057 00305E
0x00361A ---- 01:F60A:  .byte $BD   ; 003057 00305E
0x00361B ---- 01:F60B:  .byte $BB   ; 003057 00305E
0x00361C ---- 01:F60C:  .byte $BB   ; 003057 00305E
0x00361D ---- 01:F60D:  .byte $DD   ; 00305E
0x00361E ---- 01:F60E:  .byte $4D   ; 003057 00305E
0x00361F ---- 01:F60F:  .byte $DD   ; 003057 00305E
0x003620 ---- 01:F610:  .byte $DD   ; 003057 00305E
0x003621 ---- 01:F611:  .byte $BD   ; 003057 00305E
0x003622 ---- 01:F612:  .byte $DB   ; 003057 00305E
0x003623 ---- 01:F613:  .byte $BB   ; 003057 00305E
0x003624 ---- 01:F614:  .byte $9D   ; 00305E
0x003625 ---- 01:F615:  .byte $44   ; 003057 00305E
0x003626 ---- 01:F616:  .byte $DD   ; 003057 00305E
0x003627 ---- 01:F617:  .byte $DD   ; 003057 00305E
0x003628 ---- 01:F618:  .byte $DB   ; 003057 00305E
0x003629 ---- 01:F619:  .byte $DB   ; 003057 00305E
0x00362A ---- 01:F61A:  .byte $BB   ; 003057 00305E
0x00362B ---- 01:F61B:  .byte $BD   ; 00305E
0x00362C ---- 01:F61C:  .byte $94   ; 003057 00305E
0x00362D ---- 01:F61D:  .byte $4D   ; 003057 00305E
0x00362E ---- 01:F61E:  .byte $DD   ; 003057 00305E
0x00362F ---- 01:F61F:  .byte $DD   ; 003057 00305E
0x003630 ---- 01:F620:  .byte $BD   ; 003057 00305E
0x003631 ---- 01:F621:  .byte $BB   ; 003057 00305E
0x003632 ---- 01:F622:  .byte $BD   ; 00305E
0x003633 ---- 01:F623:  .byte $99   ; 003057 00305E
0x003634 ---- 01:F624:  .byte $44   ; 003057 00305E
0x003635 ---- 01:F625:  .byte $DD   ; 003057 00305E
0x003636 ---- 01:F626:  .byte $DD   ; 003057 00305E
0x003637 ---- 01:F627:  .byte $BD   ; 003057 00305E
0x003638 ---- 01:F628:  .byte $DB   ; 003057 00305E
0x003639 ---- 01:F629:  .byte $BD   ; 00305E
0x00363A ---- 01:F62A:  .byte $DD   ; 003057 00305E
0x00363B ---- 01:F62B:  .byte $DD   ; 003057 00305E
0x00363C ---- 01:F62C:  .byte $1D   ; 003057 00305E
0x00363D ---- 01:F62D:  .byte $DD   ; 003057 00305E
0x00363E ---- 01:F62E:  .byte $DD   ; 003057 00305E
0x00363F ---- 01:F62F:  .byte $1D   ; 003057 00305E
0x003640 ---- 01:F630:  .byte $DD   ; 00305E
0x003641 ---- 01:F631:  .byte $D4   ; 003057 00305E
0x003642 ---- 01:F632:  .byte $D4   ; 003057 00305E
0x003643 ---- 01:F633:  .byte $4D   ; 003057 00305E
0x003644 ---- 01:F634:  .byte $DC   ; 003057 00305E
0x003645 ---- 01:F635:  .byte $CC   ; 003057 00305E
0x003646 ---- 01:F636:  .byte $44   ; 003057 00305E
0x003647 ---- 01:F637:  .byte $DD   ; 00305E
0x003648 ---- 01:F638:  .byte $D4   ; 003057 00305E
0x003649 ---- 01:F639:  .byte $DD   ; 003057 00305E
0x00364A ---- 01:F63A:  .byte $4D   ; 003057 00305E
0x00364B ---- 01:F63B:  .byte $9C   ; 003057 00305E
0x00364C ---- 01:F63C:  .byte $CC   ; 003057 00305E
0x00364D ---- 01:F63D:  .byte $CC   ; 003057 00305E
0x00364E ---- 01:F63E:  .byte $DD   ; 00305E
0x00364F ---- 01:F63F:  .byte $CC   ; 003057 00305E
0x003650 ---- 01:F640:  .byte $C7   ; 003057 00305E
0x003651 ---- 01:F641:  .byte $4D   ; 003057 00305E
0x003652 ---- 01:F642:  .byte $D4   ; 003057 00305E
0x003653 ---- 01:F643:  .byte $CC   ; 003057 00305E
0x003654 ---- 01:F644:  .byte $CC   ; 003057 00305E
0x003655 ---- 01:F645:  .byte $DD   ; 00305E
0x003656 ---- 01:F646:  .byte $CC   ; 003057 00305E
0x003657 ---- 01:F647:  .byte $CC   ; 003057 00305E
0x003658 ---- 01:F648:  .byte $CC   ; 003057 00305E
0x003659 ---- 01:F649:  .byte $44   ; 003057 00305E
0x00365A ---- 01:F64A:  .byte $02   ; 003057 00305E
0x00365B ---- 01:F64B:  .byte $DD   ; 003057 00305E
0x00365C ---- 01:F64C:  .byte $DD   ; 00305E
0x00365D ---- 01:F64D:  .byte $DD   ; 003057 00305E
0x00365E ---- 01:F64E:  .byte $5C   ; 003057 00305E
0x00365F ---- 01:F64F:  .byte $CC   ; 003057 00305E
0x003660 ---- 01:F650:  .byte $C4   ; 003057 00305E
0x003661 ---- 01:F651:  .byte $02   ; 003057 00305E
0x003662 ---- 01:F652:  .byte $D8   ; 003057 00305E
0x003663 ---- 01:F653:  .byte $8D   ; 00305E
0x003664 ---- 01:F654:  .byte $44   ; 003057 00305E
0x003665 ---- 01:F655:  .byte $44   ; 003057 00305E
0x003666 ---- 01:F656:  .byte $CC   ; 003057 00305E
0x003667 ---- 01:F657:  .byte $CC   ; 003057 00305E
0x003668 ---- 01:F658:  .byte $CC   ; 003057 00305E
0x003669 ---- 01:F659:  .byte $C4   ; 003057 00305E
0x00366A ---- 01:F65A:  .byte $4D   ; 00305E
0x00366B ---- 01:F65B:  .byte $DD   ; 003057 00305E
0x00366C ---- 01:F65C:  .byte $D4   ; 003057 00305E
0x00366D ---- 01:F65D:  .byte $4C   ; 003057 00305E
0x00366E ---- 01:F65E:  .byte $CC   ; 003057 00305E
0x00366F ---- 01:F65F:  .byte $C7   ; 003057 00305E
0x003670 ---- 01:F660:  .byte $DD   ; 003057 00305E
0x003671 ---- 01:F661:  .byte $DD   ; 00305E
0x003672 ---- 01:F662:  .byte $D4   ; 003057 00305E
0x003673 ---- 01:F663:  .byte $44   ; 003057 00305E
0x003674 ---- 01:F664:  .byte $DC   ; 003057 00305E
0x003675 ---- 01:F665:  .byte $CC   ; 003057 00305E
0x003676 ---- 01:F666:  .byte $44   ; 003057 00305E
0x003677 ---- 01:F667:  .byte $D4   ; 003057 00305E
0x003678 ---- 01:F668:  .byte $DD   ; 00305E
0x003679 ---- 01:F669:  .byte $CC   ; 003057 00305E
0x00367A ---- 01:F66A:  .byte $C4   ; 003057 00305E
0x00367B ---- 01:F66B:  .byte $CD   ; 003057 00305E
0x00367C ---- 01:F66C:  .byte $DD   ; 003057 00305E
0x00367D ---- 01:F66D:  .byte $D4   ; 003057 00305E
0x00367E ---- 01:F66E:  .byte $D4   ; 003057 00305E
0x00367F ---- 01:F66F:  .byte $DD   ; 00305E
0x003680 ---- 01:F670:  .byte $CC   ; 003057 00305E
0x003681 ---- 01:F671:  .byte $CC   ; 003057 00305E
0x003682 ---- 01:F672:  .byte $C8   ; 003057 00305E
0x003683 ---- 01:F673:  .byte $D8   ; 003057 00305E
0x003684 ---- 01:F674:  .byte $DD   ; 003057 00305E
0x003685 ---- 01:F675:  .byte $14   ; 003057 00305E
0x003686 ---- 01:F676:  .byte $DD   ; 00305E
0x003687 ---- 01:F677:  .byte $4C   ; 003057 00305E
0x003688 ---- 01:F678:  .byte $CC   ; 003057 00305E
0x003689 ---- 01:F679:  .byte $CD   ; 003057 00305E
0x00368A ---- 01:F67A:  .byte $DD   ; 003057 00305E
0x00368B ---- 01:F67B:  .byte $D4   ; 003057 00305E
0x00368C ---- 01:F67C:  .byte $DD   ; 003057 00305E
0x00368D ---- 01:F67D:  .byte $DD   ; 00305E
0x00368E ---- 01:F67E:  .byte $44   ; 003057 00305E
0x00368F ---- 01:F67F:  .byte $7D   ; 003057 00305E
0x003690 ---- 01:F680:  .byte $DD   ; 003057 00305E
0x003691 ---- 01:F681:  .byte $DD   ; 003057 00305E
0x003692 ---- 01:F682:  .byte $D4   ; 003057 00305E
0x003693 ---- 01:F683:  .byte $D4   ; 003057 00305E
0x003694 ---- 01:F684:  .byte $DD   ; 00305E
0x003695 ---- 01:F685:  .byte $DD   ; 003057 00305E
0x003696 ---- 01:F686:  .byte $DD   ; 003057 00305E
0x003697 ---- 01:F687:  .byte $DD   ; 003057 00305E
0x003698 ---- 01:F688:  .byte $DD   ; 003057 00305E
0x003699 ---- 01:F689:  .byte $99   ; 003057 00305E
0x00369A ---- 01:F68A:  .byte $9B   ; 003057 00305E
0x00369B ---- 01:F68B:  .byte $DD   ; 00305E
0x00369C ---- 01:F68C:  .byte $D4   ; 003057 00305E
0x00369D ---- 01:F68D:  .byte $DD   ; 003057 00305E
0x00369E ---- 01:F68E:  .byte $DD   ; 003057 00305E
0x00369F ---- 01:F68F:  .byte $DD   ; 003057 00305E
0x0036A0 ---- 01:F690:  .byte $9D   ; 003057 00305E
0x0036A1 ---- 01:F691:  .byte $D9   ; 003057 00305E
0x0036A2 ---- 01:F692:  .byte $DD   ; 00305E
0x0036A3 ---- 01:F693:  .byte $4B   ; 003057 00305E
0x0036A4 ---- 01:F694:  .byte $4D   ; 003057 00305E
0x0036A5 ---- 01:F695:  .byte $DD   ; 003057 00305E
0x0036A6 ---- 01:F696:  .byte $44   ; 003057 00305E
0x0036A7 ---- 01:F697:  .byte $44   ; 003057 00305E
0x0036A8 ---- 01:F698:  .byte $D9   ; 003057 00305E
0x0036A9 ---- 01:F699:  .byte $DD   ; 00305E
0x0036AA ---- 01:F69A:  .byte $D4   ; 003057 00305E
0x0036AB ---- 01:F69B:  .byte $B4   ; 003057 00305E
0x0036AC ---- 01:F69C:  .byte $DD   ; 003057 00305E
0x0036AD ---- 01:F69D:  .byte $4D   ; 003057 00305E
0x0036AE ---- 01:F69E:  .byte $B4   ; 003057 00305E
0x0036AF ---- 01:F69F:  .byte $99   ; 003057 00305E
0x0036B0 ---- 01:F6A0:  .byte $DD   ; 00305E
0x0036B1 ---- 01:F6A1:  .byte $DD   ; 003057 00305E
0x0036B2 ---- 01:F6A2:  .byte $4D   ; 003057 00305E
0x0036B3 ---- 01:F6A3:  .byte $B9   ; 003057 00305E
0x0036B4 ---- 01:F6A4:  .byte $4B   ; 003057 00305E
0x0036B5 ---- 01:F6A5:  .byte $D4   ; 003057 00305E
0x0036B6 ---- 01:F6A6:  .byte $DD   ; 003057 00305E
0x0036B7 ---- 01:F6A7:  .byte $DD   ; 00305E
0x0036B8 ---- 01:F6A8:  .byte $DD   ; 003057 00305E
0x0036B9 ---- 01:F6A9:  .byte $DD   ; 003057 00305E
0x0036BA ---- 01:F6AA:  .byte $9D   ; 003057 00305E
0x0036BB ---- 01:F6AB:  .byte $49   ; 003057 00305E
0x0036BC ---- 01:F6AC:  .byte $44   ; 003057 00305E
0x0036BD ---- 01:F6AD:  .byte $DD   ; 003057 00305E
0x0036BE ---- 01:F6AE:  .byte $DD   ; 00305E
0x0036BF ---- 01:F6AF:  .byte $DD   ; 003057 00305E
0x0036C0 ---- 01:F6B0:  .byte $44   ; 003057 00305E
0x0036C1 ---- 01:F6B1:  .byte $94   ; 003057 00305E
0x0036C2 ---- 01:F6B2:  .byte $D9   ; 003057 00305E
0x0036C3 ---- 01:F6B3:  .byte $DD   ; 003057 00305E
0x0036C4 ---- 01:F6B4:  .byte $DD   ; 003057 00305E
0x0036C5 ---- 01:F6B5:  .byte $DD   ; 00305E
0x0036C6 ---- 01:F6B6:  .byte $DD   ; 003057 00305E
0x0036C7 ---- 01:F6B7:  .byte $4D   ; 003057 00305E
0x0036C8 ---- 01:F6B8:  .byte $B4   ; 003057 00305E
0x0036C9 ---- 01:F6B9:  .byte $9B   ; 003057 00305E
0x0036CA ---- 01:F6BA:  .byte $DD   ; 003057 00305E
0x0036CB ---- 01:F6BB:  .byte $DD   ; 003057 00305E
0x0036CC ---- 01:F6BC:  .byte $DD   ; 00305E
0x0036CD ---- 01:F6BD:  .byte $99   ; 003057 00305E
0x0036CE ---- 01:F6BE:  .byte $9B   ; 003057 00305E
0x0036CF ---- 01:F6BF:  .byte $D4   ; 003057 00305E
0x0036D0 ---- 01:F6C0:  .byte $DD   ; 003057 00305E
0x0036D1 ---- 01:F6C1:  .byte $44   ; 003057 00305E
0x0036D2 ---- 01:F6C2:  .byte $DD   ; 003057 00305E
0x0036D3 ---- 01:F6C3:  .byte $DD   ; 00305E
0x0036D4 ---- 01:F6C4:  .byte $9D   ; 003057 00305E
0x0036D5 ---- 01:F6C5:  .byte $44   ; 003057 00305E
0x0036D6 ---- 01:F6C6:  .byte $44   ; 003057 00305E
0x0036D7 ---- 01:F6C7:  .byte $DD   ; 003057 00305E
0x0036D8 ---- 01:F6C8:  .byte $49   ; 003057 00305E
0x0036D9 ---- 01:F6C9:  .byte $9D   ; 003057 00305E
0x0036DA ---- 01:F6CA:  .byte $DD   ; 00305E
0x0036DB ---- 01:F6CB:  .byte $9D   ; 003057 00305E
0x0036DC ---- 01:F6CC:  .byte $D9   ; 003057 00305E
0x0036DD ---- 01:F6CD:  .byte $DD   ; 003057 00305E
0x0036DE ---- 01:F6CE:  .byte $DD   ; 003057 00305E
0x0036DF ---- 01:F6CF:  .byte $D9   ; 003057 00305E
0x0036E0 ---- 01:F6D0:  .byte $44   ; 003057 00305E
0x0036E1 ---- 01:F6D1:  .byte $DD   ; 00305E
0x0036E2 ---- 01:F6D2:  .byte $B9   ; 003057 00305E
0x0036E3 ---- 01:F6D3:  .byte $99   ; 003057 00305E
0x0036E4 ---- 01:F6D4:  .byte $DD   ; 003057 00305E
0x0036E5 ---- 01:F6D5:  .byte $DD   ; 003057 00305E
0x0036E6 ---- 01:F6D6:  .byte $DD   ; 003057 00305E
0x0036E7 ---- 01:F6D7:  .byte $49   ; 003057 00305E
0x0036E8 ---- 01:F6D8:  .byte $9D   ; 00305E
0x0036E9 ---- 01:F6D9:  .byte $DD   ; 003057 00305E
0x0036EA ---- 01:F6DA:  .byte $DD   ; 003057 00305E
0x0036EB ---- 01:F6DB:  .byte $DD   ; 003057 00305E
0x0036EC ---- 01:F6DC:  .byte $DD   ; 003057 00305E
0x0036ED ---- 01:F6DD:  .byte $DD   ; 003057 00305E
0x0036EE ---- 01:F6DE:  .byte $D9   ; 003057 00305E
0x0036EF ---- 01:F6DF:  .byte $9D   ; 00305E
0x0036F0 ---- 01:F6E0:  .byte $D4   ; 003057 00305E
0x0036F1 ---- 01:F6E1:  .byte $D4   ; 003057 00305E
0x0036F2 ---- 01:F6E2:  .byte $D4   ; 003057 00305E
0x0036F3 ---- 01:F6E3:  .byte $D4   ; 003057 00305E
0x0036F4 ---- 01:F6E4:  .byte $D4   ; 003057 00305E
0x0036F5 ---- 01:F6E5:  .byte $D4   ; 003057 00305E
0x0036F6 ---- 01:F6E6:  .byte $DD   ; 00305E
0x0036F7 ---- 01:F6E7:  .byte $D4   ; 003057 00305E
0x0036F8 ---- 01:F6E8:  .byte $D4   ; 003057 00305E
0x0036F9 ---- 01:F6E9:  .byte $D4   ; 003057 00305E
0x0036FA ---- 01:F6EA:  .byte $D4   ; 003057 00305E
0x0036FB ---- 01:F6EB:  .byte $D4   ; 003057 00305E
0x0036FC ---- 01:F6EC:  .byte $D4   ; 003057 00305E
0x0036FD ---- 01:F6ED:  .byte $DD   ; 00305E
0x0036FE ---- 01:F6EE:  .byte $D8   ; 003057 00305E
0x0036FF ---- 01:F6EF:  .byte $D8   ; 003057 00305E
0x003700 ---- 01:F6F0:  .byte $D8   ; 003057 00305E
0x003701 ---- 01:F6F1:  .byte $D8   ; 003057 00305E
0x003702 ---- 01:F6F2:  .byte $D8   ; 003057 00305E
0x003703 ---- 01:F6F3:  .byte $D8   ; 003057 00305E
0x003704 ---- 01:F6F4:  .byte $DD   ; 00305E
0x003705 ---- 01:F6F5:  .byte $1D   ; 003057 00305E
0x003706 ---- 01:F6F6:  .byte $1D   ; 003057 00305E
0x003707 ---- 01:F6F7:  .byte $4D   ; 003057 00305E
0x003708 ---- 01:F6F8:  .byte $DD   ; 003057 00305E
0x003709 ---- 01:F6F9:  .byte $4D   ; 003057 00305E
0x00370A ---- 01:F6FA:  .byte $1D   ; 003057 00305E
0x00370B ---- 01:F6FB:  .byte $1D   ; 00305E
0x00370C ---- 01:F6FC:  .byte $4D   ; 003057 00305E
0x00370D ---- 01:F6FD:  .byte $43   ; 003057 00305E
0x00370E ---- 01:F6FE:  .byte $4D   ; 003057 00305E
0x00370F ---- 01:F6FF:  .byte $4D   ; 003057 00305E
0x003710 ---- 01:F700:  .byte $43   ; 003057 00305E
0x003711 ---- 01:F701:  .byte $4D   ; 003057 00305E
0x003712 ---- 01:F702:  .byte $4D   ; 00305E
0x003713 ---- 01:F703:  .byte $8D   ; 003057 00305E
0x003714 ---- 01:F704:  .byte $8D   ; 003057 00305E
0x003715 ---- 01:F705:  .byte $9D   ; 003057 00305E
0x003716 ---- 01:F706:  .byte $8D   ; 003057 00305E
0x003717 ---- 01:F707:  .byte $9D   ; 003057 00305E
0x003718 ---- 01:F708:  .byte $8D   ; 003057 00305E
0x003719 ---- 01:F709:  .byte $8D   ; 00305E
0x00371A ---- 01:F70A:  .byte $BB   ; 003057 00305E
0x00371B ---- 01:F70B:  .byte $DD   ; 003057 00305E
0x00371C ---- 01:F70C:  .byte $4D   ; 003057 00305E
0x00371D ---- 01:F70D:  .byte $BD   ; 003057 00305E
0x00371E ---- 01:F70E:  .byte $4D   ; 003057 00305E
0x00371F ---- 01:F70F:  .byte $DB   ; 003057 00305E
0x003720 ---- 01:F710:  .byte $BD   ; 00305E
0x003721 ---- 01:F711:  .byte $BB   ; 003057 00305E
0x003722 ---- 01:F712:  .byte $BB   ; 003057 00305E
0x003723 ---- 01:F713:  .byte $43   ; 003057 00305E
0x003724 ---- 01:F714:  .byte $B3   ; 003057 00305E
0x003725 ---- 01:F715:  .byte $4B   ; 003057 00305E
0x003726 ---- 01:F716:  .byte $BB   ; 003057 00305E
0x003727 ---- 01:F717:  .byte $BD   ; 00305E
0x003728 ---- 01:F718:  .byte $BB   ; 003057 00305E
0x003729 ---- 01:F719:  .byte $BB   ; 003057 00305E
0x00372A ---- 01:F71A:  .byte $BB   ; 003057 00305E
0x00372B ---- 01:F71B:  .byte $BB   ; 003057 00305E
0x00372C ---- 01:F71C:  .byte $BB   ; 003057 00305E
0x00372D ---- 01:F71D:  .byte $BB   ; 003057 00305E
0x00372E ---- 01:F71E:  .byte $BD   ; 00305E
0x00372F ---- 01:F71F:  .byte $1D   ; 003057 00305E
0x003730 ---- 01:F720:  .byte $1D   ; 003057 00305E
0x003731 ---- 01:F721:  .byte $4B   ; 003057 00305E
0x003732 ---- 01:F722:  .byte $BB   ; 003057 00305E
0x003733 ---- 01:F723:  .byte $4D   ; 003057 00305E
0x003734 ---- 01:F724:  .byte $1D   ; 003057 00305E
0x003735 ---- 01:F725:  .byte $1D   ; 00305E
0x003736 ---- 01:F726:  .byte $D4   ; 003057 00305E
0x003737 ---- 01:F727:  .byte $D4   ; 003057 00305E
0x003738 ---- 01:F728:  .byte $DD   ; 003057 00305E
0x003739 ---- 01:F729:  .byte $BD   ; 003057 00305E
0x00373A ---- 01:F72A:  .byte $D4   ; 003057 00305E
0x00373B ---- 01:F72B:  .byte $D4   ; 003057 00305E
0x00373C ---- 01:F72C:  .byte $DD   ; 00305E
0x00373D ---- 01:F72D:  .byte $D4   ; 003057 00305E
0x00373E ---- 01:F72E:  .byte $D4   ; 003057 00305E
0x00373F ---- 01:F72F:  .byte $DD   ; 003057 00305E
0x003740 ---- 01:F730:  .byte $DD   ; 003057 00305E
0x003741 ---- 01:F731:  .byte $D4   ; 003057 00305E
0x003742 ---- 01:F732:  .byte $D4   ; 003057 00305E
0x003743 ---- 01:F733:  .byte $DD   ; 00305E
0x003744 ---- 01:F734:  .byte $D3   ; 003057 00305E
0x003745 ---- 01:F735:  .byte $D3   ; 003057 00305E
0x003746 ---- 01:F736:  .byte $DD   ; 003057 00305E
0x003747 ---- 01:F737:  .byte $DD   ; 003057 00305E
0x003748 ---- 01:F738:  .byte $D3   ; 003057 00305E
0x003749 ---- 01:F739:  .byte $D3   ; 003057 00305E
0x00374A ---- 01:F73A:  .byte $DD   ; 00305E
0x00374B ---- 01:F73B:  .byte $DD   ; 003057 00305E
0x00374C ---- 01:F73C:  .byte $DA   ; 003057 00305E
0x00374D ---- 01:F73D:  .byte $D4   ; 003057 00305E
0x00374E ---- 01:F73E:  .byte $DD   ; 003057 00305E
0x00374F ---- 01:F73F:  .byte $4D   ; 003057 00305E
0x003750 ---- 01:F740:  .byte $4D   ; 003057 00305E
0x003751 ---- 01:F741:  .byte $DD   ; 00305E
0x003752 ---- 01:F742:  .byte $DD   ; 003057 00305E
0x003753 ---- 01:F743:  .byte $DD   ; 003057 00305E
0x003754 ---- 01:F744:  .byte $DD   ; 003057 00305E
0x003755 ---- 01:F745:  .byte $DD   ; 003057 00305E
0x003756 ---- 01:F746:  .byte $4D   ; 003057 00305E
0x003757 ---- 01:F747:  .byte $9D   ; 003057 00305E
0x003758 ---- 01:F748:  .byte $DD   ; 00305E
0x003759 ---- 01:F749:  .byte $DD   ; 003057 00305E
0x00375A ---- 01:F74A:  .byte $DA   ; 003057 00305E
0x00375B ---- 01:F74B:  .byte $D1   ; 003057 00305E
0x00375C ---- 01:F74C:  .byte $9D   ; 003057 00305E
0x00375D ---- 01:F74D:  .byte $4D   ; 003057 00305E
0x00375E ---- 01:F74E:  .byte $4D   ; 003057 00305E
0x00375F ---- 01:F74F:  .byte $DD   ; 00305E
0x003760 ---- 01:F750:  .byte $8D   ; 003057 00305E
0x003761 ---- 01:F751:  .byte $4A   ; 003057 00305E
0x003762 ---- 01:F752:  .byte $D9   ; 003057 00305E
0x003763 ---- 01:F753:  .byte $D1   ; 003057 00305E
0x003764 ---- 01:F754:  .byte $3D   ; 003057 00305E
0x003765 ---- 01:F755:  .byte $4D   ; 003057 00305E
0x003766 ---- 01:F756:  .byte $DD   ; 00305E
0x003767 ---- 01:F757:  .byte $DD   ; 003057 00305E
0x003768 ---- 01:F758:  .byte $4A   ; 003057 00305E
0x003769 ---- 01:F759:  .byte $DD   ; 003057 00305E
0x00376A ---- 01:F75A:  .byte $D4   ; 003057 00305E
0x00376B ---- 01:F75B:  .byte $DD   ; 003057 00305E
0x00376C ---- 01:F75C:  .byte $DD   ; 003057 00305E
0x00376D ---- 01:F75D:  .byte $DD   ; 00305E
0x00376E ---- 01:F75E:  .byte $4D   ; 003057 00305E
0x00376F ---- 01:F75F:  .byte $4A   ; 003057 00305E
0x003770 ---- 01:F760:  .byte $AD   ; 003057 00305E
0x003771 ---- 01:F761:  .byte $AA   ; 003057 00305E
0x003772 ---- 01:F762:  .byte $AA   ; 003057 00305E
0x003773 ---- 01:F763:  .byte $DD   ; 003057 00305E
0x003774 ---- 01:F764:  .byte $4D   ; 00305E
0x003775 ---- 01:F765:  .byte $DD   ; 003057 00305E
0x003776 ---- 01:F766:  .byte $D1   ; 003057 00305E
0x003777 ---- 01:F767:  .byte $DD   ; 003057 00305E
0x003778 ---- 01:F768:  .byte $DB   ; 003057 00305E
0x003779 ---- 01:F769:  .byte $DA   ; 003057 00305E
0x00377A ---- 01:F76A:  .byte $D8   ; 003057 00305E
0x00377B ---- 01:F76B:  .byte $8D   ; 00305E
0x00377C ---- 01:F76C:  .byte $44   ; 003057 00305E
0x00377D ---- 01:F76D:  .byte $04   ; 003057 00305E
0x00377E ---- 01:F76E:  .byte $D9   ; 003057 00305E
0x00377F ---- 01:F76F:  .byte $BB   ; 003057 00305E
0x003780 ---- 01:F770:  .byte $BA   ; 003057 00305E
0x003781 ---- 01:F771:  .byte $D1   ; 003057 00305E
0x003782 ---- 01:F772:  .byte $1D   ; 00305E
0x003783 ---- 01:F773:  .byte $3D   ; 003057 00305E
0x003784 ---- 01:F774:  .byte $0D   ; 003057 00305E
0x003785 ---- 01:F775:  .byte $D4   ; 003057 00305E
0x003786 ---- 01:F776:  .byte $BB   ; 003057 00305E
0x003787 ---- 01:F777:  .byte $BA   ; 003057 00305E
0x003788 ---- 01:F778:  .byte $D4   ; 003057 00305E
0x003789 ---- 01:F779:  .byte $DD   ; 00305E
0x00378A ---- 01:F77A:  .byte $D6   ; 003057 00305E
0x00378B ---- 01:F77B:  .byte $DD   ; 003057 00305E
0x00378C ---- 01:F77C:  .byte $D4   ; 003057 00305E
0x00378D ---- 01:F77D:  .byte $DB   ; 003057 00305E
0x00378E ---- 01:F77E:  .byte $DA   ; 003057 00305E
0x00378F ---- 01:F77F:  .byte $DB   ; 003057 00305E
0x003790 ---- 01:F780:  .byte $DD   ; 00305E
0x003791 ---- 01:F781:  .byte $D4   ; 003057 00305E
0x003792 ---- 01:F782:  .byte $D6   ; 003057 00305E
0x003793 ---- 01:F783:  .byte $D3   ; 003057 00305E
0x003794 ---- 01:F784:  .byte $33   ; 003057 00305E
0x003795 ---- 01:F785:  .byte $DD   ; 003057 00305E
0x003796 ---- 01:F786:  .byte $BB   ; 003057 00305E
0x003797 ---- 01:F787:  .byte $BD   ; 00305E
0x003798 ---- 01:F788:  .byte $D4   ; 003057 00305E
0x003799 ---- 01:F789:  .byte $D4   ; 003057 00305E
0x00379A ---- 01:F78A:  .byte $DD   ; 003057 00305E
0x00379B ---- 01:F78B:  .byte $DD   ; 003057 00305E
0x00379C ---- 01:F78C:  .byte $DA   ; 003057 00305E
0x00379D ---- 01:F78D:  .byte $BB   ; 003057 00305E
0x00379E ---- 01:F78E:  .byte $BD   ; 00305E
0x00379F ---- 01:F78F:  .byte $DD   ; 003057 00305E
0x0037A0 ---- 01:F790:  .byte $DD   ; 003057 00305E
0x0037A1 ---- 01:F791:  .byte $DD   ; 003057 00305E
0x0037A2 ---- 01:F792:  .byte $DD   ; 003057 00305E
0x0037A3 ---- 01:F793:  .byte $DA   ; 003057 00305E
0x0037A4 ---- 01:F794:  .byte $DB   ; 003057 00305E
0x0037A5 ---- 01:F795:  .byte $DD   ; 00305E
0x0037A6 ---- 01:F796:  .byte $DD   ; 003057 00305E
0x0037A7 ---- 01:F797:  .byte $D1   ; 003057 00305E
0x0037A8 ---- 01:F798:  .byte $11   ; 003057 00305E
0x0037A9 ---- 01:F799:  .byte $DD   ; 003057 00305E
0x0037AA ---- 01:F79A:  .byte $1D   ; 003057 00305E
0x0037AB ---- 01:F79B:  .byte $DD   ; 003057 00305E
0x0037AC ---- 01:F79C:  .byte $DD   ; 00305E
0x0037AD ---- 01:F79D:  .byte $D1   ; 003057 00305E
0x0037AE ---- 01:F79E:  .byte $44   ; 003057 00305E
0x0037AF ---- 01:F79F:  .byte $44   ; 003057 00305E
0x0037B0 ---- 01:F7A0:  .byte $44   ; 003057 00305E
0x0037B1 ---- 01:F7A1:  .byte $44   ; 003057 00305E
0x0037B2 ---- 01:F7A2:  .byte $DD   ; 003057 00305E
0x0037B3 ---- 01:F7A3:  .byte $DD   ; 00305E
0x0037B4 ---- 01:F7A4:  .byte $DB   ; 003057 00305E
0x0037B5 ---- 01:F7A5:  .byte $BB   ; 003057 00305E
0x0037B6 ---- 01:F7A6:  .byte $BB   ; 003057 00305E
0x0037B7 ---- 01:F7A7:  .byte $BB   ; 003057 00305E
0x0037B8 ---- 01:F7A8:  .byte $B4   ; 003057 00305E
0x0037B9 ---- 01:F7A9:  .byte $4D   ; 003057 00305E
0x0037BA ---- 01:F7AA:  .byte $DD   ; 00305E
0x0037BB ---- 01:F7AB:  .byte $BB   ; 003057 00305E
0x0037BC ---- 01:F7AC:  .byte $DD   ; 003057 00305E
0x0037BD ---- 01:F7AD:  .byte $DD   ; 003057 00305E
0x0037BE ---- 01:F7AE:  .byte $DD   ; 003057 00305E
0x0037BF ---- 01:F7AF:  .byte $BB   ; 003057 00305E
0x0037C0 ---- 01:F7B0:  .byte $44   ; 003057 00305E
0x0037C1 ---- 01:F7B1:  .byte $DD   ; 00305E
0x0037C2 ---- 01:F7B2:  .byte $BD   ; 003057 00305E
0x0037C3 ---- 01:F7B3:  .byte $9D   ; 003057 00305E
0x0037C4 ---- 01:F7B4:  .byte $D9   ; 003057 00305E
0x0037C5 ---- 01:F7B5:  .byte $DD   ; 003057 00305E
0x0037C6 ---- 01:F7B6:  .byte $DB   ; 003057 00305E
0x0037C7 ---- 01:F7B7:  .byte $BB   ; 003057 00305E
0x0037C8 ---- 01:F7B8:  .byte $DD   ; 00305E
0x0037C9 ---- 01:F7B9:  .byte $BD   ; 003057 00305E
0x0037CA ---- 01:F7BA:  .byte $9D   ; 003057 00305E
0x0037CB ---- 01:F7BB:  .byte $D9   ; 003057 00305E
0x0037CC ---- 01:F7BC:  .byte $DD   ; 003057 00305E
0x0037CD ---- 01:F7BD:  .byte $DB   ; 003057 00305E
0x0037CE ---- 01:F7BE:  .byte $BB   ; 003057 00305E
0x0037CF ---- 01:F7BF:  .byte $DD   ; 00305E
0x0037D0 ---- 01:F7C0:  .byte $BD   ; 003057 00305E
0x0037D1 ---- 01:F7C1:  .byte $DB   ; 003057 00305E
0x0037D2 ---- 01:F7C2:  .byte $DD   ; 003057 00305E
0x0037D3 ---- 01:F7C3:  .byte $DD   ; 003057 00305E
0x0037D4 ---- 01:F7C4:  .byte $BB   ; 003057 00305E
0x0037D5 ---- 01:F7C5:  .byte $44   ; 003057 00305E
0x0037D6 ---- 01:F7C6:  .byte $2D   ; 00305E
0x0037D7 ---- 01:F7C7:  .byte $BB   ; 003057 00305E
0x0037D8 ---- 01:F7C8:  .byte $BB   ; 003057 00305E
0x0037D9 ---- 01:F7C9:  .byte $BB   ; 003057 00305E
0x0037DA ---- 01:F7CA:  .byte $BB   ; 003057 00305E
0x0037DB ---- 01:F7CB:  .byte $B4   ; 003057 00305E
0x0037DC ---- 01:F7CC:  .byte $44   ; 003057 00305E
0x0037DD ---- 01:F7CD:  .byte $2D   ; 00305E
0x0037DE ---- 01:F7CE:  .byte $4B   ; 003057 00305E
0x0037DF ---- 01:F7CF:  .byte $B4   ; 003057 00305E
0x0037E0 ---- 01:F7D0:  .byte $4B   ; 003057 00305E
0x0037E1 ---- 01:F7D1:  .byte $BB   ; 003057 00305E
0x0037E2 ---- 01:F7D2:  .byte $44   ; 003057 00305E
0x0037E3 ---- 01:F7D3:  .byte $44   ; 003057 00305E
0x0037E4 ---- 01:F7D4:  .byte $DD   ; 00305E
0x0037E5 ---- 01:F7D5:  .byte $D4   ; 003057 00305E
0x0037E6 ---- 01:F7D6:  .byte $44   ; 003057 00305E
0x0037E7 ---- 01:F7D7:  .byte $44   ; 003057 00305E
0x0037E8 ---- 01:F7D8:  .byte $44   ; 003057 00305E
0x0037E9 ---- 01:F7D9:  .byte $44   ; 003057 00305E
0x0037EA ---- 01:F7DA:  .byte $4D   ; 003057 00305E
0x0037EB ---- 01:F7DB:  .byte $9D   ; 00305E
0x0037EC ---- 01:F7DC:  .byte $9D   ; 003057 00305E
0x0037ED ---- 01:F7DD:  .byte $49   ; 003057 00305E
0x0037EE ---- 01:F7DE:  .byte $44   ; 003057 00305E
0x0037EF ---- 01:F7DF:  .byte $44   ; 003057 00305E
0x0037F0 ---- 01:F7E0:  .byte $44   ; 003057 00305E
0x0037F1 ---- 01:F7E1:  .byte $2D   ; 003057 00305E
0x0037F2 ---- 01:F7E2:  .byte $9D   ; 00305E
0x0037F3 ---- 01:F7E3:  .byte $D9   ; 003057 00305E
0x0037F4 ---- 01:F7E4:  .byte $43   ; 003057 00305E
0x0037F5 ---- 01:F7E5:  .byte $94   ; 003057 00305E
0x0037F6 ---- 01:F7E6:  .byte $44   ; 003057 00305E
0x0037F7 ---- 01:F7E7:  .byte $44   ; 003057 00305E
0x0037F8 ---- 01:F7E8:  .byte $99   ; 003057 00305E
0x0037F9 ---- 01:F7E9:  .byte $9D   ; 00305E
0x0037FA ---- 01:F7EA:  .byte $DD   ; 003057 00305E
0x0037FB ---- 01:F7EB:  .byte $DD   ; 003057 00305E
0x0037FC ---- 01:F7EC:  .byte $DD   ; 003057 00305E
0x0037FD ---- 01:F7ED:  .byte $DD   ; 003057 00305E
0x0037FE ---- 01:F7EE:  .byte $DD   ; 003057 00305E
0x0037FF ---- 01:F7EF:  .byte $DD   ; 003057 00305E
0x003800 ---- 01:F7F0:  .byte $DD   ; 00305E
0x003801 ---- 01:F7F1:  .byte $DD   ; 003057 00305E
0x003802 ---- 01:F7F2:  .byte $DD   ; 003057 00305E
0x003803 ---- 01:F7F3:  .byte $DB   ; 003057 00305E
0x003804 ---- 01:F7F4:  .byte $DD   ; 003057 00305E
0x003805 ---- 01:F7F5:  .byte $DD   ; 003057 00305E
0x003806 ---- 01:F7F6:  .byte $DD   ; 003057 00305E
0x003807 ---- 01:F7F7:  .byte $DD   ; 00305E
0x003808 ---- 01:F7F8:  .byte $DD   ; 003057 00305E
0x003809 ---- 01:F7F9:  .byte $DD   ; 003057 00305E
0x00380A ---- 01:F7FA:  .byte $B9   ; 003057 00305E
0x00380B ---- 01:F7FB:  .byte $BD   ; 003057 00305E
0x00380C ---- 01:F7FC:  .byte $DD   ; 003057 00305E
0x00380D ---- 01:F7FD:  .byte $DD   ; 003057 00305E
0x00380E ---- 01:F7FE:  .byte $DD   ; 00305E
0x00380F ---- 01:F7FF:  .byte $DD   ; 003057 00305E
0x003810 ---- 01:F800:  .byte $BD   ; 003057 00305E
0x003811 ---- 01:F801:  .byte $DB   ; 003057 00305E
0x003812 ---- 01:F802:  .byte $DD   ; 003057 00305E
0x003813 ---- 01:F803:  .byte $BB   ; 003057 00305E
0x003814 ---- 01:F804:  .byte $DD   ; 003057 00305E
0x003815 ---- 01:F805:  .byte $DD   ; 00305E
0x003816 ---- 01:F806:  .byte $DB   ; 003057 00305E
0x003817 ---- 01:F807:  .byte $4B   ; 003057 00305E
0x003818 ---- 01:F808:  .byte $DD   ; 003057 00305E
0x003819 ---- 01:F809:  .byte $DB   ; 003057 00305E
0x00381A ---- 01:F80A:  .byte $44   ; 003057 00305E
0x00381B ---- 01:F80B:  .byte $BD   ; 003057 00305E
0x00381C ---- 01:F80C:  .byte $DD   ; 00305E
0x00381D ---- 01:F80D:  .byte $DD   ; 003057 00305E
0x00381E ---- 01:F80E:  .byte $B4   ; 003057 00305E
0x00381F ---- 01:F80F:  .byte $BD   ; 003057 00305E
0x003820 ---- 01:F810:  .byte $DD   ; 003057 00305E
0x003821 ---- 01:F811:  .byte $BB   ; 003057 00305E
0x003822 ---- 01:F812:  .byte $DD   ; 003057 00305E
0x003823 ---- 01:F813:  .byte $BD   ; 00305E
0x003824 ---- 01:F814:  .byte $BD   ; 003057 00305E
0x003825 ---- 01:F815:  .byte $DB   ; 003057 00305E
0x003826 ---- 01:F816:  .byte $DD   ; 003057 00305E
0x003827 ---- 01:F817:  .byte $BD   ; 003057 00305E
0x003828 ---- 01:F818:  .byte $DD   ; 003057 00305E
0x003829 ---- 01:F819:  .byte $DB   ; 003057 00305E
0x00382A ---- 01:F81A:  .byte $9D   ; 00305E
0x00382B ---- 01:F81B:  .byte $4B   ; 003057 00305E
0x00382C ---- 01:F81C:  .byte $DD   ; 003057 00305E
0x00382D ---- 01:F81D:  .byte $DB   ; 003057 00305E
0x00382E ---- 01:F81E:  .byte $9B   ; 003057 00305E
0x00382F ---- 01:F81F:  .byte $DD   ; 003057 00305E
0x003830 ---- 01:F820:  .byte $BD   ; 003057 00305E
0x003831 ---- 01:F821:  .byte $BD   ; 00305E
0x003832 ---- 01:F822:  .byte $94   ; 003057 00305E
0x003833 ---- 01:F823:  .byte $BD   ; 003057 00305E
0x003834 ---- 01:F824:  .byte $DD   ; 003057 00305E
0x003835 ---- 01:F825:  .byte $BD   ; 003057 00305E
0x003836 ---- 01:F826:  .byte $DB   ; 003057 00305E
0x003837 ---- 01:F827:  .byte $9B   ; 003057 00305E
0x003838 ---- 01:F828:  .byte $DD   ; 00305E
0x003839 ---- 01:F829:  .byte $4B   ; 003057 00305E
0x00383A ---- 01:F82A:  .byte $DD   ; 003057 00305E
0x00383B ---- 01:F82B:  .byte $BD   ; 003057 00305E
0x00383C ---- 01:F82C:  .byte $DD   ; 003057 00305E
0x00383D ---- 01:F82D:  .byte $BD   ; 003057 00305E
0x00383E ---- 01:F82E:  .byte $BD   ; 003057 00305E
0x00383F ---- 01:F82F:  .byte $DD   ; 00305E
0x003840 ---- 01:F830:  .byte $BD   ; 003057 00305E
0x003841 ---- 01:F831:  .byte $DB   ; 003057 00305E
0x003842 ---- 01:F832:  .byte $4B   ; 003057 00305E
0x003843 ---- 01:F833:  .byte $DB   ; 003057 00305E
0x003844 ---- 01:F834:  .byte $4B   ; 003057 00305E
0x003845 ---- 01:F835:  .byte $DD   ; 003057 00305E
0x003846 ---- 01:F836:  .byte $DD   ; 00305E
0x003847 ---- 01:F837:  .byte $DD   ; 003057 00305E
0x003848 ---- 01:F838:  .byte $DB   ; 003057 00305E
0x003849 ---- 01:F839:  .byte $4B   ; 003057 00305E
0x00384A ---- 01:F83A:  .byte $DD   ; 003057 00305E
0x00384B ---- 01:F83B:  .byte $BD   ; 003057 00305E
0x00384C ---- 01:F83C:  .byte $DB   ; 003057 00305E
0x00384D ---- 01:F83D:  .byte $DD   ; 00305E
0x00384E ---- 01:F83E:  .byte $DB   ; 003057 00305E
0x00384F ---- 01:F83F:  .byte $DD   ; 003057 00305E
0x003850 ---- 01:F840:  .byte $BD   ; 003057 00305E
0x003851 ---- 01:F841:  .byte $DD   ; 003057 00305E
0x003852 ---- 01:F842:  .byte $DD   ; 003057 00305E
0x003853 ---- 01:F843:  .byte $B9   ; 003057 00305E
0x003854 ---- 01:F844:  .byte $BD   ; 00305E
0x003855 ---- 01:F845:  .byte $B9   ; 003057 00305E
0x003856 ---- 01:F846:  .byte $BD   ; 003057 00305E
0x003857 ---- 01:F847:  .byte $DD   ; 003057 00305E
0x003858 ---- 01:F848:  .byte $DD   ; 003057 00305E
0x003859 ---- 01:F849:  .byte $DB   ; 003057 00305E
0x00385A ---- 01:F84A:  .byte $4B   ; 003057 00305E
0x00385B ---- 01:F84B:  .byte $DD   ; 00305E
0x00385C ---- 01:F84C:  .byte $DD   ; 003057 00305E
0x00385D ---- 01:F84D:  .byte $DD   ; 003057 00305E
0x00385E ---- 01:F84E:  .byte $DD   ; 003057 00305E
0x00385F ---- 01:F84F:  .byte $DD   ; 003057 00305E
0x003860 ---- 01:F850:  .byte $DD   ; 003057 00305E
0x003861 ---- 01:F851:  .byte $DD   ; 003057 00305E
0x003862 ---- 01:F852:  .byte $DD   ; 00305E
0x003863 ---- 01:F853:  .byte $DD   ; 003057 00305E
0x003864 ---- 01:F854:  .byte $DD   ; 003057 00305E
0x003865 ---- 01:F855:  .byte $D9   ; 003057 00305E
0x003866 ---- 01:F856:  .byte $9D   ; 003057 00305E
0x003867 ---- 01:F857:  .byte $DD   ; 003057 00305E
0x003868 ---- 01:F858:  .byte $DD   ; 003057 00305E
0x003869 ---- 01:F859:  .byte $DD   ; 00305E
0x00386A ---- 01:F85A:  .byte $DD   ; 003057 00305E
0x00386B ---- 01:F85B:  .byte $DD   ; 003057 00305E
0x00386C ---- 01:F85C:  .byte $DD   ; 003057 00305E
0x00386D ---- 01:F85D:  .byte $9D   ; 003057 00305E
0x00386E ---- 01:F85E:  .byte $DD   ; 003057 00305E
0x00386F ---- 01:F85F:  .byte $DD   ; 003057 00305E
0x003870 ---- 01:F860:  .byte $DD   ; 00305E
0x003871 ---- 01:F861:  .byte $D9   ; 003057 00305E
0x003872 ---- 01:F862:  .byte $9B   ; 003057 00305E
0x003873 ---- 01:F863:  .byte $B4   ; 003057 00305E
0x003874 ---- 01:F864:  .byte $94   ; 003057 00305E
0x003875 ---- 01:F865:  .byte $BB   ; 003057 00305E
0x003876 ---- 01:F866:  .byte $99   ; 003057 00305E
0x003877 ---- 01:F867:  .byte $DD   ; 00305E
0x003878 ---- 01:F868:  .byte $DD   ; 003057 00305E
0x003879 ---- 01:F869:  .byte $D9   ; 003057 00305E
0x00387A ---- 01:F86A:  .byte $BB   ; 003057 00305E
0x00387B ---- 01:F86B:  .byte $9B   ; 003057 00305E
0x00387C ---- 01:F86C:  .byte $B9   ; 003057 00305E
0x00387D ---- 01:F86D:  .byte $DD   ; 003057 00305E
0x00387E ---- 01:F86E:  .byte $DD   ; 00305E
0x00387F ---- 01:F86F:  .byte $BD   ; 003057 00305E
0x003880 ---- 01:F870:  .byte $DD   ; 003057 00305E
0x003881 ---- 01:F871:  .byte $9B   ; 003057 00305E
0x003882 ---- 01:F872:  .byte $BB   ; 003057 00305E
0x003883 ---- 01:F873:  .byte $9D   ; 003057 00305E
0x003884 ---- 01:F874:  .byte $DD   ; 003057 00305E
0x003885 ---- 01:F875:  .byte $BD   ; 00305E
0x003886 ---- 01:F876:  .byte $9B   ; 003057 00305E
0x003887 ---- 01:F877:  .byte $DD   ; 003057 00305E
0x003888 ---- 01:F878:  .byte $DB   ; 003057 00305E
0x003889 ---- 01:F879:  .byte $BB   ; 003057 00305E
0x00388A ---- 01:F87A:  .byte $DD   ; 003057 00305E
0x00388B ---- 01:F87B:  .byte $DB   ; 003057 00305E
0x00388C ---- 01:F87C:  .byte $9D   ; 00305E
0x00388D ---- 01:F87D:  .byte $BD   ; 003057 00305E
0x00388E ---- 01:F87E:  .byte $DD   ; 003057 00305E
0x00388F ---- 01:F87F:  .byte $68   ; 003057 00305E
0x003890 ---- 01:F880:  .byte $B8   ; 003057 00305E
0x003891 ---- 01:F881:  .byte $6D   ; 003057 00305E
0x003892 ---- 01:F882:  .byte $DD   ; 003057 00305E
0x003893 ---- 01:F883:  .byte $BD   ; 00305E
0x003894 ---- 01:F884:  .byte $DD   ; 003057 00305E
0x003895 ---- 01:F885:  .byte $DD   ; 003057 00305E
0x003896 ---- 01:F886:  .byte $9D   ; 003057 00305E
0x003897 ---- 01:F887:  .byte $6D   ; 003057 00305E
0x003898 ---- 01:F888:  .byte $9D   ; 003057 00305E
0x003899 ---- 01:F889:  .byte $DD   ; 003057 00305E
0x00389A ---- 01:F88A:  .byte $DD   ; 00305E
0x00389B ---- 01:F88B:  .byte $DD   ; 003057 00305E
0x00389C ---- 01:F88C:  .byte $D9   ; 003057 00305E
0x00389D ---- 01:F88D:  .byte $DD   ; 003057 00305E
0x00389E ---- 01:F88E:  .byte $9D   ; 003057 00305E
0x00389F ---- 01:F88F:  .byte $D9   ; 003057 00305E
0x0038A0 ---- 01:F890:  .byte $DD   ; 003057 00305E
0x0038A1 ---- 01:F891:  .byte $DD   ; 00305E
0x0038A2 ---- 01:F892:  .byte $DD   ; 003057 00305E
0x0038A3 ---- 01:F893:  .byte $DD   ; 003057 00305E
0x0038A4 ---- 01:F894:  .byte $DD   ; 003057 00305E
0x0038A5 ---- 01:F895:  .byte $DD   ; 003057 00305E
0x0038A6 ---- 01:F896:  .byte $DD   ; 003057 00305E
0x0038A7 ---- 01:F897:  .byte $DD   ; 003057 00305E
0x0038A8 ---- 01:F898:  .byte $DD   ; 00305E
0x0038A9 ---- 01:F899:  .byte $DD   ; 003057 00305E
0x0038AA ---- 01:F89A:  .byte $DD   ; 003057 00305E
0x0038AB ---- 01:F89B:  .byte $DD   ; 003057 00305E
0x0038AC ---- 01:F89C:  .byte $DD   ; 003057 00305E
0x0038AD ---- 01:F89D:  .byte $DD   ; 003057 00305E
0x0038AE ---- 01:F89E:  .byte $DD   ; 003057 00305E
0x0038AF ---- 01:F89F:  .byte $DD   ; 00305E
0x0038B0 ---- 01:F8A0:  .byte $DD   ; 003057 00305E
0x0038B1 ---- 01:F8A1:  .byte $9D   ; 003057 00305E
0x0038B2 ---- 01:F8A2:  .byte $DD   ; 003057 00305E
0x0038B3 ---- 01:F8A3:  .byte $DD   ; 003057 00305E
0x0038B4 ---- 01:F8A4:  .byte $DD   ; 003057 00305E
0x0038B5 ---- 01:F8A5:  .byte $9D   ; 003057 00305E
0x0038B6 ---- 01:F8A6:  .byte $DD   ; 00305E
0x0038B7 ---- 01:F8A7:  .byte $DD   ; 003057 00305E
0x0038B8 ---- 01:F8A8:  .byte $9D   ; 003057 00305E
0x0038B9 ---- 01:F8A9:  .byte $48   ; 003057 00305E
0x0038BA ---- 01:F8AA:  .byte $DD   ; 003057 00305E
0x0038BB ---- 01:F8AB:  .byte $DD   ; 003057 00305E
0x0038BC ---- 01:F8AC:  .byte $0D   ; 003057 00305E
0x0038BD ---- 01:F8AD:  .byte $DD   ; 00305E
0x0038BE ---- 01:F8AE:  .byte $DD   ; 003057 00305E
0x0038BF ---- 01:F8AF:  .byte $4D   ; 003057 00305E
0x0038C0 ---- 01:F8B0:  .byte $4B   ; 003057 00305E
0x0038C1 ---- 01:F8B1:  .byte $D3   ; 003057 00305E
0x0038C2 ---- 01:F8B2:  .byte $44   ; 003057 00305E
0x0038C3 ---- 01:F8B3:  .byte $4D   ; 003057 00305E
0x0038C4 ---- 01:F8B4:  .byte $DD   ; 00305E
0x0038C5 ---- 01:F8B5:  .byte $DB   ; 003057 00305E
0x0038C6 ---- 01:F8B6:  .byte $BD   ; 003057 00305E
0x0038C7 ---- 01:F8B7:  .byte $4B   ; 003057 00305E
0x0038C8 ---- 01:F8B8:  .byte $02   ; 003057 00305E
0x0038C9 ---- 01:F8B9:  .byte $DD   ; 003057 00305E
0x0038CA ---- 01:F8BA:  .byte $D9   ; 003057 00305E
0x0038CB ---- 01:F8BB:  .byte $9D   ; 00305E
0x0038CC ---- 01:F8BC:  .byte $BB   ; 003057 00305E
0x0038CD ---- 01:F8BD:  .byte $BB   ; 003057 00305E
0x0038CE ---- 01:F8BE:  .byte $BB   ; 003057 00305E
0x0038CF ---- 01:F8BF:  .byte $44   ; 003057 00305E
0x0038D0 ---- 01:F8C0:  .byte $4D   ; 003057 00305E
0x0038D1 ---- 01:F8C1:  .byte $04   ; 003057 00305E
0x0038D2 ---- 01:F8C2:  .byte $DD   ; 00305E
0x0038D3 ---- 01:F8C3:  .byte $DD   ; 003057 00305E
0x0038D4 ---- 01:F8C4:  .byte $BB   ; 003057 00305E
0x0038D5 ---- 01:F8C5:  .byte $11   ; 003057 00305E
0x0038D6 ---- 01:F8C6:  .byte $84   ; 003057 00305E
0x0038D7 ---- 01:F8C7:  .byte $D0   ; 003057 00305E
0x0038D8 ---- 01:F8C8:  .byte $43   ; 003057 00305E
0x0038D9 ---- 01:F8C9:  .byte $0D   ; 00305E
0x0038DA ---- 01:F8CA:  .byte $48   ; 003057 00305E
0x0038DB ---- 01:F8CB:  .byte $D1   ; 003057 00305E
0x0038DC ---- 01:F8CC:  .byte $33   ; 003057 00305E
0x0038DD ---- 01:F8CD:  .byte $DD   ; 003057 00305E
0x0038DE ---- 01:F8CE:  .byte $D4   ; 003057 00305E
0x0038DF ---- 01:F8CF:  .byte $3D   ; 003057 00305E
0x0038E0 ---- 01:F8D0:  .byte $0D   ; 00305E
0x0038E1 ---- 01:F8D1:  .byte $0D   ; 003057 00305E
0x0038E2 ---- 01:F8D2:  .byte $14   ; 003057 00305E
0x0038E3 ---- 01:F8D3:  .byte $CC   ; 003057 00305E
0x0038E4 ---- 01:F8D4:  .byte $CC   ; 003057 00305E
0x0038E5 ---- 01:F8D5:  .byte $CC   ; 003057 00305E
0x0038E6 ---- 01:F8D6:  .byte $CC   ; 003057 00305E
0x0038E7 ---- 01:F8D7:  .byte $CD   ; 00305E
0x0038E8 ---- 01:F8D8:  .byte $0D   ; 003057 00305E
0x0038E9 ---- 01:F8D9:  .byte $3D   ; 003057 00305E
0x0038EA ---- 01:F8DA:  .byte $CC   ; 003057 00305E
0x0038EB ---- 01:F8DB:  .byte $CC   ; 003057 00305E
0x0038EC ---- 01:F8DC:  .byte $CC   ; 003057 00305E
0x0038ED ---- 01:F8DD:  .byte $CC   ; 003057 00305E
0x0038EE ---- 01:F8DE:  .byte $CD   ; 00305E
0x0038EF ---- 01:F8DF:  .byte $DD   ; 003057 00305E
0x0038F0 ---- 01:F8E0:  .byte $9D   ; 003057 00305E
0x0038F1 ---- 01:F8E1:  .byte $CC   ; 003057 00305E
0x0038F2 ---- 01:F8E2:  .byte $CC   ; 003057 00305E
0x0038F3 ---- 01:F8E3:  .byte $CC   ; 003057 00305E
0x0038F4 ---- 01:F8E4:  .byte $CC   ; 003057 00305E
0x0038F5 ---- 01:F8E5:  .byte $CD   ; 00305E
0x0038F6 ---- 01:F8E6:  .byte $4D   ; 003057 00305E
0x0038F7 ---- 01:F8E7:  .byte $4D   ; 003057 00305E
0x0038F8 ---- 01:F8E8:  .byte $CC   ; 003057 00305E
0x0038F9 ---- 01:F8E9:  .byte $CC   ; 003057 00305E
0x0038FA ---- 01:F8EA:  .byte $CC   ; 003057 00305E
0x0038FB ---- 01:F8EB:  .byte $CC   ; 003057 00305E
0x0038FC ---- 01:F8EC:  .byte $CD   ; 00305E
0x0038FD ---- 01:F8ED:  .byte $0D   ; 003057 00305E
0x0038FE ---- 01:F8EE:  .byte $4D   ; 003057 00305E
0x0038FF ---- 01:F8EF:  .byte $CC   ; 003057 00305E
0x003900 ---- 01:F8F0:  .byte $CC   ; 003057 00305E
0x003901 ---- 01:F8F1:  .byte $CC   ; 003057 00305E
0x003902 ---- 01:F8F2:  .byte $CC   ; 003057 00305E
0x003903 ---- 01:F8F3:  .byte $CD   ; 00305E
0x003904 ---- 01:F8F4:  .byte $0D   ; 003057 00305E
0x003905 ---- 01:F8F5:  .byte $4D   ; 003057 00305E
0x003906 ---- 01:F8F6:  .byte $DD   ; 003057 00305E
0x003907 ---- 01:F8F7:  .byte $DD   ; 003057 00305E
0x003908 ---- 01:F8F8:  .byte $CC   ; 003057 00305E
0x003909 ---- 01:F8F9:  .byte $CC   ; 003057 00305E
0x00390A ---- 01:F8FA:  .byte $CD   ; 00305E
0x00390B ---- 01:F8FB:  .byte $DD   ; 003057 00305E
0x00390C ---- 01:F8FC:  .byte $3D   ; 003057 00305E
0x00390D ---- 01:F8FD:  .byte $DD   ; 003057 00305E
0x00390E ---- 01:F8FE:  .byte $DD   ; 003057 00305E
0x00390F ---- 01:F8FF:  .byte $DC   ; 003057 00305E
0x003910 ---- 01:F900:  .byte $CC   ; 003057 00305E
0x003911 ---- 01:F901:  .byte $CD   ; 00305E
0x003912 ---- 01:F902:  .byte $DD   ; 003057 00305E
0x003913 ---- 01:F903:  .byte $D9   ; 003057 00305E
0x003914 ---- 01:F904:  .byte $D4   ; 003057 00305E
0x003915 ---- 01:F905:  .byte $D4   ; 003057 00305E
0x003916 ---- 01:F906:  .byte $D4   ; 003057 00305E
0x003917 ---- 01:F907:  .byte $D9   ; 003057 00305E
0x003918 ---- 01:F908:  .byte $DD   ; 00305E
0x003919 ---- 01:F909:  .byte $D4   ; 003057 00305E
0x00391A ---- 01:F90A:  .byte $D4   ; 003057 00305E
0x00391B ---- 01:F90B:  .byte $DD   ; 003057 00305E
0x00391C ---- 01:F90C:  .byte $DD   ; 003057 00305E
0x00391D ---- 01:F90D:  .byte $D9   ; 003057 00305E
0x00391E ---- 01:F90E:  .byte $DD   ; 003057 00305E
0x00391F ---- 01:F90F:  .byte $DD   ; 00305E
0x003920 ---- 01:F910:  .byte $D4   ; 003057 00305E
0x003921 ---- 01:F911:  .byte $D4   ; 003057 00305E
0x003922 ---- 01:F912:  .byte $DD   ; 003057 00305E
0x003923 ---- 01:F913:  .byte $9D   ; 003057 00305E
0x003924 ---- 01:F914:  .byte $D9   ; 003057 00305E
0x003925 ---- 01:F915:  .byte $D9   ; 003057 00305E
0x003926 ---- 01:F916:  .byte $9D   ; 00305E
0x003927 ---- 01:F917:  .byte $D4   ; 003057 00305E
0x003928 ---- 01:F918:  .byte $DD   ; 003057 00305E
0x003929 ---- 01:F919:  .byte $D4   ; 003057 00305E
0x00392A ---- 01:F91A:  .byte $D9   ; 003057 00305E
0x00392B ---- 01:F91B:  .byte $4D   ; 003057 00305E
0x00392C ---- 01:F91C:  .byte $DD   ; 003057 00305E
0x00392D ---- 01:F91D:  .byte $9D   ; 00305E
0x00392E ---- 01:F91E:  .byte $DD   ; 003057 00305E
0x00392F ---- 01:F91F:  .byte $DD   ; 003057 00305E
0x003930 ---- 01:F920:  .byte $44   ; 003057 00305E
0x003931 ---- 01:F921:  .byte $D4   ; 003057 00305E
0x003932 ---- 01:F922:  .byte $4D   ; 003057 00305E
0x003933 ---- 01:F923:  .byte $9D   ; 003057 00305E
0x003934 ---- 01:F924:  .byte $DD   ; 00305E
0x003935 ---- 01:F925:  .byte $DD   ; 003057 00305E
0x003936 ---- 01:F926:  .byte $9D   ; 003057 00305E
0x003937 ---- 01:F927:  .byte $4D   ; 003057 00305E
0x003938 ---- 01:F928:  .byte $D4   ; 003057 00305E
0x003939 ---- 01:F929:  .byte $4D   ; 003057 00305E
0x00393A ---- 01:F92A:  .byte $44   ; 003057 00305E
0x00393B ---- 01:F92B:  .byte $DD   ; 00305E
0x00393C ---- 01:F92C:  .byte $9D   ; 003057 00305E
0x00393D ---- 01:F92D:  .byte $9D   ; 003057 00305E
0x00393E ---- 01:F92E:  .byte $D4   ; 003057 00305E
0x00393F ---- 01:F92F:  .byte $D9   ; 003057 00305E
0x003940 ---- 01:F930:  .byte $DD   ; 003057 00305E
0x003941 ---- 01:F931:  .byte $94   ; 003057 00305E
0x003942 ---- 01:F932:  .byte $DD   ; 00305E
0x003943 ---- 01:F933:  .byte $DD   ; 003057 00305E
0x003944 ---- 01:F934:  .byte $44   ; 003057 00305E
0x003945 ---- 01:F935:  .byte $D4   ; 003057 00305E
0x003946 ---- 01:F936:  .byte $DD   ; 003057 00305E
0x003947 ---- 01:F937:  .byte $D4   ; 003057 00305E
0x003948 ---- 01:F938:  .byte $9D   ; 003057 00305E
0x003949 ---- 01:F939:  .byte $DD   ; 00305E
0x00394A ---- 01:F93A:  .byte $D9   ; 003057 00305E
0x00394B ---- 01:F93B:  .byte $44   ; 003057 00305E
0x00394C ---- 01:F93C:  .byte $D4   ; 003057 00305E
0x00394D ---- 01:F93D:  .byte $4D   ; 003057 00305E
0x00394E ---- 01:F93E:  .byte $44   ; 003057 00305E
0x00394F ---- 01:F93F:  .byte $DD   ; 003057 00305E
0x003950 ---- 01:F940:  .byte $4D   ; 00305E
0x003951 ---- 01:F941:  .byte $D4   ; 003057 00305E
0x003952 ---- 01:F942:  .byte $DD   ; 003057 00305E
0x003953 ---- 01:F943:  .byte $D4   ; 003057 00305E
0x003954 ---- 01:F944:  .byte $9D   ; 003057 00305E
0x003955 ---- 01:F945:  .byte $DD   ; 003057 00305E
0x003956 ---- 01:F946:  .byte $D4   ; 003057 00305E
0x003957 ---- 01:F947:  .byte $4D   ; 00305E
0x003958 ---- 01:F948:  .byte $DD   ; 003057 00305E
0x003959 ---- 01:F949:  .byte $D4   ; 003057 00305E
0x00395A ---- 01:F94A:  .byte $D4   ; 003057 00305E
0x00395B ---- 01:F94B:  .byte $49   ; 003057 00305E
0x00395C ---- 01:F94C:  .byte $D9   ; 003057 00305E
0x00395D ---- 01:F94D:  .byte $DD   ; 003057 00305E
0x00395E ---- 01:F94E:  .byte $4D   ; 00305E
0x00395F ---- 01:F94F:  .byte $4D   ; 003057 00305E
0x003960 ---- 01:F950:  .byte $44   ; 003057 00305E
0x003961 ---- 01:F951:  .byte $DD   ; 003057 00305E
0x003962 ---- 01:F952:  .byte $DD   ; 003057 00305E
0x003963 ---- 01:F953:  .byte $D4   ; 003057 00305E
0x003964 ---- 01:F954:  .byte $9D   ; 003057 00305E
0x003965 ---- 01:F955:  .byte $DD   ; 00305E
0x003966 ---- 01:F956:  .byte $4D   ; 003057 00305E
0x003967 ---- 01:F957:  .byte $4D   ; 003057 00305E
0x003968 ---- 01:F958:  .byte $DD   ; 003057 00305E
0x003969 ---- 01:F959:  .byte $DD   ; 003057 00305E
0x00396A ---- 01:F95A:  .byte $D4   ; 003057 00305E
0x00396B ---- 01:F95B:  .byte $44   ; 003057 00305E
0x00396C ---- 01:F95C:  .byte $DD   ; 00305E
0x00396D ---- 01:F95D:  .byte $DD   ; 003057 00305E
0x00396E ---- 01:F95E:  .byte $AA   ; 003057 00305E
0x00396F ---- 01:F95F:  .byte $DD   ; 003057 00305E
0x003970 ---- 01:F960:  .byte $DD   ; 003057 00305E
0x003971 ---- 01:F961:  .byte $DD   ; 003057 00305E
0x003972 ---- 01:F962:  .byte $DD   ; 003057 00305E
0x003973 ---- 01:F963:  .byte $DD   ; 00305E
0x003974 ---- 01:F964:  .byte $6D   ; 003057 00305E
0x003975 ---- 01:F965:  .byte $DA   ; 003057 00305E
0x003976 ---- 01:F966:  .byte $BD   ; 003057 00305E
0x003977 ---- 01:F967:  .byte $2D   ; 003057 00305E
0x003978 ---- 01:F968:  .byte $DD   ; 003057 00305E
0x003979 ---- 01:F969:  .byte $DD   ; 003057 00305E
0x00397A ---- 01:F96A:  .byte $DD   ; 00305E
0x00397B ---- 01:F96B:  .byte $B6   ; 003057 00305E
0x00397C ---- 01:F96C:  .byte $DD   ; 003057 00305E
0x00397D ---- 01:F96D:  .byte $DD   ; 003057 00305E
0x00397E ---- 01:F96E:  .byte $7D   ; 003057 00305E
0x00397F ---- 01:F96F:  .byte $2D   ; 003057 00305E
0x003980 ---- 01:F970:  .byte $AA   ; 003057 00305E
0x003981 ---- 01:F971:  .byte $DD   ; 00305E
0x003982 ---- 01:F972:  .byte $BB   ; 003057 00305E
0x003983 ---- 01:F973:  .byte $D8   ; 003057 00305E
0x003984 ---- 01:F974:  .byte $10   ; 003057 00305E
0x003985 ---- 01:F975:  .byte $DD   ; 003057 00305E
0x003986 ---- 01:F976:  .byte $7B   ; 003057 00305E
0x003987 ---- 01:F977:  .byte $AD   ; 003057 00305E
0x003988 ---- 01:F978:  .byte $DD   ; 00305E
0x003989 ---- 01:F979:  .byte $BB   ; 003057 00305E
0x00398A ---- 01:F97A:  .byte $BD   ; 003057 00305E
0x00398B ---- 01:F97B:  .byte $D9   ; 003057 00305E
0x00398C ---- 01:F97C:  .byte $10   ; 003057 00305E
0x00398D ---- 01:F97D:  .byte $DD   ; 003057 00305E
0x00398E ---- 01:F97E:  .byte $DD   ; 003057 00305E
0x00398F ---- 01:F97F:  .byte $6D   ; 00305E
0x003990 ---- 01:F980:  .byte $BB   ; 003057 00305E
0x003991 ---- 01:F981:  .byte $86   ; 003057 00305E
0x003992 ---- 01:F982:  .byte $D0   ; 003057 00305E
0x003993 ---- 01:F983:  .byte $D9   ; 003057 00305E
0x003994 ---- 01:F984:  .byte $1D   ; 003057 00305E
0x003995 ---- 01:F985:  .byte $D6   ; 003057 00305E
0x003996 ---- 01:F986:  .byte $BD   ; 00305E
0x003997 ---- 01:F987:  .byte $B8   ; 003057 00305E
0x003998 ---- 01:F988:  .byte $DD   ; 003057 00305E
0x003999 ---- 01:F989:  .byte $39   ; 003057 00305E
0x00399A ---- 01:F98A:  .byte $D0   ; 003057 00305E
0x00399B ---- 01:F98B:  .byte $D8   ; 003057 00305E
0x00399C ---- 01:F98C:  .byte $DB   ; 003057 00305E
0x00399D ---- 01:F98D:  .byte $BD   ; 00305E
0x00399E ---- 01:F98E:  .byte $DD   ; 003057 00305E
0x00399F ---- 01:F98F:  .byte $DD   ; 003057 00305E
0x0039A0 ---- 01:F990:  .byte $D2   ; 003057 00305E
0x0039A1 ---- 01:F991:  .byte $39   ; 003057 00305E
0x0039A2 ---- 01:F992:  .byte $DD   ; 003057 00305E
0x0039A3 ---- 01:F993:  .byte $BB   ; 003057 00305E
0x0039A4 ---- 01:F994:  .byte $BD   ; 00305E
0x0039A5 ---- 01:F995:  .byte $DD   ; 003057 00305E
0x0039A6 ---- 01:F996:  .byte $AB   ; 003057 00305E
0x0039A7 ---- 01:F997:  .byte $5D   ; 003057 00305E
0x0039A8 ---- 01:F998:  .byte $D2   ; 003057 00305E
0x0039A9 ---- 01:F999:  .byte $36   ; 003057 00305E
0x0039AA ---- 01:F99A:  .byte $8B   ; 003057 00305E
0x0039AB ---- 01:F99B:  .byte $BD   ; 00305E
0x0039AC ---- 01:F99C:  .byte $DA   ; 003057 00305E
0x0039AD ---- 01:F99D:  .byte $AD   ; 003057 00305E
0x0039AE ---- 01:F99E:  .byte $0D   ; 003057 00305E
0x0039AF ---- 01:F99F:  .byte $5D   ; 003057 00305E
0x0039B0 ---- 01:F9A0:  .byte $DD   ; 003057 00305E
0x0039B1 ---- 01:F9A1:  .byte $DD   ; 003057 00305E
0x0039B2 ---- 01:F9A2:  .byte $BD   ; 00305E
0x0039B3 ---- 01:F9A3:  .byte $DD   ; 003057 00305E
0x0039B4 ---- 01:F9A4:  .byte $DD   ; 003057 00305E
0x0039B5 ---- 01:F9A5:  .byte $DD   ; 003057 00305E
0x0039B6 ---- 01:F9A6:  .byte $0D   ; 003057 00305E
0x0039B7 ---- 01:F9A7:  .byte $BA   ; 003057 00305E
0x0039B8 ---- 01:F9A8:  .byte $DD   ; 003057 00305E
0x0039B9 ---- 01:F9A9:  .byte $8D   ; 00305E
0x0039BA ---- 01:F9AA:  .byte $9D   ; 003057 00305E
0x0039BB ---- 01:F9AB:  .byte $DD   ; 003057 00305E
0x0039BC ---- 01:F9AC:  .byte $DD   ; 003057 00305E
0x0039BD ---- 01:F9AD:  .byte $DD   ; 003057 00305E
0x0039BE ---- 01:F9AE:  .byte $DA   ; 003057 00305E
0x0039BF ---- 01:F9AF:  .byte $AD   ; 003057 00305E
0x0039C0 ---- 01:F9B0:  .byte $DD   ; 00305E
0x0039C1 ---- 01:F9B1:  .byte $99   ; 003057 00305E
0x0039C2 ---- 01:F9B2:  .byte $DD   ; 003057 00305E
0x0039C3 ---- 01:F9B3:  .byte $DD   ; 003057 00305E
0x0039C4 ---- 01:F9B4:  .byte $DD   ; 003057 00305E
0x0039C5 ---- 01:F9B5:  .byte $DD   ; 003057 00305E
0x0039C6 ---- 01:F9B6:  .byte $DD   ; 003057 00305E
0x0039C7 ---- 01:F9B7:  .byte $9D   ; 00305E
0x0039C8 ---- 01:F9B8:  .byte $DD   ; 003057 00305E
0x0039C9 ---- 01:F9B9:  .byte $DD   ; 003057 00305E
0x0039CA ---- 01:F9BA:  .byte $9D   ; 003057 00305E
0x0039CB ---- 01:F9BB:  .byte $DD   ; 003057 00305E
0x0039CC ---- 01:F9BC:  .byte $DD   ; 003057 00305E
0x0039CD ---- 01:F9BD:  .byte $DD   ; 003057 00305E
0x0039CE ---- 01:F9BE:  .byte $DD   ; 00305E
0x0039CF ---- 01:F9BF:  .byte $99   ; 003057 00305E
0x0039D0 ---- 01:F9C0:  .byte $DD   ; 003057 00305E
0x0039D1 ---- 01:F9C1:  .byte $9D   ; 003057 00305E
0x0039D2 ---- 01:F9C2:  .byte $D9   ; 003057 00305E
0x0039D3 ---- 01:F9C3:  .byte $9D   ; 003057 00305E
0x0039D4 ---- 01:F9C4:  .byte $DD   ; 003057 00305E
0x0039D5 ---- 01:F9C5:  .byte $DD   ; 00305E
0x0039D6 ---- 01:F9C6:  .byte $D9   ; 003057 00305E
0x0039D7 ---- 01:F9C7:  .byte $DD   ; 003057 00305E
0x0039D8 ---- 01:F9C8:  .byte $9D   ; 003057 00305E
0x0039D9 ---- 01:F9C9:  .byte $DD   ; 003057 00305E
0x0039DA ---- 01:F9CA:  .byte $9D   ; 003057 00305E
0x0039DB ---- 01:F9CB:  .byte $99   ; 003057 00305E
0x0039DC ---- 01:F9CC:  .byte $BD   ; 00305E
0x0039DD ---- 01:F9CD:  .byte $D9   ; 003057 00305E
0x0039DE ---- 01:F9CE:  .byte $DD   ; 003057 00305E
0x0039DF ---- 01:F9CF:  .byte $99   ; 003057 00305E
0x0039E0 ---- 01:F9D0:  .byte $9D   ; 003057 00305E
0x0039E1 ---- 01:F9D1:  .byte $BD   ; 003057 00305E
0x0039E2 ---- 01:F9D2:  .byte $9D   ; 003057 00305E
0x0039E3 ---- 01:F9D3:  .byte $DD   ; 00305E
0x0039E4 ---- 01:F9D4:  .byte $D4   ; 003057 00305E
0x0039E5 ---- 01:F9D5:  .byte $DD   ; 003057 00305E
0x0039E6 ---- 01:F9D6:  .byte $DD   ; 003057 00305E
0x0039E7 ---- 01:F9D7:  .byte $9D   ; 003057 00305E
0x0039E8 ---- 01:F9D8:  .byte $99   ; 003057 00305E
0x0039E9 ---- 01:F9D9:  .byte $9D   ; 003057 00305E
0x0039EA ---- 01:F9DA:  .byte $DD   ; 00305E
0x0039EB ---- 01:F9DB:  .byte $B9   ; 003057 00305E
0x0039EC ---- 01:F9DC:  .byte $9D   ; 003057 00305E
0x0039ED ---- 01:F9DD:  .byte $94   ; 003057 00305E
0x0039EE ---- 01:F9DE:  .byte $94   ; 003057 00305E
0x0039EF ---- 01:F9DF:  .byte $4D   ; 003057 00305E
0x0039F0 ---- 01:F9E0:  .byte $DD   ; 003057 00305E
0x0039F1 ---- 01:F9E1:  .byte $DD   ; 00305E
0x0039F2 ---- 01:F9E2:  .byte $DD   ; 003057 00305E
0x0039F3 ---- 01:F9E3:  .byte $9B   ; 003057 00305E
0x0039F4 ---- 01:F9E4:  .byte $9B   ; 003057 00305E
0x0039F5 ---- 01:F9E5:  .byte $DD   ; 003057 00305E
0x0039F6 ---- 01:F9E6:  .byte $4D   ; 003057 00305E
0x0039F7 ---- 01:F9E7:  .byte $D9   ; 003057 00305E
0x0039F8 ---- 01:F9E8:  .byte $9D   ; 00305E
0x0039F9 ---- 01:F9E9:  .byte $DD   ; 003057 00305E
0x0039FA ---- 01:F9EA:  .byte $9D   ; 003057 00305E
0x0039FB ---- 01:F9EB:  .byte $DB   ; 003057 00305E
0x0039FC ---- 01:F9EC:  .byte $DD   ; 003057 00305E
0x0039FD ---- 01:F9ED:  .byte $9D   ; 003057 00305E
0x0039FE ---- 01:F9EE:  .byte $D9   ; 003057 00305E
0x0039FF ---- 01:F9EF:  .byte $DD   ; 00305E
0x003A00 ---- 01:F9F0:  .byte $DD   ; 003057 00305E
0x003A01 ---- 01:F9F1:  .byte $4D   ; 003057 00305E
0x003A02 ---- 01:F9F2:  .byte $D9   ; 003057 00305E
0x003A03 ---- 01:F9F3:  .byte $DD   ; 003057 00305E
0x003A04 ---- 01:F9F4:  .byte $99   ; 003057 00305E
0x003A05 ---- 01:F9F5:  .byte $49   ; 003057 00305E
0x003A06 ---- 01:F9F6:  .byte $DD   ; 00305E
0x003A07 ---- 01:F9F7:  .byte $B9   ; 003057 00305E
0x003A08 ---- 01:F9F8:  .byte $99   ; 003057 00305E
0x003A09 ---- 01:F9F9:  .byte $BB   ; 003057 00305E
0x003A0A ---- 01:F9FA:  .byte $49   ; 003057 00305E
0x003A0B ---- 01:F9FB:  .byte $9D   ; 003057 00305E
0x003A0C ---- 01:F9FC:  .byte $49   ; 003057 00305E
0x003A0D ---- 01:F9FD:  .byte $DD   ; 00305E
0x003A0E ---- 01:F9FE:  .byte $DD   ; 003057 00305E
0x003A0F ---- 01:F9FF:  .byte $D4   ; 003057 00305E
0x003A10 ---- 01:FA00:  .byte $DD   ; 003057 00305E
0x003A11 ---- 01:FA01:  .byte $DD   ; 003057 00305E
0x003A12 ---- 01:FA02:  .byte $BB   ; 003057 00305E
0x003A13 ---- 01:FA03:  .byte $D4   ; 003057 00305E
0x003A14 ---- 01:FA04:  .byte $DD   ; 00305E
0x003A15 ---- 01:FA05:  .byte $DD   ; 003057 00305E
0x003A16 ---- 01:FA06:  .byte $D9   ; 003057 00305E
0x003A17 ---- 01:FA07:  .byte $DD   ; 003057 00305E
0x003A18 ---- 01:FA08:  .byte $DD   ; 003057 00305E
0x003A19 ---- 01:FA09:  .byte $DB   ; 003057 00305E
0x003A1A ---- 01:FA0A:  .byte $D4   ; 003057 00305E
0x003A1B ---- 01:FA0B:  .byte $DD   ; 00305E
0x003A1C ---- 01:FA0C:  .byte $DD   ; 003057 00305E
0x003A1D ---- 01:FA0D:  .byte $D9   ; 003057 00305E
0x003A1E ---- 01:FA0E:  .byte $DD   ; 003057 00305E
0x003A1F ---- 01:FA0F:  .byte $DD   ; 003057 00305E
0x003A20 ---- 01:FA10:  .byte $D9   ; 003057 00305E
0x003A21 ---- 01:FA11:  .byte $D4   ; 003057 00305E
0x003A22 ---- 01:FA12:  .byte $DD   ; 00305E
0x003A23 ---- 01:FA13:  .byte $DD   ; 003057 00305E
0x003A24 ---- 01:FA14:  .byte $DD   ; 003057 00305E
0x003A25 ---- 01:FA15:  .byte $DD   ; 003057 00305E
0x003A26 ---- 01:FA16:  .byte $DD   ; 003057 00305E
0x003A27 ---- 01:FA17:  .byte $DD   ; 003057 00305E
0x003A28 ---- 01:FA18:  .byte $57   ; 003057 00305E
0x003A29 ---- 01:FA19:  .byte $DD   ; 00305E
0x003A2A ---- 01:FA1A:  .byte $DD   ; 003057 00305E
0x003A2B ---- 01:FA1B:  .byte $DD   ; 003057 00305E
0x003A2C ---- 01:FA1C:  .byte $DD   ; 003057 00305E
0x003A2D ---- 01:FA1D:  .byte $6D   ; 003057 00305E
0x003A2E ---- 01:FA1E:  .byte $DD   ; 003057 00305E
0x003A2F ---- 01:FA1F:  .byte $9D   ; 003057 00305E
0x003A30 ---- 01:FA20:  .byte $DD   ; 00305E
0x003A31 ---- 01:FA21:  .byte $DD   ; 003057 00305E
0x003A32 ---- 01:FA22:  .byte $DD   ; 003057 00305E
0x003A33 ---- 01:FA23:  .byte $D1   ; 003057 00305E
0x003A34 ---- 01:FA24:  .byte $B1   ; 003057 00305E
0x003A35 ---- 01:FA25:  .byte $D4   ; 003057 00305E
0x003A36 ---- 01:FA26:  .byte $2D   ; 003057 00305E
0x003A37 ---- 01:FA27:  .byte $DD   ; 00305E
0x003A38 ---- 01:FA28:  .byte $DD   ; 003057 00305E
0x003A39 ---- 01:FA29:  .byte $DD   ; 003057 00305E
0x003A3A ---- 01:FA2A:  .byte $6B   ; 003057 00305E
0x003A3B ---- 01:FA2B:  .byte $BB   ; 003057 00305E
0x003A3C ---- 01:FA2C:  .byte $64   ; 003057 00305E
0x003A3D ---- 01:FA2D:  .byte $2D   ; 003057 00305E
0x003A3E ---- 01:FA2E:  .byte $DD   ; 00305E
0x003A3F ---- 01:FA2F:  .byte $DD   ; 003057 00305E
0x003A40 ---- 01:FA30:  .byte $D1   ; 003057 00305E
0x003A41 ---- 01:FA31:  .byte $BB   ; 003057 00305E
0x003A42 ---- 01:FA32:  .byte $CB   ; 003057 00305E
0x003A43 ---- 01:FA33:  .byte $B4   ; 003057 00305E
0x003A44 ---- 01:FA34:  .byte $2D   ; 003057 00305E
0x003A45 ---- 01:FA35:  .byte $DD   ; 00305E
0x003A46 ---- 01:FA36:  .byte $DD   ; 003057 00305E
0x003A47 ---- 01:FA37:  .byte $6B   ; 003057 00305E
0x003A48 ---- 01:FA38:  .byte $BC   ; 003057 00305E
0x003A49 ---- 01:FA39:  .byte $CC   ; 003057 00305E
0x003A4A ---- 01:FA3A:  .byte $BB   ; 003057 00305E
0x003A4B ---- 01:FA3B:  .byte $2D   ; 003057 00305E
0x003A4C ---- 01:FA3C:  .byte $DD   ; 00305E
0x003A4D ---- 01:FA3D:  .byte $D1   ; 003057 00305E
0x003A4E ---- 01:FA3E:  .byte $BB   ; 003057 00305E
0x003A4F ---- 01:FA3F:  .byte $CC   ; 003057 00305E
0x003A50 ---- 01:FA40:  .byte $CC   ; 003057 00305E
0x003A51 ---- 01:FA41:  .byte $CB   ; 003057 00305E
0x003A52 ---- 01:FA42:  .byte $B1   ; 003057 00305E
0x003A53 ---- 01:FA43:  .byte $DD   ; 00305E
0x003A54 ---- 01:FA44:  .byte $6B   ; 003057 00305E
0x003A55 ---- 01:FA45:  .byte $BC   ; 003057 00305E
0x003A56 ---- 01:FA46:  .byte $CC   ; 003057 00305E
0x003A57 ---- 01:FA47:  .byte $CC   ; 003057 00305E
0x003A58 ---- 01:FA48:  .byte $CC   ; 003057 00305E
0x003A59 ---- 01:FA49:  .byte $BB   ; 003057 00305E
0x003A5A ---- 01:FA4A:  .byte $6D   ; 00305E
0x003A5B ---- 01:FA4B:  .byte $BB   ; 003057 00305E
0x003A5C ---- 01:FA4C:  .byte $CC   ; 003057 00305E
0x003A5D ---- 01:FA4D:  .byte $CC   ; 003057 00305E
0x003A5E ---- 01:FA4E:  .byte $CC   ; 003057 00305E
0x003A5F ---- 01:FA4F:  .byte $CC   ; 003057 00305E
0x003A60 ---- 01:FA50:  .byte $CB   ; 003057 00305E
0x003A61 ---- 01:FA51:  .byte $BD   ; 00305E
0x003A62 ---- 01:FA52:  .byte $DB   ; 003057 00305E
0x003A63 ---- 01:FA53:  .byte $CC   ; 003057 00305E
0x003A64 ---- 01:FA54:  .byte $CC   ; 003057 00305E
0x003A65 ---- 01:FA55:  .byte $CC   ; 003057 00305E
0x003A66 ---- 01:FA56:  .byte $CC   ; 003057 00305E
0x003A67 ---- 01:FA57:  .byte $CB   ; 003057 00305E
0x003A68 ---- 01:FA58:  .byte $DD   ; 00305E
0x003A69 ---- 01:FA59:  .byte $DB   ; 003057 00305E
0x003A6A ---- 01:FA5A:  .byte $CC   ; 003057 00305E
0x003A6B ---- 01:FA5B:  .byte $CC   ; 003057 00305E
0x003A6C ---- 01:FA5C:  .byte $CC   ; 003057 00305E
0x003A6D ---- 01:FA5D:  .byte $CC   ; 003057 00305E
0x003A6E ---- 01:FA5E:  .byte $CB   ; 003057 00305E
0x003A6F ---- 01:FA5F:  .byte $DD   ; 00305E
0x003A70 ---- 01:FA60:  .byte $DB   ; 003057 00305E
0x003A71 ---- 01:FA61:  .byte $CC   ; 003057 00305E
0x003A72 ---- 01:FA62:  .byte $CD   ; 003057 00305E
0x003A73 ---- 01:FA63:  .byte $DD   ; 003057 00305E
0x003A74 ---- 01:FA64:  .byte $CC   ; 003057 00305E
0x003A75 ---- 01:FA65:  .byte $CB   ; 003057 00305E
0x003A76 ---- 01:FA66:  .byte $DD   ; 00305E
0x003A77 ---- 01:FA67:  .byte $DB   ; 003057 00305E
0x003A78 ---- 01:FA68:  .byte $CC   ; 003057 00305E
0x003A79 ---- 01:FA69:  .byte $DD   ; 003057 00305E
0x003A7A ---- 01:FA6A:  .byte $DD   ; 003057 00305E
0x003A7B ---- 01:FA6B:  .byte $DC   ; 003057 00305E
0x003A7C ---- 01:FA6C:  .byte $CB   ; 003057 00305E
0x003A7D ---- 01:FA6D:  .byte $DD   ; 00305E
0x003A7E ---- 01:FA6E:  .byte $DD   ; 003057 00305E
0x003A7F ---- 01:FA6F:  .byte $DD   ; 003057 00305E
0x003A80 ---- 01:FA70:  .byte $DD   ; 003057 00305E
0x003A81 ---- 01:FA71:  .byte $DD   ; 003057 00305E
0x003A82 ---- 01:FA72:  .byte $DD   ; 003057 00305E
0x003A83 ---- 01:FA73:  .byte $4D   ; 003057 00305E
0x003A84 ---- 01:FA74:  .byte $DD   ; 00305E
0x003A85 ---- 01:FA75:  .byte $D4   ; 003057 00305E
0x003A86 ---- 01:FA76:  .byte $AA   ; 003057 00305E
0x003A87 ---- 01:FA77:  .byte $D9   ; 003057 00305E
0x003A88 ---- 01:FA78:  .byte $D4   ; 003057 00305E
0x003A89 ---- 01:FA79:  .byte $DD   ; 003057 00305E
0x003A8A ---- 01:FA7A:  .byte $DD   ; 003057 00305E
0x003A8B ---- 01:FA7B:  .byte $DD   ; 00305E
0x003A8C ---- 01:FA7C:  .byte $DD   ; 003057 00305E
0x003A8D ---- 01:FA7D:  .byte $AA   ; 003057 00305E
0x003A8E ---- 01:FA7E:  .byte $4B   ; 003057 00305E
0x003A8F ---- 01:FA7F:  .byte $BB   ; 003057 00305E
0x003A90 ---- 01:FA80:  .byte $AA   ; 003057 00305E
0x003A91 ---- 01:FA81:  .byte $D9   ; 003057 00305E
0x003A92 ---- 01:FA82:  .byte $DD   ; 00305E
0x003A93 ---- 01:FA83:  .byte $DD   ; 003057 00305E
0x003A94 ---- 01:FA84:  .byte $DD   ; 003057 00305E
0x003A95 ---- 01:FA85:  .byte $DB   ; 003057 00305E
0x003A96 ---- 01:FA86:  .byte $BB   ; 003057 00305E
0x003A97 ---- 01:FA87:  .byte $AA   ; 003057 00305E
0x003A98 ---- 01:FA88:  .byte $4D   ; 003057 00305E
0x003A99 ---- 01:FA89:  .byte $DD   ; 00305E
0x003A9A ---- 01:FA8A:  .byte $D9   ; 003057 00305E
0x003A9B ---- 01:FA8B:  .byte $DD   ; 003057 00305E
0x003A9C ---- 01:FA8C:  .byte $AA   ; 003057 00305E
0x003A9D ---- 01:FA8D:  .byte $DB   ; 003057 00305E
0x003A9E ---- 01:FA8E:  .byte $DD   ; 003057 00305E
0x003A9F ---- 01:FA8F:  .byte $DD   ; 003057 00305E
0x003AA0 ---- 01:FA90:  .byte $DD   ; 00305E
0x003AA1 ---- 01:FA91:  .byte $BB   ; 003057 00305E
0x003AA2 ---- 01:FA92:  .byte $4D   ; 003057 00305E
0x003AA3 ---- 01:FA93:  .byte $AA   ; 003057 00305E
0x003AA4 ---- 01:FA94:  .byte $9D   ; 003057 00305E
0x003AA5 ---- 01:FA95:  .byte $DD   ; 003057 00305E
0x003AA6 ---- 01:FA96:  .byte $D4   ; 003057 00305E
0x003AA7 ---- 01:FA97:  .byte $DD   ; 00305E
0x003AA8 ---- 01:FA98:  .byte $BB   ; 003057 00305E
0x003AA9 ---- 01:FA99:  .byte $BD   ; 003057 00305E
0x003AAA ---- 01:FA9A:  .byte $DD   ; 003057 00305E
0x003AAB ---- 01:FA9B:  .byte $DD   ; 003057 00305E
0x003AAC ---- 01:FA9C:  .byte $D9   ; 003057 00305E
0x003AAD ---- 01:FA9D:  .byte $DD   ; 003057 00305E
0x003AAE ---- 01:FA9E:  .byte $9D   ; 00305E
0x003AAF ---- 01:FA9F:  .byte $D4   ; 003057 00305E
0x003AB0 ---- 01:FAA0:  .byte $AA   ; 003057 00305E
0x003AB1 ---- 01:FAA1:  .byte $D4   ; 003057 00305E
0x003AB2 ---- 01:FAA2:  .byte $DD   ; 003057 00305E
0x003AB3 ---- 01:FAA3:  .byte $DD   ; 003057 00305E
0x003AB4 ---- 01:FAA4:  .byte $DD   ; 003057 00305E
0x003AB5 ---- 01:FAA5:  .byte $DD   ; 00305E
0x003AB6 ---- 01:FAA6:  .byte $9D   ; 003057 00305E
0x003AB7 ---- 01:FAA7:  .byte $AA   ; 003057 00305E
0x003AB8 ---- 01:FAA8:  .byte $BB   ; 003057 00305E
0x003AB9 ---- 01:FAA9:  .byte $AA   ; 003057 00305E
0x003ABA ---- 01:FAAA:  .byte $BB   ; 003057 00305E
0x003ABB ---- 01:FAAB:  .byte $D4   ; 003057 00305E
0x003ABC ---- 01:FAAC:  .byte $DD   ; 00305E
0x003ABD ---- 01:FAAD:  .byte $DD   ; 003057 00305E
0x003ABE ---- 01:FAAE:  .byte $DD   ; 003057 00305E
0x003ABF ---- 01:FAAF:  .byte $BD   ; 003057 00305E
0x003AC0 ---- 01:FAB0:  .byte $AA   ; 003057 00305E
0x003AC1 ---- 01:FAB1:  .byte $BB   ; 003057 00305E
0x003AC2 ---- 01:FAB2:  .byte $AA   ; 003057 00305E
0x003AC3 ---- 01:FAB3:  .byte $DD   ; 00305E
0x003AC4 ---- 01:FAB4:  .byte $DD   ; 003057 00305E
0x003AC5 ---- 01:FAB5:  .byte $D9   ; 003057 00305E
0x003AC6 ---- 01:FAB6:  .byte $BD   ; 003057 00305E
0x003AC7 ---- 01:FAB7:  .byte $DD   ; 003057 00305E
0x003AC8 ---- 01:FAB8:  .byte $BB   ; 003057 00305E
0x003AC9 ---- 01:FAB9:  .byte $AA   ; 003057 00305E
0x003ACA ---- 01:FABA:  .byte $DD   ; 00305E
0x003ACB ---- 01:FABB:  .byte $DD   ; 003057 00305E
0x003ACC ---- 01:FABC:  .byte $4D   ; 003057 00305E
0x003ACD ---- 01:FABD:  .byte $4D   ; 003057 00305E
0x003ACE ---- 01:FABE:  .byte $DD   ; 003057 00305E
0x003ACF ---- 01:FABF:  .byte $DD   ; 003057 00305E
0x003AD0 ---- 01:FAC0:  .byte $DD   ; 003057 00305E
0x003AD1 ---- 01:FAC1:  .byte $DD   ; 00305E
0x003AD2 ---- 01:FAC2:  .byte $4D   ; 003057 00305E
0x003AD3 ---- 01:FAC3:  .byte $DD   ; 003057 00305E
0x003AD4 ---- 01:FAC4:  .byte $DD   ; 003057 00305E
0x003AD5 ---- 01:FAC5:  .byte $DD   ; 003057 00305E
0x003AD6 ---- 01:FAC6:  .byte $D4   ; 003057 00305E
0x003AD7 ---- 01:FAC7:  .byte $9D   ; 003057 00305E
0x003AD8 ---- 01:FAC8:  .byte $DD   ; 00305E
0x003AD9 ---- 01:FAC9:  .byte $DD   ; 003057 00305E
0x003ADA ---- 01:FACA:  .byte $DD   ; 003057 00305E
0x003ADB ---- 01:FACB:  .byte $DD   ; 003057 00305E
0x003ADC ---- 01:FACC:  .byte $DD   ; 003057 00305E
0x003ADD ---- 01:FACD:  .byte $DD   ; 003057 00305E
0x003ADE ---- 01:FACE:  .byte $DD   ; 003057 00305E
0x003ADF ---- 01:FACF:  .byte $DD   ; 00305E
0x003AE0 ---- 01:FAD0:  .byte $DD   ; 003057 00305E
0x003AE1 ---- 01:FAD1:  .byte $DD   ; 003057 00305E
0x003AE2 ---- 01:FAD2:  .byte $D1   ; 003057 00305E
0x003AE3 ---- 01:FAD3:  .byte $1D   ; 003057 00305E
0x003AE4 ---- 01:FAD4:  .byte $DD   ; 003057 00305E
0x003AE5 ---- 01:FAD5:  .byte $6D   ; 003057 00305E
0x003AE6 ---- 01:FAD6:  .byte $DD   ; 00305E
0x003AE7 ---- 01:FAD7:  .byte $D6   ; 003057 00305E
0x003AE8 ---- 01:FAD8:  .byte $6D   ; 003057 00305E
0x003AE9 ---- 01:FAD9:  .byte $1B   ; 003057 00305E
0x003AEA ---- 01:FADA:  .byte $B6   ; 003057 00305E
0x003AEB ---- 01:FADB:  .byte $D1   ; 003057 00305E
0x003AEC ---- 01:FADC:  .byte $B1   ; 003057 00305E
0x003AED ---- 01:FADD:  .byte $DD   ; 00305E
0x003AEE ---- 01:FADE:  .byte $1B   ; 003057 00305E
0x003AEF ---- 01:FADF:  .byte $B1   ; 003057 00305E
0x003AF0 ---- 01:FAE0:  .byte $BB   ; 003057 00305E
0x003AF1 ---- 01:FAE1:  .byte $BB   ; 003057 00305E
0x003AF2 ---- 01:FAE2:  .byte $1B   ; 003057 00305E
0x003AF3 ---- 01:FAE3:  .byte $BB   ; 003057 00305E
0x003AF4 ---- 01:FAE4:  .byte $1D   ; 00305E
0x003AF5 ---- 01:FAE5:  .byte $BB   ; 003057 00305E
0x003AF6 ---- 01:FAE6:  .byte $BB   ; 003057 00305E
0x003AF7 ---- 01:FAE7:  .byte $BB   ; 003057 00305E
0x003AF8 ---- 01:FAE8:  .byte $BB   ; 003057 00305E
0x003AF9 ---- 01:FAE9:  .byte $BB   ; 003057 00305E
0x003AFA ---- 01:FAEA:  .byte $BB   ; 003057 00305E
0x003AFB ---- 01:FAEB:  .byte $BD   ; 00305E
0x003AFC ---- 01:FAEC:  .byte $9B   ; 003057 00305E
0x003AFD ---- 01:FAED:  .byte $AB   ; 003057 00305E
0x003AFE ---- 01:FAEE:  .byte $BB   ; 003057 00305E
0x003AFF ---- 01:FAEF:  .byte $BB   ; 003057 00305E
0x003B00 ---- 01:FAF0:  .byte $AB   ; 003057 00305E
0x003B01 ---- 01:FAF1:  .byte $BB   ; 003057 00305E
0x003B02 ---- 01:FAF2:  .byte $BD   ; 00305E
0x003B03 ---- 01:FAF3:  .byte $BB   ; 003057 00305E
0x003B04 ---- 01:FAF4:  .byte $AA   ; 003057 00305E
0x003B05 ---- 01:FAF5:  .byte $AB   ; 003057 00305E
0x003B06 ---- 01:FAF6:  .byte $BB   ; 003057 00305E
0x003B07 ---- 01:FAF7:  .byte $AA   ; 003057 00305E
0x003B08 ---- 01:FAF8:  .byte $AB   ; 003057 00305E
0x003B09 ---- 01:FAF9:  .byte $9D   ; 00305E
0x003B0A ---- 01:FAFA:  .byte $BB   ; 003057 00305E
0x003B0B ---- 01:FAFB:  .byte $BB   ; 003057 00305E
0x003B0C ---- 01:FAFC:  .byte $AB   ; 003057 00305E
0x003B0D ---- 01:FAFD:  .byte $9B   ; 003057 00305E
0x003B0E ---- 01:FAFE:  .byte $BB   ; 003057 00305E
0x003B0F ---- 01:FAFF:  .byte $AB   ; 003057 00305E
0x003B10 ---- 01:FB00:  .byte $BD   ; 00305E
0x003B11 ---- 01:FB01:  .byte $BB   ; 003057 00305E
0x003B12 ---- 01:FB02:  .byte $BB   ; 003057 00305E
0x003B13 ---- 01:FB03:  .byte $BB   ; 003057 00305E
0x003B14 ---- 01:FB04:  .byte $BB   ; 003057 00305E
0x003B15 ---- 01:FB05:  .byte $BB   ; 003057 00305E
0x003B16 ---- 01:FB06:  .byte $BB   ; 003057 00305E
0x003B17 ---- 01:FB07:  .byte $BD   ; 00305E
0x003B18 ---- 01:FB08:  .byte $BB   ; 003057 00305E
0x003B19 ---- 01:FB09:  .byte $BB   ; 003057 00305E
0x003B1A ---- 01:FB0A:  .byte $B3   ; 003057 00305E
0x003B1B ---- 01:FB0B:  .byte $3B   ; 003057 00305E
0x003B1C ---- 01:FB0C:  .byte $BB   ; 003057 00305E
0x003B1D ---- 01:FB0D:  .byte $BB   ; 003057 00305E
0x003B1E ---- 01:FB0E:  .byte $8D   ; 00305E
0x003B1F ---- 01:FB0F:  .byte $8B   ; 003057 00305E
0x003B20 ---- 01:FB10:  .byte $BB   ; 003057 00305E
0x003B21 ---- 01:FB11:  .byte $3D   ; 003057 00305E
0x003B22 ---- 01:FB12:  .byte $D3   ; 003057 00305E
0x003B23 ---- 01:FB13:  .byte $BB   ; 003057 00305E
0x003B24 ---- 01:FB14:  .byte $B8   ; 003057 00305E
0x003B25 ---- 01:FB15:  .byte $DD   ; 00305E
0x003B26 ---- 01:FB16:  .byte $D8   ; 003057 00305E
0x003B27 ---- 01:FB17:  .byte $33   ; 003057 00305E
0x003B28 ---- 01:FB18:  .byte $DD   ; 003057 00305E
0x003B29 ---- 01:FB19:  .byte $DD   ; 003057 00305E
0x003B2A ---- 01:FB1A:  .byte $33   ; 003057 00305E
0x003B2B ---- 01:FB1B:  .byte $3D   ; 003057 00305E
0x003B2C ---- 01:FB1C:  .byte $DD   ; 00305E
0x003B2D ---- 01:FB1D:  .byte $DD   ; 003057 00305E
0x003B2E ---- 01:FB1E:  .byte $DD   ; 003057 00305E
0x003B2F ---- 01:FB1F:  .byte $DD   ; 003057 00305E
0x003B30 ---- 01:FB20:  .byte $DD   ; 003057 00305E
0x003B31 ---- 01:FB21:  .byte $DD   ; 003057 00305E
0x003B32 ---- 01:FB22:  .byte $DD   ; 003057 00305E
0x003B33 ---- 01:FB23:  .byte $DD   ; 00305E
0x003B34 ---- 01:FB24:  .byte $DD   ; 003057 00305E
0x003B35 ---- 01:FB25:  .byte $DA   ; 003057 00305E
0x003B36 ---- 01:FB26:  .byte $DD   ; 003057 00305E
0x003B37 ---- 01:FB27:  .byte $DD   ; 003057 00305E
0x003B38 ---- 01:FB28:  .byte $AD   ; 003057 00305E
0x003B39 ---- 01:FB29:  .byte $DD   ; 003057 00305E
0x003B3A ---- 01:FB2A:  .byte $DD   ; 00305E
0x003B3B ---- 01:FB2B:  .byte $AA   ; 003057 00305E
0x003B3C ---- 01:FB2C:  .byte $DA   ; 003057 00305E
0x003B3D ---- 01:FB2D:  .byte $DA   ; 003057 00305E
0x003B3E ---- 01:FB2E:  .byte $AA   ; 003057 00305E
0x003B3F ---- 01:FB2F:  .byte $AD   ; 003057 00305E
0x003B40 ---- 01:FB30:  .byte $AA   ; 003057 00305E
0x003B41 ---- 01:FB31:  .byte $AD   ; 00305E
0x003B42 ---- 01:FB32:  .byte $BB   ; 003057 00305E
0x003B43 ---- 01:FB33:  .byte $4D   ; 003057 00305E
0x003B44 ---- 01:FB34:  .byte $D4   ; 003057 00305E
0x003B45 ---- 01:FB35:  .byte $DD   ; 003057 00305E
0x003B46 ---- 01:FB36:  .byte $AD   ; 003057 00305E
0x003B47 ---- 01:FB37:  .byte $AB   ; 003057 00305E
0x003B48 ---- 01:FB38:  .byte $AD   ; 00305E
0x003B49 ---- 01:FB39:  .byte $BA   ; 003057 00305E
0x003B4A ---- 01:FB3A:  .byte $AA   ; 003057 00305E
0x003B4B ---- 01:FB3B:  .byte $AD   ; 003057 00305E
0x003B4C ---- 01:FB3C:  .byte $9D   ; 003057 00305E
0x003B4D ---- 01:FB3D:  .byte $D4   ; 003057 00305E
0x003B4E ---- 01:FB3E:  .byte $BB   ; 003057 00305E
0x003B4F ---- 01:FB3F:  .byte $BD   ; 00305E
0x003B50 ---- 01:FB40:  .byte $BB   ; 003057 00305E
0x003B51 ---- 01:FB41:  .byte $DA   ; 003057 00305E
0x003B52 ---- 01:FB42:  .byte $DD   ; 003057 00305E
0x003B53 ---- 01:FB43:  .byte $AD   ; 003057 00305E
0x003B54 ---- 01:FB44:  .byte $AA   ; 003057 00305E
0x003B55 ---- 01:FB45:  .byte $AA   ; 003057 00305E
0x003B56 ---- 01:FB46:  .byte $BD   ; 00305E
0x003B57 ---- 01:FB47:  .byte $AA   ; 003057 00305E
0x003B58 ---- 01:FB48:  .byte $DA   ; 003057 00305E
0x003B59 ---- 01:FB49:  .byte $DA   ; 003057 00305E
0x003B5A ---- 01:FB4A:  .byte $AD   ; 003057 00305E
0x003B5B ---- 01:FB4B:  .byte $DA   ; 003057 00305E
0x003B5C ---- 01:FB4C:  .byte $DD   ; 003057 00305E
0x003B5D ---- 01:FB4D:  .byte $DD   ; 00305E
0x003B5E ---- 01:FB4E:  .byte $DD   ; 003057 00305E
0x003B5F ---- 01:FB4F:  .byte $4B   ; 003057 00305E
0x003B60 ---- 01:FB50:  .byte $4D   ; 003057 00305E
0x003B61 ---- 01:FB51:  .byte $4B   ; 003057 00305E
0x003B62 ---- 01:FB52:  .byte $DA   ; 003057 00305E
0x003B63 ---- 01:FB53:  .byte $DD   ; 003057 00305E
0x003B64 ---- 01:FB54:  .byte $AD   ; 00305E
0x003B65 ---- 01:FB55:  .byte $DA   ; 003057 00305E
0x003B66 ---- 01:FB56:  .byte $AB   ; 003057 00305E
0x003B67 ---- 01:FB57:  .byte $AA   ; 003057 00305E
0x003B68 ---- 01:FB58:  .byte $AA   ; 003057 00305E
0x003B69 ---- 01:FB59:  .byte $DB   ; 003057 00305E
0x003B6A ---- 01:FB5A:  .byte $4D   ; 003057 00305E
0x003B6B ---- 01:FB5B:  .byte $AD   ; 00305E
0x003B6C ---- 01:FB5C:  .byte $4D   ; 003057 00305E
0x003B6D ---- 01:FB5D:  .byte $D4   ; 003057 00305E
0x003B6E ---- 01:FB5E:  .byte $DD   ; 003057 00305E
0x003B6F ---- 01:FB5F:  .byte $AD   ; 003057 00305E
0x003B70 ---- 01:FB60:  .byte $BB   ; 003057 00305E
0x003B71 ---- 01:FB61:  .byte $AD   ; 003057 00305E
0x003B72 ---- 01:FB62:  .byte $AD   ; 00305E
0x003B73 ---- 01:FB63:  .byte $AA   ; 003057 00305E
0x003B74 ---- 01:FB64:  .byte $DA   ; 003057 00305E
0x003B75 ---- 01:FB65:  .byte $AD   ; 003057 00305E
0x003B76 ---- 01:FB66:  .byte $A4   ; 003057 00305E
0x003B77 ---- 01:FB67:  .byte $AA   ; 003057 00305E
0x003B78 ---- 01:FB68:  .byte $AD   ; 003057 00305E
0x003B79 ---- 01:FB69:  .byte $DD   ; 00305E
0x003B7A ---- 01:FB6A:  .byte $DD   ; 003057 00305E
0x003B7B ---- 01:FB6B:  .byte $4D   ; 003057 00305E
0x003B7C ---- 01:FB6C:  .byte $BB   ; 003057 00305E
0x003B7D ---- 01:FB6D:  .byte $DD   ; 003057 00305E
0x003B7E ---- 01:FB6E:  .byte $BA   ; 003057 00305E
0x003B7F ---- 01:FB6F:  .byte $DD   ; 003057 00305E
0x003B80 ---- 01:FB70:  .byte $AD   ; 00305E
0x003B81 ---- 01:FB71:  .byte $DA   ; 003057 00305E
0x003B82 ---- 01:FB72:  .byte $AA   ; 003057 00305E
0x003B83 ---- 01:FB73:  .byte $BD   ; 003057 00305E
0x003B84 ---- 01:FB74:  .byte $DD   ; 003057 00305E
0x003B85 ---- 01:FB75:  .byte $DA   ; 003057 00305E
0x003B86 ---- 01:FB76:  .byte $DA   ; 003057 00305E
0x003B87 ---- 01:FB77:  .byte $AD   ; 00305E
0x003B88 ---- 01:FB78:  .byte $DA   ; 003057 00305E
0x003B89 ---- 01:FB79:  .byte $DD   ; 003057 00305E
0x003B8A ---- 01:FB7A:  .byte $DD   ; 003057 00305E
0x003B8B ---- 01:FB7B:  .byte $DD   ; 003057 00305E
0x003B8C ---- 01:FB7C:  .byte $DD   ; 003057 00305E
0x003B8D ---- 01:FB7D:  .byte $DD   ; 003057 00305E
0x003B8E ---- 01:FB7E:  .byte $DD   ; 00305E
0x003B8F ---- 01:FB7F:  .byte $CC   ; 003057 00305E
0x003B90 ---- 01:FB80:  .byte $CC   ; 003057 00305E
0x003B91 ---- 01:FB81:  .byte $CC   ; 003057 00305E
0x003B92 ---- 01:FB82:  .byte $CC   ; 003057 00305E
0x003B93 ---- 01:FB83:  .byte $CC   ; 003057 00305E
0x003B94 ---- 01:FB84:  .byte $CC   ; 003057 00305E
0x003B95 ---- 01:FB85:  .byte $CD   ; 00305E
0x003B96 ---- 01:FB86:  .byte $CC   ; 003057 00305E
0x003B97 ---- 01:FB87:  .byte $CC   ; 003057 00305E
0x003B98 ---- 01:FB88:  .byte $CC   ; 003057 00305E
0x003B99 ---- 01:FB89:  .byte $CC   ; 003057 00305E
0x003B9A ---- 01:FB8A:  .byte $CC   ; 003057 00305E
0x003B9B ---- 01:FB8B:  .byte $CC   ; 003057 00305E
0x003B9C ---- 01:FB8C:  .byte $CD   ; 00305E
0x003B9D ---- 01:FB8D:  .byte $CC   ; 003057 00305E
0x003B9E ---- 01:FB8E:  .byte $C4   ; 003057 00305E
0x003B9F ---- 01:FB8F:  .byte $CC   ; 003057 00305E
0x003BA0 ---- 01:FB90:  .byte $CC   ; 003057 00305E
0x003BA1 ---- 01:FB91:  .byte $C4   ; 003057 00305E
0x003BA2 ---- 01:FB92:  .byte $CC   ; 003057 00305E
0x003BA3 ---- 01:FB93:  .byte $CD   ; 00305E
0x003BA4 ---- 01:FB94:  .byte $C4   ; 003057 00305E
0x003BA5 ---- 01:FB95:  .byte $D4   ; 003057 00305E
0x003BA6 ---- 01:FB96:  .byte $D4   ; 003057 00305E
0x003BA7 ---- 01:FB97:  .byte $C4   ; 003057 00305E
0x003BA8 ---- 01:FB98:  .byte $D4   ; 003057 00305E
0x003BA9 ---- 01:FB99:  .byte $D4   ; 003057 00305E
0x003BAA ---- 01:FB9A:  .byte $CD   ; 00305E
0x003BAB ---- 01:FB9B:  .byte $C3   ; 003057 00305E
0x003BAC ---- 01:FB9C:  .byte $34   ; 003057 00305E
0x003BAD ---- 01:FB9D:  .byte $DD   ; 003057 00305E
0x003BAE ---- 01:FB9E:  .byte $DD   ; 003057 00305E
0x003BAF ---- 01:FB9F:  .byte $D4   ; 003057 00305E
0x003BB0 ---- 01:FBA0:  .byte $33   ; 003057 00305E
0x003BB1 ---- 01:FBA1:  .byte $CD   ; 00305E
0x003BB2 ---- 01:FBA2:  .byte $CC   ; 003057 00305E
0x003BB3 ---- 01:FBA3:  .byte $C4   ; 003057 00305E
0x003BB4 ---- 01:FBA4:  .byte $14   ; 003057 00305E
0x003BB5 ---- 01:FBA5:  .byte $94   ; 003057 00305E
0x003BB6 ---- 01:FBA6:  .byte $14   ; 003057 00305E
0x003BB7 ---- 01:FBA7:  .byte $CC   ; 003057 00305E
0x003BB8 ---- 01:FBA8:  .byte $CD   ; 00305E
0x003BB9 ---- 01:FBA9:  .byte $9C   ; 003057 00305E
0x003BBA ---- 01:FBAA:  .byte $CC   ; 003057 00305E
0x003BBB ---- 01:FBAB:  .byte $D8   ; 003057 00305E
0x003BBC ---- 01:FBAC:  .byte $D8   ; 003057 00305E
0x003BBD ---- 01:FBAD:  .byte $DC   ; 003057 00305E
0x003BBE ---- 01:FBAE:  .byte $CC   ; 003057 00305E
0x003BBF ---- 01:FBAF:  .byte $9D   ; 00305E
0x003BC0 ---- 01:FBB0:  .byte $CC   ; 003057 00305E
0x003BC1 ---- 01:FBB1:  .byte $CC   ; 003057 00305E
0x003BC2 ---- 01:FBB2:  .byte $D1   ; 003057 00305E
0x003BC3 ---- 01:FBB3:  .byte $D1   ; 003057 00305E
0x003BC4 ---- 01:FBB4:  .byte $DC   ; 003057 00305E
0x003BC5 ---- 01:FBB5:  .byte $CC   ; 003057 00305E
0x003BC6 ---- 01:FBB6:  .byte $CD   ; 00305E
0x003BC7 ---- 01:FBB7:  .byte $CC   ; 003057 00305E
0x003BC8 ---- 01:FBB8:  .byte $CC   ; 003057 00305E
0x003BC9 ---- 01:FBB9:  .byte $D4   ; 003057 00305E
0x003BCA ---- 01:FBBA:  .byte $D4   ; 003057 00305E
0x003BCB ---- 01:FBBB:  .byte $DC   ; 003057 00305E
0x003BCC ---- 01:FBBC:  .byte $CC   ; 003057 00305E
0x003BCD ---- 01:FBBD:  .byte $CD   ; 00305E
0x003BCE ---- 01:FBBE:  .byte $CC   ; 003057 00305E
0x003BCF ---- 01:FBBF:  .byte $C4   ; 003057 00305E
0x003BD0 ---- 01:FBC0:  .byte $DD   ; 003057 00305E
0x003BD1 ---- 01:FBC1:  .byte $1D   ; 003057 00305E
0x003BD2 ---- 01:FBC2:  .byte $D4   ; 003057 00305E
0x003BD3 ---- 01:FBC3:  .byte $CC   ; 003057 00305E
0x003BD4 ---- 01:FBC4:  .byte $CD   ; 00305E
0x003BD5 ---- 01:FBC5:  .byte $C4   ; 003057 00305E
0x003BD6 ---- 01:FBC6:  .byte $C4   ; 003057 00305E
0x003BD7 ---- 01:FBC7:  .byte $D8   ; 003057 00305E
0x003BD8 ---- 01:FBC8:  .byte $88   ; 003057 00305E
0x003BD9 ---- 01:FBC9:  .byte $D4   ; 003057 00305E
0x003BDA ---- 01:FBCA:  .byte $C4   ; 003057 00305E
0x003BDB ---- 01:FBCB:  .byte $CD   ; 00305E
0x003BDC ---- 01:FBCC:  .byte $D4   ; 003057 00305E
0x003BDD ---- 01:FBCD:  .byte $14   ; 003057 00305E
0x003BDE ---- 01:FBCE:  .byte $DD   ; 003057 00305E
0x003BDF ---- 01:FBCF:  .byte $DD   ; 003057 00305E
0x003BE0 ---- 01:FBD0:  .byte $D4   ; 003057 00305E
0x003BE1 ---- 01:FBD1:  .byte $14   ; 003057 00305E
0x003BE2 ---- 01:FBD2:  .byte $DD   ; 00305E
0x003BE3 ---- 01:FBD3:  .byte $D3   ; 003057 00305E
0x003BE4 ---- 01:FBD4:  .byte $DD   ; 003057 00305E
0x003BE5 ---- 01:FBD5:  .byte $DD   ; 003057 00305E
0x003BE6 ---- 01:FBD6:  .byte $DD   ; 003057 00305E
0x003BE7 ---- 01:FBD7:  .byte $DD   ; 003057 00305E
0x003BE8 ---- 01:FBD8:  .byte $D3   ; 003057 00305E
0x003BE9 ---- 01:FBD9:  .byte $DD   ; 00305E
0x003BEA ---- 01:FBDA:  .byte $DD   ; 003057 00305E
0x003BEB ---- 01:FBDB:  .byte $DD   ; 003057 00305E
0x003BEC ---- 01:FBDC:  .byte $9D   ; 003057 00305E
0x003BED ---- 01:FBDD:  .byte $DD   ; 003057 00305E
0x003BEE ---- 01:FBDE:  .byte $D9   ; 003057 00305E
0x003BEF ---- 01:FBDF:  .byte $DD   ; 003057 00305E
0x003BF0 ---- 01:FBE0:  .byte $DD   ; 00305E
0x003BF1 ---- 01:FBE1:  .byte $D9   ; 003057 00305E
0x003BF2 ---- 01:FBE2:  .byte $DD   ; 003057 00305E
0x003BF3 ---- 01:FBE3:  .byte $D9   ; 003057 00305E
0x003BF4 ---- 01:FBE4:  .byte $DD   ; 003057 00305E
0x003BF5 ---- 01:FBE5:  .byte $9B   ; 003057 00305E
0x003BF6 ---- 01:FBE6:  .byte $BD   ; 003057 00305E
0x003BF7 ---- 01:FBE7:  .byte $DD   ; 00305E
0x003BF8 ---- 01:FBE8:  .byte $DD   ; 003057 00305E
0x003BF9 ---- 01:FBE9:  .byte $9D   ; 003057 00305E
0x003BFA ---- 01:FBEA:  .byte $DD   ; 003057 00305E
0x003BFB ---- 01:FBEB:  .byte $D9   ; 003057 00305E
0x003BFC ---- 01:FBEC:  .byte $B6   ; 003057 00305E
0x003BFD ---- 01:FBED:  .byte $7D   ; 003057 00305E
0x003BFE ---- 01:FBEE:  .byte $DD   ; 00305E
0x003BFF ---- 01:FBEF:  .byte $DD   ; 003057 00305E
0x003C00 ---- 01:FBF0:  .byte $D9   ; 003057 00305E
0x003C01 ---- 01:FBF1:  .byte $DB   ; 003057 00305E
0x003C02 ---- 01:FBF2:  .byte $BB   ; 003057 00305E
0x003C03 ---- 01:FBF3:  .byte $BB   ; 003057 00305E
0x003C04 ---- 01:FBF4:  .byte $D5   ; 003057 00305E
0x003C05 ---- 01:FBF5:  .byte $DD   ; 00305E
0x003C06 ---- 01:FBF6:  .byte $D7   ; 003057 00305E
0x003C07 ---- 01:FBF7:  .byte $DD   ; 003057 00305E
0x003C08 ---- 01:FBF8:  .byte $9B   ; 003057 00305E
0x003C09 ---- 01:FBF9:  .byte $B9   ; 003057 00305E
0x003C0A ---- 01:FBFA:  .byte $BD   ; 003057 00305E
0x003C0B ---- 01:FBFB:  .byte $D9   ; 003057 00305E
0x003C0C ---- 01:FBFC:  .byte $DD   ; 00305E
0x003C0D ---- 01:FBFD:  .byte $D8   ; 003057 00305E
0x003C0E ---- 01:FBFE:  .byte $7B   ; 003057 00305E
0x003C0F ---- 01:FBFF:  .byte $D9   ; 003057 00305E
0x003C10 ---- 01:FC00:  .byte $BB   ; 003057 00305E
0x003C11 ---- 01:FC01:  .byte $9D   ; 003057 00305E
0x003C12 ---- 01:FC02:  .byte $D5   ; 003057 00305E
0x003C13 ---- 01:FC03:  .byte $DD   ; 00305E
0x003C14 ---- 01:FC04:  .byte $DD   ; 003057 00305E
0x003C15 ---- 01:FC05:  .byte $BB   ; 003057 00305E
0x003C16 ---- 01:FC06:  .byte $BB   ; 003057 00305E
0x003C17 ---- 01:FC07:  .byte $BD   ; 003057 00305E
0x003C18 ---- 01:FC08:  .byte $D9   ; 003057 00305E
0x003C19 ---- 01:FC09:  .byte $DD   ; 003057 00305E
0x003C1A ---- 01:FC0A:  .byte $DD   ; 00305E
0x003C1B ---- 01:FC0B:  .byte $D6   ; 003057 00305E
0x003C1C ---- 01:FC0C:  .byte $7B   ; 003057 00305E
0x003C1D ---- 01:FC0D:  .byte $D9   ; 003057 00305E
0x003C1E ---- 01:FC0E:  .byte $BD   ; 003057 00305E
0x003C1F ---- 01:FC0F:  .byte $DD   ; 003057 00305E
0x003C20 ---- 01:FC10:  .byte $9D   ; 003057 00305E
0x003C21 ---- 01:FC11:  .byte $DD   ; 00305E
0x003C22 ---- 01:FC12:  .byte $DB   ; 003057 00305E
0x003C23 ---- 01:FC13:  .byte $BB   ; 003057 00305E
0x003C24 ---- 01:FC14:  .byte $9D   ; 003057 00305E
0x003C25 ---- 01:FC15:  .byte $9D   ; 003057 00305E
0x003C26 ---- 01:FC16:  .byte $6D   ; 003057 00305E
0x003C27 ---- 01:FC17:  .byte $D9   ; 003057 00305E
0x003C28 ---- 01:FC18:  .byte $DD   ; 00305E
0x003C29 ---- 01:FC19:  .byte $BB   ; 003057 00305E
0x003C2A ---- 01:FC1A:  .byte $B9   ; 003057 00305E
0x003C2B ---- 01:FC1B:  .byte $DD   ; 003057 00305E
0x003C2C ---- 01:FC1C:  .byte $DD   ; 003057 00305E
0x003C2D ---- 01:FC1D:  .byte $5D   ; 003057 00305E
0x003C2E ---- 01:FC1E:  .byte $DD   ; 003057 00305E
0x003C2F ---- 01:FC1F:  .byte $DD   ; 00305E
0x003C30 ---- 01:FC20:  .byte $DD   ; 003057 00305E
0x003C31 ---- 01:FC21:  .byte $9D   ; 003057 00305E
0x003C32 ---- 01:FC22:  .byte $DD   ; 003057 00305E
0x003C33 ---- 01:FC23:  .byte $DD   ; 003057 00305E
0x003C34 ---- 01:FC24:  .byte $DD   ; 003057 00305E
0x003C35 ---- 01:FC25:  .byte $D5   ; 003057 00305E
0x003C36 ---- 01:FC26:  .byte $9D   ; 00305E
0x003C37 ---- 01:FC27:  .byte $DD   ; 003057 00305E
0x003C38 ---- 01:FC28:  .byte $DD   ; 003057 00305E
0x003C39 ---- 01:FC29:  .byte $DD   ; 003057 00305E
0x003C3A ---- 01:FC2A:  .byte $DD   ; 003057 00305E
0x003C3B ---- 01:FC2B:  .byte $D6   ; 003057 00305E
0x003C3C ---- 01:FC2C:  .byte $7D   ; 003057 00305E
0x003C3D ---- 01:FC2D:  .byte $DD   ; 00305E
0x003C3E ---- 01:FC2E:  .byte $7D   ; 003057 00305E
0x003C3F ---- 01:FC2F:  .byte $6D   ; 003057 00305E
0x003C40 ---- 01:FC30:  .byte $DD   ; 003057 00305E
0x003C41 ---- 01:FC31:  .byte $DD   ; 003057 00305E
0x003C42 ---- 01:FC32:  .byte $DD   ; 003057 00305E
0x003C43 ---- 01:FC33:  .byte $DD   ; 003057 00305E
0x003C44 ---- 01:FC34:  .byte $DD   ; 00305E
0x003C45 ---- 01:FC35:  .byte $DD   ; 003057 00305E
0x003C46 ---- 01:FC36:  .byte $DD   ; 003057 00305E
0x003C47 ---- 01:FC37:  .byte $20   ; 003057 00305E
0x003C48 ---- 01:FC38:  .byte $DD   ; 003057 00305E
0x003C49 ---- 01:FC39:  .byte $DD   ; 003057 00305E
0x003C4A ---- 01:FC3A:  .byte $DD   ; 003057 00305E
0x003C4B ---- 01:FC3B:  .byte $DD   ; 00305E
0x003C4C ---- 01:FC3C:  .byte $22   ; 003057 00305E
0x003C4D ---- 01:FC3D:  .byte $20   ; 003057 00305E
0x003C4E ---- 01:FC3E:  .byte $D2   ; 003057 00305E
0x003C4F ---- 01:FC3F:  .byte $DD   ; 003057 00305E
0x003C50 ---- 01:FC40:  .byte $22   ; 003057 00305E
0x003C51 ---- 01:FC41:  .byte $DD   ; 003057 00305E
0x003C52 ---- 01:FC42:  .byte $DD   ; 00305E
0x003C53 ---- 01:FC43:  .byte $22   ; 003057 00305E
0x003C54 ---- 01:FC44:  .byte $24   ; 003057 00305E
0x003C55 ---- 01:FC45:  .byte $4D   ; 003057 00305E
0x003C56 ---- 01:FC46:  .byte $DD   ; 003057 00305E
0x003C57 ---- 01:FC47:  .byte $24   ; 003057 00305E
0x003C58 ---- 01:FC48:  .byte $2D   ; 003057 00305E
0x003C59 ---- 01:FC49:  .byte $DD   ; 00305E
0x003C5A ---- 01:FC4A:  .byte $00   ; 003057 00305E
0x003C5B ---- 01:FC4B:  .byte $D4   ; 003057 00305E
0x003C5C ---- 01:FC4C:  .byte $2D   ; 003057 00305E
0x003C5D ---- 01:FC4D:  .byte $D0   ; 003057 00305E
0x003C5E ---- 01:FC4E:  .byte $24   ; 003057 00305E
0x003C5F ---- 01:FC4F:  .byte $4D   ; 003057 00305E
0x003C60 ---- 01:FC50:  .byte $DD   ; 00305E
0x003C61 ---- 01:FC51:  .byte $D2   ; 003057 00305E
0x003C62 ---- 01:FC52:  .byte $D4   ; 003057 00305E
0x003C63 ---- 01:FC53:  .byte $02   ; 003057 00305E
0x003C64 ---- 01:FC54:  .byte $D2   ; 003057 00305E
0x003C65 ---- 01:FC55:  .byte $44   ; 003057 00305E
0x003C66 ---- 01:FC56:  .byte $4D   ; 003057 00305E
0x003C67 ---- 01:FC57:  .byte $DD   ; 00305E
0x003C68 ---- 01:FC58:  .byte $D2   ; 003057 00305E
0x003C69 ---- 01:FC59:  .byte $0D   ; 003057 00305E
0x003C6A ---- 01:FC5A:  .byte $D4   ; 003057 00305E
0x003C6B ---- 01:FC5B:  .byte $24   ; 003057 00305E
0x003C6C ---- 01:FC5C:  .byte $00   ; 003057 00305E
0x003C6D ---- 01:FC5D:  .byte $4D   ; 003057 00305E
0x003C6E ---- 01:FC5E:  .byte $DD   ; 00305E
0x003C6F ---- 01:FC5F:  .byte $D2   ; 003057 00305E
0x003C70 ---- 01:FC60:  .byte $DD   ; 003057 00305E
0x003C71 ---- 01:FC61:  .byte $04   ; 003057 00305E
0x003C72 ---- 01:FC62:  .byte $42   ; 003057 00305E
0x003C73 ---- 01:FC63:  .byte $D2   ; 003057 00305E
0x003C74 ---- 01:FC64:  .byte $4D   ; 003057 00305E
0x003C75 ---- 01:FC65:  .byte $DD   ; 00305E
0x003C76 ---- 01:FC66:  .byte $D0   ; 003057 00305E
0x003C77 ---- 01:FC67:  .byte $DD   ; 003057 00305E
0x003C78 ---- 01:FC68:  .byte $24   ; 003057 00305E
0x003C79 ---- 01:FC69:  .byte $42   ; 003057 00305E
0x003C7A ---- 01:FC6A:  .byte $D2   ; 003057 00305E
0x003C7B ---- 01:FC6B:  .byte $4D   ; 003057 00305E
0x003C7C ---- 01:FC6C:  .byte $DD   ; 00305E
0x003C7D ---- 01:FC6D:  .byte $D0   ; 003057 00305E
0x003C7E ---- 01:FC6E:  .byte $33   ; 003057 00305E
0x003C7F ---- 01:FC6F:  .byte $D4   ; 003057 00305E
0x003C80 ---- 01:FC70:  .byte $44   ; 003057 00305E
0x003C81 ---- 01:FC71:  .byte $D2   ; 003057 00305E
0x003C82 ---- 01:FC72:  .byte $23   ; 003057 00305E
0x003C83 ---- 01:FC73:  .byte $4D   ; 00305E
0x003C84 ---- 01:FC74:  .byte $D0   ; 003057 00305E
0x003C85 ---- 01:FC75:  .byte $DD   ; 003057 00305E
0x003C86 ---- 01:FC76:  .byte $02   ; 003057 00305E
0x003C87 ---- 01:FC77:  .byte $40   ; 003057 00305E
0x003C88 ---- 01:FC78:  .byte $22   ; 003057 00305E
0x003C89 ---- 01:FC79:  .byte $20   ; 003057 00305E
0x003C8A ---- 01:FC7A:  .byte $0D   ; 00305E
0x003C8B ---- 01:FC7B:  .byte $DD   ; 003057 00305E
0x003C8C ---- 01:FC7C:  .byte $2D   ; 003057 00305E
0x003C8D ---- 01:FC7D:  .byte $40   ; 003057 00305E
0x003C8E ---- 01:FC7E:  .byte $24   ; 003057 00305E
0x003C8F ---- 01:FC7F:  .byte $4D   ; 003057 00305E
0x003C90 ---- 01:FC80:  .byte $D0   ; 003057 00305E
0x003C91 ---- 01:FC81:  .byte $DD   ; 00305E
0x003C92 ---- 01:FC82:  .byte $DD   ; 003057 00305E
0x003C93 ---- 01:FC83:  .byte $20   ; 003057 00305E
0x003C94 ---- 01:FC84:  .byte $2D   ; 003057 00305E
0x003C95 ---- 01:FC85:  .byte $DD   ; 003057 00305E
0x003C96 ---- 01:FC86:  .byte $42   ; 003057 00305E
0x003C97 ---- 01:FC87:  .byte $D2   ; 003057 00305E
0x003C98 ---- 01:FC88:  .byte $DD   ; 00305E
0x003C99 ---- 01:FC89:  .byte $DD   ; 003057 00305E
0x003C9A ---- 01:FC8A:  .byte $20   ; 003057 00305E
0x003C9B ---- 01:FC8B:  .byte $DD   ; 003057 00305E
0x003C9C ---- 01:FC8C:  .byte $DD   ; 003057 00305E
0x003C9D ---- 01:FC8D:  .byte $D4   ; 003057 00305E
0x003C9E ---- 01:FC8E:  .byte $4D   ; 003057 00305E
0x003C9F ---- 01:FC8F:  .byte $DD   ; 00305E
0x003CA0 ---- 01:FC90:  .byte $DD   ; 003057 00305E
0x003CA1 ---- 01:FC91:  .byte $DD   ; 003057 00305E
0x003CA2 ---- 01:FC92:  .byte $DD   ; 003057 00305E
0x003CA3 ---- 01:FC93:  .byte $DD   ; 003057 00305E
0x003CA4 ---- 01:FC94:  .byte $DD   ; 003057 00305E
0x003CA5 ---- 01:FC95:  .byte $DD   ; 003057 00305E
0x003CA6 ---- 01:FC96:  .byte $DD   ; 00305E
0x003CA7 ---- 01:FC97:  .byte $DD   ; 003057 00305E
0x003CA8 ---- 01:FC98:  .byte $DD   ; 003057 00305E
0x003CA9 ---- 01:FC99:  .byte $4D   ; 003057 00305E
0x003CAA ---- 01:FC9A:  .byte $4D   ; 003057 00305E
0x003CAB ---- 01:FC9B:  .byte $DD   ; 003057 00305E
0x003CAC ---- 01:FC9C:  .byte $DD   ; 003057 00305E
0x003CAD ---- 01:FC9D:  .byte $DD   ; 00305E
0x003CAE ---- 01:FC9E:  .byte $BD   ; 003057 00305E
0x003CAF ---- 01:FC9F:  .byte $DB   ; 003057 00305E
0x003CB0 ---- 01:FCA0:  .byte $4B   ; 003057 00305E
0x003CB1 ---- 01:FCA1:  .byte $4B   ; 003057 00305E
0x003CB2 ---- 01:FCA2:  .byte $DD   ; 003057 00305E
0x003CB3 ---- 01:FCA3:  .byte $BD   ; 003057 00305E
0x003CB4 ---- 01:FCA4:  .byte $DD   ; 00305E
0x003CB5 ---- 01:FCA5:  .byte $4B   ; 003057 00305E
0x003CB6 ---- 01:FCA6:  .byte $B4   ; 003057 00305E
0x003CB7 ---- 01:FCA7:  .byte $44   ; 003057 00305E
0x003CB8 ---- 01:FCA8:  .byte $44   ; 003057 00305E
0x003CB9 ---- 01:FCA9:  .byte $BB   ; 003057 00305E
0x003CBA ---- 01:FCAA:  .byte $4B   ; 003057 00305E
0x003CBB ---- 01:FCAB:  .byte $DD   ; 00305E
0x003CBC ---- 01:FCAC:  .byte $44   ; 003057 00305E
0x003CBD ---- 01:FCAD:  .byte $44   ; 003057 00305E
0x003CBE ---- 01:FCAE:  .byte $94   ; 003057 00305E
0x003CBF ---- 01:FCAF:  .byte $94   ; 003057 00305E
0x003CC0 ---- 01:FCB0:  .byte $44   ; 003057 00305E
0x003CC1 ---- 01:FCB1:  .byte $4B   ; 003057 00305E
0x003CC2 ---- 01:FCB2:  .byte $DD   ; 00305E
0x003CC3 ---- 01:FCB3:  .byte $AA   ; 003057 00305E
0x003CC4 ---- 01:FCB4:  .byte $A4   ; 003057 00305E
0x003CC5 ---- 01:FCB5:  .byte $44   ; 003057 00305E
0x003CC6 ---- 01:FCB6:  .byte $44   ; 003057 00305E
0x003CC7 ---- 01:FCB7:  .byte $AA   ; 003057 00305E
0x003CC8 ---- 01:FCB8:  .byte $AB   ; 003057 00305E
0x003CC9 ---- 01:FCB9:  .byte $DD   ; 00305E
0x003CCA ---- 01:FCBA:  .byte $A4   ; 003057 00305E
0x003CCB ---- 01:FCBB:  .byte $44   ; 003057 00305E
0x003CCC ---- 01:FCBC:  .byte $44   ; 003057 00305E
0x003CCD ---- 01:FCBD:  .byte $44   ; 003057 00305E
0x003CCE ---- 01:FCBE:  .byte $44   ; 003057 00305E
0x003CCF ---- 01:FCBF:  .byte $AA   ; 003057 00305E
0x003CD0 ---- 01:FCC0:  .byte $BD   ; 00305E
0x003CD1 ---- 01:FCC1:  .byte $44   ; 003057 00305E
0x003CD2 ---- 01:FCC2:  .byte $4A   ; 003057 00305E
0x003CD3 ---- 01:FCC3:  .byte $44   ; 003057 00305E
0x003CD4 ---- 01:FCC4:  .byte $4A   ; 003057 00305E
0x003CD5 ---- 01:FCC5:  .byte $44   ; 003057 00305E
0x003CD6 ---- 01:FCC6:  .byte $4B   ; 003057 00305E
0x003CD7 ---- 01:FCC7:  .byte $BD   ; 00305E
0x003CD8 ---- 01:FCC8:  .byte $44   ; 003057 00305E
0x003CD9 ---- 01:FCC9:  .byte $AA   ; 003057 00305E
0x003CDA ---- 01:FCCA:  .byte $A4   ; 003057 00305E
0x003CDB ---- 01:FCCB:  .byte $AA   ; 003057 00305E
0x003CDC ---- 01:FCCC:  .byte $A4   ; 003057 00305E
0x003CDD ---- 01:FCCD:  .byte $4A   ; 003057 00305E
0x003CDE ---- 01:FCCE:  .byte $AD   ; 00305E
0x003CDF ---- 01:FCCF:  .byte $BA   ; 003057 00305E
0x003CE0 ---- 01:FCD0:  .byte $AB   ; 003057 00305E
0x003CE1 ---- 01:FCD1:  .byte $BB   ; 003057 00305E
0x003CE2 ---- 01:FCD2:  .byte $BB   ; 003057 00305E
0x003CE3 ---- 01:FCD3:  .byte $AA   ; 003057 00305E
0x003CE4 ---- 01:FCD4:  .byte $BA   ; 003057 00305E
0x003CE5 ---- 01:FCD5:  .byte $BD   ; 00305E
0x003CE6 ---- 01:FCD6:  .byte $DB   ; 003057 00305E
0x003CE7 ---- 01:FCD7:  .byte $BD   ; 003057 00305E
0x003CE8 ---- 01:FCD8:  .byte $DD   ; 003057 00305E
0x003CE9 ---- 01:FCD9:  .byte $DD   ; 003057 00305E
0x003CEA ---- 01:FCDA:  .byte $BB   ; 003057 00305E
0x003CEB ---- 01:FCDB:  .byte $DB   ; 003057 00305E
0x003CEC ---- 01:FCDC:  .byte $DD   ; 00305E
0x003CED ---- 01:FCDD:  .byte $DD   ; 003057 00305E
0x003CEE ---- 01:FCDE:  .byte $DD   ; 003057 00305E
0x003CEF ---- 01:FCDF:  .byte $DD   ; 003057 00305E
0x003CF0 ---- 01:FCE0:  .byte $DD   ; 003057 00305E
0x003CF1 ---- 01:FCE1:  .byte $DD   ; 003057 00305E
0x003CF2 ---- 01:FCE2:  .byte $DD   ; 003057 00305E
0x003CF3 ---- 01:FCE3:  .byte $DD   ; 00305E
0x003CF4 ---- 01:FCE4:  .byte $DD   ; 003057 00305E
0x003CF5 ---- 01:FCE5:  .byte $DD   ; 003057 00305E
0x003CF6 ---- 01:FCE6:  .byte $DD   ; 003057 00305E
0x003CF7 ---- 01:FCE7:  .byte $DD   ; 003057 00305E
0x003CF8 ---- 01:FCE8:  .byte $DD   ; 003057 00305E
0x003CF9 ---- 01:FCE9:  .byte $DD   ; 003057 00305E
0x003CFA ---- 01:FCEA:  .byte $DD   ; 00305E
0x003CFB ---- 01:FCEB:  .byte $DD   ; 003057 00305E
0x003CFC ---- 01:FCEC:  .byte $DD   ; 003057 00305E
0x003CFD ---- 01:FCED:  .byte $DD   ; 003057 00305E
0x003CFE ---- 01:FCEE:  .byte $DD   ; 003057 00305E
0x003CFF ---- 01:FCEF:  .byte $DD   ; 003057 00305E
0x003D00 ---- 01:FCF0:  .byte $DD   ; 003057 00305E
0x003D01 ---- 01:FCF1:  .byte $DD   ; 00305E
0x003D02 ---- 01:FCF2:  .byte $6D   ; 003057 00305E
0x003D03 ---- 01:FCF3:  .byte $DD   ; 003057 00305E
0x003D04 ---- 01:FCF4:  .byte $DD   ; 003057 00305E
0x003D05 ---- 01:FCF5:  .byte $6D   ; 003057 00305E
0x003D06 ---- 01:FCF6:  .byte $DD   ; 003057 00305E
0x003D07 ---- 01:FCF7:  .byte $DD   ; 003057 00305E
0x003D08 ---- 01:FCF8:  .byte $6D   ; 00305E
0x003D09 ---- 01:FCF9:  .byte $DD   ; 003057 00305E
0x003D0A ---- 01:FCFA:  .byte $DD   ; 003057 00305E
0x003D0B ---- 01:FCFB:  .byte $DD   ; 003057 00305E
0x003D0C ---- 01:FCFC:  .byte $DD   ; 003057 00305E
0x003D0D ---- 01:FCFD:  .byte $DD   ; 003057 00305E
0x003D0E ---- 01:FCFE:  .byte $DD   ; 003057 00305E
0x003D0F ---- 01:FCFF:  .byte $DD   ; 00305E
0x003D10 ---- 01:FD00:  .byte $DD   ; 003057 00305E
0x003D11 ---- 01:FD01:  .byte $DD   ; 003057 00305E
0x003D12 ---- 01:FD02:  .byte $DD   ; 003057 00305E
0x003D13 ---- 01:FD03:  .byte $DD   ; 003057 00305E
0x003D14 ---- 01:FD04:  .byte $DD   ; 003057 00305E
0x003D15 ---- 01:FD05:  .byte $DD   ; 003057 00305E
0x003D16 ---- 01:FD06:  .byte $DD   ; 00305E
0x003D17 ---- 01:FD07:  .byte $DD   ; 003057 00305E
0x003D18 ---- 01:FD08:  .byte $DD   ; 003057 00305E
0x003D19 ---- 01:FD09:  .byte $DD   ; 003057 00305E
0x003D1A ---- 01:FD0A:  .byte $DD   ; 003057 00305E
0x003D1B ---- 01:FD0B:  .byte $DD   ; 003057 00305E
0x003D1C ---- 01:FD0C:  .byte $DD   ; 003057 00305E
0x003D1D ---- 01:FD0D:  .byte $DD   ; 00305E
0x003D1E ---- 01:FD0E:  .byte $DD   ; 003057 00305E
0x003D1F ---- 01:FD0F:  .byte $DD   ; 003057 00305E
0x003D20 ---- 01:FD10:  .byte $DD   ; 003057 00305E
0x003D21 ---- 01:FD11:  .byte $DD   ; 003057 00305E
0x003D22 ---- 01:FD12:  .byte $DD   ; 003057 00305E
0x003D23 ---- 01:FD13:  .byte $DD   ; 003057 00305E
0x003D24 ---- 01:FD14:  .byte $DD   ; 00305E
0x003D25 ---- 01:FD15:  .byte $DD   ; 003057 00305E
0x003D26 ---- 01:FD16:  .byte $DD   ; 003057 00305E
0x003D27 ---- 01:FD17:  .byte $DD   ; 003057 00305E
0x003D28 ---- 01:FD18:  .byte $DD   ; 003057 00305E
0x003D29 ---- 01:FD19:  .byte $DD   ; 003057 00305E
0x003D2A ---- 01:FD1A:  .byte $DD   ; 003057 00305E
0x003D2B ---- 01:FD1B:  .byte $DD   ; 00305E
0x003D2C ---- 01:FD1C:  .byte $DD   ; 003057 00305E
0x003D2D ---- 01:FD1D:  .byte $DD   ; 003057 00305E
0x003D2E ---- 01:FD1E:  .byte $DD   ; 003057 00305E
0x003D2F ---- 01:FD1F:  .byte $DD   ; 003057 00305E
0x003D30 ---- 01:FD20:  .byte $DD   ; 003057 00305E
0x003D31 ---- 01:FD21:  .byte $DD   ; 003057 00305E
0x003D32 ---- 01:FD22:  .byte $DD   ; 00305E
0x003D33 ---- 01:FD23:  .byte $DD   ; 003057 00305E
0x003D34 ---- 01:FD24:  .byte $DD   ; 003057 00305E
0x003D35 ---- 01:FD25:  .byte $DD   ; 003057 00305E
0x003D36 ---- 01:FD26:  .byte $DD   ; 003057 00305E
0x003D37 ---- 01:FD27:  .byte $DD   ; 003057 00305E
0x003D38 ---- 01:FD28:  .byte $DD   ; 003057 00305E
0x003D39 ---- 01:FD29:  .byte $DD   ; 00305E
0x003D3A ---- 01:FD2A:  .byte $BD   ; 003057 00305E
0x003D3B ---- 01:FD2B:  .byte $DD   ; 003057 00305E
0x003D3C ---- 01:FD2C:  .byte $DD   ; 003057 00305E
0x003D3D ---- 01:FD2D:  .byte $DD   ; 003057 00305E
0x003D3E ---- 01:FD2E:  .byte $DD   ; 003057 00305E
0x003D3F ---- 01:FD2F:  .byte $DD   ; 003057 00305E
0x003D40 ---- 01:FD30:  .byte $BD   ; 00305E
0x003D41 ---- 01:FD31:  .byte $BB   ; 003057 00305E
0x003D42 ---- 01:FD32:  .byte $DD   ; 003057 00305E
0x003D43 ---- 01:FD33:  .byte $DD   ; 003057 00305E
0x003D44 ---- 01:FD34:  .byte $DD   ; 003057 00305E
0x003D45 ---- 01:FD35:  .byte $DD   ; 003057 00305E
0x003D46 ---- 01:FD36:  .byte $DB   ; 003057 00305E
0x003D47 ---- 01:FD37:  .byte $BD   ; 00305E
0x003D48 ---- 01:FD38:  .byte $9B   ; 003057 00305E
0x003D49 ---- 01:FD39:  .byte $BD   ; 003057 00305E
0x003D4A ---- 01:FD3A:  .byte $DD   ; 003057 00305E
0x003D4B ---- 01:FD3B:  .byte $DD   ; 003057 00305E
0x003D4C ---- 01:FD3C:  .byte $DD   ; 003057 00305E
0x003D4D ---- 01:FD3D:  .byte $BB   ; 003057 00305E
0x003D4E ---- 01:FD3E:  .byte $9D   ; 00305E
0x003D4F ---- 01:FD3F:  .byte $99   ; 003057 00305E
0x003D50 ---- 01:FD40:  .byte $BB   ; 003057 00305E
0x003D51 ---- 01:FD41:  .byte $DD   ; 003057 00305E
0x003D52 ---- 01:FD42:  .byte $DD   ; 003057 00305E
0x003D53 ---- 01:FD43:  .byte $DB   ; 003057 00305E
0x003D54 ---- 01:FD44:  .byte $B9   ; 003057 00305E
0x003D55 ---- 01:FD45:  .byte $9D   ; 00305E
0x003D56 ---- xx:FD46:  .byte $FF   ; 
0x003D57 ---- xx:FD47:  .byte $FF   ; 
0x003D58 ---- xx:FD48:  .byte $FF   ; 
0x003D59 ---- xx:FD49:  .byte $FF   ; 
0x003D5A ---- xx:FD4A:  .byte $FF   ; 
0x003D5B ---- xx:FD4B:  .byte $FF   ; 
0x003D5C ---- xx:FD4C:  .byte $FF   ; 
0x003D5D ---- xx:FD4D:  .byte $FF   ; 
0x003D5E ---- xx:FD4E:  .byte $FF   ; 
0x003D5F ---- xx:FD4F:  .byte $FF   ; 
0x003D60 ---- xx:FD50:  .byte $2E   ; 
0x003D61 ---- xx:FD51:  .byte $2E   ; 
0x003D62 ---- xx:FD52:  .byte $2E   ; 
0x003D63 ---- xx:FD53:  .byte $2E   ; 
0x003D64 ---- xx:FD54:  .byte $2E   ; 
0x003D65 ---- xx:FD55:  .byte $2E   ; 
0x003D66 ---- xx:FD56:  .byte $2E   ; 
0x003D67 ---- xx:FD57:  .byte $2E   ; 
0x003D68 ---- xx:FD58:  .byte $2E   ; 
0x003D69 ---- xx:FD59:  .byte $2E   ; 
0x003D6A ---- xx:FD5A:  .byte $2E   ; 
0x003D6B ---- xx:FD5B:  .byte $2E   ; 
0x003D6C ---- xx:FD5C:  .byte $2E   ; 
0x003D6D ---- xx:FD5D:  .byte $2E   ; 
0x003D6E ---- xx:FD5E:  .byte $2E   ; 
0x003D6F ---- xx:FD5F:  .byte $2E   ; 
0x003D70 ---- xx:FD60:  .byte $2E   ; 
0x003D71 ---- xx:FD61:  .byte $2E   ; 
0x003D72 ---- xx:FD62:  .byte $2E   ; 
0x003D73 ---- xx:FD63:  .byte $40   ; 
0x003D74 ---- xx:FD64:  .byte $2E   ; 
0x003D75 ---- xx:FD65:  .byte $2E   ; 
0x003D76 ---- xx:FD66:  .byte $2E   ; 
0x003D77 ---- xx:FD67:  .byte $2E   ; 
0x003D78 ---- xx:FD68:  .byte $2E   ; 
0x003D79 ---- xx:FD69:  .byte $2E   ; 
0x003D7A ---- xx:FD6A:  .byte $2E   ; 
0x003D7B ---- xx:FD6B:  .byte $40   ; 
0x003D7C ---- xx:FD6C:  .byte $40   ; 
0x003D7D ---- xx:FD6D:  .byte $40   ; 
0x003D7E ---- xx:FD6E:  .byte $40   ; 
0x003D7F ---- xx:FD6F:  .byte $2E   ; 
0x003D80 ---- xx:FD70:  .byte $40   ; 
0x003D81 ---- xx:FD71:  .byte $40   ; 
0x003D82 ---- xx:FD72:  .byte $40   ; 
0x003D83 ---- xx:FD73:  .byte $40   ; 
0x003D84 ---- xx:FD74:  .byte $40   ; 
0x003D85 ---- xx:FD75:  .byte $40   ; 
0x003D86 ---- xx:FD76:  .byte $40   ; 
0x003D87 ---- xx:FD77:  .byte $2E   ; 
0x003D88 ---- xx:FD78:  .byte $2E   ; 
0x003D89 ---- xx:FD79:  .byte $2E   ; 
0x003D8A ---- xx:FD7A:  .byte $40   ; 
0x003D8B ---- xx:FD7B:  .byte $2E   ; 
0x003D8C ---- xx:FD7C:  .byte $2E   ; 
0x003D8D ---- xx:FD7D:  .byte $40   ; 
0x003D8E ---- xx:FD7E:  .byte $2E   ; 
0x003D8F ---- xx:FD7F:  .byte $2E   ; 
0x003D90 ---- xx:FD80:  .byte $2E   ; 
0x003D91 ---- xx:FD81:  .byte $2E   ; 
0x003D92 ---- xx:FD82:  .byte $2E   ; 
0x003D93 ---- xx:FD83:  .byte $40   ; 
0x003D94 ---- xx:FD84:  .byte $2E   ; 
0x003D95 ---- xx:FD85:  .byte $2E   ; 
0x003D96 ---- xx:FD86:  .byte $2E   ; 
0x003D97 ---- xx:FD87:  .byte $2E   ; 
0x003D98 ---- xx:FD88:  .byte $2E   ; 
0x003D99 ---- xx:FD89:  .byte $40   ; 
0x003D9A ---- xx:FD8A:  .byte $2E   ; 
0x003D9B ---- xx:FD8B:  .byte $2E   ; 
0x003D9C ---- xx:FD8C:  .byte $40   ; 
0x003D9D ---- xx:FD8D:  .byte $2E   ; 
0x003D9E ---- xx:FD8E:  .byte $2E   ; 
0x003D9F ---- xx:FD8F:  .byte $2E   ; 
0x003DA0 ---- xx:FD90:  .byte $2E   ; 
0x003DA1 ---- xx:FD91:  .byte $2E   ; 
0x003DA2 ---- xx:FD92:  .byte $40   ; 
0x003DA3 ---- xx:FD93:  .byte $2E   ; 
0x003DA4 ---- xx:FD94:  .byte $40   ; 
0x003DA5 ---- xx:FD95:  .byte $2E   ; 
0x003DA6 ---- xx:FD96:  .byte $2E   ; 
0x003DA7 ---- xx:FD97:  .byte $2E   ; 
0x003DA8 ---- xx:FD98:  .byte $2E   ; 
0x003DA9 ---- xx:FD99:  .byte $2E   ; 
0x003DAA ---- xx:FD9A:  .byte $2E   ; 
0x003DAB ---- xx:FD9B:  .byte $40   ; 
0x003DAC ---- xx:FD9C:  .byte $2E   ; 
0x003DAD ---- xx:FD9D:  .byte $40   ; 
0x003DAE ---- xx:FD9E:  .byte $2E   ; 
0x003DAF ---- xx:FD9F:  .byte $2E   ; 
0x003DB0 ---- xx:FDA0:  .byte $40   ; 
0x003DB1 ---- xx:FDA1:  .byte $40   ; 
0x003DB2 ---- xx:FDA2:  .byte $2E   ; 
0x003DB3 ---- xx:FDA3:  .byte $2E   ; 
0x003DB4 ---- xx:FDA4:  .byte $2E   ; 
0x003DB5 ---- xx:FDA5:  .byte $40   ; 
0x003DB6 ---- xx:FDA6:  .byte $40   ; 
0x003DB7 ---- xx:FDA7:  .byte $2E   ; 
0x003DB8 ---- xx:FDA8:  .byte $2E   ; 
0x003DB9 ---- xx:FDA9:  .byte $40   ; 
0x003DBA ---- xx:FDAA:  .byte $40   ; 
0x003DBB ---- xx:FDAB:  .byte $2E   ; 
0x003DBC ---- xx:FDAC:  .byte $2E   ; 
0x003DBD ---- xx:FDAD:  .byte $2E   ; 
0x003DBE ---- xx:FDAE:  .byte $40   ; 
0x003DBF ---- xx:FDAF:  .byte $40   ; 
0x003DC0 ---- xx:FDB0:  .byte $2E   ; 
0x003DC1 ---- xx:FDB1:  .byte $2E   ; 
0x003DC2 ---- xx:FDB2:  .byte $2E   ; 
0x003DC3 ---- xx:FDB3:  .byte $2E   ; 
0x003DC4 ---- xx:FDB4:  .byte $2E   ; 
0x003DC5 ---- xx:FDB5:  .byte $2E   ; 
0x003DC6 ---- xx:FDB6:  .byte $2E   ; 
0x003DC7 ---- xx:FDB7:  .byte $2E   ; 
0x003DC8 ---- xx:FDB8:  .byte $2E   ; 
0x003DC9 ---- xx:FDB9:  .byte $2E   ; 
0x003DCA ---- xx:FDBA:  .byte $2E   ; 
0x003DCB ---- xx:FDBB:  .byte $2E   ; 
0x003DCC ---- xx:FDBC:  .byte $2E   ; 
0x003DCD ---- xx:FDBD:  .byte $2E   ; 
0x003DCE ---- xx:FDBE:  .byte $2E   ; 
0x003DCF ---- xx:FDBF:  .byte $2E   ; 
0x003DD0 ---- xx:FDC0:  .byte $2E   ; 
0x003DD1 ---- xx:FDC1:  .byte $2E   ; 
0x003DD2 ---- xx:FDC2:  .byte $2E   ; 
0x003DD3 ---- xx:FDC3:  .byte $2E   ; 
0x003DD4 ---- xx:FDC4:  .byte $2E   ; 
0x003DD5 ---- xx:FDC5:  .byte $40   ; 
0x003DD6 ---- xx:FDC6:  .byte $2E   ; 
0x003DD7 ---- xx:FDC7:  .byte $40   ; 
0x003DD8 ---- xx:FDC8:  .byte $40   ; 
0x003DD9 ---- xx:FDC9:  .byte $40   ; 
0x003DDA ---- xx:FDCA:  .byte $40   ; 
0x003DDB ---- xx:FDCB:  .byte $40   ; 
0x003DDC ---- xx:FDCC:  .byte $40   ; 
0x003DDD ---- xx:FDCD:  .byte $40   ; 
0x003DDE ---- xx:FDCE:  .byte $2E   ; 
0x003DDF ---- xx:FDCF:  .byte $2E   ; 
0x003DE0 ---- xx:FDD0:  .byte $2E   ; 
0x003DE1 ---- xx:FDD1:  .byte $2E   ; 
0x003DE2 ---- xx:FDD2:  .byte $2E   ; 
0x003DE3 ---- xx:FDD3:  .byte $2E   ; 
0x003DE4 ---- xx:FDD4:  .byte $40   ; 
0x003DE5 ---- xx:FDD5:  .byte $2E   ; 
0x003DE6 ---- xx:FDD6:  .byte $2E   ; 
0x003DE7 ---- xx:FDD7:  .byte $40   ; 
0x003DE8 ---- xx:FDD8:  .byte $2E   ; 
0x003DE9 ---- xx:FDD9:  .byte $2E   ; 
0x003DEA ---- xx:FDDA:  .byte $2E   ; 
0x003DEB ---- xx:FDDB:  .byte $2E   ; 
0x003DEC ---- xx:FDDC:  .byte $2E   ; 
0x003DED ---- xx:FDDD:  .byte $40   ; 
0x003DEE ---- xx:FDDE:  .byte $2E   ; 
0x003DEF ---- xx:FDDF:  .byte $2E   ; 
0x003DF0 ---- xx:FDE0:  .byte $2E   ; 
0x003DF1 ---- xx:FDE1:  .byte $2E   ; 
0x003DF2 ---- xx:FDE2:  .byte $2E   ; 
0x003DF3 ---- xx:FDE3:  .byte $40   ; 
0x003DF4 ---- xx:FDE4:  .byte $2E   ; 
0x003DF5 ---- xx:FDE5:  .byte $2E   ; 
0x003DF6 ---- xx:FDE6:  .byte $2E   ; 
0x003DF7 ---- xx:FDE7:  .byte $40   ; 
0x003DF8 ---- xx:FDE8:  .byte $40   ; 
0x003DF9 ---- xx:FDE9:  .byte $40   ; 
0x003DFA ---- xx:FDEA:  .byte $40   ; 
0x003DFB ---- xx:FDEB:  .byte $40   ; 
0x003DFC ---- xx:FDEC:  .byte $40   ; 
0x003DFD ---- xx:FDED:  .byte $40   ; 
0x003DFE ---- xx:FDEE:  .byte $2E   ; 
0x003DFF ---- xx:FDEF:  .byte $2E   ; 
0x003E00 ---- xx:FDF0:  .byte $2E   ; 
0x003E01 ---- xx:FDF1:  .byte $2E   ; 
0x003E02 ---- xx:FDF2:  .byte $40   ; 
0x003E03 ---- xx:FDF3:  .byte $2E   ; 
0x003E04 ---- xx:FDF4:  .byte $40   ; 
0x003E05 ---- xx:FDF5:  .byte $2E   ; 
0x003E06 ---- xx:FDF6:  .byte $2E   ; 
0x003E07 ---- xx:FDF7:  .byte $2E   ; 
0x003E08 ---- xx:FDF8:  .byte $2E   ; 
0x003E09 ---- xx:FDF9:  .byte $2E   ; 
0x003E0A ---- xx:FDFA:  .byte $40   ; 
0x003E0B ---- xx:FDFB:  .byte $2E   ; 
0x003E0C ---- xx:FDFC:  .byte $2E   ; 
0x003E0D ---- xx:FDFD:  .byte $2E   ; 
0x003E0E ---- xx:FDFE:  .byte $2E   ; 
0x003E0F ---- xx:FDFF:  .byte $2E   ; 
0x003E10 ---- xx:FE00:  .byte $2E   ; 
0x003E11 ---- xx:FE01:  .byte $40   ; 
0x003E12 ---- xx:FE02:  .byte $2E   ; 
0x003E13 ---- xx:FE03:  .byte $2E   ; 
0x003E14 ---- xx:FE04:  .byte $40   ; 
0x003E15 ---- xx:FE05:  .byte $2E   ; 
0x003E16 ---- xx:FE06:  .byte $40   ; 
0x003E17 ---- xx:FE07:  .byte $40   ; 
0x003E18 ---- xx:FE08:  .byte $40   ; 
0x003E19 ---- xx:FE09:  .byte $40   ; 
0x003E1A ---- xx:FE0A:  .byte $40   ; 
0x003E1B ---- xx:FE0B:  .byte $40   ; 
0x003E1C ---- xx:FE0C:  .byte $40   ; 
0x003E1D ---- xx:FE0D:  .byte $40   ; 
0x003E1E ---- xx:FE0E:  .byte $40   ; 
0x003E1F ---- xx:FE0F:  .byte $2E   ; 
0x003E20 ---- xx:FE10:  .byte $2E   ; 
0x003E21 ---- xx:FE11:  .byte $2E   ; 
0x003E22 ---- xx:FE12:  .byte $2E   ; 
0x003E23 ---- xx:FE13:  .byte $2E   ; 
0x003E24 ---- xx:FE14:  .byte $40   ; 
0x003E25 ---- xx:FE15:  .byte $2E   ; 
0x003E26 ---- xx:FE16:  .byte $2E   ; 
0x003E27 ---- xx:FE17:  .byte $2E   ; 
0x003E28 ---- xx:FE18:  .byte $40   ; 
0x003E29 ---- xx:FE19:  .byte $2E   ; 
0x003E2A ---- xx:FE1A:  .byte $40   ; 
0x003E2B ---- xx:FE1B:  .byte $2E   ; 
0x003E2C ---- xx:FE1C:  .byte $40   ; 
0x003E2D ---- xx:FE1D:  .byte $2E   ; 
0x003E2E ---- xx:FE1E:  .byte $2E   ; 
0x003E2F ---- xx:FE1F:  .byte $2E   ; 
0x003E30 ---- xx:FE20:  .byte $2E   ; 
0x003E31 ---- xx:FE21:  .byte $2E   ; 
0x003E32 ---- xx:FE22:  .byte $2E   ; 
0x003E33 ---- xx:FE23:  .byte $2E   ; 
0x003E34 ---- xx:FE24:  .byte $40   ; 
0x003E35 ---- xx:FE25:  .byte $2E   ; 
0x003E36 ---- xx:FE26:  .byte $2E   ; 
0x003E37 ---- xx:FE27:  .byte $40   ; 
0x003E38 ---- xx:FE28:  .byte $2E   ; 
0x003E39 ---- xx:FE29:  .byte $2E   ; 
0x003E3A ---- xx:FE2A:  .byte $40   ; 
0x003E3B ---- xx:FE2B:  .byte $2E   ; 
0x003E3C ---- xx:FE2C:  .byte $2E   ; 
0x003E3D ---- xx:FE2D:  .byte $40   ; 
0x003E3E ---- xx:FE2E:  .byte $2E   ; 
0x003E3F ---- xx:FE2F:  .byte $2E   ; 
0x003E40 ---- xx:FE30:  .byte $2E   ; 
0x003E41 ---- xx:FE31:  .byte $2E   ; 
0x003E42 ---- xx:FE32:  .byte $2E   ; 
0x003E43 ---- xx:FE33:  .byte $2E   ; 
0x003E44 ---- xx:FE34:  .byte $40   ; 
0x003E45 ---- xx:FE35:  .byte $2E   ; 
0x003E46 ---- xx:FE36:  .byte $40   ; 
0x003E47 ---- xx:FE37:  .byte $2E   ; 
0x003E48 ---- xx:FE38:  .byte $2E   ; 
0x003E49 ---- xx:FE39:  .byte $2E   ; 
0x003E4A ---- xx:FE3A:  .byte $40   ; 
0x003E4B ---- xx:FE3B:  .byte $2E   ; 
0x003E4C ---- xx:FE3C:  .byte $2E   ; 
0x003E4D ---- xx:FE3D:  .byte $2E   ; 
0x003E4E ---- xx:FE3E:  .byte $40   ; 
0x003E4F ---- xx:FE3F:  .byte $2E   ; 
0x003E50 ---- xx:FE40:  .byte $2E   ; 
0x003E51 ---- xx:FE41:  .byte $2E   ; 
0x003E52 ---- xx:FE42:  .byte $2E   ; 
0x003E53 ---- xx:FE43:  .byte $2E   ; 
0x003E54 ---- xx:FE44:  .byte $2E   ; 
0x003E55 ---- xx:FE45:  .byte $2E   ; 
0x003E56 ---- xx:FE46:  .byte $2E   ; 
0x003E57 ---- xx:FE47:  .byte $2E   ; 
0x003E58 ---- xx:FE48:  .byte $2E   ; 
0x003E59 ---- xx:FE49:  .byte $2E   ; 
0x003E5A ---- xx:FE4A:  .byte $2E   ; 
0x003E5B ---- xx:FE4B:  .byte $2E   ; 
0x003E5C ---- xx:FE4C:  .byte $2E   ; 
0x003E5D ---- xx:FE4D:  .byte $2E   ; 
0x003E5E ---- xx:FE4E:  .byte $2E   ; 
0x003E5F ---- xx:FE4F:  .byte $2E   ; 
0x003E60 ---- xx:FE50:  .byte $2E   ; 
0x003E61 ---- xx:FE51:  .byte $2E   ; 
0x003E62 ---- xx:FE52:  .byte $2E   ; 
0x003E63 ---- xx:FE53:  .byte $2E   ; 
0x003E64 ---- xx:FE54:  .byte $40   ; 
0x003E65 ---- xx:FE55:  .byte $2E   ; 
0x003E66 ---- xx:FE56:  .byte $2E   ; 
0x003E67 ---- xx:FE57:  .byte $2E   ; 
0x003E68 ---- xx:FE58:  .byte $2E   ; 
0x003E69 ---- xx:FE59:  .byte $2E   ; 
0x003E6A ---- xx:FE5A:  .byte $2E   ; 
0x003E6B ---- xx:FE5B:  .byte $2E   ; 
0x003E6C ---- xx:FE5C:  .byte $2E   ; 
0x003E6D ---- xx:FE5D:  .byte $2E   ; 
0x003E6E ---- xx:FE5E:  .byte $2E   ; 
0x003E6F ---- xx:FE5F:  .byte $2E   ; 
0x003E70 ---- xx:FE60:  .byte $40   ; 
0x003E71 ---- xx:FE61:  .byte $40   ; 
0x003E72 ---- xx:FE62:  .byte $40   ; 
0x003E73 ---- xx:FE63:  .byte $40   ; 
0x003E74 ---- xx:FE64:  .byte $40   ; 
0x003E75 ---- xx:FE65:  .byte $40   ; 
0x003E76 ---- xx:FE66:  .byte $40   ; 
0x003E77 ---- xx:FE67:  .byte $40   ; 
0x003E78 ---- xx:FE68:  .byte $2E   ; 
0x003E79 ---- xx:FE69:  .byte $40   ; 
0x003E7A ---- xx:FE6A:  .byte $40   ; 
0x003E7B ---- xx:FE6B:  .byte $40   ; 
0x003E7C ---- xx:FE6C:  .byte $40   ; 
0x003E7D ---- xx:FE6D:  .byte $40   ; 
0x003E7E ---- xx:FE6E:  .byte $40   ; 
0x003E7F ---- xx:FE6F:  .byte $40   ; 
0x003E80 ---- xx:FE70:  .byte $40   ; 
0x003E81 ---- xx:FE71:  .byte $2E   ; 
0x003E82 ---- xx:FE72:  .byte $2E   ; 
0x003E83 ---- xx:FE73:  .byte $2E   ; 
0x003E84 ---- xx:FE74:  .byte $2E   ; 
0x003E85 ---- xx:FE75:  .byte $2E   ; 
0x003E86 ---- xx:FE76:  .byte $2E   ; 
0x003E87 ---- xx:FE77:  .byte $40   ; 
0x003E88 ---- xx:FE78:  .byte $2E   ; 
0x003E89 ---- xx:FE79:  .byte $40   ; 
0x003E8A ---- xx:FE7A:  .byte $2E   ; 
0x003E8B ---- xx:FE7B:  .byte $2E   ; 
0x003E8C ---- xx:FE7C:  .byte $40   ; 
0x003E8D ---- xx:FE7D:  .byte $2E   ; 
0x003E8E ---- xx:FE7E:  .byte $2E   ; 
0x003E8F ---- xx:FE7F:  .byte $40   ; 
0x003E90 ---- xx:FE80:  .byte $2E   ; 
0x003E91 ---- xx:FE81:  .byte $40   ; 
0x003E92 ---- xx:FE82:  .byte $40   ; 
0x003E93 ---- xx:FE83:  .byte $40   ; 
0x003E94 ---- xx:FE84:  .byte $40   ; 
0x003E95 ---- xx:FE85:  .byte $40   ; 
0x003E96 ---- xx:FE86:  .byte $40   ; 
0x003E97 ---- xx:FE87:  .byte $2E   ; 
0x003E98 ---- xx:FE88:  .byte $2E   ; 
0x003E99 ---- xx:FE89:  .byte $40   ; 
0x003E9A ---- xx:FE8A:  .byte $2E   ; 
0x003E9B ---- xx:FE8B:  .byte $2E   ; 
0x003E9C ---- xx:FE8C:  .byte $40   ; 
0x003E9D ---- xx:FE8D:  .byte $2E   ; 
0x003E9E ---- xx:FE8E:  .byte $2E   ; 
0x003E9F ---- xx:FE8F:  .byte $40   ; 
0x003EA0 ---- xx:FE90:  .byte $2E   ; 
0x003EA1 ---- xx:FE91:  .byte $2E   ; 
0x003EA2 ---- xx:FE92:  .byte $2E   ; 
0x003EA3 ---- xx:FE93:  .byte $2E   ; 
0x003EA4 ---- xx:FE94:  .byte $40   ; 
0x003EA5 ---- xx:FE95:  .byte $2E   ; 
0x003EA6 ---- xx:FE96:  .byte $2E   ; 
0x003EA7 ---- xx:FE97:  .byte $2E   ; 
0x003EA8 ---- xx:FE98:  .byte $2E   ; 
0x003EA9 ---- xx:FE99:  .byte $40   ; 
0x003EAA ---- xx:FE9A:  .byte $40   ; 
0x003EAB ---- xx:FE9B:  .byte $40   ; 
0x003EAC ---- xx:FE9C:  .byte $40   ; 
0x003EAD ---- xx:FE9D:  .byte $40   ; 
0x003EAE ---- xx:FE9E:  .byte $40   ; 
0x003EAF ---- xx:FE9F:  .byte $40   ; 
0x003EB0 ---- xx:FEA0:  .byte $2E   ; 
0x003EB1 ---- xx:FEA1:  .byte $40   ; 
0x003EB2 ---- xx:FEA2:  .byte $40   ; 
0x003EB3 ---- xx:FEA3:  .byte $40   ; 
0x003EB4 ---- xx:FEA4:  .byte $40   ; 
0x003EB5 ---- xx:FEA5:  .byte $40   ; 
0x003EB6 ---- xx:FEA6:  .byte $40   ; 
0x003EB7 ---- xx:FEA7:  .byte $2E   ; 
0x003EB8 ---- xx:FEA8:  .byte $2E   ; 
0x003EB9 ---- xx:FEA9:  .byte $40   ; 
0x003EBA ---- xx:FEAA:  .byte $2E   ; 
0x003EBB ---- xx:FEAB:  .byte $2E   ; 
0x003EBC ---- xx:FEAC:  .byte $40   ; 
0x003EBD ---- xx:FEAD:  .byte $2E   ; 
0x003EBE ---- xx:FEAE:  .byte $2E   ; 
0x003EBF ---- xx:FEAF:  .byte $40   ; 
0x003EC0 ---- xx:FEB0:  .byte $2E   ; 
0x003EC1 ---- xx:FEB1:  .byte $2E   ; 
0x003EC2 ---- xx:FEB2:  .byte $2E   ; 
0x003EC3 ---- xx:FEB3:  .byte $2E   ; 
0x003EC4 ---- xx:FEB4:  .byte $40   ; 
0x003EC5 ---- xx:FEB5:  .byte $2E   ; 
0x003EC6 ---- xx:FEB6:  .byte $2E   ; 
0x003EC7 ---- xx:FEB7:  .byte $2E   ; 
0x003EC8 ---- xx:FEB8:  .byte $2E   ; 
0x003EC9 ---- xx:FEB9:  .byte $40   ; 
0x003ECA ---- xx:FEBA:  .byte $2E   ; 
0x003ECB ---- xx:FEBB:  .byte $2E   ; 
0x003ECC ---- xx:FEBC:  .byte $40   ; 
0x003ECD ---- xx:FEBD:  .byte $2E   ; 
0x003ECE ---- xx:FEBE:  .byte $2E   ; 
0x003ECF ---- xx:FEBF:  .byte $40   ; 
0x003ED0 ---- xx:FEC0:  .byte $2E   ; 
0x003ED1 ---- xx:FEC1:  .byte $2E   ; 
0x003ED2 ---- xx:FEC2:  .byte $40   ; 
0x003ED3 ---- xx:FEC3:  .byte $40   ; 
0x003ED4 ---- xx:FEC4:  .byte $40   ; 
0x003ED5 ---- xx:FEC5:  .byte $2E   ; 
0x003ED6 ---- xx:FEC6:  .byte $2E   ; 
0x003ED7 ---- xx:FEC7:  .byte $2E   ; 
0x003ED8 ---- xx:FEC8:  .byte $2E   ; 
0x003ED9 ---- xx:FEC9:  .byte $40   ; 
0x003EDA ---- xx:FECA:  .byte $40   ; 
0x003EDB ---- xx:FECB:  .byte $40   ; 
0x003EDC ---- xx:FECC:  .byte $40   ; 
0x003EDD ---- xx:FECD:  .byte $40   ; 
0x003EDE ---- xx:FECE:  .byte $40   ; 
0x003EDF ---- xx:FECF:  .byte $40   ; 
0x003EE0 ---- xx:FED0:  .byte $2E   ; 
0x003EE1 ---- xx:FED1:  .byte $2E   ; 
0x003EE2 ---- xx:FED2:  .byte $2E   ; 
0x003EE3 ---- xx:FED3:  .byte $2E   ; 
0x003EE4 ---- xx:FED4:  .byte $2E   ; 
0x003EE5 ---- xx:FED5:  .byte $2E   ; 
0x003EE6 ---- xx:FED6:  .byte $2E   ; 
0x003EE7 ---- xx:FED7:  .byte $2E   ; 
0x003EE8 ---- xx:FED8:  .byte $2E   ; 
0x003EE9 ---- xx:FED9:  .byte $2E   ; 
0x003EEA ---- xx:FEDA:  .byte $2E   ; 
0x003EEB ---- xx:FEDB:  .byte $2E   ; 
0x003EEC ---- xx:FEDC:  .byte $2E   ; 
0x003EED ---- xx:FEDD:  .byte $2E   ; 
0x003EEE ---- xx:FEDE:  .byte $2E   ; 
0x003EEF ---- xx:FEDF:  .byte $2E   ; 
0x003EF0 ---- xx:FEE0:  .byte $2E   ; 
0x003EF1 ---- xx:FEE1:  .byte $2E   ; 
0x003EF2 ---- xx:FEE2:  .byte $2E   ; 
0x003EF3 ---- xx:FEE3:  .byte $40   ; 
0x003EF4 ---- xx:FEE4:  .byte $2E   ; 
0x003EF5 ---- xx:FEE5:  .byte $2E   ; 
0x003EF6 ---- xx:FEE6:  .byte $2E   ; 
0x003EF7 ---- xx:FEE7:  .byte $2E   ; 
0x003EF8 ---- xx:FEE8:  .byte $2E   ; 
0x003EF9 ---- xx:FEE9:  .byte $2E   ; 
0x003EFA ---- xx:FEEA:  .byte $2E   ; 
0x003EFB ---- xx:FEEB:  .byte $2E   ; 
0x003EFC ---- xx:FEEC:  .byte $2E   ; 
0x003EFD ---- xx:FEED:  .byte $40   ; 
0x003EFE ---- xx:FEEE:  .byte $2E   ; 
0x003EFF ---- xx:FEEF:  .byte $2E   ; 
0x003F00 ---- xx:FEF0:  .byte $2E   ; 
0x003F01 ---- xx:FEF1:  .byte $2E   ; 
0x003F02 ---- xx:FEF2:  .byte $2E   ; 
0x003F03 ---- xx:FEF3:  .byte $40   ; 
0x003F04 ---- xx:FEF4:  .byte $2E   ; 
0x003F05 ---- xx:FEF5:  .byte $2E   ; 
0x003F06 ---- xx:FEF6:  .byte $2E   ; 
0x003F07 ---- xx:FEF7:  .byte $2E   ; 
0x003F08 ---- xx:FEF8:  .byte $40   ; 
0x003F09 ---- xx:FEF9:  .byte $2E   ; 
0x003F0A ---- xx:FEFA:  .byte $2E   ; 
0x003F0B ---- xx:FEFB:  .byte $2E   ; 
0x003F0C ---- xx:FEFC:  .byte $2E   ; 
0x003F0D ---- xx:FEFD:  .byte $40   ; 
0x003F0E ---- xx:FEFE:  .byte $2E   ; 
0x003F0F ---- xx:FEFF:  .byte $2E   ; 
0x003F10 ---- xx:FF00:  .byte $2E   ; 
0x003F11 ---- xx:FF01:  .byte $2E   ; 
0x003F12 ---- xx:FF02:  .byte $2E   ; 
0x003F13 ---- xx:FF03:  .byte $40   ; 
0x003F14 ---- xx:FF04:  .byte $2E   ; 
0x003F15 ---- xx:FF05:  .byte $2E   ; 
0x003F16 ---- xx:FF06:  .byte $2E   ; 
0x003F17 ---- xx:FF07:  .byte $2E   ; 
0x003F18 ---- xx:FF08:  .byte $40   ; 
0x003F19 ---- xx:FF09:  .byte $2E   ; 
0x003F1A ---- xx:FF0A:  .byte $2E   ; 
0x003F1B ---- xx:FF0B:  .byte $2E   ; 
0x003F1C ---- xx:FF0C:  .byte $2E   ; 
0x003F1D ---- xx:FF0D:  .byte $40   ; 
0x003F1E ---- xx:FF0E:  .byte $2E   ; 
0x003F1F ---- xx:FF0F:  .byte $2E   ; 
0x003F20 ---- xx:FF10:  .byte $2E   ; 
0x003F21 ---- xx:FF11:  .byte $2E   ; 
0x003F22 ---- xx:FF12:  .byte $2E   ; 
0x003F23 ---- xx:FF13:  .byte $40   ; 
0x003F24 ---- xx:FF14:  .byte $2E   ; 
0x003F25 ---- xx:FF15:  .byte $2E   ; 
0x003F26 ---- xx:FF16:  .byte $2E   ; 
0x003F27 ---- xx:FF17:  .byte $2E   ; 
0x003F28 ---- xx:FF18:  .byte $40   ; 
0x003F29 ---- xx:FF19:  .byte $2E   ; 
0x003F2A ---- xx:FF1A:  .byte $2E   ; 
0x003F2B ---- xx:FF1B:  .byte $2E   ; 
0x003F2C ---- xx:FF1C:  .byte $2E   ; 
0x003F2D ---- xx:FF1D:  .byte $40   ; 
0x003F2E ---- xx:FF1E:  .byte $2E   ; 
0x003F2F ---- xx:FF1F:  .byte $2E   ; 
0x003F30 ---- xx:FF20:  .byte $2E   ; 
0x003F31 ---- xx:FF21:  .byte $2E   ; 
0x003F32 ---- xx:FF22:  .byte $2E   ; 
0x003F33 ---- xx:FF23:  .byte $40   ; 
0x003F34 ---- xx:FF24:  .byte $2E   ; 
0x003F35 ---- xx:FF25:  .byte $2E   ; 
0x003F36 ---- xx:FF26:  .byte $2E   ; 
0x003F37 ---- xx:FF27:  .byte $2E   ; 
0x003F38 ---- xx:FF28:  .byte $40   ; 
0x003F39 ---- xx:FF29:  .byte $2E   ; 
0x003F3A ---- xx:FF2A:  .byte $2E   ; 
0x003F3B ---- xx:FF2B:  .byte $2E   ; 
0x003F3C ---- xx:FF2C:  .byte $2E   ; 
0x003F3D ---- xx:FF2D:  .byte $40   ; 
0x003F3E ---- xx:FF2E:  .byte $2E   ; 
0x003F3F ---- xx:FF2F:  .byte $2E   ; 
0x003F40 ---- xx:FF30:  .byte $2E   ; 
0x003F41 ---- xx:FF31:  .byte $2E   ; 
0x003F42 ---- xx:FF32:  .byte $40   ; 
0x003F43 ---- xx:FF33:  .byte $2E   ; 
0x003F44 ---- xx:FF34:  .byte $2E   ; 
0x003F45 ---- xx:FF35:  .byte $2E   ; 
0x003F46 ---- xx:FF36:  .byte $2E   ; 
0x003F47 ---- xx:FF37:  .byte $2E   ; 
0x003F48 ---- xx:FF38:  .byte $40   ; 
0x003F49 ---- xx:FF39:  .byte $2E   ; 
0x003F4A ---- xx:FF3A:  .byte $2E   ; 
0x003F4B ---- xx:FF3B:  .byte $2E   ; 
0x003F4C ---- xx:FF3C:  .byte $2E   ; 
0x003F4D ---- xx:FF3D:  .byte $40   ; 
0x003F4E ---- xx:FF3E:  .byte $2E   ; 
0x003F4F ---- xx:FF3F:  .byte $2E   ; 
0x003F50 ---- xx:FF40:  .byte $2E   ; 
0x003F51 ---- xx:FF41:  .byte $40   ; 
0x003F52 ---- xx:FF42:  .byte $2E   ; 
0x003F53 ---- xx:FF43:  .byte $2E   ; 
0x003F54 ---- xx:FF44:  .byte $2E   ; 
0x003F55 ---- xx:FF45:  .byte $2E   ; 
0x003F56 ---- xx:FF46:  .byte $2E   ; 
0x003F57 ---- xx:FF47:  .byte $2E   ; 
0x003F58 ---- xx:FF48:  .byte $2E   ; 
0x003F59 ---- xx:FF49:  .byte $2E   ; 
0x003F5A ---- xx:FF4A:  .byte $2E   ; 
0x003F5B ---- xx:FF4B:  .byte $40   ; 
0x003F5C ---- xx:FF4C:  .byte $40   ; 
0x003F5D ---- xx:FF4D:  .byte $40   ; 
0x003F5E ---- xx:FF4E:  .byte $2E   ; 
0x003F5F ---- xx:FF4F:  .byte $2E   ; 
0x003F60 ---- xx:FF50:  .byte $FF   ; 
0x003F61 ---- xx:FF51:  .byte $FF   ; 
0x003F62 ---- xx:FF52:  .byte $FF   ; 
0x003F63 ---- xx:FF53:  .byte $FF   ; 
0x003F64 ---- xx:FF54:  .byte $FF   ; 
0x003F65 ---- xx:FF55:  .byte $FF   ; 
0x003F66 ---- xx:FF56:  .byte $FF   ; 
0x003F67 ---- xx:FF57:  .byte $FF   ; 
0x003F68 ---- xx:FF58:  .byte $FF   ; 
0x003F69 ---- xx:FF59:  .byte $FF   ; 
0x003F6A ---- xx:FF5A:  .byte $FF   ; 
0x003F6B ---- xx:FF5B:  .byte $FF   ; 
0x003F6C ---- xx:FF5C:  .byte $FF   ; 
0x003F6D ---- xx:FF5D:  .byte $FF   ; 
0x003F6E ---- xx:FF5E:  .byte $FF   ; 
0x003F6F ---- xx:FF5F:  .byte $FF   ; 
0x003F70 ---- xx:FF60:  .byte $FF   ; 
0x003F71 ---- xx:FF61:  .byte $FF   ; 
0x003F72 ---- xx:FF62:  .byte $FF   ; 
0x003F73 ---- xx:FF63:  .byte $FF   ; 
0x003F74 ---- xx:FF64:  .byte $FF   ; 
0x003F75 ---- xx:FF65:  .byte $FF   ; 
0x003F76 ---- xx:FF66:  .byte $FF   ; 
0x003F77 ---- xx:FF67:  .byte $FF   ; 
0x003F78 ---- xx:FF68:  .byte $FF   ; 
0x003F79 ---- xx:FF69:  .byte $FF   ; 
0x003F7A ---- xx:FF6A:  .byte $FF   ; 
0x003F7B ---- xx:FF6B:  .byte $FF   ; 
0x003F7C ---- xx:FF6C:  .byte $FF   ; 
0x003F7D ---- xx:FF6D:  .byte $FF   ; 
0x003F7E ---- xx:FF6E:  .byte $FF   ; 
0x003F7F ---- xx:FF6F:  .byte $FF   ; 
0x003F80 ---- xx:FF70:  .byte $FF   ; 
0x003F81 ---- xx:FF71:  .byte $FF   ; 
0x003F82 ---- xx:FF72:  .byte $FF   ; 
0x003F83 ---- xx:FF73:  .byte $FF   ; 
0x003F84 ---- xx:FF74:  .byte $FF   ; 
0x003F85 ---- xx:FF75:  .byte $FF   ; 
0x003F86 ---- xx:FF76:  .byte $FF   ; 
0x003F87 ---- xx:FF77:  .byte $FF   ; 
0x003F88 ---- xx:FF78:  .byte $FF   ; 
0x003F89 ---- xx:FF79:  .byte $FF   ; 
0x003F8A ---- xx:FF7A:  .byte $FF   ; 
0x003F8B ---- xx:FF7B:  .byte $FF   ; 
0x003F8C ---- xx:FF7C:  .byte $FF   ; 
0x003F8D ---- xx:FF7D:  .byte $FF   ; 
0x003F8E ---- xx:FF7E:  .byte $FF   ; 
0x003F8F ---- xx:FF7F:  .byte $FF   ; 
0x003F90 ---- xx:FF80:  .byte $FF   ; 
0x003F91 ---- xx:FF81:  .byte $FF   ; 
0x003F92 ---- xx:FF82:  .byte $FF   ; 
0x003F93 ---- xx:FF83:  .byte $FF   ; 
0x003F94 ---- xx:FF84:  .byte $FF   ; 
0x003F95 ---- xx:FF85:  .byte $FF   ; 
0x003F96 ---- xx:FF86:  .byte $FF   ; 
0x003F97 ---- xx:FF87:  .byte $FF   ; 
0x003F98 ---- xx:FF88:  .byte $FF   ; 
0x003F99 ---- xx:FF89:  .byte $FF   ; 
0x003F9A ---- xx:FF8A:  .byte $FF   ; 
0x003F9B ---- xx:FF8B:  .byte $FF   ; 
0x003F9C ---- xx:FF8C:  .byte $FF   ; 
0x003F9D ---- xx:FF8D:  .byte $FF   ; 
0x003F9E ---- xx:FF8E:  .byte $FF   ; 
0x003F9F ---- xx:FF8F:  .byte $FF   ; 
0x003FA0 ---- xx:FF90:  .byte $FF   ; 
0x003FA1 ---- xx:FF91:  .byte $FF   ; 
0x003FA2 ---- xx:FF92:  .byte $FF   ; 
0x003FA3 ---- xx:FF93:  .byte $FF   ; 
0x003FA4 ---- xx:FF94:  .byte $FF   ; 
0x003FA5 ---- xx:FF95:  .byte $FF   ; 
0x003FA6 ---- xx:FF96:  .byte $FF   ; 
0x003FA7 ---- xx:FF97:  .byte $FF   ; 
0x003FA8 ---- xx:FF98:  .byte $FF   ; 
0x003FA9 ---- xx:FF99:  .byte $FF   ; 
0x003FAA ---- xx:FF9A:  .byte $FF   ; 
0x003FAB ---- xx:FF9B:  .byte $FF   ; 
0x003FAC ---- xx:FF9C:  .byte $FF   ; 
0x003FAD ---- xx:FF9D:  .byte $FF   ; 
0x003FAE ---- xx:FF9E:  .byte $FF   ; 
0x003FAF ---- xx:FF9F:  .byte $FF   ; 
0x003FB0 ---- xx:FFA0:  .byte $FF   ; 
0x003FB1 ---- xx:FFA1:  .byte $FF   ; 
0x003FB2 ---- xx:FFA2:  .byte $FF   ; 
0x003FB3 ---- xx:FFA3:  .byte $FF   ; 
0x003FB4 ---- xx:FFA4:  .byte $FF   ; 
0x003FB5 ---- xx:FFA5:  .byte $FF   ; 
0x003FB6 ---- xx:FFA6:  .byte $FF   ; 
0x003FB7 ---- xx:FFA7:  .byte $FF   ; 
0x003FB8 ---- xx:FFA8:  .byte $FF   ; 
0x003FB9 ---- xx:FFA9:  .byte $FF   ; 
0x003FBA ---- xx:FFAA:  .byte $FF   ; 
0x003FBB ---- xx:FFAB:  .byte $FF   ; 
0x003FBC ---- xx:FFAC:  .byte $FF   ; 
0x003FBD ---- xx:FFAD:  .byte $FF   ; 
0x003FBE ---- xx:FFAE:  .byte $FF   ; 
0x003FBF ---- xx:FFAF:  .byte $FF   ; 
0x003FC0 ---- xx:FFB0:  .byte $FF   ; 
0x003FC1 ---- xx:FFB1:  .byte $FF   ; 
0x003FC2 ---- xx:FFB2:  .byte $FF   ; 
0x003FC3 ---- xx:FFB3:  .byte $FF   ; 
0x003FC4 ---- xx:FFB4:  .byte $FF   ; 
0x003FC5 ---- xx:FFB5:  .byte $FF   ; 
0x003FC6 ---- xx:FFB6:  .byte $FF   ; 
0x003FC7 ---- xx:FFB7:  .byte $FF   ; 
0x003FC8 ---- xx:FFB8:  .byte $FF   ; 
0x003FC9 ---- xx:FFB9:  .byte $FF   ; 
0x003FCA ---- xx:FFBA:  .byte $FF   ; 
0x003FCB ---- xx:FFBB:  .byte $FF   ; 
0x003FCC ---- xx:FFBC:  .byte $FF   ; 
0x003FCD ---- xx:FFBD:  .byte $FF   ; 
0x003FCE ---- xx:FFBE:  .byte $FF   ; 
0x003FCF ---- xx:FFBF:  .byte $FF   ; 
0x003FD0 ---- xx:FFC0:  .byte $FF   ; 
0x003FD1 ---- xx:FFC1:  .byte $FF   ; 
0x003FD2 ---- xx:FFC2:  .byte $FF   ; 
0x003FD3 ---- xx:FFC3:  .byte $FF   ; 
0x003FD4 ---- xx:FFC4:  .byte $FF   ; 
0x003FD5 ---- xx:FFC5:  .byte $FF   ; 
0x003FD6 ---- xx:FFC6:  .byte $FF   ; 
0x003FD7 ---- xx:FFC7:  .byte $FF   ; 
0x003FD8 ---- xx:FFC8:  .byte $FF   ; 
0x003FD9 ---- xx:FFC9:  .byte $FF   ; 
0x003FDA ---- xx:FFCA:  .byte $FF   ; 
0x003FDB ---- xx:FFCB:  .byte $FF   ; 
0x003FDC ---- xx:FFCC:  .byte $FF   ; 
0x003FDD ---- xx:FFCD:  .byte $FF   ; 
0x003FDE ---- xx:FFCE:  .byte $FF   ; 
0x003FDF ---- xx:FFCF:  .byte $FF   ; 
0x003FE0 ---- xx:FFD0:  .byte $FF   ; 
0x003FE1 ---- xx:FFD1:  .byte $FF   ; 
0x003FE2 ---- xx:FFD2:  .byte $FF   ; 
0x003FE3 ---- xx:FFD3:  .byte $FF   ; 
0x003FE4 ---- xx:FFD4:  .byte $FF   ; 
0x003FE5 ---- xx:FFD5:  .byte $FF   ; 
0x003FE6 ---- xx:FFD6:  .byte $FF   ; 
0x003FE7 ---- xx:FFD7:  .byte $FF   ; 
0x003FE8 ---- xx:FFD8:  .byte $FF   ; 
0x003FE9 ---- xx:FFD9:  .byte $FF   ; 
0x003FEA ---- xx:FFDA:  .byte $FF   ; 
0x003FEB ---- xx:FFDB:  .byte $FF   ; 
0x003FEC ---- xx:FFDC:  .byte $FF   ; 
0x003FED ---- xx:FFDD:  .byte $FF   ; 
0x003FEE ---- xx:FFDE:  .byte $FF   ; 
0x003FEF ---- xx:FFDF:  .byte $FF   ; 
0x003FF0 ---- xx:FFE0:  .byte $FF   ; 
0x003FF1 ---- xx:FFE1:  .byte $FF   ; 
0x003FF2 ---- xx:FFE2:  .byte $FF   ; 
0x003FF3 ---- xx:FFE3:  .byte $FF   ; 
0x003FF4 ---- xx:FFE4:  .byte $FF   ; 
0x003FF5 ---- xx:FFE5:  .byte $FF   ; 
0x003FF6 ---- xx:FFE6:  .byte $FF   ; 
0x003FF7 ---- xx:FFE7:  .byte $FF   ; 
0x003FF8 ---- xx:FFE8:  .byte $FF   ; 
0x003FF9 ---- xx:FFE9:  .byte $FF   ; 
0x003FFA ---- xx:FFEA:  .byte $FF   ; 
0x003FFB ---- xx:FFEB:  .byte $FF   ; 
0x003FFC ---- xx:FFEC:  .byte $FF   ; 
0x003FFD ---- xx:FFED:  .byte $FF   ; 
0x003FFE ---- xx:FFEE:  .byte $FF   ; 
0x003FFF ---- xx:FFEF:  .byte $FF   ; 
0x004000 ---- xx:FFF0:  .byte $FF   ; 
0x004001 ---- xx:FFF1:  .byte $FF   ; 
0x004002 ---- xx:FFF2:  .byte $FF   ; 
0x004003 ---- xx:FFF3:  .byte $FF   ; 
0x004004 ---- xx:FFF4:  .byte $FF   ; 
0x004005 ---- xx:FFF5:  .byte $FF   ; 
0x004006 ---- xx:FFF6:  .byte $FF   ; 
0x004007 ---- xx:FFF7:  .byte $FF   ; 
0x004008 ---- xx:FFF8:  .byte $FF   ; 
0x004009 ---- xx:FFF9:  .byte $FF   ; 
0x00400A ---- xx:FFFA:  .byte $00   ; 
0x00400B ---- xx:FFFB:  .byte $D4   ; 
0x00400C ---- xx:FFFC:  .byte $70   ; 
0x00400D ---- xx:FFFD:  .byte $C0   ; 
0x00400E ---- xx:FFFE:  .byte $70   ; 
0x00400F ---- xx:FFFF:  .byte $C0   ; 
