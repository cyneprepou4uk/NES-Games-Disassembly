# Dr. Mario (NES) Disassembly
This is a disassembly of Dr. Mario for the Nintendo Entertainment System.

It builds Dr. Mario (Japan, USA) (Rev A).nes using ASM6f (https://github.com/freem/asm6f).

Thanks to Sour, author of the excellent NES emulator Mesen (https://www.mesen.ca/), which debug options were vital to this project.

Also, thanks to all contributors of the Dr.Mario articles at Data Crystal (https://datacrystal.romhacking.net/wiki/Dr._Mario) and The Cutting Room Floor (https://tcrf.net/Dr._Mario_(NES)).